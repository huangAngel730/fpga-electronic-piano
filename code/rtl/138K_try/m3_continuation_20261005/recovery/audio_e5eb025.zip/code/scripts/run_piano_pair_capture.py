#!/usr/bin/env python3
"""T024 real-core PCM spectral and velocity validation; no production RTL rewrite."""
from pathlib import Path
import subprocess
import sys
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--piano',action='store_true');args=parser.parse_args()
root=Path(__file__).resolve().parents[2];stage=root/'code/output/v1_formal_integration_20261001'/('pair_piano' if args.piano else 'pair_sine');stage.mkdir(parents=True,exist_ok=True)
source=root/'code/rtl/audio/voice_allocator_4.sv';net=stage/'allocator.v';ys=stage/'lower.ys'
ys.write_text('read_slang --top voice_allocator_4 '+source.as_posix()+'\nproc\nopt\ntechmap\nopt\nwrite_verilog -noattr '+net.as_posix()+'\n',encoding='ascii')
cad=Path('D:/Gowin/oss-cad-suite');q=lambda p:'"'+str(p)+'"'
commands=[q(cad/'bin/yosys.exe')+' -Q -T -s '+q(ys),q(cad/'bin/iverilog.exe')+' -g2012 -I '+q(root/'code/rtl/board')+' -s tb_piano_pair_capture -P tb_piano_pair_capture.PIANO_TIMBRE_ENABLE='+str(int(args.piano))+' -o '+q(stage/'tb.vvp')+' '+' '.join(map(q,[root/'code/rtl/common/audio_defs_pkg.sv',net,root/'code/rtl/common/note_pitch.sv',root/'code/rtl/board/sustain_control_contract_pkg.sv',root/'code/rtl/input/sustain_control/sustain_controller.sv',root/'code/rtl/board/polyphonic_event_router.sv',root/'code/rtl/board/polyphonic_envelope_bank.sv',root/'code/rtl/audio/dds_oscillator.sv',root/'code/rtl/audio/piano_dds_oscillator.sv',root/'code/rtl/audio/adsr_piano_envelope.sv',root/'code/rtl/board/polyphonic_pcm_commit.sv',root/'code/rtl/mixer/pcm_mixer_4voice.sv',root/'code/rtl/audio_out/pcm_result_hold.sv',root/'code/rtl/audio_out/pcm_frame_buffer.sv',root/'code/rtl/common/pcm_clip_counter.sv',root/'code/rtl/common/system_status_counters.sv',root/'code/rtl/board/voice_gain_q15_candidate.sv',root/'code/rtl/board/polyphonic_audio_core.sv',root/'code/tb/board/tb_piano_pair_capture.sv'])),q(cad/'bin/vvp.exe')+' '+q(stage/'tb.vvp')+' '+q('+VELOCITY_ROM_PATH='+str(root/'code/model/generated/wavetables/velocity_gain_rom.mem'))+' '+q('+WAVETABLE_PATH='+str(root/'code/model/generated/wavetables'/('piano_band_4x256_8191.mem' if args.piano else 'sine_1024_8192.mem')))+' '+q('+CAPTURE='+str(stage/'audio.capture'))]
bat=stage/'run.bat';bat.write_text('@echo off\r\ncall '+q(cad/'environment.bat')+' >nul\r\n'+'\r\nif errorlevel 1 exit /b 1\r\n'.join(commands)+'\r\nexit /b %errorlevel%\r\n',encoding='ascii')
p=subprocess.run(['cmd.exe','/c',str(bat)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180,cwd=stage)
(stage/'run.log').write_text(p.stdout+p.stderr,encoding='utf-8');
for line in (p.stdout+p.stderr).splitlines():
    if 'PASS piano_pair_capture' in line or 'FATAL' in line or 'error:' in line:print(line)
print('Full log:',stage/'run.log')
if p.returncode or 'PASS piano_pair_capture' not in p.stdout:raise SystemExit(p.returncode or 1)
raise SystemExit(0)
