# N32-A 平衡分配器独立后继

2026-10-14，M3／主对话2。原任务为 N32 独立候选 A；当前内容为新 RTL、逐沿独立参考、向量和有界执行计划。状态与实际结果以后置收据及同版审核汇总为准，不预写仿真、综合或时序通过。

## 基线与接口

工作基线 `0b5f45388f974ce4ae0a2081eac7add93181c32a`。任务单引用的临时生成路径 `code/build/138k_polyphony_resource/prepared/N32_R1_20261011_01/sources/b2c_voice_allocator.sv` 本机不存在；仓库持久路径 `code/rtl/common/polyphony_scaling_candidate/b2c_voice_allocator.sv` 实际 SHA256 为 `9fec9f838a9ef333d01d1b79ecf77d137e41bc0c5e78a40d2820c37739506061`，逐字节身份与冻结基线相同。prepare 从该持久原件复制精确字节，实际执行只读本轮 capsule，不修改或补写旧生成目录。

新模块 `code/rtl/common/m3_n32_allocator_candidate_20261013/m3_balanced_voice_allocator.sv`，名称 `m3_balanced_voice_allocator`，参数 `N=8, SW=$clog2(N)`；本任务支持 N4/N8/N16/N32。原输入 `sys_clk/sys_rst_n/note_on/note_off/source_id/channel_id/midi_note/release_done` 及四公开输出、拍数、槽打包格式保持。单时钟，低有效异步复位；槽宽为 `18+SW`。

已阅读父目录硬件索引、BOARD_CONTEXT 和项目协作规范。本任务是无引脚的隔离数字模块，仿真时钟由 TB 提供，不增加物理时钟、不改正式时钟/复位/端口/约束，也不使用资料中尚待确认的外设电气参数。

## 结构与沿语义

- 每槽并行计算身份匹配、IDLE、旧年龄与槽号；平衡树按“身份匹配 → IDLE → LRU”归约。
- 匹配与 IDLE 选最小槽号；LRU 选最小年龄，同龄选最小槽号；同时传递被选旧年龄。
- 年龄与目标字段按槽并行写回；不存在选择目标后动态索引年龄的反馈串链。
- release_done、note_on、note_off 按原顺序覆盖相关字段，所有条件读取沿前状态。同沿完成释放不立即变为 IDLE 候选。
- NoteOff 对全部旧 active 身份匹配槽生效，公开 release_slot 取最大匹配槽；无事件时两个 slot 输出保持。
- N32 选择归约深度五层是源码结构说明；综合资源、PnR 和 40 MHz STA 尚未执行。

## 独立参考与覆盖

`reference.py` 以 Python 候选集合/min 规则和旧状态副本计算下一状态，与 RTL 平衡树结构独立。比较所有四公开输出和全部 packed 槽字段；期望由输入重算，向量内 expected 也核对，拒布尔冒整数、缺行/多行/字段或槽数不符。

`vectors.py` 固定 seed `0x3261`，每 N 含 1024 随机沿和定向填满/窃取/身份隔离/Release/重触发/复位。五个明确 `INJECT_` 旧状态专项用于多匹配和同龄等转移边界，独立注明不声称自然事件可达；正常随机链在注入后复位。

软件单测不代替实际 RTL 变异。计划中的两项行为变异将生成隔离副本：交换身份/IDLE 优先级、反转低槽 tie-break；必须真实编译和仿真后由独立 checker 指定拒收。

## 执行与审核

先 prepare 绑定源码、参考、向量、TB、Python/Icarus/VVP 及实际依赖静态 SHA、完整命令、次数与预算；同版不可变快照分别送审核员/预审员。按 N32 固定自检授权，计划核对通过后各步骤一次执行；单工具不超过300秒，runner全流程不超过900秒，包括后验和收尾。输出独占、私有进程树、失败立即停止并保留历史；不自动重试、换工具或加限。

PLAN 和 RESULT 使用不同 Review-Key。计划通过不冒充实际结果，结果变化必须升版。原声数学、旧专项、T052/T060 capture、Gowin、设备操作均不属于 A 的执行。

R02/B-001 最小返修：`plan.capsule_files` 绑定实际编译源、TB、向量、checker/reference 及 runner/helper 的私有副本；原路径只作 provenance。前后身份核对、封存和实际命令均指 capsule，拒额外文件和 shadow import。新增单个软件反例在临时 live 副本改动并恢复原 allocator/checker/helper，证明实际参数仍只读冻结副本；不重跑已签 15/7 软件组，也不把此软件检查写成 RTL 结果。

R03/B-002/B-003 后继：child cwd 在计划、verify 和 launcher 三处唯一固定为 capsule。单个软件 guard 在临时 live 的 worker/reference/vectors/helper 被破坏期间，由全新 `-I/-S/-B` Python 沿固定 SHA bootstrap 进入同一冻结 worker 的 `import-verify` 分支，实际加载六模块并记录、核对各自 `__file__` 和 SHA。该分支不进入 execute、不调用 HDL、也不创建 actual receipt；旧静态 guard 证据只保留为历史，不扩大成实际加载链证明。

启动时从审核过的 capsule 读取 `a_launch.py` 原字节，外部核 SHA 后 compile/exec。launcher 仅用标准库核 plan/纯标准库 bootstrap 的固定 SHA 和完整 capsule；随后载入 capsule 中原字节 supervisor。子进程按 `plan.launch.argv_prefix + [精确 plan SHA]` 调用 bootstrap，bootstrap 在同进程进入冻结 worker。parent budget 从 launcher 首次验证之前计起，整个子树仍只有 900 秒总上限；每个实际 HDL 工具上限 300 秒。父进程记录真实 child PID/退出码/日志/收据身份及 completion，失败不重试。父级输出是独立全新目录，不与实际证据目录嵌套。所有路径、SHA、命令在 PLAN 中冻结；最终 RESULT 另附这次实际父级观察，不沿用 PLAN 的 NOT_RUN。

## 并行所有权

主对话2及子智能体仅写 A 的 allocator 与本软件目录；主对话4写 B 专有 wrapper/TB，主对话3写 C 压力软件和 C 专有 TB。B 实际验证等待 A 同版通过，C 等 B 通过。共享看板与当前状态由 M2 维护。阶段成果最终统一交 M2 复核。
