# T061-N32-A-PLAN-R04 修复映射

2026-10-14，M3／主对话2。R03/Q-0003 两阻断均仅作关联增量修复。

- B-002 → prepare将launch.cwd固定为capsule；verify断言一致；launcher读取该字段、验证等于capsule后传给observe_run。机器、工具、业务RTL、向量、18步及预算不变。
- B-003 → bootstrap新增显式纯软件import-verify分支，仍沿相同SHA检查和runpy进入真实冻结worker；worker实际导入reference/vectors/runner_tail/runner/windows_job，记录并核查worker及五依赖实际__file__/SHA。该分支不调用execute/HDL且不生成actual receipt。

新增一次守卫06：临时live副本保留破坏期间，全新隔离Python实际沿plan.launch.argv_prefix与固定bootstrap SHA启动，child实际退出0，六模块位置均在capsule且SHA匹配，随后恢复临时原件。父级1项OK、退出0、1.750秒，原stdout完整保留软件child PID/argv/cwd/实际导入结果，stderr及收据齐套。没有重跑旧15/7组，没有运行HDL或EDA。

旧R03、guard04导入失败和guard05仅静态检查的历史均保留，不覆写或回填。06也仅证明软件隔离加载链，不冒充分配器实际仿真。最终新plan10，实际输出仍不存在；双审R04汇总PASS后才按18步各一次执行。
