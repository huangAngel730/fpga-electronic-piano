`timescale 1ns/1ps
module tb_allocator;
localparam integer N=32, SW=$clog2(N);
reg sys_clk=0, sys_rst_n=1, note_on=0, note_off=0;
reg [3:0] source_id=0, channel_id=0;
reg [7:0] midi_note=0;
reg [N-1:0] release_done=0;
wire [SW-1:0] oa, orl, ca, crl;
wire ov, orv, cv, crv;
integer fo, fc, j;
always #5 sys_clk=~sys_clk;
b2c_voice_allocator #(.N(N)) original(sys_clk,sys_rst_n,note_on,note_off,
source_id,channel_id,midi_note,release_done,oa,ov,orl,orv);
m3_balanced_voice_allocator #(.N(N)) candidate(sys_clk,sys_rst_n,note_on,note_off,
source_id,channel_id,midi_note,release_done,ca,cv,crl,crv);
task observe(input integer idx);
begin
$fwrite(fo,"{\"index\":%0d,\"outputs\":{\"allocated_slot\":%0d,\"slot_valid\":%0d,\"release_slot\":%0d,\"release_target_valid\":%0d},\"slots\":[",idx,oa,ov,orl,orv);
$fwrite(fc,"{\"index\":%0d,\"outputs\":{\"allocated_slot\":%0d,\"slot_valid\":%0d,\"release_slot\":%0d,\"release_target_valid\":%0d},\"slots\":[",idx,ca,cv,crl,crv);
for(j=0;j<N;j=j+1)begin
if(j>0)begin $fwrite(fo,","); $fwrite(fc,",");end
$fwrite(fo,"%0d",original.slots[j]); $fwrite(fc,"%0d",candidate.slots[j]);
end
$fwrite(fo,"]}\n"); $fwrite(fc,"]}\n");
end endtask
initial begin
fo=$fopen("original.jsonl","w"); fc=$fopen("candidate.jsonl","w");
if(!fo || !fc)$fatal(1,"CAPTURE_OPEN");

@(negedge sys_clk);
sys_rst_n=0;
note_on=1;
note_off=1;
source_id=15;
channel_id=15;
midi_note=255;
release_done=4294967295;
@(posedge sys_clk); #1; observe(0);
@(negedge sys_clk);
// Verification-only arbitrary old state; not natural reachability.
original.slots[0]=23'd0; candidate.slots[0]=23'd0;
original.slots[1]=23'd1; candidate.slots[1]=23'd1;
original.slots[2]=23'd2; candidate.slots[2]=23'd2;
original.slots[3]=23'd3; candidate.slots[3]=23'd3;
original.slots[4]=23'd4; candidate.slots[4]=23'd4;
original.slots[5]=23'd5; candidate.slots[5]=23'd5;
original.slots[6]=23'd6; candidate.slots[6]=23'd6;
original.slots[7]=23'd7; candidate.slots[7]=23'd7;
original.slots[8]=23'd8; candidate.slots[8]=23'd8;
original.slots[9]=23'd9; candidate.slots[9]=23'd9;
original.slots[10]=23'd10; candidate.slots[10]=23'd10;
original.slots[11]=23'd11; candidate.slots[11]=23'd11;
original.slots[12]=23'd12; candidate.slots[12]=23'd12;
original.slots[13]=23'd13; candidate.slots[13]=23'd13;
original.slots[14]=23'd14; candidate.slots[14]=23'd14;
original.slots[15]=23'd15; candidate.slots[15]=23'd15;
original.slots[16]=23'd16; candidate.slots[16]=23'd16;
original.slots[17]=23'd17; candidate.slots[17]=23'd17;
original.slots[18]=23'd18; candidate.slots[18]=23'd18;
original.slots[19]=23'd19; candidate.slots[19]=23'd19;
original.slots[20]=23'd20; candidate.slots[20]=23'd20;
original.slots[21]=23'd21; candidate.slots[21]=23'd21;
original.slots[22]=23'd22; candidate.slots[22]=23'd22;
original.slots[23]=23'd23; candidate.slots[23]=23'd23;
original.slots[24]=23'd24; candidate.slots[24]=23'd24;
original.slots[25]=23'd25; candidate.slots[25]=23'd25;
original.slots[26]=23'd26; candidate.slots[26]=23'd26;
original.slots[27]=23'd27; candidate.slots[27]=23'd27;
original.slots[28]=23'd28; candidate.slots[28]=23'd28;
original.slots[29]=23'd29; candidate.slots[29]=23'd29;
original.slots[30]=23'd30; candidate.slots[30]=23'd30;
original.slots[31]=23'd2517855; candidate.slots[31]=23'd2517855;
sys_rst_n=1;
note_on=1;
note_off=0;
source_id=3;
channel_id=3;
midi_note=90;
release_done=0;
@(posedge sys_clk); #1; observe(1);
$fclose(fo);$fclose(fc);$display("ALLOCATOR_CAPTURE_COMPLETE");$finish;
end
endmodule
