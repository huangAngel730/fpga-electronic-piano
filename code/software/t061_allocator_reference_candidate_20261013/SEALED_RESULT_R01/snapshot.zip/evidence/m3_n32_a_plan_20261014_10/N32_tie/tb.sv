`timescale 1ns/1ps
module tb_allocator;
localparam integer N=32, SW=$clog2(N);
reg sys_clk=0, sys_rst_n=1, note_on=0, note_off=0;
reg [3:0] source_id=0, channel_id=0;
reg [7:0] midi_note=0;
reg [N-1:0] release_done=0;
wire [SW-1:0] oa, orl, ca, crl;
wire ov, orv, cv, crv;
integer fo, fc, j;
always #5 sys_clk=~sys_clk;
b2c_voice_allocator #(.N(N)) original(sys_clk,sys_rst_n,note_on,note_off,
source_id,channel_id,midi_note,release_done,oa,ov,orl,orv);
m3_balanced_voice_allocator #(.N(N)) candidate(sys_clk,sys_rst_n,note_on,note_off,
source_id,channel_id,midi_note,release_done,ca,cv,crl,crv);
task observe(input integer idx);
begin
$fwrite(fo,"{\"index\":%0d,\"outputs\":{\"allocated_slot\":%0d,\"slot_valid\":%0d,\"release_slot\":%0d,\"release_target_valid\":%0d},\"slots\":[",idx,oa,ov,orl,orv);
$fwrite(fc,"{\"index\":%0d,\"outputs\":{\"allocated_slot\":%0d,\"slot_valid\":%0d,\"release_slot\":%0d,\"release_target_valid\":%0d},\"slots\":[",idx,ca,cv,crl,crv);
for(j=0;j<N;j=j+1)begin
if(j>0)begin $fwrite(fo,","); $fwrite(fc,",");end
$fwrite(fo,"%0d",original.slots[j]); $fwrite(fc,"%0d",candidate.slots[j]);
end
$fwrite(fo,"]}\n"); $fwrite(fc,"]}\n");
end endtask
initial begin
fo=$fopen("original.jsonl","w"); fc=$fopen("candidate.jsonl","w");
if(!fo || !fc)$fatal(1,"CAPTURE_OPEN");

@(negedge sys_clk);
sys_rst_n=0;
note_on=1;
note_off=1;
source_id=15;
channel_id=15;
midi_note=255;
release_done=4294967295;
@(posedge sys_clk); #1; observe(0);
@(negedge sys_clk);
// Verification-only arbitrary old state; not natural reachability.
original.slots[0]=23'd4472863; candidate.slots[0]=23'd4472863;
original.slots[1]=23'd4472864; candidate.slots[1]=23'd4472864;
original.slots[2]=23'd4472927; candidate.slots[2]=23'd4472927;
original.slots[3]=23'd4472959; candidate.slots[3]=23'd4472959;
original.slots[4]=23'd4472991; candidate.slots[4]=23'd4472991;
original.slots[5]=23'd4473023; candidate.slots[5]=23'd4473023;
original.slots[6]=23'd4473055; candidate.slots[6]=23'd4473055;
original.slots[7]=23'd4473087; candidate.slots[7]=23'd4473087;
original.slots[8]=23'd4473119; candidate.slots[8]=23'd4473119;
original.slots[9]=23'd4473151; candidate.slots[9]=23'd4473151;
original.slots[10]=23'd4473183; candidate.slots[10]=23'd4473183;
original.slots[11]=23'd4473215; candidate.slots[11]=23'd4473215;
original.slots[12]=23'd4473247; candidate.slots[12]=23'd4473247;
original.slots[13]=23'd4473279; candidate.slots[13]=23'd4473279;
original.slots[14]=23'd4473311; candidate.slots[14]=23'd4473311;
original.slots[15]=23'd4473343; candidate.slots[15]=23'd4473343;
original.slots[16]=23'd4473375; candidate.slots[16]=23'd4473375;
original.slots[17]=23'd4473407; candidate.slots[17]=23'd4473407;
original.slots[18]=23'd4473439; candidate.slots[18]=23'd4473439;
original.slots[19]=23'd4473471; candidate.slots[19]=23'd4473471;
original.slots[20]=23'd4473503; candidate.slots[20]=23'd4473503;
original.slots[21]=23'd4473535; candidate.slots[21]=23'd4473535;
original.slots[22]=23'd4473567; candidate.slots[22]=23'd4473567;
original.slots[23]=23'd4473599; candidate.slots[23]=23'd4473599;
original.slots[24]=23'd4473631; candidate.slots[24]=23'd4473631;
original.slots[25]=23'd4473663; candidate.slots[25]=23'd4473663;
original.slots[26]=23'd4473695; candidate.slots[26]=23'd4473695;
original.slots[27]=23'd4473727; candidate.slots[27]=23'd4473727;
original.slots[28]=23'd4473759; candidate.slots[28]=23'd4473759;
original.slots[29]=23'd4473791; candidate.slots[29]=23'd4473791;
original.slots[30]=23'd4473823; candidate.slots[30]=23'd4473823;
original.slots[31]=23'd4473824; candidate.slots[31]=23'd4473824;
sys_rst_n=1;
note_on=1;
note_off=0;
source_id=8;
channel_id=8;
midi_note=240;
release_done=0;
@(posedge sys_clk); #1; observe(1);
$fclose(fo);$fclose(fc);$display("ALLOCATOR_CAPTURE_COMPLETE");$finish;
end
endmodule
