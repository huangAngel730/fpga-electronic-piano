"""Freeze a new, immutable N32-A PLAN or RESULT snapshot for both reviewers."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import a_harness


def digest(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
            + "\n").encode("utf-8")


def binary_diff(paths):
    """Git's binary-safe patch, including every new input absent from base."""
    base = "0b5f45388f974ce4ae0a2081eac7add93181c32a"
    git = shutil.which("git")
    a_harness.require(git is not None, "GIT_MISSING")
    patches = []
    for path in sorted(set(paths)):
        relative = Path(path).resolve().relative_to(a_harness.ROOT).as_posix()
        exists = subprocess.run([git, "cat-file", "-e", base + ":" + relative],
                                cwd=a_harness.ROOT, capture_output=True, timeout=10)
        a_harness.require(exists.returncode in (0, 128), "BASE_LOOKUP_FAILED")
        argv = ([git, "diff", "--binary", base, "--", relative]
                if exists.returncode == 0 else
                [git, "diff", "--no-index", "--binary", "--", "/dev/null", relative])
        result = subprocess.run(argv, cwd=a_harness.ROOT,
                                capture_output=True, timeout=10)
        a_harness.require(result.returncode in (0, 1), "DIFF_FAILED:" + relative)
        patches.append(result.stdout)
    return b"".join(patches), {"path": git, **a_harness.identity(git)}


def seal(plan_path, target, review_key, evidence):
    target = Path(target).resolve()
    a_harness.require(target.is_relative_to(HERE) and target != HERE,
                      "DELIVERY_OUTSIDE_A_WRITESET")
    a_harness.require(not target.exists(), "DELIVERY_EXISTS")
    plan_path = Path(plan_path).resolve()
    plan = a_harness.verify(plan_path)
    members = {}
    capsule = Path(plan["capsule_root"])
    frozen_inputs = {item["source_provenance"]: capsule / relative
                     for relative, item in plan["capsule_files"].items()}
    for path, expected in plan["inputs"].items():
        source = Path(path)
        raw = frozen_inputs[path].read_bytes()
        a_harness.require(digest(raw) == expected, "SEAL_INPUT_DRIFT:" + path)
        members["files/" + source.relative_to(a_harness.ROOT).as_posix()] = raw
    members["plan.json"] = plan_path.read_bytes()
    members["README_A.md"] = (HERE / "README_A.md").read_bytes()
    for root in evidence:
        root = a_harness.under_output(root)
        for source in sorted(root.rglob("*")):
            if source.is_file() and source.suffix not in (".vvp", ".pyc"):
                members["evidence/" + root.name + "/" +
                        source.relative_to(root).as_posix()] = source.read_bytes()
    patch_paths = [Path(path) for path in plan["inputs"]]
    patch_paths.extend((plan_path, HERE / "README_A.md"))
    for root in evidence:
        patch_paths.extend(path for path in Path(root).rglob("*")
                           if path.is_file() and path.suffix not in (".vvp", ".pyc"))
    # Git diff reads paths; it may not silently represent different live bytes.
    # Execution evidence and archived source themselves come from the capsule.
    for path, expected in plan["inputs"].items():
        a_harness.require(a_harness.identity(path) == expected,
                          "PATCH_PROVENANCE_DRIFT:" + path)
    members["changes.patch"], diff_tool = binary_diff(patch_paths)
    manifest = {
        "review_key": review_key,
        "base": "0b5f45388f974ce4ae0a2081eac7add93181c32a",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "generator": "M3 / main-dialogue-2 / a_delivery.py",
        "diff_tool": diff_tool,
        "diff_scope": "All plan inputs, plan, README and archived evidence; existing unchanged base inputs have empty diffs.",
        "state": "SEALED-UNCOMMITTED", "plan": digest(members["plan.json"]),
        "files": {name: digest(raw) for name, raw in sorted(members.items())},
        "evidence_roots": [str(Path(p).resolve()) for p in evidence],
        "permission": "Existing bounded N32-A selftest only; no T052/T060/EDA/devices",
    }
    manifest_raw = encode(manifest)
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as bundle:
        for name, raw in sorted(members.items()):
            bundle.writestr(name, raw)
        bundle.writestr("MANIFEST.json", manifest_raw)
    archive = stream.getvalue()
    # All bytes are determined before exclusive target creation.
    target.mkdir(parents=True, exist_ok=False)
    (target / "snapshot.zip.b64").write_bytes(base64.b64encode(archive) + b"\n")
    (target / "MANIFEST.json").write_bytes(manifest_raw)
    receipt = {"review_key": review_key, "snapshot": digest(archive),
               "scope": digest(manifest_raw), "plan": digest(members["plan.json"]),
               "members": len(members) + 1, "state": "SEALED-UNCOMMITTED"}
    (target / "seal.json").write_bytes(encode(receipt))
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--review-key", required=True)
    parser.add_argument("--evidence", type=Path, action="append", default=[])
    args = parser.parse_args()
    print(json.dumps(seal(args.plan, args.target, args.review_key, args.evidence)))
