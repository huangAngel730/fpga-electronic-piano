# N32-A 实际执行失败交接

2026-10-14，M3／主对话2。当前 **FAIL_PARTIAL**，不是 A 通过。

## 精确身份与执行

- 源基线：`0b5f45388f974ce4ae0a2081eac7add93181c32a`，当前未提交。
- PLAN：`T061-N32-A-PLAN-R04`，Q-0004，审核员 REVIEW-1 与预审员 PRECHECK-1 汇总 PASS。
- PLAN ZIP：`9df6e5e89d133bce8bc38b6cf35923d1dafdae604a7f096a740d1b5b49b97e5c`。
- plan10：`414f836520d7dc8e1e0063a516e642cbf7094bb4cdcea5240f9d8b06e7e4f40b`。
- 候选 allocator：`51472b796c9cd883e0fd07ec304559c249fd055929b64a96d53aad5af5b2ce99`。
- 根据已生效 N32-A 固定授权，实际启动一次冻结 parent_launch。没有借用 T052/T060 许可，没有 Gowin 或设备操作。

## 实际结果

首个 `N4_none_compile`：Icarus PID19604，实际6.015秒，退出 `3221225477 / 0xC0000005`，stdout/stderr各0字节，没有sim.vvp。runner按失败规则立即停止，后17步从未开始；不存在有效capture。runner总9.844秒退出1，父进程真实观察child非零、约10.094秒。

原始收据：`code/output/m3_n32_a_actual_20261014_10/receipt.json`，SHA `9d8ec4747a4bda08f664d27df4814da0db5ac7ae758641b8f0cb79fad7773b03`。

父观察：`code/output/m3_n32_a_actual_20261014_10_parent/observation.json`，SHA `448b2bbd0f161110b2f33a88613e5ebc0f4727330c110d174665055fc142466b`。失败没有completion，不将失败观察改写为零退出。

随后只做了读取诊断和身份补收集，未启动任何编译/RTL工具。34项冻结项目源、6783项工具/运行依赖后验均与plan一致；这些是**失败后另行只读收集**，不冒充原runner预算内成功收尾。`postcheck.py`生成报告退出0只代表身份收集成功，不代表A成功。Windows故障日志初次受限；窄范围只读提权查询后未找到对应Application Error记录，故障模块与根因仍UNKNOWN，不能认定为RTL语法错误或工具安装损坏。

## 当前边界及请求

已立即停止本清单；无重试、换工具/机器、增限或未列扫描。B/C实际执行继续等待，不用静态、fixture或旧N32签收代替A新组合结果。完整T052/T060/T061仍PARTIAL。

请M2核对该失败证据，决定是否授权独立compile-only诊断及其精确范围：机器/现有工具/源与输入、调用次数、新目录、预算及失败规则。需要恢复A清单时须另明确，不复用本次已尝试输出。当前不自行进行该诊断，也不自动启动旧仓库RTL门禁。

Git发布尚未完成。尚未运行本轮仓库九门禁或同步develop，不能写成“已提交/已推送”。主对话4的B和主对话3的C继续保留各自软件准备，后续正式运行不越过A/B依赖。
