"""Read-only post-failure identities; never launches an HDL/EDA tool."""
import hashlib
import json
from pathlib import Path


def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    here = Path(__file__).resolve().parent
    root = here.parents[2]
    plan_path = root / "code/output/m3_n32_a_plan_20261014_10/plan.json"
    expected_plan = "414f836520d7dc8e1e0063a516e642cbf7094bb4cdcea5240f9d8b06e7e4f40b"
    assert identity(plan_path)["sha256"] == expected_plan
    plan = json.loads(plan_path.read_bytes())
    capsule = Path(plan["capsule_root"])
    source_after = {relative: identity(capsule / relative)
                    for relative in plan["capsule_files"]}
    tools_after = {path: identity(path) for path in plan["tool_files"]}
    source_match = all(actual == {key: plan["capsule_files"][relative][key]
                                 for key in ("bytes", "sha256")}
                       for relative, actual in source_after.items())
    tools_match = tools_after == plan["tool_files"]
    actual = Path(plan["execution_output"])
    parent = Path(str(actual) + "_parent")
    receipt = json.loads((actual / "receipt.json").read_bytes())
    observation = json.loads((parent / "observation.json").read_bytes())
    assert receipt["status"] == "FAIL_PARTIAL" and receipt["exit_code"] == 1
    assert len(receipt["steps"]) == 1
    assert receipt["steps"][0]["exit_code"] == 3221225477
    assert observation["step"]["exit_code"] == 1
    artifacts = {str(path.relative_to(root)): identity(path)
                 for folder in (actual, parent) for path in sorted(folder.rglob("*"))
                 if path.is_file()}
    result = {
        "scope": "POST_FAILURE_READ_ONLY_IDENTITY_COLLECTION_NOT_RETRY",
        "generator": identity(__file__), "plan": identity(plan_path),
        "source_after": source_after, "tools_after": tools_after,
        "source_matches_reviewed_plan": source_match,
        "tools_match_reviewed_plan": tools_match,
        "artifacts": artifacts,
        "actual_steps_started": 1, "actual_steps_not_started": 17,
        "compile_exit_hex": "0xC0000005", "valid_capture": False,
        "Windows_fault_event": "Privileged read-only query found no matching Application Error record",
        "root_cause": "UNKNOWN", "automatic_retries": 0,
        "T061_complete": False,
    }
    destination = here / "postcheck.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": "FAILURE_IDENTITIES_COLLECTED",
                      "source_match": source_match, "tool_match": tools_match,
                      "sources": len(source_after), "tools": len(tools_after),
                      "report": identity(destination)}))
    return 0 if source_match and tools_match else 1


if __name__ == "__main__":
    raise SystemExit(main())
