"""Bound precise-publication-tree recheck with explicit read-only original inputs.

This wrapper does not modify the sealed candidate or copy historical N32 output.
No archive member, HDL, VVP, Gowin, serial or device operation is executed.
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback


MAIN = Path("E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano")
PUBLICATION = Path("E:/FPGA/GAOYUNFPGA/worktrees/m3_task_delivery_rule_20261015")
RELATIVE = Path("code/software/n32_d_cfull_binding_candidate_20261015")
HERE = PUBLICATION / RELATIVE
ABCD = MAIN / "code/output/n32_publication_20261014_r01/transfer/M3_N32_ABCD_20261014_COMPLETE.zip"
CFULL = MAIN / "code/output/n32_c_full_publication_20261014_r01/transfer/M3_N32_C_FULL_20261014.zip"
RECEIPT = Path("E:/FPGA/GAOYUNFPGA/Callback3/chat6/M2_REVIEW_RECEIPT.json")
JOB = PUBLICATION / "code/software/t052_runner_acceptance_candidate_20261012/windows_job.py"
JOB_SHA = "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b"
ANCHORS = {
    ABCD: "ba9e4f42d9aa5bb60c6d5122ae271fc58b3b9e7d27cca4caa48fd9740d85aa36",
    CFULL: "eac6e9371a96e91447a75d869d7e7a6dc76252fd89d6c8b621953a396a42c726",
    RECEIPT: "e0447a093fc6d2cc593d9012f8ac2be0585aeed33cee447bc02ffbe84d795fbe",
}


def info(path: Path) -> dict:
    digest = hashlib.sha256()
    length = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            digest.update(block)
            length += len(block)
    return {"bytes": length, "sha256": digest.hexdigest()}


def no_reparse(path: Path) -> None:
    for current in (path, *path.parents):
        if current.exists() or current.is_symlink():
            if current.is_symlink() or getattr(current.lstat(), "st_file_attributes", 0) & 0x400:
                raise ValueError("REPARSE_PATH: " + str(current))


def collect(paths: list[Path]) -> tuple[dict, list]:
    records, errors = {}, []
    for path in paths:
        try:
            no_reparse(path)
            records[str(path)] = info(path)
        except Exception as exc:
            records[str(path)] = None
            errors.append(str(path) + ": " + str(exc))
    return records, errors


def write_json(path: Path, value) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    output = args.output.absolute()
    if ".." in args.output.parts or output.parent != PUBLICATION / "code/output" or not output.name.startswith("n32_d_cfull_binding_"):
        parser.error("fresh direct publication/code/output/n32_d_cfull_binding_* required")
    no_reparse(output)
    output.mkdir(exist_ok=False)
    started = time.monotonic()
    result = {
        "schema": "N32_D_CFULL_PUBLICATION_RECHECK_V1", "passed": False,
        "runner_exit": 1, "stages": [], "total_bound_seconds": 300,
        "step_bound_seconds": 90, "automatic_retries": 0,
        "EDA_calls": 0, "RTL_calls": 0, "device_calls": 0,
        "scope": "STATIC_BINDING_ONLY", "resources": "UNKNOWN", "STA": "NOT_RUN",
        "T061_complete": False, "main_root": str(MAIN), "publication_root": str(PUBLICATION),
        "argv": list(sys.argv if argv is None else argv), "cwd": str(Path.cwd()),
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "original_inputs": {"abcd": str(ABCD), "cfull": str(CFULL), "m2_receipt": str(RECEIPT)},
        "input_selection": "Explicit read-only main originals; fixed production SHA checks remain enabled",
        "packaged_payload_execution": False, "candidate_source_modified": False,
    }
    paths, before = [], {}
    try:
        source_names = sorted(path.name for path in (MAIN / RELATIVE).iterdir()
                              if path.is_file() and path.suffix in (".py", ".json", ".txt"))
        publication_names = sorted(path.name for path in HERE.iterdir()
                                   if path.is_file() and path.suffix in (".py", ".json", ".txt"))
        if not source_names or source_names != publication_names:
            raise ValueError("PUBLICATION_SOURCE_MEMBER_SET_MISMATCH")
        for name in source_names:
            main_source, publication_source = MAIN / RELATIVE / name, HERE / name
            no_reparse(main_source)
            no_reparse(publication_source)
            if info(main_source) != info(publication_source):
                raise ValueError("PUBLICATION_SOURCE_IDENTITY_MISMATCH: " + name)
            target = output / "source_before" / name
            target.parent.mkdir(exist_ok=True)
            shutil.copyfile(publication_source, target)
            paths.extend([main_source, publication_source])
        paths.extend([ABCD, CFULL, RECEIPT, RECEIPT.with_name("M2_REVIEW.md"), JOB,
                      MAIN / "code/build/138k_polyphony_resource/m3_n32_allocator_candidate_20261013/D_N32_R1_EXACT_HANDOFF_20261015.md",
                      Path(__file__).absolute(), Path(sys.executable).absolute()])
        runtime = Path(sys.executable).absolute().parent
        paths.extend(path for path in runtime.rglob("*") if path.is_file()
                     and path.suffix.lower() in (".exe", ".dll", ".pyd", ".zip"))
        paths = sorted(set(paths))
        before, errors = collect(paths)
        if errors:
            raise ValueError("PRE_IDENTITIES_UNAVAILABLE: " + repr(errors))
        for path, sha in ANCHORS.items():
            if before[str(path)]["sha256"] != sha:
                raise ValueError("INDEPENDENT_ANCHOR_MISMATCH: " + str(path))
        if before[str(JOB)]["sha256"] != JOB_SHA:
            raise ValueError("PRIVATE_JOB_IDENTITY_CHANGED")
        result["wrapper_identity"] = before[str(Path(__file__).absolute())]
        result["publication_sources"] = {name: before[str(HERE / name)] for name in source_names}
        spec = importlib.util.spec_from_file_location("publication_bounded_runner", HERE / "run_acceptance.py")
        bounded = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(bounded)
        if bounded.JOB != JOB or bounded.JOB_SHA != JOB_SHA:
            raise ValueError("PUBLICATION_PRIVATE_JOB_BINDING_MISMATCH")
        environment = {key: value for key, value in os.environ.items()
                       if key.upper() in ("SYSTEMROOT", "WINDIR", "COMSPEC", "PATH", "TEMP", "TMP")}
        environment.update(PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", PYTHONIOENCODING="utf-8")
        result["explicit_environment"] = environment
        bootstrap = (
            "import os,sys,unittest;from pathlib import Path;"
            "sys.path.insert(0,sys.argv[1]);os.environ['N32_BINDING_TEST_OUTPUT']=sys.argv[2];"
            "import test_binding as t;"
            "t.ABCD=Path(sys.argv[3]);t.CFULL=Path(sys.argv[4]);t.RECEIPT=Path(sys.argv[5]);"
            "s=unittest.defaultTestLoader.loadTestsFromModule(t);"
            "n=s.countTestCases();"
            "assert n==71,('EXPECTED_71_TESTS',n);"
            "r=unittest.TextTestRunner(verbosity=2).run(s);raise SystemExit(not r.wasSuccessful())"
        )
        base = [sys.executable, "-I", "-S", "-B", "-X", "utf8"]
        commands = [
            ("software_tests", base + ["-c", bootstrap, str(HERE), str(output / "cases"),
                                      str(ABCD), str(CFULL), str(RECEIPT)]),
            ("prepare", base + [str(HERE / "binding_check.py"), "prepare", "--abcd", str(ABCD),
                               "--cfull", str(CFULL), "--receipt", str(RECEIPT),
                               "--output", str(output / "prepared")]),
            ("verify", base + [str(HERE / "binding_check.py"), "verify", "--prepared", str(output / "prepared"),
                              "--output", str(output / "verified")]),
        ]
        for name, command in commands:
            remaining = 300 - (time.monotonic() - started) - 10
            if remaining <= 0:
                raise TimeoutError("OUTER_BUDGET_BEFORE_LAUNCH")
            record = bounded.execute(command, PUBLICATION, output / (name + "_logs"),
                                     min(90, remaining), environment)
            result["stages"].append({"name": name, "execution": record})
            if record.get("exit_code") != 0 or record.get("timed_out") or record.get("error"):
                raise ValueError("PUBLICATION_STAGE_FAILED: " + name)
        for name in ("prepared", "verified"):
            generated = json.loads((output / name / "receipt.json").read_text(encoding="utf-8"))
            if generated.get("exit_code") != 0 or generated.get("status") != "PASS_STATIC_BINDING_ONLY_T061_PARTIAL":
                raise ValueError("BINDING_SUCCESS_RECEIPT_INVALID: " + name)
        result["passed"] = True
    except Exception as exc:
        result["error"] = type(exc).__name__ + ": " + str(exc)
        result["traceback"] = traceback.format_exc()
    finally:
        after, identity_errors = collect(paths)
        result.update(before=before, after=after, identity_errors=identity_errors,
                      seconds=time.monotonic() - started,
                      ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        if identity_errors or before != after or result["seconds"] > 300:
            result["passed"] = False
        result["runner_exit"] = 0 if result["passed"] else 1
        write_json(output / "receipt.json", result)
    print(json.dumps({key: result.get(key) for key in ("passed", "runner_exit", "error", "seconds")}, ensure_ascii=False))
    print("Receipt:", output / "receipt.json")
    return result["runner_exit"]


if __name__ == "__main__":
    raise SystemExit(main())
