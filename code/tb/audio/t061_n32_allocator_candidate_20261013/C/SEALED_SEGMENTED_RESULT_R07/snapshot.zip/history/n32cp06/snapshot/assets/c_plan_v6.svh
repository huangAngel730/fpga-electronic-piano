// Compact dispatch: independent inputs are in c_plan_v4.mem.
load_commands(459);
for(command_index=0;command_index<459;command_index=command_index+1)
    run_command(command_index);
