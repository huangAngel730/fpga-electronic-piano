"""Compile the independent C v4 JSONL plan into an SV stimulus include.

This generator does not read a DUT trace or execute HDL tools.  All commands
are literal plan inputs; operation completion is decided by public handshakes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def event_word(op: dict) -> int:
    kind = op["op"]
    typ = {"note_on": 0, "note_off": 1, "cc64": 4,
           "control_event": 4}[kind]
    ctl, value = 0, 0
    if kind == "cc64":
        ctl, value = 6, 4095 if op["down"] else 0
    elif kind == "control_event":
        typ, ctl = {"pitch_bend": (3, 0), "modulation": (4, 1),
                    "pitch_range": (4, 4)}[op["control"]]
        value = op["value"]
    fields = [(typ, 3), (op.get("source", 0), 4),
              (op.get("channel", 0), 4), (op.get("note", 0), 7),
              (op.get("velocity", 0), 10),
              (op.get("expression", 0), 10), (ctl, 8), (value, 12), (0, 6)]
    result = 0
    for value, width in fields:
        if type(value) is not int or not 0 <= value < (1 << width):
            raise ValueError("C4_EVENT_FIELD_RANGE")
        result = (result << width) | value
    return result


def generate(plan: Path, output: Path) -> dict:
    raw = plan.read_bytes()
    rows = [json.loads(line) for line in raw.decode("utf-8").splitlines()]
    if rows[0]["record"] != "META" or rows[-1]["record"] != "END":
        raise ValueError("C4_PLAN_ENVELOPE")
    operations = rows[1:-1]
    lines = ["// Generated only from the independent C v4 input plan."]
    for index, op in enumerate(operations):
        if op.get("record") != "PLAN" or op["index"] != index:
            raise ValueError("C4_PLAN_INDEX")
        kind = op["op"]
        lines.append(f'begin_op({index}, "{kind}");')
        if kind in ("note_on", "note_off", "cc64", "control_event"):
            lines.append(f"send_event(64'h{event_word(op):016x});")
        elif kind == "sample":
            lines.append(f"send_sample(32'h{op['result_id']:08x}, "
                         f"{op.get('min_hold_cycles', 0)});")
        elif kind == "read":
            lines.append(f"read_bank({op['slot']});")
        elif kind == "read_stall":
            lines.append(f"read_stall({op['slot']}, {op['cycles']});")
        elif kind == "await_release_done":
            lines.append(f"await_retirement({op['slot']});")
        elif kind == "set_result_ready":
            lines.append(f"result_ready = 1'b{op['value']}; next_edge();")
        elif kind == "reset":
            lines.append("reset_domain();")
        elif kind == "cancel":
            lines.append("cancel = 1; next_edge(); cancel = 0;")
        elif kind == "wait_idle":
            lines.append("wait_idle();")
        elif kind == "tick":
            lines.append("next_edge();")
        else:
            raise ValueError("C4_UNKNOWN_OP:" + kind)
        lines.append("end_op();")
    body = ("\n".join(lines) + "\n").encode("ascii")
    with output.open("xb") as stream:
        stream.write(body)
    return {"plan_sha256": hashlib.sha256(raw).hexdigest(),
            "include_sha256": hashlib.sha256(body).hexdigest(),
            "operations": len(operations)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.plan, args.output), sort_keys=True))
