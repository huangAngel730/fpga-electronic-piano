# T061 B0 独立复音候选：同源预算

仅源码清单、条件日历和 Python 协议 oracle。没有新 RTL、音频等价、综合或 STA 通过。

主候选：单套分时完整上下文 engine。其它架构只作短对比。生产选型由 M2 决定。

21 拍/voice 是待实现设计合同，非实测；未给 dispatch 上界时整体 UNKNOWN。

| N | 条件拍数 | 条件余量 | 逻辑状态分配 bits（非 FF） | 整体 |
|---|---:|---:|---:|---|
| 4 | 117 | 716 | 15628 | UNKNOWN |
| 8 | 205 | 628 | 21748 | UNKNOWN |
| 16 | 381 | 452 | 33988 | UNKNOWN |
| 32 | 733 | 100 | 58476 | UNKNOWN |

## 原冻结 L 状态字段（N4，未来 N 只为缩放提案）

重复保存的身份、快照、工作寄存不无证明合并；ADSR pipeline 全保留，另计一套 engine 工作副本。

| 源/行 | 字段及位宽 | 类 | 份数 | bits | 生命周期 |
|---|---|---|---:|---:|---|
| piano_dds_oscillator.sv:31 | phase_acc:32 | voice_context | 4 | 128 | sample tick; reset clears; cancel does not roll back |
| piano_dds_oscillator.sv:32 | attack_samples_left:11 | voice_context | 4 | 44 | note-on loads; tick decrements; reset clears |
| piano_dds_oscillator.sv:36 | active_table:2, pending_table:2, table_change_pending:1 | voice_context | 4 | 20 | note-on/tick/wrap table policy; reset clears pending |
| piano_dds_oscillator.sv:130 | dout:16 | voice_work | 4 | 64 | synchronous wave ROM read every clock; qualify by context |
| adsr_piano_envelope.sv:24 | state:4 | voice_context | 4 | 16 | event/preparation clocks/tick; reset IDLE; keep private states |
| adsr_piano_envelope.sv:25 | level_q16:32, start_q16:32, peak_q16:32, sustain_q16:32 | voice_context | 4 | 512 | event/preparation/tick; sustain uses previous registered product |
| adsr_piano_envelope.sv:26 | step_q16:33, elapsed:13, pending_tick:1, release_start_q16:32, rom_addr:10 | voice_context | 4 | 356 | event and preparation/tick; retain Release and pending tick on context switch |
| adsr_piano_envelope.sv:70 | step_delta_q:33, reciprocal_q:26, step_product_q:59, sustain_product_q:45, rom_dout:16 | voice_work | 4 | 716 | continuous pipeline/ROM; NOT safely discardable until B2 equivalence proves it |
| pitch_mod_fcw_pipeline.sv:62 | lfo_phase:32 | voice_context | 4 | 128 | note-on resets; accepted enable advances; cancel no rollback |
| pitch_mod_fcw_pipeline.sv:73 | sine_s0:16, depth_s0:10, semi_s0:17, semi_s1:17, sine_product_s1:26, total_s2:18, oct_s3:20, sub_s3:20, ratio_s4:40, fcw_product_s5:57, base_s0:32, base_s1:32, base_s2:32, base_s3:32, base_s4:32, valid_pipe:6, fcw_out:32, fcw_valid:1 | voice_work | 4 | 1760 | enable/valid-qualified pipeline; reset invalidates; retain pending work conservatively |
| voice_allocator_4.sv:20 | note_active:1, in_release:1, source:4, channel:4, note:8, age:2 | voice_context | 4 | 80 | allocation/release/retire; relative LRU ranks, not an unbounded age counter |
| polyphonic_event_router.sv:13 | slot_note_on:1, slot_note_off:1, slot_occupied:1, slot_releasing:1, slot_velocity:10, slot_fcw:32, slot_notes:8, slot_sources:4, slot_channels:4, slot_generation:32, retire_pending:1, retire_generation:32 | voice_context | 4 | 508 | registered router state; generation wraps modulo 2^32; full identity guards retire |
| sustain_controller.sv:11 | occupied:1, key_down:1, deferred:1, releasing:1, pending_mask:1, pending_generations:32, source_mem:4, channel_mem:4, note_mem:7, generation_mem:32 | voice_context | 4 | 336 | accepted command/ACK; pending release payload immutable until ACK; reset clears |
| performance_control_snapshot.sv:30 | control_mem.range:5, control_mem.mod:12, control_mem.bend:12, initialized:1 | identity | 256 | 7680 | identity=source4 concatenated channel4; write event/read snapshot; reset invalidates |
| sustain_controller.sv:10 | pedal_down:1 | identity | 256 | 256 | 256 independent source/channel pedals; panic/reset clears |
| performance_control_snapshot.sv:17 | snapshot_occupied:1, snapshot_sources:4, snapshot_channels:4, snapshot_generations:32, snapshot_pitch_bend:12, snapshot_modulation:12, snapshot_pitch_range:5 | snapshot | 4 | 280 | one shared control read per cycle; events locked until snapshot ends |
| pitch_mod_snapshot_pipeline.sv:30 | held_occupied:1, held_sources:4, held_channels:4, held_generations:32, result_occupied:1, result_sources:4, result_channels:4, result_generations:32, result_fcw:32 | snapshot | 4 | 456 | accept holds identity; result handshake or frame cancel invalidates token |
| polyphonic_envelope_bank.sv:70 | frozen_base:32, computed_fcw:32, frozen_occupied:1, frozen_sources:4, frozen_channels:4, frozen_generations:32, result_envelopes:16, result_waves:16, result_fcw:32, result_occupied:1, result_states:3 | snapshot | 4 | 692 | CAPTURE freezes; ADVANCE once; HOLD until consumed; frame cancels result, not DSP |
| voice_allocator_4.sv:14 | allocated_slot:2, slot_valid:1, release_slot:2, release_target_valid:1 | global | 1 | 6 | registered allocation/release outputs; reset clears |
| polyphonic_event_router.sv:28 | held_event:64, state:4, target_slot:2, release_index:3 | global | 1 | 73 | one event held; scan index includes N sentinel; reset IDLE |
| performance_control_snapshot.sv:32 | busy:1, read_slot:2, control_applied:1, invalid_range:1, snapshot_valid:1, snapshot_id:32 | global | 1 | 38 | atomic request; hold valid; reset clears |
| pitch_mod_snapshot_pipeline.sv:28 | busy:1, cancelled:1, age:3, held_id:32, result_valid:1, result_id:32 | global | 1 | 70 | one math token; cancel drains; no LFO rollback |
| polyphonic_envelope_bank.sv:33 | phase:4, delay_count:3, pending_req_id:32, resume_requested:1, result_valid:1, result_req_id:32 | global | 1 | 73 | frame enters DRAIN; pending request survives drain |
| pcm_result_hold.sv:27 | request_window:1, pcm_valid:1, pcm_req_id:32, pcm_left:24, pcm_right:24, pcm_clip_any:1 | global | 1 | 83 | current request only; once; frame expires; reset clears valid |
| pcm_frame_buffer.sv:30 | sample_req:1, sample_req_id:32, pending_valid:1, pending_left:24, pending_right:24, held_left:24, held_right:24, ever_committed:1, request_active:1, audio_frame_count:32, pcm_request_count:32, pcm_commit_count:32, audio_underrun:32 | global | 1 | 260 | one pending stereo pair; frame holds old PCM on underrun; reset clears |
| system_status_counters.sv:16 | elapsed:32, request_active:1, max_processing_cycles:32 | global | 1 | 65 | accepted request/commit; saturation; reset clears |
| pcm_clip_counter.sv:15 | clip_count:32 | global | 1 | 32 | increment only successful clipped commit; reset clears |

## ROM（全部七份，piano 激活五表；替代 sine 不重复计）

| 表 | 深×宽 | 单份 bits | piano 激活 | 用途 |
|---|---:|---:|---|---|
| lfo_sine_q15.mem | 1024×16 | 16384 | True | lfo_lut; sync read |
| oct_ratio_q16.mem | 50×20 | 1000 | True | oct_lut; sync read |
| sub_ratio_q16.mem | 1024×20 | 20480 | True | sub_lut; XOR-permuted physical address in L |
| velocity_gain_rom.mem | 1024×16 | 16384 | True | gain_rom; sync read |
| piano_band_4x256_8191.mem | 1024×16 | 16384 | True | rom_data; piano mode sync read |
| sine_1024_8192.mem | 1024×16 | 16384 | False | alternative sine mode, not extra piano ROM |
| sine_1024_32767.mem | 1024×16 | 16384 | False | unused bank default overridden by audio core |

## 容量来源

冻结 L 原工具报告，不是本轮新综合。
- Logic: 138240 tool Logic units, NOT LUT; 原整机用量 18823。
- Register: 139095 registers; 原整机用量 8669。
- DSP: 298 DSP blocks; 原整机用量 46。
- BSRAM: 340 BSRAM blocks, NOT KiB; 原整机用量 20。

## 未验证边界

- Event drain/CC64 release and downstream backpressure have no measured finite end-to-end bound here.
- 21-cycle serial voice contract is a proposal; actual II/latency unknown until B1/B2 TB.
- All voices including silent and Release must execute once. No occupied-only shortcut.
- ADSR continuous pipeline + previous-cycle sustain product need exact context/preparation equivalence.
- LFO cancellation is non-rollback; protocol oracle does not model or prove DSP progression.
- 32-bit request/generation wrap needs bounded outstanding-work/flush contract in RTL.
- Statebank ports, forwarding, event serialization, pipeline flush and tag fanout await RTL.
- Resource bits are logical allocations, NOT FF count/DSP mapping/BSRAM packing.
- Board/I2S/display/FIFO/PLL state is outside this audio-kernel inventory; old whole-design totals are reference only.
- N4 audio equivalence, N8/16/32 full audio, compiled behavioral mutants, synthesis and new whole STA NOT RUN.

完整逐周期日历、每字段源 SHA、56 输入 SHA、缩放清单见同次 budget.json。
