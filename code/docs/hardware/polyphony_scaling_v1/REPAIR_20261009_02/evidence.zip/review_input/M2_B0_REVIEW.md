# T061 B0／41d2871：M2独立复核与B1准入条件

2026-10-09。实际fetch核实41d2871，随后3a0f28c只增加上传后通知。14+1文件均在D043/D044授权新候选软件、指定runner及hardware文档范围，未改生产RTL/ROM/公共接口/共享表。

结论：签收冻结来源清单、条件日历与既有正常整数输入下的Python协议自检（L0/软件L1），允许继续单一分时主候选B1独立scheduler/statebank/tagROM验证。整体T061不关闭；尚无新RTL、N4声音等价、32复音、综合或新STA。软件参数边界问题需最小纠正，取消后tag排空前置条件必须明确落入B1，不能宣称协议已经对所有输入fail-closed。

## 身份与原始证据

外层用户B0_20261009.zip：509132bytes，SHAe10334952a4b12211aced2d70a5beb74c14c642f8398d5d1aaedfe24e9fa8473。
通知所列3c7d63eddfed73423faf6cd39c9504af75eb73a846b2698566fa6b64bda0bc6e是evidence.zip.b64解码后的**内层ZIP**，543209bytes、279members，CRC通过；两层不能混淆。279文件逐member/bytes/rawSHA全部核对，原件不改。最终5个执行源与远端代码SHA一致；原两个失败receipt保留。

原最终runner B0_SCOPE_PASS_T061_PARTIAL/exit0，task_complete=false，322.891秒；27自检exit0，原九门禁raw log实际9PASS/0FAIL/exit0，317.625秒。前后56冻结输入与候选源SHA一致；原前两失败为lfoROM载体身份、python_unit问题，不当行为负例计分。

M2第一次独立执行因复核副本漏放sources导致6项FileNotFoundError，日志保存independent_logs，不能计PASS；补齐只读依赖后的新independent_logs_qualified执行27/27 exit0、预算入口exit0。没有修改M3代码或原冻结文件。预算/calendars/unknowns等实质JSON字段与原预算完全一致。

冻结L松散目录缺容量rpt，不是数学源改变；从原M3_138K_Hold修复证据_20261005.zip的L同名member只读恢复到复核副本，raw与交付报告完全一致，原工作区不回写。56输入/7ROM与最终运行清单身份复核一致，三份CRLF原始ROM的内存恢复规则受明确SHA限定，不任意归一化。

## 条件预算复算

|N|条件拍数|条件余量（833−条件）|候选逻辑分配bits（非FF）|端到端|
|---|---:|---:|---:|---|
|4|117|716|15628|UNKNOWN|
|8|205|628|21748|UNKNOWN|
|16|381|452|33988|UNKNOWN|
|32|733|100|58476|UNKNOWN|

29+22N包括admission8、atomic snapshot N+1、21拍/voice、drain2/commit2/guard16；每槽包含contextread、Pitch消费7、DDS、wave、envelopesettle6、gain、stereo累加、tagcheck、contextwrite。所有N槽含静音/Release都执行。733与100为未实现合同估算，不是实际II/latency/余量；dispatch/CC64扫描/backpressure没有有限上界，所以整体UNKNOWN保留正确。各步端口/延迟变化后要重预算，不能拿模块综合或条件拍数代新40MHzSTA。

保留256 source-channel控制/踏板身份、32bit request/generation、ADSR4bit私有state及持续ROM/product上下文，state/mask/scan位宽随N扩展。635bit/voice工作流水全留另加一套engine副本、重复身份快照不随便去重；逻辑bits不是FF占用。5张活跃piano ROM一份70632bit，7份ROM身份齐，两个sine是替代模式；XOR地址及sub_source初始化规则保持。DSP/BSRAMpacking/LUT未知，八个逻辑乘法不等于八DSP。

## 新发现：限定范围返修

1. **公开Python身份类型不严格**：ProtocolOracle初始化接受source=True、source=0.5及generation=True；result tag的source=True可与合法source=1相等并接受。构造/replace/pedal/tag字段应逐项type(x)is int且检查范围；Tag接受必须拒bool/float，异常不能替代指定拒收。slot_width(4.0)当前抛AttributeError，公开N应先严格int校验，再可控ValueError。仅修本新候选software及对应tests，保留旧证据；不修改协议/生产RTL。不必等新综合再补这些低成本边界。
2. **取消后同一request+generation立即复用仍接受旧tag**：begin7→issue→cancel→begin7→issue，同旧tag被accept。合同已写“旧事务排空或有限在途上界”，因此本次列为尚未编码的前置条件，不断言生产RTL已有ABA故障。B1必须做有限排空/隔离：cancel清scratch不等于清ROM/engine在途结果；如tag不增epoch，就应明确所有旧工作已drain前禁止复用完整tag。32位回绕也需同一防护。加入旧结果跨cancel/回绕/替换到达的公开TB及行为反例，不用Python已测wrongrequest覆盖替代。
3. **声音持续状态不能用21拍自动保证**：ADSR静默时钟/previous-cycle sustain产品、ROM预取、LFO非回滚、tick/事件先后要在B1上下文时序和B2数学等价证明。event/control互斥不能无界挡MIDI或丢事件；先给排空/CC64最大扫描服务界限，再谈end-to-end fits。

上述发现不推翻已复算的预算表，但限制“完整tag oracle验证”结论；不宜把27PASS写成所有非法输入/回绕恢复通过。真实硬件tag是固定位宽，本Python类型漏检是验收接口问题，不能扩大成硬件电平或已经错播。

## B1继续范围与验收

按既定五处B授权，新独立可综合scheduler/statebank/tagROM，单一主方案；先N4公开协议边界，再参数N8/16/32同一链，不建三套engine。M2认可该路线用于独立工程验证，正式生产选型/首接入档位仍未签。

实际II/latency、同步ROM读口/写冲突/forwarding、输出valid-ready稳定、乱序合法result/错完整tag/重复/未发起均需自检；全N齐再commit，reset/cancel每阶段后可恢复且旧结果不写当前scratch。至少两个可编译RTL行为变异由指定断言拒收。上述新参数返修可同阶段交，不阻止仅独立B1开发。

B1不证明声音或32复音。B2先N4冻结L逐样本声音等价，再8/16/32，保持数学/48k/事件和纯正弦目标；不迁就候选改黄金。当前一次新模块Gowin综合额度尚未使用，只有新RTL/正负/身份齐后再考虑一次有界资源预检，无PnR/码流/下载许可。

RAM优化候选、T060剩余router/CC64与T061保持独立提交，避免共享源冲突；正式连接、CDC/reset/pins、全新整机STA归M2，原4voice/L-v3回退保持，不降时序门槛。

## 发布与通知

M3→M2本次通知已用户转发收到；M2回执/类型返修意见待用户私发M3，尚未送达。旧包的HEAD96b364a/未提交说明按生成时身份保留，当前上传另记。本地M2 HEAD f02a2c4，远端3a0f28c已fetch，但普通merge同步未明确获准；未取新号/共享登记/提交推送。已有fetch/登记/提交/普通推送许可持续有效，不绕过先前rebase审批拒绝。没有安装、串口、接线、烧录或新RTL/Gowin运行。
