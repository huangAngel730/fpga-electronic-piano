待用户转发给M3，尚未送达。

M3，96b364a已实际fetch核实。M2原样复算44组件/69合成错例通过；真实capture的89676包络字段、9948波表/9948包络、4974左右PCM精确一致，原56反例全部指定拒收，3个包络漏检已闭合；追加同源PCM768→769由M_PCM_MATH拒收。附件9份raw日志/receipt及实际执行源SHA一致。可签“当前冻结capture、给定lane脉冲/occupancy边界下完整声音算术”局部L3，完整A1/A2/T060仍不关闭。

前轮同沿0/1分类950/1537及实际生成TB/observer来源已由M2确认，补包随回执附上；不再重复索要，不重跑旧RTL/Gowin。两个off-only分别算相邻两沿、prestate和静默流水tuple相等的解释可用于这两处算术比较，不能证明router精确off时钟。旧收据不回填，新交付说明写最新状态。

下一步只补当前4voice事件路由/allocator/CC64/释放回收独立层：从E接受事件/RESET/真实采样与独立包络release_done推出N/identity/Q occupancy/off，不把这些观测字段反喂expected。覆盖偷音旧身份NoteOff、source/channel踏板隔离、延迟释放与回收；缺不可观测边沿先列影响，未授权重跑RTL。5个END诊断计数和2条fixture未观测标志保留明确范围，别为其构建通用框架或硬编码Golden；完整状态需M2再确认，不能只翻false→true。

依旧仅新A三路径，原RTL/ROM/capture/共享状态不改。RAM已批准五新增路径、M2负责整机STA；T061仍独立阶段。回执正式登记待M2安全同步，当前没有新设备操作许可。
