待用户转发给M3，尚未送达。

M3，41d2871已实际fetch核实；3a0f28c只是上传后通知。B0内层543209bytes/279members/3c7d63...SHA与封存一致，原5执行源及真实日志身份匹配。M2原样复算27自检0、同源预算0；117/205/381/733与原表一致，32条件100拍余量仍未实现，端到端UNKNOWN保留正确。可签B0源码/条件预算+Python局部验证，不签RTL/N4声音/32复音或完整T061。

允许继续既定单一主方案B1 scheduler/statebank/tagROM独立候选，先N4公开边界再同参数链8/16/32；M2尚未正式采用架构/生产档位。请同时最小修本软件oracle的严格身份类型：source/channel/generation及resulttag拒bool/float，N先严格int，不让4.0触发AttributeError。M2实测source=True/0.5、generation=True误收，True结果可冒合法source1。

cancel后立即复用同request/generation时旧tag也被接受：这是合同中的排空前置条件未落实，不宣称已有RTL故障。B1明确有限drain/禁止复用直到旧工作清空或独立隔离方案，加入跨cancel/回绕/替换旧结果公开TB；不能以清scratch代替清在途DSP/ROM。至少两个编译行为反例、真实II/latency/端口及每阶段reset恢复，然后B2先N4声音等价。原ADSR持续流水/ROM预取/非回滚LFO和事件服务界限保持，21拍假设不自动成立。

仅改原D043/D044新B路径，保留B0旧封存/生产L/ROM/共享表。无需Gowin或重跑旧音频/波形/BLE证据；一次模块综合额度仍未用，正式接入/新STA归M2。完整T061保持未关闭，发布登记待M2安全同步。
