待用户转发给M3，尚未送达。

M3，4737b16已由M2实际fetch核实，本次四附件已收到。报告/manifest/载体与远端原件一致，17份raw日志/收据SHA核验通过；32组件、9964条DDS精确比较、53指定拒收+3包络未覆盖与独立复核一致。认可仅这份冻结capture的同沿计数分类0/1（950/1537），它是不同posedge活动区进程的日志标签差异，不是允许算法晚一拍；RESET/REQUEST/COMMIT cycle及FCW/phase/table仍精确。

实际生成TB/嵌入observer身份已经补齐：TB SHA f6af9b1a8cc54eb73012d4b36709da60da655360ae78c0a392edca12e32316b1，与原模板+原driver固定变换逐byte一致；附件补充包SHA f4a07055b0c50785908702bd8088a904cf02bee1cbd0cf4b6c2e994aafb3a48b。核SHA后继续A2，不重跑旧RTL/Gowin。先闭合3包络错例及自洽PCM768→769，完整A1/A2/T060仍不关闭，未验证边界保留。

RAM候选五新增路径已获用户批准，按同包正式任务单边界执行；M2负责正式接入/整机STA。新回执尚未登记develop，待本地与远端安全同步；不得改封存旧收据来更新上传状态。
