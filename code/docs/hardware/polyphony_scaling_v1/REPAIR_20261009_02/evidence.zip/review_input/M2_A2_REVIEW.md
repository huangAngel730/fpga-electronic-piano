# T060 A2／96b364a：M2独立复核与收口条件

日期2026-10-09。远端已实际fetch核实96b364a；相对4737b16的14个文件都处于既定三处授权范围，未改生产RTL/ROM/公共接口/约束/共享登记。用户转发的4份附件与远端原件逐byte一致。报告/manifest中的未提交/未推送是生成时身份，旧件保留不回填；当前已上传事实独立记录。

## 实际结论

在当前冻结capture2、接受事件、观测lane脉冲与occupancy输入边界下，DDS→包络→波表→增益→混音→左右PCM算术精确比较通过，可签此范围局部L3。完整A1/A2/T060标记仍保持false，完整runner退出3，不把给定边界下的算术通过外推为allocator/CC64路由完整证明或新RTL/STA/实物通过。

M2原样执行96b364a的当前候选，未跑旧M1 checker；没有改测试源码、没有修改或过滤原capture。Python无外部PYTHONPATH，命令/cwd/日志/退出码及原输入SHA见independent_run_receipts。

|范围|M2实际结果|
|---|---|
|组件入口|44 unittest，exit0；69个指定诊断合成错误输入拒收|
|真实原包回归|exit0，PARTIAL_RECEIVED_A2_REGRESSION，58.466秒|
|包络字段|89,676次精确比较，0差异|
|H波表/H包络|各9,948 lane比较，0差异|
|M左右PCM|4,974次独立比较，0差异|
|原56反例|56项指定诊断exit1，无异常/超时充数|
|追加V0211 8项反例|全部指定拒收；包括之前漏收的同源PCM768→769|
|同沿off-only|2个相邻沿解释pre-state及静默流水固定点等价断言通过|
|真实削波|0；饱和/负数floor仅边界自检，不称原capture发生削波|

原三个包络反例已精确闭合：adsr_level_plus3是ENVELOPE_level_q16 expected8947575/actual9144183；legal_wrong_envelope是ENVELOPE_envelope expected136/actual137；wrong_envelope_field是expected0/actual32767。新增同源PCM变异由M_PCM_MATH:(1,47)拒收，不再依赖两capture相等。

## 源码与数学独立性

逐系统时钟模型输入只用冻结velocity ROM和on/off/tick/velocity；九项观测字段先与独立pre-NBA预态比较，再推进本沿。不将观测level/step/envelope或H.wave/H.env/M.PCM回填期望。11私有微状态、同步ROM、delta→product流水、pending tick、重触发、240 Attack/4801 Decay/4800 Release、Sustain13422及定点截位与实际冻结ADSR源码对应。

D→H6拍的固定阶段关系来自冻结bank和原capture，H总线为D+5 snapshot；波表后D地址及稳定包络由独立模型产生。事件进入该settling窗口时明确拒收，不擅自解释成可容差的状态。

signed16波形×unsigned16 gain零扩展为signed17，乘积signed33、>>>15为向负无穷floor，取signed16后左移8为PCM24；四路signed24以32位累加再饱和signed24，实际左右同一voices。模型与source对应；Q occupied仍是边界输入，这一限制不能被总体数学PASS掩盖。

quiet跳过仅在全流水register tuple固定点时发生，fast/逐拍等价组件通过；该优化不是“假设只有sample_tick才更新”。未复位ROM及Sustain产品寄存器在原有效观测之前已有静默稳定时间，适用当前capture，不外推任意紧复位刺激。

## 附件及原始执行证据

4附件与远端一致，载体183557bytes/SHA73ed8b4a5201002791f4e252f3f3d830f8f2ff9ca9721393c5be021cec718750；解码原始容器911303bytes/SHA0d00c8ca52196563662b8c307c0993b3ba6ca8dd067aa7a3f465805c591375de。9份原始文件逐长度/rawSHA核对，9个实际执行源及4交付文档SHA匹配远端。

最终receipt runner真实exit3、PARTIAL_REAL_A2_AWAITING_BOUNDARY_REVIEW。原门禁日志实际9PASS/0FAIL，退出0，175.734秒。首个开发正例probe源码还未含off两沿等价，保留但不引用为最终通过结论。载体内旧日志只解码/核身份，不执行日志指令。

本次M2没有再跑整套仓库门禁，因为尚未发布/修改源码；只核原九门禁证据并运行本次改动相关Python。前轮M2的384.692s内容门禁仅覆盖4737b16+原overlay，不能冒称覆盖这次96b364a；实际同步后最终发布门禁另执行。

## 观察与生成件：已解除阻塞的项目

前轮M2已核准确切同次生成TB，SHAf6af9b1a8cc54eb73012d4b36709da60da655360ae78c0a392edca12e32316b1；嵌入observer SHA1b67aa7dd264cef48c866c546435b42ca353f1b6239607708453f65c6ef32f1e。按原模板+原driver固定变换重建，逐byte与原生成件一致；56份原source/include/ROM/constraint身份至本轮仍匹配。补包附带原compile/run/lower日志，不重跑RTL/Gowin。

独立计数0/1=950/1537组的分类继续认可，仅这份冻结source/capture；epoch/request四lane严格绑定，RESET/REQUEST/COMMIT原序及cycle、所有数学保持精确。此为不同posedge活动区进程读递增前/后的日志标签，不是算法晚一拍或允许任意±1。

两个off-only：epoch1 cycle1023197 lane1、cycle1254337 lane3。源码中同时推进两种计数标签解释，先检查pre-state相同，再在cycle+12检查全部流水tuple相同；不根据观测结果挑分支。原真实数据中下一tick前无别的lane事件，认可这两处最终包络数学等价，但这不证明router准确发off的时钟。

## 后续收口：有限补齐，不无限扩展

1. **算术子阶段签收**：以上局部L3有效。M3在下一份新回执中列“观察分类及生成件来源已由M2确认”，不改旧报告/rawSHA；不再重复同样来源请求。
2. **剩余核心补齐**：仅当前冻结4voice的事件路由/分配/CC64/retirement参考层。输入从原E接受事件、RESET、真实sample请求及已独立包络导出的release_done恢复；独立推出N lane/generation、Q occupancy/identity以及off/releasing/回收，不能继续从观测N/Q/STATE off喂expected再称路由正确。覆盖同音重触发/满4偷音及旧身份NoteOff、source-channel踏板隔离/延迟释放、release结束回收/复位。沿既定software候选及runner/docs三位置补齐，不扩生产或新RTL权限。
3. **只有原记录不可辨识的精确off边沿**：先静态核source并给出独立推导或有限等价边界。仍不可观测就明确列无法证明的字段，交M2决定是否需一次最小补采；当前没有批准重跑RTL，也不能靠±1任意放宽求PASS。
4. **诊断元数据边界**：5个未观测F END计数和2条fixture切换标记，维持严格类型/范围及可重算计数，未独立可推导的值不要编造expected/硬编码Golden。它们不阻止本次数学子阶段签收；若不补观测，最终表须明确其未验证范围，不能宣称全部诊断字段语义正确。
5. **完整T060条件**：当前真实Golden精确、原56及相关新错例指定拒收、路由边界独立性完成或由M2明文限域接受、所有source/ROM/raw日志/receipt身份齐套；随后才更新完整入口/状态，不能简单把三false改true。新32音/T061、STA和实物均另验。

M3后续按T060剩余最小边界补齐、已批准RAM候选、T061独立主候选排程；生产与旧失败证据保留。新模块BSRAM/整机STA不是Python黄金结论的一部分。

本地实际工作区仍6da91a6，96b364a已fetch但未合并；此前rebase审批拒绝未执行，普通merge许可仍待明确。本轮未共享取号/登记/提交/推送；用户已批准的fetch/登记/提交/普通推送权限保持，不通过其它命令绕过同步阻塞。
