"""Persist the human's exact one-shot verbose diagnostic authorization."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('D:/17/project_17/fpga_gowin')
OUT = Path(__file__).resolve().parent
BUILD = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017'
authorization = {
    'schema': 'M2_R09_DIAG01_USER_AUTHORIZATION_V1', 'scope': 'R09_DIAG_01_RAW_COMPILE_VERBOSE_ONLY',
    'approved': True, 'user_answer': '授权一次有界编译诊断',
    'source': 'direct human response to request_user_input_async, current conversation',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'group_seconds': 20, 'compile_seconds': 15, 'compile_launches_max': 1,
    'change_from_original_argv': 'insert -v only', 'same_original_two_raw_sources': True,
    'same_tools_and_environment': True, 'VVP_allowed': False, 'boundary_allowed': False,
    'EDA_allowed': False, 'device_allowed': False, 'retry_allowed': False,
    'old_budgets_restored': False, 'old_30_second_repair_consumed_by_this': False,
    'board_release_allowed': False,
}
path = BUILD / 'R09_DIAG_AUTHORIZATION_20261017.json'
with path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(authorization, ensure_ascii=False, indent=2) + '\n')
assert not (OUT / 'R09_DIAG_01').exists()
header = ('## 2026-10-17 用户新增一次有界verbose编译诊断许可\n\n'
          '用户已直接答复“授权一次有界编译诊断”。仅R09_DIAG_01：同一raw两源、同一Icarus/50依赖及固定环境，原argv只增加-v，一次compile≤15秒/整组≤20秒，结束即封存；不启动VVP/boundary/EDA/设备，不重试、不恢复旧SW/UNIT01或消费旧30秒条件修复。准入原件在C8 build/R09_DIAG_AUTHORIZATION_20261017.json。该新许可不改变旧0xC0000005失败，也不放行C9/完整链；Pro仍PARTIAL、board_release_allowed=false。下方“诊断待批准”是形成时历史，当前以本许可及后续实际回执为准。\n\n')
states = ['code/docs/M2_Pro基础最小单元执行单_R09_2026-10-17.md', 'code/docs/M2_完赛任务单_2026-10-15.md',
          'code/docs/138K四声部后续集成任务总览_2026-10-15.md', 'code/docs/当前状态.md', 'code/docs/任务看板.md']
before = {}
backup = OUT / 'DIAG_AUTH_BEFORE'
backup.mkdir(exist_ok=False)
for rel in states:
    raw = (ROOT / rel).read_bytes()
    before[rel] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    (backup / Path(rel).name).write_bytes(raw)
    first, sep, rest = raw.partition(b'\n')
    assert sep
    (ROOT / rel).write_bytes(first + b'\n\n' + header.encode('utf-8') + rest.lstrip(b'\n'))
(OUT / 'DIAG_AUTH_PREPARED.json').write_text(json.dumps({'states': states, 'before': before, 'header': header,
                                                       'authorization': str(path)}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'authorization_saved': True, 'scope': authorization['scope'], 'group_created': False}, ensure_ascii=False))
