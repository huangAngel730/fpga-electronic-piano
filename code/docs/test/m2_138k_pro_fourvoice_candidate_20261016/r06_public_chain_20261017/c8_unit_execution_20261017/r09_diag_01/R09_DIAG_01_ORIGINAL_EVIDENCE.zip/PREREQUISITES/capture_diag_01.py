"""Capture only the user-approved R09 diagnostic controller."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ENTRY = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017/run_r09_diag_01.py'


def main():
    folder = OUT / 'LAUNCH_R09_DIAG_01'
    folder.mkdir(exist_ok=False)
    argv = [sys.executable, '-E', '-s', '-S', '-B', '-X', 'utf8', str(ENTRY)]
    record = {'argv': argv, 'cwd': str(ROOT), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (folder / 'START.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
    start = time.monotonic()
    with (folder / 'stdout.raw').open('xb') as stdout, (folder / 'stderr.raw').open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
        code = process.wait()
    record.update({'exit_code': code, 'elapsed_seconds': time.monotonic() - start,
                   'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    for name in ['stdout.raw', 'stderr.raw']:
        raw = (folder / name).read_bytes()
        record[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    (folder / 'RECEIPT.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(record), flush=True)
    for name in ['stdout.raw', 'stderr.raw']:
        print(name + ':\n' + (folder / name).read_text(encoding='utf-8'), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
