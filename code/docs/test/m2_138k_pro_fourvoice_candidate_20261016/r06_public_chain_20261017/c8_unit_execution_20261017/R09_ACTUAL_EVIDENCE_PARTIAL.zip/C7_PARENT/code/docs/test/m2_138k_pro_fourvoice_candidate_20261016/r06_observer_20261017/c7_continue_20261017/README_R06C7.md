# R08下M2 Pro基础续接 C7（本地未发布）

本轮按R08下M2-R6-2自身公开观察/旁带→R6-1合同余项→R6-3精确准入准备继续。远端已核仍为`ef4fbc74b9d24e08de1e09d0be0eb3163118f258`，没有新的待接入提交。**整体仍PARTIAL；本目录是L0候选源码/合同及静态装配，没有新软件功能组、HDL/EDA/设备执行，没有实际TB PASS。** 旧消费/P7/旧Python-dummy执行器不改变。

## 已推进的自身实现

新增组合模块`m2_r06_raw_cancel_reason`，从实际`candidate_cancel=frame_tick`原始控制编码出`00=NONE`、`01=FRAME_BOUNDARY`，`10/11`保留且已知值拒收。直接拼接`{1'b0,raw_cancel}`，X/Z保留为0X/0Z，不吞成0。它没有复位或状态；采集必须用实际`obs_rst_n`/`obs_polyphonic_valid`及独立RESET_EDGES限定有效窗口，不凭原始控制位制造交易CANCEL，不编码不存在的RESET原因，不以reason充req_id，也不放宽严格`t-F<833且早于下一独立FRAME`。

三份新候选采用独立`r06c7`模块/文件名，将`obs_raw_cancel_reason[1:0]`从core经board到outer明确导出，固定音分支输出00且`obs_polyphonic_valid=0`。旧C3三份源码、C4侧带/TB/绑定原件不覆盖。移除新增诊断内容并还原命名后，三份原源码逐字节可还原；该证明只签源码变更范围，不是行为等价仿真。

`NORMALIZED_ROW_SCHEMA_R06C7.json`为明确新版本：原61字段保留，cancel_reason变为有真实原始来源的2位编码，新增`tx_metadata_valid`、`tx_req_id_valid`、`tx_clip_mask`、`metadata_error`、`frame_id_overflow`五字段，共66。旧单bit`tx_clip`继续映射clip-any，不用双clip替换；数值ID0与无效/null分开。此schema只定义表示格式，没有执行schema正负例/跨行状态检查，没有认证真实来源。旧C1/C3 schema和软件收据保持原SHA，不能转签到C7。

新增raw-cause自检TB源码包含0/1/X/Z及返回正常后的转换、独立watchdog和正常结束；仍NOT_RUN。另新增`tb_m2_r06_tx_identity_boundary_c7`，在现有窄ordinal max处补四次tx_valid=0 FRAME，要求counter/overflow保持，恢复实际采纳max后才overflow；追加仅在sidecar公开commit_id上错ID的负例，核即时/粘滞错误、实际PCM/TX/HOLD继续和async reset恢复。不使用私有force，也没有改真实buffer输入。所有断言仅是待运行目标，没有运行check/cycle计数。

## 精确装配与准入

后继源包在`../../r06_public_chain_20261017/c7_continue_20261017/SOURCE_CLOSURE_R06C7.zip`。以C6为基础：71单元中替换三份C7候选、把C3 sidecar明确换为原C4 SHA`40fd5145a9d80bae36ead96b8e1144be84acdf3669aa5c47a26fcef305a54d1e`，再加一个raw编码leaf，共72单元、9ROM、2头、74个唯一字面module、3条literal include边。不是把C6旧C3的SHA叫作C4。C5/C6和C4原件均保留；M1数学/ROM原字节不改。

解包`inputs/`为cwd，`+incdir+include`及`rom/`相对路径仍绑定；具体编译器开关兼容、宏展开/elaboration和行为尚未验证。完整链list不含尚未到件的R7-A/B TB，不声称新完整链可立即运行。

`UNIT_ADMISSION_R06C7.json`只列raw-cause单元与sidecar边界C7单元，两目标六个精确源输入。决定仍`BLOCKED_EXECUTOR_AND_EXACT_TOOL_DEPENDENCIES`、`approved=false`。旧EXE本体观察仅是历史记录，不是完整DLL/VPI/target/config依赖；现有执行器仅Python dummy且未扩权。M3-R6-1/4已到，后者消费端漏洞REWORK_REQUIRED；R7-A/B在当前远端跟踪数各0。旧C4“不曾到件”的表述只保留其当时状态，不再套作当前结论。

## 失败原件与实际检查等级

首个自有源码生成辅助在反向还原检查处因多拼一个空行退出1；尚未写出候选文件、未改原件。失败脚本/原因保留；仅修回退检查后一次重试exit0，实际生成七文件。装配辅助exit0，只做文件生成/哈希/成员回读，未调用任何被审程序、目标验证器、HDL或EDA，不计作新功能组PASS。后续独立静读结果与完整输入/产物身份随本轮本地封存。

## 仍未完成

- M1十九项真实语义/候选出口、实际apply seq与config packing、audio_stable定义和真实实现仍待，不能用accept+1/固定等待/一次TX替代。
- 本轮raw reason是原始控制原因，交易取消是否合法及active ID由独立账本和严格期限判断；没有关闭M3归一器/日历/REAL权威缺陷。
- raw TB、边界TB、普通TB都未编译/仿真，默认32位实际全范围溢出、其他metadata错误分支、完整串行链未验证。
- 真实Part/version/板修订/Bank/商业许可/Pro PLL/完整STA/新.fs/板测仍待，`board_release_allowed=false`。

当前没有完整M2-R6-2结项或可批准的真实工具组合，按根规范保留本地准备原件，不因一个新字段或新增TB源码触发例行推送。本轮未Git暂存/提交/推送、未取V号。给M3的C7合同增量说明为“待用户转发，尚未送达”；既有R08任务顺序/写集和五新组消费不变。
