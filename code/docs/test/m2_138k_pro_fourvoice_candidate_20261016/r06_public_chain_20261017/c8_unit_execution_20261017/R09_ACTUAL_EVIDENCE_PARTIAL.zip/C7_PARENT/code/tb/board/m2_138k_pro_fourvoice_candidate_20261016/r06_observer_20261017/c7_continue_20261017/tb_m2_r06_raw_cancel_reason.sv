`timescale 1ns/1ps
// C7 raw-cause unit source only. NOT_RUN; no HDL permission is implied.
module tb_m2_r06_raw_cancel_reason;
    logic raw_cancel;
    wire [1:0] raw_reason;
    integer checks = 0;
    m2_r06_raw_cancel_reason dut (
        .raw_cancel(raw_cancel), .raw_reason(raw_reason)
    );

    task automatic check(input logic value, input logic [1:0] expected);
        begin
            raw_cancel = value;
            #1;
            if (raw_reason !== expected)
                $fatal(1, "raw_cancel=%b reason=%b expected=%b", value, raw_reason, expected);
            checks = checks + 1;
        end
    endtask

    initial begin
        check(1'b0, 2'b00);
        check(1'b1, 2'b01);
        check(1'bx, 2'b0x);
        check(1'bz, 2'b0z);
        check(1'b0, 2'b00);
        check(1'b1, 2'b01);
        check(1'b0, 2'b00);
        $display("PASS raw_cancel_reason checks=%0d", checks);
        $finish;
    end
    initial begin
        #100;
        $fatal(1, "raw_cancel_reason watchdog");
    end
endmodule
