// M2 C7 successor boundary self-check. NOT_RUN: HDL admission is pending.
// Copies the unchanged C4 baseline; adds max-ordinal gating and one
// commit-ID diagnostic fault injected only at public sidecar inputs.
// Compile only with the frozen pcm_result_hold.sv / pcm_frame_buffer.sv and
// m2_r06_tx_identity_sidecar.sv. This file has not been compiled or simulated.
// Two diagnostic sidecars observe the same public hold/buffer connections.
// ID_WIDTH=2 makes a real request-ID wrap reachable; FRAME_ID_WIDTH=2 makes
// the diagnostic ordinal boundary reachable without any hierarchy access.
// The default sidecar retains its production 32-bit ordinal configuration.
// This is a manually driven unit test, not an I2S, adapter, PLL or board test.
`timescale 1ns/1ps
module tb_m2_r06_tx_identity_boundary_c7;
    localparam logic signed [23:0] PAYLOAD_LEFT = -24'sd123456;
    localparam logic signed [23:0] PAYLOAD_RIGHT = 24'sd654321;
    localparam logic [1:0] PAYLOAD_CLIP = 2'b10;

    logic clk = 1'b0;
    logic rst_n = 1'b1;
    logic frame_tick = 1'b0;
    logic tx_valid = 1'b1;
    logic result_valid = 1'b0;
    logic inject_bad_commit_id = 1'b0;
    logic [1:0] result_id = 2'd0;
    logic [1:0] result_clip_mask = 2'b00;
    logic signed [23:0] result_left = 24'sd0;
    logic signed [23:0] result_right = 24'sd0;

    wire result_ready, pcm_valid, pcm_ready, pcm_clip_any;
    wire [1:0] pcm_req_id, sample_req_id;
    wire signed [23:0] pcm_left, pcm_right;
    wire sample_req, pending_valid;
    wire signed [23:0] play_left, play_right;
    wire [31:0] frame_count, request_count, commit_count, underrun_count;
    wire actual_commit = pcm_valid && pcm_ready;
    // Explicit zero extension preserves legal numeric ID zero and avoids an
    // implicit port-width conversion hiding the request-ID wrap under test.
    wire [31:0] result_id_public = {30'd0, result_id};
    wire [31:0] commit_id_public = {30'd0, pcm_req_id};
    // Only diagnostic inputs see this fault. The frozen buffer and
    // result-hold continue using their actual ID and handshakes.
    wire [31:0] observed_commit_id = inject_bad_commit_id ?
                                      (commit_id_public ^ 32'd1) :
                                      commit_id_public;

    pcm_result_hold #(.ID_WIDTH(2)) u_result_hold (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .calc_ready(1'b1), .current_req_id(sample_req_id),
        .result_valid(result_valid), .result_ready(result_ready),
        .result_req_id(result_id), .result_left(result_left),
        .result_right(result_right), .result_clip_any(|result_clip_mask),
        .pcm_valid(pcm_valid), .pcm_ready(pcm_ready),
        .pcm_req_id(pcm_req_id), .pcm_left(pcm_left),
        .pcm_right(pcm_right), .pcm_clip_any(pcm_clip_any)
    );

    pcm_frame_buffer #(.ID_WIDTH(2)) u_frame_buffer (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .calc_ready(1'b1), .sample_req(sample_req),
        .sample_req_id(sample_req_id), .pcm_valid(pcm_valid),
        .pcm_ready(pcm_ready), .pcm_req_id(pcm_req_id),
        .pcm_left(pcm_left), .pcm_right(pcm_right),
        .play_left(play_left), .play_right(play_right),
        .pending_valid(pending_valid), .audio_frame_count(frame_count),
        .pcm_request_count(request_count), .pcm_commit_count(commit_count),
        .audio_underrun(underrun_count)
    );

    wire full_sample_valid, full_metadata_valid, full_req_id_valid;
    wire [31:0] full_frame_id, full_req_id;
    wire [1:0] full_clip_mask;
    wire full_clip_any, full_hold, full_startup_zero;
    wire signed [23:0] full_left, full_right;
    wire full_error, full_overflow;

    m2_r06_tx_identity_sidecar u_default_sidecar (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .tx_valid(tx_valid), .result_valid(result_valid),
        .result_ready(result_ready), .result_id(result_id_public),
        .result_clip_mask(result_clip_mask), .commit_pulse(actual_commit),
        .commit_id(observed_commit_id), .commit_left(pcm_left),
        .commit_right(pcm_right), .buffer_pending_valid(pending_valid),
        .play_left(play_left), .play_right(play_right),
        .tx_sample_valid(full_sample_valid),
        .tx_metadata_valid(full_metadata_valid),
        .tx_req_id_valid(full_req_id_valid), .tx_frame_id(full_frame_id),
        .tx_req_id(full_req_id), .tx_clip_mask(full_clip_mask),
        .tx_clip_any(full_clip_any), .tx_hold(full_hold),
        .tx_startup_zero(full_startup_zero), .tx_left(full_left),
        .tx_right(full_right), .metadata_error(full_error),
        .frame_id_overflow(full_overflow)
    );

    wire short_sample_valid, short_metadata_valid, short_req_id_valid;
    wire [31:0] short_frame_id, short_req_id;
    wire [1:0] short_clip_mask;
    wire short_clip_any, short_hold, short_startup_zero;
    wire signed [23:0] short_left, short_right;
    wire short_error, short_overflow;

    m2_r06_tx_identity_sidecar #(.FRAME_ID_WIDTH(2)) u_short_sidecar (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .tx_valid(tx_valid), .result_valid(result_valid),
        .result_ready(result_ready), .result_id(result_id_public),
        .result_clip_mask(result_clip_mask), .commit_pulse(actual_commit),
        .commit_id(observed_commit_id), .commit_left(pcm_left),
        .commit_right(pcm_right), .buffer_pending_valid(pending_valid),
        .play_left(play_left), .play_right(play_right),
        .tx_sample_valid(short_sample_valid),
        .tx_metadata_valid(short_metadata_valid),
        .tx_req_id_valid(short_req_id_valid), .tx_frame_id(short_frame_id),
        .tx_req_id(short_req_id), .tx_clip_mask(short_clip_mask),
        .tx_clip_any(short_clip_any), .tx_hold(short_hold),
        .tx_startup_zero(short_startup_zero), .tx_left(short_left),
        .tx_right(short_right), .metadata_error(short_error),
        .frame_id_overflow(short_overflow)
    );

    integer checks = 0;
    integer cycles = 0;

    task automatic must(input logic condition, input string message);
        begin
            checks = checks + 1;
            if (condition !== 1'b1) begin
                $display("FAIL cycle=%0d: %s", cycles, message);
                $fatal(1, "M2_R06_SIDECAR_BOUNDARY_C7_FAIL");
            end
        end
    endtask

    // All ordinary observation fields are checked with stable inputs before
    // the active edge (POSEDGE_PRE_NBA). No DUT internal state is accessed.
    // The following call observes the previous edge's ordinal/overflow update.
    task automatic cycle_check(
        input string label,
        input logic expected_ready,
        input logic expected_commit,
        input logic expected_pending,
        input logic expected_sample,
        input logic expected_startup,
        input logic expected_hold,
        input logic expected_identity,
        input logic [31:0] expected_id,
        input logic [1:0] expected_clip,
        input logic signed [23:0] expected_left,
        input logic signed [23:0] expected_right,
        input logic [31:0] expected_full_ordinal,
        input logic [31:0] expected_short_ordinal,
        input logic expected_short_overflow
    );
        begin
            #2;
            must(clk === 1'b0, {label, ": clock-low setup"});
            must(rst_n === 1'b1, {label, ": reset released"});
            must(result_ready === expected_ready, {label, ": result ready"});
            must(actual_commit === expected_commit, {label, ": real commit"});
            must(pending_valid === expected_pending, {label, ": real pending"});
            must(full_sample_valid === expected_sample,
                 {label, ": default actual TX adoption"});
            must(short_sample_valid === expected_sample,
                 {label, ": short actual TX adoption"});
            must(full_metadata_valid === expected_sample,
                 {label, ": default metadata validity"});
            must(short_metadata_valid ===
                 (expected_sample && !expected_short_overflow),
                 {label, ": short metadata validity"});
            must(full_req_id_valid === expected_identity,
                 {label, ": default identity validity"});
            must(short_req_id_valid ===
                 (expected_identity && !expected_short_overflow),
                 {label, ": short identity validity"});
            must(full_req_id === expected_id && short_req_id === expected_id,
                 {label, ": raw saved identity in both instances"});
            must(full_clip_mask === expected_clip &&
                 short_clip_mask === expected_clip,
                 {label, ": saved dual clip in both instances"});
            must(full_clip_any === (|expected_clip) &&
                 short_clip_any === (|expected_clip),
                 {label, ": saved scalar clip in both instances"});
            must(full_hold === expected_hold && short_hold === expected_hold,
                 {label, ": actual HOLD in both instances"});
            must(full_startup_zero === expected_startup &&
                 short_startup_zero === expected_startup,
                 {label, ": actual startup in both instances"});
            must(full_left === expected_left && short_left === expected_left &&
                 play_left === expected_left,
                 {label, ": actual left PCM in both instances"});
            must(full_right === expected_right &&
                 short_right === expected_right && play_right === expected_right,
                 {label, ": actual right PCM in both instances"});
            must(full_frame_id === expected_full_ordinal,
                 {label, ": default ordinal"});
            must(short_frame_id === expected_short_ordinal,
                 {label, ": saturated zero-extended short ordinal"});
            must(full_overflow === 1'b0,
                 {label, ": default ordinal has not overflowed"});
            must(short_overflow === expected_short_overflow,
                 {label, ": short ordinal overflow"});
            must(full_error === 1'b0 && short_error === 1'b0,
                 {label, ": legal source sequence has no metadata error"});
            if (expected_ready && result_valid) begin
                must(sample_req_id === 2'd0 && result_id_public === 32'd0,
                     {label, ": real current generation is legal ID zero"});
                must(result_left === PAYLOAD_LEFT &&
                     result_right === PAYLOAD_RIGHT &&
                     result_clip_mask === PAYLOAD_CLIP,
                     {label, ": source tuple accepted for ID zero"});
            end
            if (expected_commit) begin
                must(pcm_valid === 1'b1 && pcm_ready === 1'b1,
                     {label, ": frozen modules really handshake"});
                must(commit_id_public === 32'd0 &&
                     pcm_left === PAYLOAD_LEFT && pcm_right === PAYLOAD_RIGHT &&
                     pcm_clip_any === (|PAYLOAD_CLIP),
                     {label, ": frozen result hold saved ID zero and PCM"});
            end
            #3 clk = 1'b1;
            #1 clk = 1'b0;
            #1;
            cycles = cycles + 1;
        end
    endtask

    // Reset observations intentionally occur between edges: the asynchronous
    // assertion must clear identities, PCM, diagnostics and both counters
    // without a clock. The next cycle_check resumes PRE_NBA observation.
    task automatic assert_reset;
        begin
            frame_tick = 1'b0;
            result_valid = 1'b0;
            inject_bad_commit_id = 1'b0;
            tx_valid = 1'b1;
            must(clk === 1'b0, "async reset starts with clock low");
            #1 rst_n = 1'b0;
            #1;
            must(clk === 1'b0, "async reset does not create a clock edge");
            must(pending_valid === 1'b0 && pcm_valid === 1'b0 &&
                 sample_req_id === 2'd0,
                 "async reset clears frozen hold/buffer generation and storage");
            must(full_sample_valid === 1'b0 && short_sample_valid === 1'b0,
                 "async reset masks actual adoption in both instances");
            must(full_metadata_valid === 1'b0 && short_metadata_valid === 1'b0 &&
                 full_req_id_valid === 1'b0 && short_req_id_valid === 1'b0,
                 "async reset invalidates both metadata and identity labels");
            must(full_frame_id === 32'd0 && short_frame_id === 32'd0 &&
                 full_overflow === 1'b0 && short_overflow === 1'b0,
                 "async reset clears both ordinals and overflow flags");
            must(full_error === 1'b0 && short_error === 1'b0,
                 "async reset clears both diagnostic flags");
            must(full_req_id === 32'd0 && short_req_id === 32'd0 &&
                 full_clip_mask === 2'b00 && short_clip_mask === 2'b00 &&
                 full_clip_any === 1'b0 && short_clip_any === 1'b0,
                 "async reset clears saved IDs and clip fields");
            must(full_left === 24'sd0 && short_left === 24'sd0 &&
                 full_right === 24'sd0 && short_right === 24'sd0,
                 "async reset clears actual PCM without a clock");
            must(full_hold === 1'b0 && short_hold === 1'b0 &&
                 full_startup_zero === 1'b0 && short_startup_zero === 1'b0,
                 "async reset masks both adoption classification flags");
            #1 rst_n = 1'b1;
        end
    endtask

    initial begin
        // Independent watchdog; this candidate source remains NOT_RUN.
        #20000;
        $fatal(1, "M2_R06_SIDECAR_BOUNDARY_C7_TIMEOUT");
    end

    initial begin
        assert_reset();
        frame_tick = 1'b1;
        tx_valid = 1'b0;
        cycle_check("gated FRAME does not adopt", 0,0,0, 0,0,0,0,
                    0,2'b00, 0,0, 0,0,0);
        tx_valid = 1'b1;
        cycle_check("valid resumes at unchanged ordinal zero", 0,0,0, 1,1,0,0,
                    0,2'b00, 0,0, 0,0,0);

        // Rebase both counters and the real 2-bit request generator. Exactly
        // four actual adoptions now make request IDs 1,2,3,0 at the NBA edges.
        assert_reset();
        frame_tick = 1'b1;
        cycle_check("boundary FRAME ordinal zero", 0,0,0, 1,1,0,0,
                    0,2'b00, 0,0, 0,0,0);
        cycle_check("boundary FRAME ordinal one", 0,0,0, 1,1,0,0,
                    0,2'b00, 0,0, 1,1,0);
        cycle_check("boundary FRAME ordinal two", 0,0,0, 1,1,0,0,
                    0,2'b00, 0,0, 2,2,0);
        // Pause at the actual saturated value before it is adopted. Four
        // gated FRAME edges keep the real 2-bit request generator at the same
        // generation modulo four, preserving the later legal numeric ID zero.
        // All four must leave the ordinal at max with overflow still clear.
        tx_valid = 1'b0;
        cycle_check("max ordinal pause one does not adopt", 0,0,0,
                    0,0,0,0, 0,2'b00, 0,0, 3,3,0);
        cycle_check("max ordinal pause two does not overflow", 0,0,0,
                    0,0,0,0, 0,2'b00, 0,0, 3,3,0);
        cycle_check("max ordinal pause three preserves counters", 0,0,0,
                    0,0,0,0, 0,2'b00, 0,0, 3,3,0);
        cycle_check("max ordinal pause four preserves request wrap", 0,0,0,
                    0,0,0,0, 0,2'b00, 0,0, 3,3,0);
        tx_valid = 1'b1;

        // Max is still a valid PRE_NBA label. Overflow is set only by the
        // edge after this check, never early enough to suppress this sample.
        cycle_check("max ordinal is the final legal short label", 0,0,0,
                    1,1,0,0, 0,2'b00, 0,0, 3,3,0);

        frame_tick = 1'b0;
        result_valid = 1'b1;
        result_id = 2'd0;
        result_left = PAYLOAD_LEFT;
        result_right = PAYLOAD_RIGHT;
        result_clip_mask = PAYLOAD_CLIP;
        cycle_check("real wrapped ID zero result acceptance", 1,0,0,
                    0,0,0,0, 0,2'b00, 0,0, 4,3,1);

        // Change the live result fields before the real next-cycle commit.
        // Both sidecars must retain the accepted dual clip instead.
        result_valid = 1'b0;
        result_id = 2'd3;
        result_left = 24'sd999;
        result_right = -24'sd888;
        result_clip_mask = 2'b01;
        cycle_check("real ID zero commit saves accepted tuple", 0,1,0,
                    0,0,0,0, 0,2'b00, 0,0, 4,3,1);

        frame_tick = 1'b1;
        cycle_check("ID zero TX remains actual after short overflow", 0,0,1,
                    1,0,0,1, 0,PAYLOAD_CLIP,
                    PAYLOAD_LEFT,PAYLOAD_RIGHT, 4,3,1);

        tx_valid = 1'b0;
        cycle_check("gated held FRAME preserves counters and tuple", 0,0,0,
                    0,0,0,0, 0,PAYLOAD_CLIP,
                    PAYLOAD_LEFT,PAYLOAD_RIGHT, 5,3,1);
        tx_valid = 1'b1;
        cycle_check("HOLD resumes with valid numeric ID zero", 0,0,0,
                    1,0,1,1, 0,PAYLOAD_CLIP,
                    PAYLOAD_LEFT,PAYLOAD_RIGHT, 5,3,1);

        // The prior sequence leaves real held PCM and a sticky short overflow.
        // Reset must recover both without manufacturing an intervening clock.
        assert_reset();
        frame_tick = 1'b1;
        cycle_check("async reset restarts at clean ordinal zero", 0,0,0,
                    1,1,0,0, 0,2'b00, 0,0, 0,0,0);
        cycle_check("both counters progress after reset recovery", 0,0,0,
                    1,1,0,0, 0,2'b00, 0,0, 1,1,0);

        // After the existing reset/recovery two FRAMEs, finish a genuine
        // 2-bit request-ID wrap. No private counter force is used.
        cycle_check("fault setup request generation three", 0,0,0,
                    1,1,0,0, 0,2'b00, 0,0, 2,2,0);
        cycle_check("fault setup request generation zero", 0,0,0,
                    1,1,0,0, 0,2'b00, 0,0, 3,3,0);
        frame_tick = 1'b0;
        result_valid = 1'b1;
        result_id = 2'd0;
        result_left = PAYLOAD_LEFT;
        result_right = PAYLOAD_RIGHT;
        result_clip_mask = PAYLOAD_CLIP;
        cycle_check("fault setup accepts real ID zero", 1,0,0,
                    0,0,0,0, 0,2'b00, 0,0, 4,3,1);

        // Negative case: actual hold/buffer commit ID remains zero, but both
        // diagnostic observers see ID one. The mismatch must be visible at
        // PRE_NBA, invalidate labels, and remain sticky through TX and HOLD.
        result_valid = 1'b0;
        inject_bad_commit_id = 1'b1;
        #2;
        must(clk === 1'b0 && rst_n === 1'b1 && frame_tick === 1'b0,
             "mismatched commit setup is before the active edge");
        must(actual_commit === 1'b1 && pcm_valid === 1'b1 && pcm_ready === 1'b1,
             "mismatched sidecar label does not prevent the actual commit");
        must(commit_id_public === 32'd0 && observed_commit_id === 32'd1,
             "only the public diagnostic commit ID is mismatched");
        must(full_error === 1'b1 && short_error === 1'b1,
             "commit-ID mismatch is diagnosed before the commit edge");
        must(full_sample_valid === 1'b0 && short_sample_valid === 1'b0 &&
             full_metadata_valid === 1'b0 && short_metadata_valid === 1'b0 &&
             full_req_id_valid === 1'b0 && short_req_id_valid === 1'b0,
             "non-TX commit edge has no sample or usable label");
        #3 clk = 1'b1;
        #1 clk = 1'b0;
        #1;
        cycles = cycles + 1;

        inject_bad_commit_id = 1'b0;
        frame_tick = 1'b1;
        #2;
        must(pending_valid === 1'b1 && actual_commit === 1'b0,
             "actual buffer holds the committed tuple before TX");
        must(full_sample_valid === 1'b1 && short_sample_valid === 1'b1,
             "bad metadata never suppresses actual pending TX adoption");
        must(full_error === 1'b1 && short_error === 1'b1 &&
             full_metadata_valid === 1'b0 && short_metadata_valid === 1'b0 &&
             full_req_id_valid === 1'b0 && short_req_id_valid === 1'b0,
             "mismatched ID remains unusable after the injection is removed");
        must(full_req_id === 32'd1 && short_req_id === 32'd1 &&
             full_clip_mask === PAYLOAD_CLIP && short_clip_mask === PAYLOAD_CLIP,
             "raw rejected ID and original saved dual clip remain observable");
        must(full_left === PAYLOAD_LEFT && short_left === PAYLOAD_LEFT &&
             full_right === PAYLOAD_RIGHT && short_right === PAYLOAD_RIGHT,
             "diagnostic fault leaves actual TX PCM untouched");
        must(full_startup_zero === 1'b0 && short_startup_zero === 1'b0 &&
             full_hold === 1'b0 && short_hold === 1'b0,
             "invalid pending identity is not reclassified as startup");
        must(full_frame_id === 32'd4 && short_frame_id === 32'd3 &&
             full_overflow === 1'b0 && short_overflow === 1'b1,
             "pending fault preserves the independent ordinal states");
        #3 clk = 1'b1;
        #1 clk = 1'b0;
        #1;
        cycles = cycles + 1;

        #2;
        must(pending_valid === 1'b0 && full_hold === 1'b1 && short_hold === 1'b1 &&
             full_sample_valid === 1'b1 && short_sample_valid === 1'b1,
             "bad identity is retained as actual HOLD after the pending TX");
        must(full_error === 1'b1 && short_error === 1'b1 &&
             full_metadata_valid === 1'b0 && short_metadata_valid === 1'b0 &&
             full_req_id_valid === 1'b0 && short_req_id_valid === 1'b0 &&
             full_startup_zero === 1'b0 && short_startup_zero === 1'b0,
             "HOLD cannot turn invalid identity into null startup metadata");
        must(full_left === PAYLOAD_LEFT && short_left === PAYLOAD_LEFT &&
             full_right === PAYLOAD_RIGHT && short_right === PAYLOAD_RIGHT &&
             full_clip_mask === PAYLOAD_CLIP && short_clip_mask === PAYLOAD_CLIP,
             "held PCM and clip survive the invalid label");
        #3 clk = 1'b1;
        #1 clk = 1'b0;
        #1;
        cycles = cycles + 1;
        assert_reset();
        frame_tick = 1'b1;
        cycle_check("async reset clears mismatched commit diagnostic", 0,0,0,
                    1,1,0,0, 0,2'b00, 0,0, 0,0,0);

        // Reaching the 2-bit boundary is not a simulation of 2**32 samples
        // and does not establish default-width overflow or physical timing.
        $display("PASS M2_R06_SIDECAR_BOUNDARY_C7 cycles=%0d checks=%0d", cycles, checks);
        $finish;
    end
endmodule
