"""Read PE/COFF bytes and configuration only; no process or DLL loading."""
from collections import deque
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import time


OUT=Path(__file__).parent
SUITE=Path('D:/Gowin/oss-cad-suite')
IVL=SUITE/'lib/ivl'
SYSTEM=Path(os.environ.get('SystemRoot','C:/Windows'))/'System32'
MAX_PE=512

def ident(path):
    raw=path.read_bytes()
    return raw,{'path':path.resolve().as_posix(),'bytes':len(raw),
                'sha256':hashlib.sha256(raw).hexdigest()}


class PE:
    def __init__(self,path):
        self.path=path
        self.raw,self.identity=ident(path)
        raw=self.raw
        if raw[:2]!=b'MZ':raise ValueError('NOT_MZ')
        self.pe=struct.unpack_from('<I',raw,0x3c)[0]
        if raw[self.pe:self.pe+4]!=b'PE\0\0':raise ValueError('NOT_PE')
        self.machine,self.sections_count,_,_,_,self.optional_size,self.characteristics=struct.unpack_from('<HHIIIHH',raw,self.pe+4)
        optional=self.pe+24
        magic=struct.unpack_from('<H',raw,optional)[0]
        if magic==0x20b:
            self.pointer_width=8;directory=optional+112
            self.image_base=struct.unpack_from('<Q',raw,optional+24)[0]
            count=struct.unpack_from('<I',raw,optional+108)[0]
        elif magic==0x10b:
            self.pointer_width=4;directory=optional+96
            self.image_base=struct.unpack_from('<I',raw,optional+28)[0]
            count=struct.unpack_from('<I',raw,optional+92)[0]
        else:raise ValueError('UNKNOWN_OPTIONAL_MAGIC')
        self.directories=[struct.unpack_from('<II',raw,directory+8*i) for i in range(min(count,16))]
        self.headers_size=struct.unpack_from('<I',raw,optional+60)[0]
        self.sections=[]
        for i in range(self.sections_count):
            offset=optional+self.optional_size+40*i
            name=raw[offset:offset+8].rstrip(b'\0').decode('ascii',errors='replace')
            vsize,rva,rsize,rptr=struct.unpack_from('<IIII',raw,offset+8)
            self.sections.append({'name':name,'virtual_size':vsize,'rva':rva,
                                  'raw_size':rsize,'raw_pointer':rptr})

    def offset(self,rva):
        if rva<self.headers_size:return rva
        for s in self.sections:
            if s['rva']<=rva<s['rva']+max(s['virtual_size'],s['raw_size']):
                delta=rva-s['rva']
                if delta>=s['raw_size']:raise ValueError('RVA_NOT_FILE_BACKED')
                return s['raw_pointer']+delta
        raise ValueError('RVA_NOT_MAPPED:'+hex(rva))

    def string(self,rva):
        offset=self.offset(rva)
        end=self.raw.find(b'\0',offset,min(len(self.raw),offset+8192))
        if end<0:raise ValueError('UNTERMINATED_PE_STRING')
        return self.raw[offset:end].decode('ascii',errors='replace')

    def thunks(self,rva):
        if not rva:return []
        result=[];offset=self.offset(rva)
        high=1<<(self.pointer_width*8-1)
        fmt='<Q' if self.pointer_width==8 else '<I'
        for i in range(16384):
            value=struct.unpack_from(fmt,self.raw,offset+i*self.pointer_width)[0]
            if not value:break
            result.append('#'+str(value&0xffff) if value&high else self.string(value+2))
        else:raise ValueError('THUNK_COUNT_LIMIT')
        return result

    def imports(self):
        result=[]
        for index,delayed,size in [(1,False,20),(13,True,32)]:
            if len(self.directories)<=index:continue
            rva,length=self.directories[index]
            if not rva:continue
            offset=self.offset(rva)
            for i in range(4096):
                words=struct.unpack_from('<'+'I'*(size//4),self.raw,offset+size*i)
                if not any(words):break
                if delayed:
                    attr=words[0]
                    name=words[1] if attr&1 else words[1]-self.image_base
                    thunk=words[4] or words[3]
                    if not attr&1:thunk-=self.image_base
                else:name=words[3];thunk=words[0] or words[4]
                result.append({'dll':self.string(name),'delayed':delayed,
                               'symbols':self.thunks(thunk)})
            else:raise ValueError('IMPORT_DESCRIPTOR_LIMIT')
        return result

    def forwarded_exports(self):
        if not self.directories:return {}
        rva,size=self.directories[0]
        if not rva:return {}
        p=self.offset(rva)
        fields=struct.unpack_from('<IIHHIIIIIII',self.raw,p)
        ordinal_base,nfunc,nnames,functions,names,ordinals=fields[5:]
        funcs=struct.unpack_from('<'+'I'*nfunc,self.raw,self.offset(functions)) if nfunc else []
        result={}
        for i,value in enumerate(funcs):
            if rva<=value<rva+size:result['#'+str(ordinal_base+i)]=self.string(value)
        for i in range(nnames):
            name_rva=struct.unpack_from('<I',self.raw,self.offset(names)+4*i)[0]
            ordinal=struct.unpack_from('<H',self.raw,self.offset(ordinals)+2*i)[0]
            if ordinal<nfunc and rva<=funcs[ordinal]<rva+size:
                result[self.string(name_rva)]=self.string(funcs[ordinal])
        return result

    def report(self):
        imports=self.imports()
        dangerous={'LoadLibraryA','LoadLibraryW','LoadLibraryExA','LoadLibraryExW',
                   'GetProcAddress','CreateProcessA','CreateProcessW','WinExec',
                   'ShellExecuteA','ShellExecuteW','system','_wsystem','_popen',
                   '_wpopen','_spawnv','_spawnvp','_execv','_execvp'}
        return {**self.identity,'machine':hex(self.machine),'pointer_width':self.pointer_width,
                'imports':imports,'delay_imports_present':any(i['delayed'] for i in imports),
                'dynamic_or_process_imports':sorted({s for i in imports for s in i['symbols']} & dangerous),
                'forwarded_export_count':len(self.forwarded_exports())}


def api_set_map():
    path=SYSTEM/'apisetschema.dll'
    pe=PE(path)
    section=next(s for s in pe.sections if s['name']=='.apiset')
    data=pe.raw[section['raw_pointer']:section['raw_pointer']+section['raw_size']]
    version,size,flags,count,entries,hash_offset,hash_factor=struct.unpack_from('<7I',data,0)
    if version!=6:raise ValueError('API_SET_SCHEMA_VERSION_NOT_IMPLEMENTED:'+str(version))
    def u16(offset,length):return data[offset:offset+length].decode('utf-16-le')
    mapping={}
    for i in range(count):
        _,name_offset,name_length,_,value_offset,value_count=struct.unpack_from('<6I',data,entries+24*i)
        name=u16(name_offset,name_length).lower()+'.dll'
        values=[]
        for j in range(value_count):
            _,alias_offset,alias_length,host_offset,host_length=struct.unpack_from('<5I',data,value_offset+20*j)
            values.append({'alias':u16(alias_offset,alias_length),'host':u16(host_offset,host_length)})
        mapping[name]=values
    return mapping,{**pe.identity,'namespace_version':version,'contracts':count,
                    'source':'static .apiset section bytes; not live process resolution'}


def main():
    started=time.monotonic()
    apis,api_identity=api_set_map()
    search_dirs=[SUITE/'bin',SUITE/'lib',IVL,SYSTEM]
    directory_entries={p:{c.name.casefold():c for c in p.iterdir() if c.is_file()} for p in search_dirs}
    roots=[SUITE/'bin/iverilog.exe',SUITE/'bin/vvp.exe',IVL/'ivl.exe',IVL/'ivlpp.exe',IVL/'vvp.tgt']
    roots += sorted(IVL.glob('*.vpi'))
    queue=deque(roots);seen={};edges=[];unresolved=[];parse_errors=[]
    forward_requests=[]
    def resolve(dll,importer,symbols,kind):
        name=dll.lower()
        if not name.endswith('.dll'):name+='.dll'
        if name.startswith(('api-ms-','ext-ms-')):
            values=apis.get(name,[])
            defaults=[v['host'] for v in values if not v['alias'] and v['host']]
            hosts=defaults or sorted({v['host'] for v in values if v['host']})
            if not hosts:
                unresolved.append({'importer':str(importer),'dll':name,'kind':kind,'reason':'API_SET_CONTRACT_NO_STATIC_HOST'})
                return
            for host in hosts:
                edges.append({'importer':str(importer),'requested':name,'kind':'API_SET_CONTRACT','host':host,
                              'candidate_only':True,'alias_conditional':not bool(defaults)})
                resolve(host,importer,symbols,'API_SET_HOST')
            return
        dirs=[importer.parent]+[p for p in search_dirs if p!=importer.parent]
        candidates=[]
        for folder in dirs:
            entries=directory_entries.get(folder)
            if entries is None:
                entries={c.name.casefold():c for c in folder.iterdir() if c.is_file()}
                directory_entries[folder]=entries
            if name in entries and entries[name] not in candidates:candidates.append(entries[name])
        if not candidates:
            unresolved.append({'importer':str(importer),'dll':name,'kind':kind,'reason':'NO_FILE_IN_DECLARED_STATIC_SEARCH_DIRECTORIES'})
            return
        chosen=candidates[0]
        edges.append({'importer':str(importer),'requested':name,'kind':kind,
                      'resolved_candidate':chosen.resolve().as_posix(),
                      'candidates':[p.resolve().as_posix() for p in candidates],
                      'actual_windows_loader_resolution_verified':False})
        queue.append(chosen)
        forward_requests.append((chosen,importer,symbols))
    processed_forward=set()
    while queue or forward_requests:
        while queue:
            p=queue.popleft()
            key=p.resolve().as_posix().casefold()
            if key in seen:continue
            if len(seen)>=MAX_PE:raise ValueError('PE_FILE_LIMIT')
            try:
                pe=PE(p);seen[key]=(p,pe,pe.report())
                for imp in pe.imports():resolve(imp['dll'],p,imp['symbols'],'DELAY_IMPORT' if imp['delayed'] else 'STATIC_IMPORT')
            except (ValueError,struct.error,StopIteration) as error:
                parse_errors.append({'path':p.as_posix(),'error':type(error).__name__+':'+str(error)})
        current=forward_requests;forward_requests=[]
        for selected,importer,symbols in current:
            k=selected.resolve().as_posix().casefold()
            if k not in seen:continue
            exports=seen[k][1].forwarded_exports()
            for sym in symbols:
                f=exports.get(sym)
                if not f:continue
                key=(k,sym,f)
                if key in processed_forward:continue
                processed_forward.add(key)
                module,forward_symbol=f.rsplit('.',1)
                edges.append({'importer':selected.as_posix(),'kind':'EXPORTED_FORWARDER','symbol':sym,'forwarded_to':f})
                resolve(module,selected,[forward_symbol],'FORWARDED_DLL')

    component_files=[];configs={};hints={}
    for p in sorted(IVL.rglob('*')):
        if not p.is_file():continue
        raw,identity=ident(p)
        component_files.append(identity)
        if p.suffix=='.conf':configs[p.relative_to(IVL).as_posix()]={'identity':identity,'text':raw.decode('utf-8',errors='replace')}
    for p in roots:
        raw=p.read_bytes()
        strings=[s.decode('ascii') for s in re.findall(rb'[\x20-\x7e]{5,}',raw)]
        selected=[s for s in strings if any(v in s.lower() for v in ['.vpi','.tgt','.conf','ivlpp','/ivl','\\ivl','v2009','system.vpi'])]
        hints[p.resolve().as_posix()]=selected[:100]
    records=[entry[2] for entry in seen.values()]
    same_after=all(ident(p)[1]==report['path'] and False for p,pe,report in [])  # replaced below; no re-execution
    changed=[]
    for p,_,report in seen.values():
        if ident(p)[1]!={k:report[k] for k in ['path','bytes','sha256']}:changed.append(p.as_posix())
    by_root={p.resolve().as_posix():seen[p.resolve().as_posix().casefold()][2] for p in roots}
    plan={
      'schema':'M2_C8_STATIC_ICARUS_DEPENDENCY_INVENTORY_V1',
      'created_utc':datetime.now(timezone.utc).isoformat(),
      'scope':'read/parse/hash only; no EXE launch, DLL loading, tool execution or version query',
      'root_tools':by_root,
      'static_resolution_search_directories':[p.as_posix() for p in search_dirs],
      'PE_files':records,'dependency_edges':edges,'unresolved_static_entries':unresolved,
      'PE_parse_errors':parse_errors,'api_set_schema':api_identity,
      'ivl_directory_files':component_files,'configuration_files':configs,
      'binary_string_hints_untrusted_not_behavior_proof':hints,
      'inputs_changed_during_inventory':changed,
      'static_file_identity_status':'IDENTIFIED' if not changed else 'INPUT_CHANGED',
      'static_graph_status':'RESOLVED_CANDIDATES_ONLY' if not unresolved and not parse_errors else 'PARTIAL_STATIC_GRAPH',
      'actual_runtime_loaded_DLLs_verified':False,
      'remaining_dynamic_unknowns':[
          'Windows loader KnownDLL/SxS/redirection/package search behavior not observed; paths are static candidates',
          'LoadLibrary/GetProcAddress module names built at runtime and VPI dlopen requests cannot be proven by PE imports',
          'driver runtime component prefix/cwd/environment/temp paths not executed; must be explicitly bound before admission',
          'compiled VVP dynamic VPI-module directives not yet generated or inspected; bind permitted module folder/list after compilation',
          'compiler/target/preprocessor command shape and exact tool syntax have not been executed',
          'API-set schema static mapping is not a live process load trace',
          'OS servicing may change System32 identities; hash-check selected files immediately before execution'],
      'environment_script_note':'environment.ps1 and environment.bat launch gdk-pixbuf-query-loaders.exe; not executed; construct required environment directly',
      'board_release_allowed':False,'execution_admission':None,'actual_level':'L0_STATIC_TOOL_FILES',
      'tool_process_launches':0,'DLL_loads':0,'elapsed_seconds':time.monotonic()-started}
    (OUT/'TOOL_INVENTORY.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    summary={'status':plan['static_graph_status'],'roots':[{k:r[k] for k in ['path','bytes','sha256','machine','dynamic_or_process_imports']} for r in by_root.values()],
             'PE_files':len(records),'dependency_edges':len(edges),'ivl_files':len(component_files),
             'unresolved_static_entries':unresolved,'PE_parse_errors':parse_errors,'inputs_changed':changed,
             'elapsed_seconds':plan['elapsed_seconds'],'tool_process_launches':0,'DLL_loads':0}
    (OUT/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
