"""Preserve the concrete pre-admission controller defect before its fix."""
import json
from pathlib import Path
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ENTRY = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017/run_r09.py'
d = OUT / 'SW_FIX_BEFORE'
d.mkdir(exist_ok=False)
(d / 'run_r09.py').write_bytes(ENTRY.read_bytes())
(d / 'ADMISSION_FAILURE.json').write_text(json.dumps({
    'reason': 'IVL_DIRECTORY_MEMBERS_CHANGED', 'actual_top_level_files': 34,
    'frozen_recursive_files': 36, 'missed_in_top_level_scan': ['include/constants.vams', 'include/disciplines.vams'],
    'HDL_calls': 0, 'UNIT01_consumed': False, 'admission_created': False,
    'auxiliary_capture_first_attempt': 'Python -c quoting SyntaxError; no modification; file script used instead',
}, indent=2) + '\n', encoding='utf-8', newline='\n')
print('FAILURE_AND_SOURCE_PRESERVED')
