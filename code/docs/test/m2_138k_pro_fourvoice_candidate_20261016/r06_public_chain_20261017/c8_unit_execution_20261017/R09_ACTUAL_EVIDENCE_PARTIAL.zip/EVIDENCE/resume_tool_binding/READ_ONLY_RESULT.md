# R09 工具绑定恢复检查（L0，只读）

本子任务不签执行许可，不启动 Icarus、VVP、DLL、夹具或 HDL。只读取本机文件、既有静态图、启动条件与官方说明；只在本目录保存结果。

## 实际身份结果

- 原 `TOOL_FILES.json` 26 项与 `TOOL_RUNTIME_BINDING.json` 的 ivl 目录 36 项合并为 **50 个唯一路径**，本次字节数及 SHA-256 **50/50 核同**。
- ivl 目录递归文件集合与冻结的 36 项一致，没有新增或缺项。22 项应用与配置、3 个 OS 直接边界 DLL、1 个 cmd 候选均保留原身份。
- 57 条应用侧静态导入边的冻结文件都存在，没有新缺件；原 resolver 对 `ivl.exe` 加 `.dll` 的错误不代表安装缺件。
- 8 个应用 DLL 名在 bin/lib/ivl/System32 四个声明候选目录各只有原单一文件。这不等价于完整 Windows loader 搜索顺序观测。
- 本次只读检查 Command Processor AutoRun：HKCU 32/64 位 key absent；HKLM 32/64 位 value absent。未改注册表。
- iverilog/vvp/ivl/ivlpp/cmd 的 `.local`、`.manifest` 共十个旁件均不存在。并不因此排除 PE 内嵌 manifest 或 OS 的其他解析机制。
- 实际主机平台字符串 `Windows-11-10.0.26200-SP0`。此处不核签 Windows 安装或系统动态装载图。

逐项依据：`READ_ONLY_RECHECK.json`。固定消费端清单候选：`TOOL_BINDING_CANDIDATE.json` 的 `tool_files` 字段。后者包含原 26 与 ivl 全目录 36 的 union，额外绑定其他 target/config 文件仅用于身份快照，不授予其他 target 执行权限。

## 给 M2 的消费端字段与执行条件建议

工具字段可使用候选 JSON 内 `tool_files` 50 项，另冻结候选清单本体身份、入口/runtime/helper、Python EXE/DLL、六项单元源码和 C7 原 ZIP。执行前后均核实；不能仅比较清单中的 SHA 文本而不读文件。

固定 Icarus `-B D:/Gowin/oss-cad-suite/lib/ivl -g2012 -t vvp -s <既定单元 top>`，只使用原定六源的相应子集。不得接入任意 `-m/-L/-f/-c`、工具路径、预算、插件或包含目录。默认插件共有 `system.vpi / vhdl_sys.vpi / vhdl_textio.vpi / v2005_math.vpi / va_math.vpi / v2009.vpi`，其本体及静态应用 DLL 已在清单中。

官方文档说明 `vvp -M` 是追加搜索目录，`-M-` 才移除编译内置目录。因此推荐固定 argv 使用 `-M- -M <exact IVL>`，并在第一次 runtime 前读取刚生成的 VVP，逐条核验全部 `:vpi_module`。默认六件可以作为精确的路径/文件身份允许集，其他模块拒收。已有旧 VVP 正文使用 `D:\Gowin\OSS-CA~1\lib\ivl\...` 的 8.3 绝对路径；允许长短路径等价必须使用实际解析后身份与 SHA，而不能裸字符串匹配或只认 basename。旧 VVP 只作为格式提示，不签转新工具组合的运行事实。[Icarus VVP 官方参数说明](https://steveicarus.github.io/iverilog/usage/vvp_flags.html)

环境从固定白名单新建，不从用户环境复制：SystemRoot/WINDIR、COMSPEC、固定 bin/lib/System32 PATH，以及每 step 独占 TMP/TEMP。**现有 `ExactRunner.execute` 已创建私有 tmp 并覆盖 TMP/TEMP，本条不是新增缺陷。** IVERILOG_ICONFIG、IVERILOG_VPI_MODULE_PATH、IVERILOG_DUMPER、PYTHONPATH/PYTHONHOME 不继承。不能 source suite 环境脚本，因为脚本会另起缓存工具。

保持新建独占 cwd，不放 DLL/VPI/EXE，事前单次消费，精确工件身份、静态 VPI 指令核验及本次 Job 内所有子孙的清理记录。不能把根程序返回 0 或 Job 清理成功单独判作 HDL PASS。

## OS 动态边界与可签范围

现有绑定足以陈述“所选应用包及其配置/应用侧静态导入文件已逐项冻结”，还不足以陈述“所有实际加载的 DLL/VPI/内部 shell 已观察并匹配”。Windows 的 DLL redirection、API-set、SxS、已装模块和 KnownDLL 参与解析；即便最初 DLL 使用绝对路径，其依赖仍可按名字解析。因此固定 PATH 和本清单不是完整 DLL 沙箱。[Microsoft DLL 搜索顺序](https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order)

M2 可以在具体限域准入中把当前 Windows 平台作为明确外部 OS 边界接受，保持 `full_dynamic_closure_proven=false`，并仅签两个既定单元及既定预算。若规则要求“全动态图已观测”作为强前置，则当前静态材料仍不满足，不能以本报告代签。模块枚举抽样可能遗漏短命编译子进程，也不能据此自动升级为完整动态闭包；本次没有运行此类观测。

本报告的实际结论为 L0 静态绑定核同；工具启动、目标 DLL 加载、夹具与 HDL 均 0。R09 软件证明和 M2 精确单元准入仍由主窗口决定，Pro 整体 PARTIAL、`board_release_allowed=false`。
