"""M2 admission for the current proven runtime and two exact R09 units."""
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('D:/17/project_17/fpga_gowin')
HERE = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017'
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location('m2_r09_admission_entry', HERE / 'run_r09.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
proof_path = m.OUT / 'SW_FIX_01/GROUP_RECEIPT.json'
proof = json.loads(proof_path.read_text(encoding='utf-8'))
current = m.base_inputs()
assert proof['passed'] is True and proof['inputs_unchanged'] is True and proof['group_deadline_kept'] is True
assert proof['inputs'] == current and len(proof['results']) == 11
assert not (m.OUT / 'UNIT_01').exists()
tools = m.required_tool_files()
m.check_tool_startup_inputs()
sources = m.unit_sources()
source_ids = {name: {'bytes': len(raw), 'sha256': __import__('hashlib').sha256(raw).hexdigest()} for name, raw in sources.items()}
assert len(source_ids) == 6
admission = {
    'schema': 'M2_R09_UNIT_ADMISSION_V1', 'scope': 'R09_UNIT01_RAW_AND_BOUNDARY_ONLY',
    'approved': True, 'approved_by': 'M2 integration', 'approved_utc': m.utc(),
    'authority': 'M2 R09 scoped execution plan; user start execution and resume instructions',
    'runner_inputs': current, 'software_proof_identity': m.identity(proof_path),
    'software_cases': list(proof['results']), 'tool_files': tools,
    'tool_catalog_identity': m.identity(m.TOOL_FILES_SOURCE),
    'tool_binding_identity': m.identity(m.TOOL_BINDING_SOURCE),
    'unit_source_identities': source_ids,
    'group_seconds': 60, 'compile_seconds_each': 15, 'run_seconds_each': 10,
    'launches': ['raw_compile', 'raw_run', 'boundary_compile', 'boundary_run'],
    'fixed_units': m.UNITS, 'environment': m.environment(tool=True),
    'VPI_policy': 'product-declared paths resolve to frozen IVL .vpi files; vvp -M- -M fixed_IVL',
    'tool_application_static_files': 50, 'full_ivl_directory_files': 36,
    'command_processor_AutoRun': 'absent HKCU/HKLM 32/64 at admission; checked again before group',
    'EXE_local_manifest': 'absent for fixed five executables; checked again before group',
    'platform_boundary': 'current installed Windows API-set/SxS/loader and Python standard library accepted as platform for these two local software simulations only',
    'full_dynamic_closure_proven': False,
    'limitation': 'static application identities and observed owned Job lifetime; no claim of complete OS dynamic module inventory',
    'old_budgets_restored': False, 'full_chain_allowed': False, 'Gowin_EDA_allowed': False,
    'device_allowed': False, 'board_release_allowed': False,
}
path = HERE / 'EXECUTION_ADMISSION_R09_UNIT01.json'
with path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(admission, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'approved': True, 'path': str(path), 'identity': m.identity(path), 'tool_files': len(tools), 'source_files': len(sources)}))
