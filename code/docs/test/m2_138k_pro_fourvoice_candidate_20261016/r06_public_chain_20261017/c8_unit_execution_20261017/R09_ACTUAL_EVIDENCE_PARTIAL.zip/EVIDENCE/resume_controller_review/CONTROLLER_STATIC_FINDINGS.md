# R09 controller 静态自审增量

范围：只读 `run_r09.py`、`unit_fixture.py`、C7 raw-cause 与 boundary TB，及理解其调用所需的新 runtime/固定 Windows Job helper。未启动被审入口、fixture、EXE、编译或 HDL；本报告不签执行准入，也不重复 runtime 原三项。

## 1. 软件证明未与当前 runner 实现身份逐项相等

- 位置：`run_r09.py` 的 `units()`，原行 173–177。
- 触发：SW_01 在版本 A 完成；随后 controller/runtime/helper 改为 B。新 admission 将 `runner_inputs` 写为 B，并引用旧 SW_01 的真实 identity。当前检查分别接受 B 的 runner_inputs 和 A 的 passed proof，却没有比较 `proof['inputs'] == base_inputs()`。
- 影响：旧版软件安全结果可被转签到新版单元执行器，不符合先软件安全、后同版精确单元准入。
- 最小修法：消费 UNIT_01 前核 proof 的 scope、严格布尔结果以及 `proof['inputs'] == inputs`（此时 inputs 仍为 base_inputs），不等则拒绝；proof 原件本身也加入前后输入身份核验。不要因拒绝而恢复 SW_01 旧消费。

## 2. JSON 工具列表只被逐项核验，不能证明工具集合齐套

- 位置：`run_r09.py` 原行 178–180，以及固定 IVERILOG/VVP/IVL 常量。
- 触发：admission 的 `tool_files` 为 `{}`，或漏掉固定 iverilog/vvp/ivl/ivlpp、配置、target/VPI 和应用依赖；for 循环对缺项不执行。controller 仍按固定 argv 启动工具。
- 影响：批准文件声称工具冻结但实际启动工具及其必要依赖未绑定；修改被漏项工具不被 check_inputs 发现。固定 argv 没有受到 JSON 改写，本问题是清单可被缩减。
- 最小修法：从已冻结且有精确 identity 的工具绑定原件重建必需路径/身份集合，要求 admission.tool_files 与重建集合相等，并明确静态与尚未观察的动态边界；拒绝缺项、额外项及不一致后才能创建 UNIT_01 消费记录。

## 3. Python 优化模式可移除全部 assert 型准入与 PASS 检查

- 位置：`run_r09.py` 的 `main()` 没有优化模式拒绝；`units()` 原行 172–182、202–210 的准入、工具/源身份、clean_exit 和 TB marker 均使用 assert。
- 触发：用 `python -O run_r09.py units`（或在优化模式中调用 main）；这些 assert 被 Python 编译器删除。读取 JSON 仍进行，但 approved=false、旧 proof 或 TB 无 PASS 都不再由这些条件阻止。
- 影响：入口不再 fail closed；软件组也会跳过大量安全行为断言并可写 passed=true。
- 最小修法：main 最先用普通 if 检查 `sys.flags.optimize != 0` 并 raise PermissionError；关键准入/验收条件使用不可优化删除的显式检查。最终固定调用记录亦保存 sys.flags/argv。

## 阅读范围内其余结论

- 固定 argv 来自源码常量/UNITS 表，admission JSON 当前没有直接构造 argv 的入口。
- SW_01/UNIT_01 由固定目录 mkdir(exist_ok=False) 事前消费；逐 case 同样独占。测试的是重复 case 拒收；固定组目录本身可静读确定拒绝重复，不必为证明重复而再运行一组。
- 90/60 秒组绝对期限和单 step 的 2/4/15/10 秒常量存在，不接受 CLI 时限参数。
- 两 TB 的成功 marker 都在各自最后自检之后输出；raw 共 7 次逐值检查，boundary 有异步复位、max gating、真实 ID0、HOLD 和坏 commit-ID 自检。这里只确认源码结构，不确认语法或行为 PASS。
- fixture orphan/timeout 等待 grandchild.ready，并在超时后写 ESCAPED 标志；controller 同时检查 Job 总进程数和未有 ESCAPED。未执行，不能据此签生命周期成功。

本报告只写本独占 output 路径，未修改源码/任务单/共享状态。
