# C8 独立 unit executor：只读实现建议

日期：2026-10-17。对象：新的、精确白名单 unit executor。性质：M2 内部只读辅助；正式审核制度未开启。本报告没有授予执行许可，没有运行执行器、fixture、编译、HDL、EDA、硬件或其他目标程序，也没有修改旧实现或任务状态。只读取现有源码、已封回执与官方 API 文档；本目录是唯一写入范围。

结论：可以复用旧 R03 的设计思路，不能直接把旧 R03 的软件结论升级成新执行器的工具准入。最小新增重点是：Job 关闭前确认整组收敛、异常全路径保存当前句柄所有权、精确输入和一次消费、功能成功与清理成功分开。旧 owned_executor 不扩权、不修改；M3 plan_adapter 不在范围内。

## 已读版本与旧失败边界

- `code/software/t052_runner_acceptance_candidate_20261012/windows_job.py`，SHA-256 `5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b`，102 行全文。第 68 行仅设 KILL_ON_JOB_CLOSE；77–91 行附着/恢复；93–101 行终止/关闭。
- `code/build/138k_pro_fourvoice_candidate_20261016/executor_guard_successor_20261017/owned_executor.py`，SHA-256 `86227ae2637adf270df056b30ad67c751cb930daad50d1eb788f76228a090979`，全文。50–56 行只接受固定 Python dummy 五种 mode；78–126 行枚举与关闭验证；129–241 行启动、轮询、异常和封存。
- 同目录 `software_dummy.py` 全文，仅用于理解旧双流、三代树、根退出、超时与溢出反例，未运行。
- `code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/executor_guard_successor_20261017/FAILURE_AND_REPAIR_HISTORY.json`、`R03_REPAIR_SUMMARY.json`、`LOCAL_EXECUTION_SCOPE_R03.json`、`RUN_03/keyboard_interrupt_before_attachment/RECEIPT.json`；另读 `code/docs/M2_Pro四声基础来源与执行器自审_2026-10-17.md`。

旧 R01 五种软件行为使用旧源码 `97a2...`，不等于最终 R03 全组实测。R01 后续静态发现 Popen 已创建且尚未附着时，写 metadata 异常可能让 suspended root 留在 Job 外；原记录明确没有观察到实际泄漏。R02 两个定向普通异常使用 `1cd67...`。R03 最终源码只新增一次附着前 KeyboardInterrupt：原始回执 root exit 1、当前 root 句柄 signaled、原异常向外传播、两份原始流均为空且输入前后一致；外层组耗时 0.098566 秒、单 case 0.029494 秒是不同计时，不能混用。SystemExit 只做过静态共路分析。旧组、旧失败原件和旧额度均保留，不要求重跑。

## 具体差距与最小新实现

| 编号 | 现有位置 / 触发 | 对新执行器的影响 | 最小处理 |
|---|---|---|---|
| C8-E1 | `owned_executor.py:78–126,193–199`：只枚举一次成员，随后先关闭 Job，再等待已枚举句柄 | 枚举后新生的子孙不在已保存句柄集合；关闭 Job 的清理机制不能提供之后的 ActiveProcesses=0 查询证据 | 新执行器持有自己的非继承 Job，失败时先显式 TerminateJobObject，Job 仍打开时有界查询收敛；保留当前 root/实际已捕获成员的句柄等待证据。Kill-on-close 保留为最后兜底，不作为 PASS 证据 |
| C8-E2 | `windows_job.py:77–91` 与 `owned_executor.py:177–180,207–233`：外层 attached 标志在 helper 全部返回后才置位，分配成功但恢复失败与尚未分配共用标志 | 新 helper 若仅用一个 attached 标志，无法准确表达 suspended root 归属；中途 BaseException 也必须清理 | 新建 created / assigned / resumed 三个事实状态；从取得本次进程句柄起进入 finally。未 assigned 只终止/等待本次 Popen 当前句柄；已 assigned 则清理本次 Job 全树；记录 Assign/Resume API 的真实结果，不在创建到附着之间写可失败 metadata |
| C8-E3 | `owned_executor.py:106,124–126,202–240`：内层仅 except Exception，最终 snapshot/hash/write 可再次失败 | 第一次 KeyboardInterrupt/SystemExit 可能被封存错误遮蔽；未写出终态不能被上层当成成功 | 资源 finally 覆盖 BaseException 路径；保留 primary_error 与 cleanup_errors/finalization_errors 分列。清理和证据失败均不可清掉首错；处理后原 BaseException 继续传播。写不出完整回执时保持运行未完成/证据不全，不能默认 PASS |
| C8-E4 | `owned_executor.py:184–201`：root 退出后对所有残留成员走 kill-on-close；旧 parent_exit_tree 的“通过”是在测清理机制 | 若新 unit root exit 0 但真实活跃后代仍运行，不能因清理成功而判功能成功 | 功能与清理分别记。root 已退出时，查新鲜 Job 成员并以当前打开、复核属于该 Job 的进程句柄确认是否仍活跃；如存在活跃后代，记 ROOT_EXIT_WITH_LIVE_DESCENDANTS 并终止收敛。ActiveProcesses 暂未降零本身不能直接误认活后代，需区分已退出但仍持有引用 |
| C8-E5 | `owned_executor.py:174–176,235–240`：已有直接双流文件，但完整全树收敛证明不足 | root 退出不保证继承流句柄的子孙已结束；提前 hash 可能遗漏尾部输出 | 保留 stdout.raw / stderr.raw 独立直接文件，stdin DEVNULL，禁止 pipe/读取线程增复杂度。只把必要标准流句柄传给本次子进程，Job/管理句柄不能继承；整 Job 已收敛、父侧流句柄关闭后再取字节数和 SHA。不能确认收敛时标日志未封存，不以双流已有文件代替完成 |
| C8-E6 | `owned_executor.py:50–56,139–147`：旧 argv 固定 dummy、目录限定 RUN_01/02/03，但不是新 unit 的一次消费许可 | 调整旧 argv 白名单会扩大旧授权；仅用新目录名不能阻止同一许可换目录重用 | 新独立入口按冻结 admission 的精确 unit id 构建 argv，不接收任意 argv/命令字符串。冻结工具、依赖、源/TB、输入、cwd、输出、逐步/总时限和日志阈值；首个目标 spawn 之前原子独占创建消费凭据并绑定 admission SHA。任何已消费许可均拒绝再次启动，失败不恢复额度；预检拒绝须记录零启动 |
| C8-E7 | `windows_job.py:93–101`、`owned_executor.py:195–240`：API 调用成功、root exit 与最终返回没有统一功能判定 | TerminateJobObject 成功、受控杀死后 root 返回、等待失败或日志溢出都可能被上层过宽地解释 | 新执行器单一判定：自然 exit 0 + 本 unit 明确语义断言/新产物 + 输入一致 + 完整双流封存 + Job 无活动成员 + 句柄终止证据 + 无控制/清理/封存错误。超时、溢出、异常、API/身份错误、强制终止为粘性 FAIL/UNKNOWN，清理成功只能更新 cleanup 状态 |

## 最小收敛次序

1. 预检固定输入与路径，检查可用总预算并预留清理时间；原子消费本次 admission；创建本次专属输出与非继承、带 KILL_ON_JOB_CLOSE 的 Job。禁止 shell、breakaway、任意参数透传或 P7 环境变量路线。
2. 直接打开双 raw 文件；以 CREATE_SUSPENDED 创建固定命令，立刻保存本次当前句柄所有权；AssignProcessToJobObject 成功才恢复主线程/进程。旧 helper 用 NtResumeProcess，新实现可保留已知机制或选择已验证的句柄恢复方法，但不能回退到先运行后附着。创建或附着失败时不允许恢复未被 Job 拥有的 root。
3. 所有轮询、根等待、Job 查询、清理与封存共用冻结的单调总截止时间；清理预算不能由异常重置。超时或任意失败先保留首错，再 TerminateJobObject，并等待本次实际进程句柄。只使用当前创建句柄与新鲜 Job 成员句柄，不能操作历史 PID、进程名或全机扫描结果。
4. Job 仍打开时记录 root 及已捕获成员的 WAIT_OBJECT_0 结果与 exit code；WAIT_TIMEOUT、WAIT_FAILED 或无法确认成员身份不代表退出。关闭已完成等待的进程/线程引用后，继续有界 QueryInformationJobObject(class 1) 至 ActiveProcesses=0。若保留 class 3 成员表，则保存终态空表，并正确处理长度/查询错误；一次列表不是全树证明。保持 Job 句柄有效直到证明结束，随后关闭 Job；查询或等待失败则 cleanup_confirmed=false，阻止下一步目标启动。
5. 最后关闭父侧双流句柄、读取原始字节数与 SHA，核输入后快照、产物和语义结果，写终态。强制终止产生的退出码不能充当自然成功；脚本只打印 PASS 也不能覆盖控制错误。封存写入错误明确单列，不可吞掉原异常或返回成功。

Microsoft 对 ActiveProcesses 的说明包含进程退出及引用释放，因此不要为了零计数一直保留所有进程句柄，也不要先关 Job 再查零。必须先把句柄已 signaled 的事实保存，再释放自己的进程引用，最后查询仍持有的 Job。也不能把等待 Job 句柄当作等待全部子孙退出；应等待进程句柄并查询 Job 状态。相关依据：[BasicAccounting.ActiveProcesses](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_accounting_information)、[QueryInformationJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-queryinformationjobobject)、[WaitForSingleObject](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitforsingleobject)。这些是对 API 语义的静态设计建议，未在本机新执行验证。

## 新执行器需要的最小验证要求（待 M2 冻结精确许可；本窗口未执行）

验证源码本体、执行器、helper、fixture、运行时/工具及依赖先冻结 SHA，执行后同范围复核。不要把旧 R01 五例复制的历史 PASS 写到新源码名下；也不要为新执行器重开旧 RUN_01/02/03。

| 新组 | 必须能区分的结果 | 验证层级 |
|---|---|---|
| admission 拒绝组 | 非白名单 unit/argv、身份变化、输出逃逸及第二次消费都零目标启动；同一许可失败后仍拒绝二次消费。消费前预检拒绝与消费后失败分开记 | 新软件控制 |
| 正常/非零组 | 双流均保留；自然 exit 0 满足语义才可 PASS；自然非零仍 FAIL，cleanup 可 PASS | 新软件控制 |
| 全树组 | 超时多代树确实停止；根先 exit 0、子孙继续写流时功能 FAIL；所有本次句柄已 signaled、Job 活动归零后才封流，不能仅凭 escape marker 未出现判断无进程 | 新软件控制 |
| 所有权故障组 | 创建后附着前 BaseException 与 assigned 后 resumed 前错误均停止本次所有权内进程，首错保留。KeyboardInterrupt 与 SystemExit 哪个实际注入、哪个只静态覆盖必须分开登记；metadata/finalization 失败不得产生伪 PASS | 新软件控制 |
| 清理/日志故障组 | Query/Wait/Terminate 失败或预算耗尽为 cleanup 未确认，禁止后续目标启动；原始流超阈值会失败且保留实际字节。直接文件是“观察超限后停止”，不能宣称硬字节上限 | 新软件控制；API 故障可用隔离注入 |
| 精确 unit 组 | 只运行新 admission 列出的编译与仿真步骤，每步独立 Job/双流与整组总预算；编译的新产物来源和 SHA、仿真语义自检/计数/正常终态齐套。任一步控制或清理失败，不再执行后一步 | 新单元仿真；不代表完整链路或 Pro 实板 |

不提出旧 executor 扩权、M3 plan_adapter 代做、P7 恢复、EDA 或下载许可。新 unit 具体 source list、工具依赖与语义成功条件由 M2 当前新合同精确冻结，本报告没有替它选择更大范围。

## 外部依据读取限制

读取了 Microsoft Learn 的 Job、AssignProcessToJobObject、TerminateJobObject、QueryInformationJobObject、BasicAccounting 与 WaitForSingleObject 官方文档。[TerminateJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-terminatejobobject) 描述终止整个关联 Job，API 返回成功仍须配套退出证据。一个 Microsoft DevBlogs 辅助页返回 403；未重试、未将未读正文作为依据；未改变本地源文件。
