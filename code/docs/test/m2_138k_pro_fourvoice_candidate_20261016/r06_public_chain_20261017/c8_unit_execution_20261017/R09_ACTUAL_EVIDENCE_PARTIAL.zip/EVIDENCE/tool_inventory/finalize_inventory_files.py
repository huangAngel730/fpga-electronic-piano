"""Preserve tiny config originals and a flat file binding; no tool launch."""
from pathlib import Path
import hashlib
import json

O=Path(__file__).parent
j=json.loads((O/'TOOL_RUNTIME_BINDING.json').read_text(encoding='utf-8'))
flat={r['path']:{k:r[k] for k in ['bytes','sha256']} for r in j['selected_application_and_config_files']}
for r in j['OS_boundary_files']+[j['internal_shell_candidate']]:
    flat[r['path']]={k:r[k] for k in ['bytes','sha256']}
changed=[]
for name,expected in flat.items():
    raw=Path(name).read_bytes()
    actual={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    if actual!=expected:changed.append(name)
config=O/'CONFIG_ORIGINALS'
config.mkdir(exist_ok=True)
for name in ['vvp.conf','vvp-s.conf']:
    (config/name).write_bytes(Path('D:/Gowin/oss-cad-suite/lib/ivl',name).read_bytes())
for name in ['environment.ps1','environment.bat']:
    (config/(name+'.readonly.txt')).write_bytes(Path('D:/Gowin/oss-cad-suite',name).read_bytes())
result={'schema':'M2_C8_STATIC_TOOL_FILES_V1','files':flat,
        'file_count':len(flat),'application_and_config_files':22,
        'OS_boundary_and_shell_files':4,'hash_recheck_changed':changed,
        'level':'L0_STATIC_FILE_IDENTITY','execution_admission':None,
        'OS_full_dynamic_closure_claimed':False,'target_EXE_launches':0,
        'target_DLL_loads':0,'note':'catalogued files do not authorize any tool command; explicit unit executor admission is separate'}
(O/'TOOL_FILES.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def id(p):
    raw=p.read_bytes()
    return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
print(json.dumps({'flat_binding':id(O/'TOOL_FILES.json'),'files':len(flat),
                  'hash_recheck_changed':changed,
                  'config_identities':{n:j['configs'][n]['identity'] for n in ['vvp.conf','vvp-s.conf']}},indent=2))
raise SystemExit(0 if not changed else 1)
