"""Read/hash only; never import or start any catalogued tool or helper."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import winreg


ROOT = Path('D:/17/project_17/fpga_gowin')
BASE = ROOT / 'code/output/m2_unit_execution_c8_20261017'
HERE = BASE / 'resume_tool_binding'
INV = BASE / 'tool_inventory'


def identity(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, obj):
    (HERE / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


files_path = INV / 'TOOL_FILES.json'
binding_path = INV / 'TOOL_RUNTIME_BINDING.json'
files = json.loads(files_path.read_text(encoding='utf-8'))
binding = json.loads(binding_path.read_text(encoding='utf-8'))
expected = dict(files['files'])
origins = {path: ['TOOL_FILES'] for path in expected}
for section in ['selected_application_and_config_files', 'OS_boundary_files', 'full_ivl_directory_catalog_not_execution_permission']:
    for row in binding[section]:
        path = row['path']
        pair = {k: row[k] for k in ['bytes', 'sha256']}
        if path in expected:
            assert pair == expected[path], ('INCONSISTENT_CATALOG_IDENTITY', path)
        expected[path] = pair
        origins.setdefault(path, []).append(section)
expected[binding['internal_shell_candidate']['path']] = {k: binding['internal_shell_candidate'][k] for k in ['bytes', 'sha256']}
checks = []
for path, pair in expected.items():
    actual = identity(path)
    checks.append({'path': path, 'expected': pair, 'actual': actual, 'match': actual == pair, 'origins': origins.get(path, ['internal_shell_candidate'])})

ivl_root = Path('D:/Gowin/oss-cad-suite/lib/ivl')
ivl_expected = {row['path'] for row in binding['full_ivl_directory_catalog_not_execution_permission']}
ivl_actual = {p.as_posix() for p in ivl_root.rglob('*') if p.is_file()}
all_sources = binding['selected_application_and_config_files']
candidate_dirs = [Path('D:/Gowin/oss-cad-suite/bin'), Path('D:/Gowin/oss-cad-suite/lib'), ivl_root, Path('C:/Windows/System32')]
names = sorted({Path(e['to']).name for e in binding['package_static_import_edges'] if e['relation'] == 'PACKAGE_PE_IMPORT'})
shadows = {}
for name in names:
    matches = []
    for directory in candidate_dirs:
        p = directory / name
        if p.is_file():
            matches.append({'path': p.as_posix(), **identity(p)})
    shadows[name] = matches

records = []
for k, row in binding['inputs'].items():
    records.append({'key': k, 'path': row['path'], 'expected': {x: row[x] for x in ['bytes', 'sha256']}, 'actual': identity(row['path'])})

shell_startup = []
for hive_name, hive in [('HKCU', winreg.HKEY_CURRENT_USER), ('HKLM', winreg.HKEY_LOCAL_MACHINE)]:
    for view_name, view in [('64bit', winreg.KEY_WOW64_64KEY), ('32bit', winreg.KEY_WOW64_32KEY)]:
        item = {'hive': hive_name, 'view': view_name, 'subkey': r'Software\Microsoft\Command Processor', 'value': 'AutoRun'}
        try:
            with winreg.OpenKey(hive, item['subkey'], 0, winreg.KEY_READ | view) as key:
                try:
                    value, value_type = winreg.QueryValueEx(key, item['value'])
                    item.update({'state': 'PRESENT', 'content': value, 'type': value_type})
                except FileNotFoundError:
                    item['state'] = 'VALUE_ABSENT'
        except FileNotFoundError:
            item['state'] = 'KEY_ABSENT'
        except OSError as error:
            item.update({'state': 'UNREADABLE', 'error': str(error)})
        shell_startup.append(item)

redirection_sidecars = []
for path in [Path(r['path']) for r in all_sources if r['path'].lower().endswith('.exe')] + [Path(binding['internal_shell_candidate']['path'])]:
    for suffix in ['.local', '.manifest']:
        item = Path(str(path) + suffix)
        entry = {'path': item.as_posix(), 'exists': item.exists(), 'is_file': item.is_file(), 'is_dir': item.is_dir()}
        if item.is_file():
            entry['identity'] = identity(item)
        redirection_sidecars.append(entry)

result = {
    'schema': 'M2_R09_READ_ONLY_TOOL_RECHECK_V1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'inputs': {files_path.as_posix(): identity(files_path), binding_path.as_posix(): identity(binding_path)},
    'input_provenance_rechecks': records,
    'tool_files_26_count': len(files['files']),
    'ivl_catalog_36_count': len(ivl_expected),
    'unique_bound_file_count': len(expected),
    'identity_checks': checks,
    'all_catalogued_files_match': all(row['match'] for row in checks),
    'ivl_directory_missing_from_actual': sorted(ivl_expected - ivl_actual),
    'ivl_directory_new_unlisted': sorted(ivl_actual - ivl_expected),
    'same_name_static_search_candidates': shadows,
    'command_processor_AutoRun_readonly_snapshot': shell_startup,
    'EXE_local_and_manifest_sidecars': redirection_sidecars,
    'application_static_import_edges': len(binding['package_static_import_edges']),
    'unresolved_application_static_imports': binding['unresolved_application_static_imports'],
    'os_platform': platform.platform(),
    'python': {'executable': sys.executable, 'version': sys.version, 'identity': identity(sys.executable)},
    'actual_level': 'L0_STATIC_FILE_IDENTITY_ONLY',
    'actual_tool_launches': 0,
    'actual_target_DLL_loads': 0,
    'loaded_module_graph_observed': False,
    'execution_admission': None,
    'board_release_allowed': False,
}
save('READ_ONLY_RECHECK.json', result)

candidate = {
    'schema': 'M2_R09_TOOL_BINDING_CANDIDATE_NOT_ADMISSION_V1',
    'status': 'STATIC_APPLICATION_CATALOG_MATCHES_ONLY',
    'tool_files': expected,
    'catalogue_provenance': result['inputs'],
    'package_roots': ['D:/Gowin/oss-cad-suite/bin', 'D:/Gowin/oss-cad-suite/lib', 'D:/Gowin/oss-cad-suite/lib/ivl'],
    'compiler_component_directory': ivl_root.as_posix(),
    'runtime_VPI_directory': ivl_root.as_posix(),
    'environment_template': {
        'SystemRoot': 'C:\\Windows',
        'WINDIR': 'C:\\Windows',
        'COMSPEC': 'C:\\Windows\\System32\\cmd.exe',
        'PATH': 'D:\\Gowin\\oss-cad-suite\\bin;D:\\Gowin\\oss-cad-suite\\lib;C:\\Windows\\System32',
        'TEMP': '<exact_new_empty_step_private_temp_directory>',
        'TMP': '<same_exact_new_empty_step_private_temp_directory>',
        'PYTHONIOENCODING': 'utf-8',
    },
    'inherited_environment': False,
    'explicitly_absent_variables': ['IVERILOG_ICONFIG', 'IVERILOG_VPI_MODULE_PATH', 'IVERILOG_DUMPER', 'PYTHONPATH', 'PYTHONHOME', 'VPI_MODULE_PATH', 'LD_PRELOAD', 'LD_LIBRARY_PATH'],
    'command_processor_AutoRun_readonly_snapshot': shell_startup,
    'EXE_local_and_manifest_sidecars': redirection_sidecars,
    'VVP_default_search_removal_candidate': ['-M-', '-M', ivl_root.as_posix()],
    'do_not_source': ['D:/Gowin/oss-cad-suite/environment.ps1', 'D:/Gowin/oss-cad-suite/environment.bat'],
    'OS_boundary': {
        'scope': 'HOST_WINDOWS_PLATFORM_DEPENDENCY_NOT_APPLICATION_PAYLOAD',
        'hashed_direct_boundary_DLLs': binding['OS_boundary_files'],
        'internal_shell': {k: binding['internal_shell_candidate'][k] for k in ['path', 'bytes', 'sha256']},
        'full_dynamic_closure_proven': False,
        'not_observed': binding['still_not_proven'],
    },
    'required_consumer_checks': [
        'Exact fixed operation table reconstructed by consumer, not caller-supplied argv.',
        'Read-only bound application files rehashed immediately before launch and after group; no reparse on input/output ancestors.',
        'Exact component directory selected with compiler -B; fixed -g2012, -t vvp, top and six selected sources only.',
        'No custom VPI CLI arguments, include paths, command files, inherited Icarus environment or arbitrary module flags.',
        'Recheck shell AutoRun state and EXE .local/.manifest sidecars before actual tool use; unreadable or changed state is not static closure.',
        'Fresh exclusively owned cwd contains only staged six-or-subset source files and no DLL/VPI/EXE payload.',
        'Fixed per-step TEMP/TMP directories remain within newly owned output tree.',
        'After compile, hash product, parse every :vpi_module directive and require path/module allowlist before runtime starts.',
        'Every internal compiler shell, preprocessor, engine and simulator descendant remains in the same nonbreakaway owned Job.',
        'One-time group ledger written before first launch; no repeat under a new directory.',
        'Root signaled/closed and owned Job empty before final stream close/hash; all cleanup failures keep group non-success.',
    ],
    'prohibited_claims': ['complete OS loader closure', 'all dynamic modules observed', 'HDL PASS from static binding', 'Pro or full-chain release'],
    'execution_admission': None,
    'board_release_allowed': False,
}
save('TOOL_BINDING_CANDIDATE.json', candidate)
print(json.dumps({k: result[k] for k in ['tool_files_26_count','ivl_catalog_36_count','unique_bound_file_count','all_catalogued_files_match','ivl_directory_missing_from_actual','ivl_directory_new_unlisted','application_static_import_edges','actual_tool_launches']}, ensure_ascii=False))
