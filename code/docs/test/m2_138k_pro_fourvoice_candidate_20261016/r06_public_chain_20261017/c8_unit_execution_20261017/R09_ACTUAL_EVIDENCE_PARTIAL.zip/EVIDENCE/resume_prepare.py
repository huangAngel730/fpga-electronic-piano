"""Verify restart identities and preserve the unexecuted source baseline."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('D:/17/project_17/fpga_gowin')
OUT = Path(__file__).resolve().parent
BUILD = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017'
saved = json.loads((OUT / 'RESTART_SAVE_20261017/RESULT.json').read_text(encoding='utf-8'))
digest = lambda raw: hashlib.sha256(raw).hexdigest()
package = Path(saved['package']['path'])
assert digest(package.read_bytes()) == saved['package']['sha256']
with zipfile.ZipFile(package) as archive:
    assert archive.testzip() is None
    for name, expected in json.loads(archive.read('MANIFEST.json'))['payloads'].items():
        raw = archive.read(name)
        assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256'], name
for name, expected in saved['C8_source_identities'].items():
    raw = (BUILD / name).read_bytes()
    assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256'], name
prior = json.loads((ROOT / 'code/output/m2_c7_cancel_and_boundary_20261017/PREPARED.json').read_text(encoding='utf-8'))
for rel, expected in prior['protected'].items():
    raw = (ROOT / rel).read_bytes()
    assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256'], rel
git = lambda *args, cwd=ROOT: subprocess.check_output(['git', '-c', 'core.longpaths=true', *args], cwd=cwd)
assert git('rev-parse', 'HEAD').decode().strip() == 'ad2de2169230dc8fd9f4b6f8157d384306c2479a'
assert not git('diff', '--cached', '--name-only', '-z')
assert not (OUT / 'SW_01').exists() and not (OUT / 'UNIT_01').exists()
assert not (BUILD / 'EXECUTION_ADMISSION_R09_UNIT01.json').exists()
backup = OUT / 'RESUME_UNEXECUTED_BASELINE'
backup.mkdir(exist_ok=False)
for name in saved['C8_source_identities']:
    (backup / name).write_bytes((BUILD / name).read_bytes())
publish = ROOT / 'code/output/m2_r06_review_publish_20261017'
result = {'resumed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'restart_package_verified': True, 'payloads_verified': saved['package']['payloads'],
          'source_before': saved['C8_source_identities'], 'protected_inputs_verified': len(prior['protected']),
          'remote_after_fetch': git('rev-parse', 'origin/develop', cwd=publish).decode().strip(),
          'budgets_consumed': False, 'board_release_allowed': False}
(OUT / 'RESUME_STARTED.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(result, ensure_ascii=False))
