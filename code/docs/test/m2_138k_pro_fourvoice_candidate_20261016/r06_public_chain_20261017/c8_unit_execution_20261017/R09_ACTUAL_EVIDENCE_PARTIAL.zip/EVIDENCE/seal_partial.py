"""Seal R09 actual results without upgrading the failed HDL unit."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('D:/17/project_17/fpga_gowin')
OUT = Path(__file__).resolve().parent
BUILD = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017'
DOC = ROOT / 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017'
PUBLISH = ROOT / 'code/output/m2_r06_review_publish_20261017'
BASE = 'ef4fbc74b9d24e08de1e09d0be0eb3163118f258'


def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(rel):
    return json.loads((ROOT / rel).read_text(encoding='utf-8'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def git(*args, root=ROOT):
    return subprocess.check_output(['git', '-c', 'core.longpaths=true', *args], cwd=root)


def main():
    assert not DOC.exists()
    protected = read('code/output/m2_c7_cancel_and_boundary_20261017/PREPARED.json')['protected']
    for rel, value in protected.items():
        assert ident((ROOT / rel).read_bytes()) == value, rel
    assert git('rev-parse', 'HEAD').decode().strip() == 'ad2de2169230dc8fd9f4b6f8157d384306c2479a'
    assert not git('diff', '--cached', '--name-only', '-z')
    assert git('rev-parse', 'HEAD', root=PUBLISH).decode().strip() == BASE
    assert not git('status', '--porcelain', '-z', root=PUBLISH)
    sw = read('code/output/m2_unit_execution_c8_20261017/SW_01/GROUP_RECEIPT.json')
    fix = read('code/output/m2_unit_execution_c8_20261017/SW_FIX_01/GROUP_RECEIPT.json')
    unit = read('code/output/m2_unit_execution_c8_20261017/UNIT_01/GROUP_RECEIPT.json')
    compile_r = read('code/output/m2_unit_execution_c8_20261017/UNIT_01/raw_compile/RECEIPT.json')
    assert sw['passed'] and fix['passed'] and not unit['passed'] and not unit['results']
    assert len(sw['results']) == 11 and len(fix['increment_results']) == 5
    assert compile_r['root_exit_code'] == 3221225477 and compile_r['job_empty_before_close']
    assert compile_r['root_handle_closed'] and compile_r['receipt_complete'] and compile_r['inputs_unchanged']
    for path, expected in fix['inputs'].items():
        assert ident(Path(path).read_bytes()) == expected
    # Recheck every sealed stdout/stderr from the actual step receipts.
    for folder in ['SW_01', 'UNIT_01']:
        for receipt_file in (OUT / folder).rglob('RECEIPT.json'):
            receipt = json.loads(receipt_file.read_text(encoding='utf-8'))
            for name, value in receipt.get('logs', {}).items():
                assert ident((receipt_file.parent / name).read_bytes()) == value
    DOC.mkdir(parents=True)
    outcome = {
        'schema': 'M2_R09_ACTUAL_RESULT_V1', 'status': 'PARTIAL_COMPILER_ACCESS_VIOLATION',
        'software_group': {'passed': True, 'actual_launch_cases': 8, 'prelaunch_refusals': 3,
                           'controller_exit': 0, 'controller_seconds': 4.393640199967194},
        'software_increment': {'consumed': True, 'passed': True, 'checks': 5, 'seconds': fix['elapsed_seconds'],
                               'defect': 'top-level enumeration omitted two frozen include/*.vams files',
                               'lifecycle_cases_rerun': False},
        'unit_group': {'consumed': True, 'passed': False, 'compile_launches': 1, 'VVP_launches': 0,
                       'raw_compile_exit': 3221225477, 'raw_compile_exit_hex': '0xC0000005',
                       'raw_compile_seconds': compile_r['elapsed_seconds'], 'raw_simulation': 'NOT_STARTED',
                       'boundary_compile': 'NOT_STARTED', 'boundary_simulation': 'NOT_STARTED',
                       'job_total': 5, 'job_final_active': 0, 'root_handle_closed': True,
                       'stdout_bytes': 0, 'stderr_bytes': 0, 'inputs_unchanged': True,
                       'residual_unvalidated_product': ident((OUT / 'UNIT_01/raw_compile/unit.vvp').read_bytes())},
        'unit_repair': {'consumed': False, 'seconds': 30,
                        'condition': 'only one identified source/entry defect in same scope; unknown compiler crash does not satisfy it'},
        'root_cause': 'UNKNOWN', 'blind_retry': False, 'alternate_tool_or_privilege_bypass': False,
        'application_event_log_read': 'denied; no retry or alternate access',
        'full_dynamic_OS_loader_closure_proven': False, 'protected_files_verified': len(protected),
        'C4_C7_originals_modified': False, 'M3_R08_task_count': 36, 'M3_notification_delivered': False,
        'full_chain_executed': False, 'Gowin_EDA_calls': 0, 'device_calls': 0,
        'board_release_allowed': False, 'task_completed': False,
        'next_action': 'new independent bounded diagnostic scope in an explicitly usable execution environment; retain original compiler/Job/streams/source evidence',
    }
    save(BUILD / 'CURRENT_RUN_OUTCOME.json', outcome)
    payloads = {}
    directories = ['SW_01', 'SW_FIX_01', 'SW_FIX_BEFORE', 'UNIT_01', 'LAUNCH_SOFTWARE', 'LAUNCH_UNITS',
                   'RESUME_UNEXECUTED_BASELINE', 'executor_readonly', 'resume_controller_review',
                   'resume_tool_binding', 'tool_inventory']
    for directory in directories:
        for path in (OUT / directory).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                payloads['EVIDENCE/' + path.relative_to(OUT).as_posix()] = path.read_bytes()
    for name in ['resume_prepare.py', 'RESUME_STARTED.json', 'capture_phase.py', 'admit_units.py', 'repair_prepare.py',
                 'verify_software_increment.py', 'seal_partial.py']:
        payloads['EVIDENCE/' + name] = (OUT / name).read_bytes()
    for path in BUILD.iterdir():
        if path.is_file():
            payloads['CURRENT_SOURCE/' + path.name] = path.read_bytes()
    # Parent preparation remains a historical input, not a new L2 acceptance.
    c7 = read('code/output/m2_c7_cancel_and_boundary_20261017/RESULT.json')
    for rel in c7['new_files']:
        payloads['C7_PARENT/' + rel] = (ROOT / rel).read_bytes()
    payloads['EVIDENCE/RESTART_SAVE_RESULT.json'] = (OUT / 'RESTART_SAVE_20261017/RESULT.json').read_bytes()
    payloads['EVIDENCE/RESTART_HANDOFF_ORIGINAL.md'] = (ROOT / 'code/docs/NEXT_CHAT_HANDOFF_M2_R09_RESTART_2026-10-17.md').read_bytes()
    payloads['RESULT.json'] = (BUILD / 'CURRENT_RUN_OUTCOME.json').read_bytes()
    manifest = {name: ident(raw) for name, raw in payloads.items()}
    package = DOC / 'R09_ACTUAL_EVIDENCE_PARTIAL.zip'
    with zipfile.ZipFile(package, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in payloads.items():
            archive.writestr(name, raw)
        archive.writestr('MANIFEST.json', json.dumps({'status': outcome['status'], 'payloads': manifest}, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None
        for name, value in manifest.items():
            assert ident(archive.read(name)) == value, name
    outcome['package'] = {'path': package.relative_to(ROOT).as_posix(), **ident(package.read_bytes()), 'payloads': len(payloads)}
    save(DOC / 'RESULT.json', outcome)
    request = {'status': 'NEW_DIAGNOSTIC_SCOPE_REQUIRED', 'reason': 'compiler root access violation; no identified source/entry defect',
               'do_not_repeat': ['SW_01', 'SW_FIX_01', 'UNIT_01', 'old P7', 'full public chain'],
               'available_conditional_repair_is_not_diagnostic_permission': True,
               'proposed_next_work': 'read existing executable/source identities and fixed command; specify one separate bounded compiler diagnostic and its evidence before any new tool launch',
               'environment_requirement': 'explicitly usable execution context under current policy; never route around a denied action',
               'board_release_allowed': False}
    save(DOC / 'BLOCKER_REQUEST.json', request)
    header = ('## 2026-10-17 R09重启后实际结果：软件通过，首个编译访问冲突，整体PARTIAL\n\n'
              '本轮用户“继续 M2，从 R09 重启交接恢复”已执行，覆盖下方旧暂停状态。新独立执行器修正root引用/Job归零、最终日志水位和首异常保留；新软件组8实际启动场景+3启动前拒收通过，exit0/4.394秒。准入前发现ivl目录只扫顶层漏两头，保留失败后唯一软件增量5检查exit0/0.948秒；旧生命周期组不重跑。精确两单元准入绑定当前软件证明、50项工具与6源。UNIT01已消费：仅raw_compile一次，exit3221225477/0xC0000005、9.448秒、双流0B，Job共5/最终0、root已关、身份未变；4934B残留vvp未运行，raw仿真和boundary均NOT_STARTED。根因UNKNOWN，不以产物存在签成功；事件日志读取被拒不绕过。≤30秒修复额度未用，只适用于具体源码/入口缺陷，不作为盲诊断重跑。\n\n'
              'R09未完成，M2-R6-1/2/3和Pro仍PARTIAL、board_release_allowed=false；新软件安全证明不覆盖旧执行器/P7，完整链/EDA/设备均未启动。M3最新R08的36项与五组消费保持，M1/物理真实缺件不升级。详细原件与下一执行边界见test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017/README_R09.md；C4/C7旧原件和他人修改保留，M3通知待用户转发尚未送达。\n\n')
    states = ['code/docs/M2_完赛任务单_2026-10-15.md', 'code/docs/138K四声部后续集成任务总览_2026-10-15.md',
              'code/docs/当前状态.md', 'code/docs/任务看板.md']
    before = {}
    for rel in states + ['code/docs/M2_Pro基础最小单元执行单_R09_2026-10-17.md', 'code/docs/NEXT_CHAT_HANDOFF_M2_R09_RESTART_2026-10-17.md']:
        path = ROOT / rel
        raw = path.read_bytes()
        before[rel] = ident(raw)
        backup = OUT / 'STATE_BEFORE_RESUME_RESULT' / Path(rel).name
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_bytes(raw)
        first, sep, rest = raw.partition(b'\n')
        assert sep
        path.write_bytes(first + b'\n\n' + header.encode('utf-8') + rest.lstrip(b'\n'))
    readme = f'''# M2 R09实际执行与阻断交接（2026-10-17）

R09已从重启包恢复并真实执行。**当前PARTIAL，任务未完成，两个HDL单元均未获得L2 PASS，board_release_allowed=false。** 旧暂停段落只保留历史；不要重跑已消费组，也不要把残留vvp或TB中的PASS字符串当作成功。

| 项目 | 实际结果 | 消费 |
|---|---|---|
| 新owned Job执行器 | root引用释放后再核Job空；最后bytes复判；双流分别close；首BaseException保留；固定能力/身份/私有tmp | 本轮实现 |
| SW_01 | 8启动场景+3启动前拒收，exit0，4.393640秒 | 一次≤90秒已消费 |
| SW_FIX_01 | 目录枚举漏2个include/*.vams；仅改递归枚举和后继证明路径，5检查通过，exit0/0.948080秒 | 唯一≤60秒增量已消费；0夹具/HDL |
| UNIT01 raw compile | exit3221225477 (0xC0000005)，9.448011秒，stdout/stderr各0B | 唯一≤60秒组已消费 |
| raw VVP / boundary compile+VVP | NOT_STARTED | 不可把组剩余时间挪成新组 |
| 对应单元修复 | 尚无有据源码/入口修法，根因UNKNOWN | 一次≤30秒未用；条件未满足 |

新软件场景为正常双流、非零7、root退后子孙写流、超时子孙、日志越限、最终尾写越限、附Job前BaseException、首错同时回执失败；启动前拒收改argv/未知操作/重复步骤。负例通过指正确拒收或清理，不指进程退出0。首错+回执失败场景预期备用FINALIZATION_FAILURE，不能改写成完整回执。

软件证明绑定当前entry/runtime/fixture、冻结Job助手和本机Python EXE/DLL。最初SW证明保留；后继证明继承未变生命周期代码并检查唯一两行controller差异。工具应用侧绑定原26项与完整ivl目录36项并集50项；额外核HKCU/HKLM 32/64 Command Processor AutoRun及五EXE的.local/.manifest不存在。Windows API-set/SxS/loader和Python标准库作为当前平台边界接受，**没有证明完整动态闭包**。`vvp -M- -M fixed_IVL`及产物VPI绑定已实现，但本轮未到VVP阶段，不能写实际装载通过。

固定单元源为C7 raw leaf+TB，以及冻结pcm_result_hold/pcm_frame_buffer+C4 sidecar SHA40fd+boundary C7 TB。UNIT_01/source保存全部六源。C4/C7仍保留其本地历史版本，不在此次直接暂存/代发；包内C7_PARENT与六源是此次输入快照。已签准入是**单次历史准入**，当前CURRENT_RUN_OUTCOME说明已消费失败，不能复用。发布的entry为原执行记录，依赖本机固定路径及历史输入；其他checkout不得直接启动，应先以封包回读核同，再由新有效任务指定新范围/环境/额度。

实际编译argv/cwd/env/UTC在UNIT_01/raw_compile/START与RECEIPT；控制器双流在LAUNCH_UNITS。Job共5进程且最终active0、root句柄关闭、双流封存、输入前后SHA同。残留unit.vvp 4934B仅静读见版本/六VPI/尾表，SHA见RESULT；没有运行。访问冲突来源尚不确定；历史相同退出码、提权后成功记录均不能证明本次根因。应用事件日志读取被拒，未重试/换访问方式。

封包：`R09_ACTUAL_EVIDENCE_PARTIAL.zip`，{outcome['package']['bytes']}B，SHA-256 **{outcome['package']['sha256']}**，{len(payloads)}载荷；CRC和全部清单大小/SHA已回读。包含首次准入失败、修复前源码、原SW与增量、原编译失败、当前源码/准入、工具静态材料、C7父输入及重启来源。首个辅助失败记录命令引号SyntaxError、若干只读路径拼写/检索错误无产品修改，已记录；它们不计为编译修复或三次有效解决尝试。

下一动作是形成**独立、有界的编译诊断范围和可用执行环境**后再启动工具；现额度不支持无变化重试、换工具、放宽时限或绕过被拒操作。R09保持PARTIAL，不把软件部分单独改成整项完成。本次仅按需新执行许可/环境决定节点集中封存；是否发布取决于本任务精确文件的九门禁，发布前无编号，发布结果另有独立回执。

M3继续其最新R08任务的既有授权软件工作，不能把本轮安全执行器证明当作M3 plan_adapter或旧P7许可。M1十九语义/apply/config/audio_stable、真实Pro公开trace/时基/PCM/身份和板测仍待。本轮未启用审核员/预审员；M2自审，M3消息待用户转发尚未送达。

参考：[微软Job计数语义](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_accounting_information)、[Icarus VVP参数](https://steveicarus.github.io/iverilog/usage/vvp_flags.html)、[产物版本所指官方driver源码](https://raw.githubusercontent.com/steveicarus/iverilog/a690e3a03/driver/main.c)。前两者仅支持机制实现，均不代签本机实际HDL成功。
'''
    (DOC / 'README_R09.md').write_text(readme, encoding='utf-8', newline='\n')
    forward = '''M3：M2 R09重启续接已实际执行，整体PARTIAL。新独立owned Job执行器8启动+3拒收的软件组通过；ivl递归目录漏两头的问题经唯一软件增量5检查修复通过。仅raw_compile首次执行后以0xC0000005退出，双流0B、Job5→0、root已关；残留4934B vvp未运行，raw仿真和boundary均未开始，不能签L2或接入真实采集。原UNIT01已消费，≤30秒修复只有具体源码/入口缺陷时可用，当前根因UNKNOWN；禁止复用本准入/旧P7或把M2执行器证明用于M3 adapter。你继续R08原36项及其五组已有软件边界/消费，M1/真实Pro缺件不升级。原件包及SHA见同目录README_R09.md和RESULT.json；包含C7父输入与6单元源、首次失败/修复前后/实际命令退出及双流。board_release_allowed=false。待用户转发，尚未送达；本消息不表示已接单或已签收。
'''
    (DOC / 'FORWARD_TO_M3.md').write_text(forward, encoding='utf-8', newline='\n')
    save(OUT / 'SEALED.json', {'status': outcome['status'], 'package': outcome['package'], 'header': header,
                              'states': states, 'before_documents': before, 'protected': protected,
                              'main_head': git('rev-parse', 'HEAD').decode().strip(), 'publish_base': BASE,
                              'main_C4_C7_preserved': True, 'task_completed': False})
    print(json.dumps({'sealed': True, 'status': outcome['status'], 'package': outcome['package'], 'protected': len(protected)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
