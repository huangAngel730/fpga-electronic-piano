"""Classify existing static inventory without re-running tools or traversal."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from read_pe_inventory import PE

O=Path(__file__).parent
j=json.loads((O/'TOOL_INVENTORY.json').read_text(encoding='utf-8'))
SUITE=Path('D:/Gowin/oss-cad-suite')
IVL=SUITE/'lib/ivl'
def identity(p):
    b=p.read_bytes()
    return {'path':p.resolve().as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
package=[r for r in j['PE_files'] if r['path'].startswith('D:/Gowin/oss-cad-suite/')]
package_paths={r['path'].casefold():r for r in package}
by_name={Path(r['path']).name.casefold():r for r in package}
closure_edges=[];missing=[];os_boundary={}
for r in package:
    for imp in r['imports']:
        name=imp['dll'].casefold()
        if name in by_name:
            target=by_name[name]
            closure_edges.append({'from':r['path'],'import':imp['dll'],'to':target['path'],
                                  'relation':'MAIN_ENGINE_EXE_EXPORTS' if name=='ivl.exe' else 'PACKAGE_PE_IMPORT',
                                  'delay_import':imp['delayed']})
            continue
        candidate=Path('C:/Windows/System32')/imp['dll']
        if candidate.is_file():
            os_boundary[candidate.resolve().as_posix()]=identity(candidate)
            closure_edges.append({'from':r['path'],'import':imp['dll'],'to':candidate.resolve().as_posix(),
                                  'relation':'PLATFORM_OS_BOUNDARY_STATIC_CANDIDATE','delay_import':imp['delayed']})
        else:missing.append({'from':r['path'],'import':imp['dll'],'delayed':imp['delayed']})

# Correct the import spelling ivl.exe without modifying the original traversal.
main_export_binding={'original_inventory_entry':'ivl.exe.dll is a resolver suffix error, not an absent DLL',
 'importer':str(IVL/'vvp.tgt'),'literal_import':'ivl.exe',
 'bound_file':identity(IVL/'ivl.exe'),
 'meaning':'target imports symbols from the main ivl engine executable; runtime module context remains to observe'}
selected=[{k:r[k] for k in ['path','bytes','sha256']} for r in package]
for n in ['vvp.conf','vvp-s.conf']:
    selected.append(identity(IVL/n))
shell=PE(Path('C:/Windows/System32/cmd.exe'))
scripts=[identity(SUITE/n) for n in ['environment.ps1','environment.bat']]
hints={}
for p in [SUITE/'bin/iverilog.exe',SUITE/'bin/libvvp-1.dll']:
    raw=p.read_bytes()
    strings=[s.decode('ascii') for s in re.findall(rb'[\x20-\x7e]{5,}',raw)]
    needles=['usage:','iverilog [-','-b base','-m path','vpi','iverilog_iconfig','iverilog_vpi_module_path','ivlpp_dir']
    hints[p.as_posix()]=[s for s in strings if any(n in s.lower() for n in needles)][:50]
unresolved_counts=Counter(u['reason'] for u in j['unresolved_static_entries'])
api_names=sorted({u['dll'] for u in j['unresolved_static_entries'] if u['reason']=='API_SET_CONTRACT_NO_STATIC_HOST'})
runtime={
 'schema':'M2_C8_STATIC_TOOL_RUNTIME_BINDING_V1',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'status':'APPLICATION_STATIC_IMPORT_FILES_IDENTIFIED_OS_AND_DYNAMIC_LOAD_BOUNDARY_EXPLICIT',
 'inputs':{'inventory':identity(O/'TOOL_INVENTORY.json'),'scanner':identity(O/'read_pe_inventory.py')},
 'selected_application_and_config_files':selected,
 'package_static_import_edges':closure_edges,
 'unresolved_application_static_imports':missing,
 'main_engine_export_binding_correction':main_export_binding,
 'OS_boundary_files':list(os_boundary.values()),
 'internal_shell_candidate':{**shell.identity,'imports':shell.imports(),
                              'binding_required':'pin COMSPEC to this exact path if the admitted runtime uses the C runtime system/_popen path; actual invocation not observed'},
 'full_ivl_directory_catalog_not_execution_permission':j['ivl_directory_files'],
 'configs':{n:j['configuration_files'][n] for n in ['vvp.conf','vvp-s.conf']},
 'binary_string_evidence_not_execution_proof':hints,
 'API_set_boundary':{'schema_identity':j['api_set_schema'],
                    'unmatched_contract_name_count':len(api_names),'unmatched_contract_names':api_names,
                    'interpretation':'exact-name static schema match is incomplete for OS API-set version/alias resolution; no missing-installation inference and no guessed host substitution'},
 'initial_inventory_limitations':{'first_graph_PE_count':len(j['PE_files']),
                                  'first_graph_edges':len(j['dependency_edges']),
                                  'first_graph_unresolved_count_by_reason':dict(unresolved_counts),
                                  'suffix_normalization_error_preserved':True},
 'execution_environment_conditions_not_executed':{
    'application_bin':(SUITE/'bin').as_posix(),'package_DLL_directory':(SUITE/'lib').as_posix(),
    'ivl_component_and_VPI_directory':IVL.as_posix(),
    'PATH_minimum_candidate_prefixes':[(SUITE/'bin').as_posix(),(SUITE/'lib').as_posix(),'C:/Windows/System32'],
    'do_not_source_environment_scripts':scripts,
    'why':'both environment scripts start gdk-pixbuf-query-loaders.exe; not part of this exact unit task',
    'compiler_component_directory_must_be_explicit':True,
    'VPI_search_folder_and_compiled_module_directives_must_be_bound':True,
    'cwd_output_temp_and_process_tree_ownership_must_be_exact':True,
    'CLI_option_compatibility':'NOT_EXECUTED; strings only'},
 'still_not_proven':['actual loader KnownDLL/SxS/redirected and API-set host resolution',
                    'dynamic LoadLibrary/GetProcAddress modules beyond manifest',
                    'generated VVP module directives and which default VPI bodies are actually loaded',
                    'internal shell/ivlpp/ivl subprocess argv and full Job lifecycle',
                    'exact compiler/runtime invocation compatibility and unit results'],
 'changed_inputs_detected_in_initial_inventory':j['inputs_changed_during_inventory'],
 'PE_parse_errors_in_initial_inventory':j['PE_parse_errors'],
 'actual_level':'L0_STATIC_TOOL_FILES','tool_launches':0,'DLL_loads':0,'execution_admission':None,
 'board_release_allowed':False}
(O/'TOOL_RUNTIME_BINDING.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'selected_application_files':len(selected),'package_PE_files':len(package),
                  'package_static_import_edges':len(closure_edges),'unresolved_application_imports':missing,
                  'OS_boundary_files':list(os_boundary.values()),'shell':shell.identity,
                  'unmatched_API_set_names':len(api_names),'runtime_binding':identity(O/'TOOL_RUNTIME_BINDING.json'),
                  'hints':hints},ensure_ascii=False,indent=2))
