# 新 runtime 首版只读增量

读取边界：`code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017/owned_unit_runtime.py` 全文，SHA-256 `62b0838227c613bf92052e9703037467c6c69778cc90424346f71e58bc572070`；同目录 `unit_fixture.py` 全文，SHA-256 `4fd5c4760f9771d6c2f5190e42bacd20139ed6c2641224cdbedd3f9c732cfc00`。这是这两个精确版本的静态结论，未运行或改动任何被审源码、fixture、工具或进程，也未读取/代签尚未纳入本次范围的新 admission 入口。

新 runtime 已有独立固定 operation table、挂起后附着、附着前 BaseException 的当前 Popen 句柄清理、双 raw 文件、Job 打开期间 accounting 查询、失败时终止以及输入复核。剩余三个具体问题如下；已分别发给根 M2，待其最小修复，不能记为已修复。

1. **收敛次序依赖尚未释放的 root 引用，且计数非零被直接命名为孤儿。** 169–180 行在 `poll()` 得到根退出码后仍保留 `_handle`，以 active 非零持续 0.2 秒命名 ORPHAN。202–210 行先 `wait_empty()`，然后才 root wait/WAIT_OBJECT_0/Close。Microsoft 的 [ActiveProcesses 文档](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_accounting_information) 将计数递减与退出和引用释放相联系，因此此顺序依赖特定实现的计数行为，不能从静态阅读保证无假阳性。最小修法：根已确认退出后，先保存 exit code、当前 root 的 WAIT_OBJECT_0 结果并关闭其进程引用，再继续 Job accounting；finally 的活根路径按 TerminateJob → root wait/signaled/Close → still-open Job wait_empty → closeJob。跟踪 closed 标志防止再次等待已关闭句柄。实际活子孙会在 root 引用释放后仍使 Job 非空；如果无法区分计数延迟与活子孙，可用准确的 `JOB_NONEMPTY_AFTER_ROOT_EXIT` 名称，继续按 FAIL 清理，不必新增全机扫描。**未在本机新源码上执行，不声称已观察到死锁或泄漏。** [WaitForSingleObject 官方文档](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitforsingleobject) 也要求不能在等待尚未完成时关闭相应句柄。

2. **尾部日志可以超过阈值却仍 `clean_exit=true`。** 164–175 行先读文件大小，再 poll/查 Job；如果根在大小读取之后写出最后一批数据并退出，读取到的旧大小未超阈值，而 Job 已归零，循环直接置 ROOT_AND_JOB_EXITED。228 行最终 hash 已含超量尾部，235–238 行却只看 stop_reason 等字段，不再检查最终字节数。最小修法：父侧双流关闭并取得最终 raw 字节数后，再判断总量是否超过冻结的 watermark；如超过，记录 LOG_WATERMARK 或独立粘性 log_limit_observed，并保证 clean_exit=false。保留“观察超限后停止，非硬字节上限”的既有说明。该修法不需要 pipe/读取线程。

3. **封存异常可以遮蔽原 BaseException，或让终态回执缺失而没有独立原因。** 185–188 行按预期重抛首异常；但 220–228 行 close/identity、239 行 save 仍在未保护的 finally 中。若附着前 FixtureAbort/KeyboardInterrupt 后遇磁盘读写/关闭失败，新异常会取代向上传播的原异常；stdout.close 失败还会跳过 stderr.close。最小修法：双流分别独立 close，finalization 错误与 primary_error/cleanup_error 分列；在最外层保存原异常后执行有界清理和尽力封存，再重抛原异常。不能写出完整回执时上层必须认作证据不全/非成功，不能以文件不存在默认通过。没有原异常时封存失败也须非零/异常退出。不要通过吞掉 KeyboardInterrupt/SystemExit 来保证回执。

`unit_fixture.py` 中 normal/nonzero、三代 stdout/stderr、根先退出、超时和 flood 的意图与上述范围一致；这里只看源码，没有将其静态阅读登记成任何动态 PASS。该首版没有在本报告中完成最终功能白名单、工具准入、一次消费入口或 HDL 单元语义判定审核；这些由根 M2 在新合同和受控执行中负责。
