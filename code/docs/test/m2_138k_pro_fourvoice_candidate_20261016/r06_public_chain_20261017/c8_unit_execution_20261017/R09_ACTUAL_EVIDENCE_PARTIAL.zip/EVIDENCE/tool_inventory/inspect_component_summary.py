from collections import Counter
import json
from pathlib import Path
from read_pe_inventory import api_set_map

O=Path(__file__).parent
j=json.loads((O/'TOOL_INVENTORY.json').read_text(encoding='utf-8'))
apis,meta=api_set_map()
toolprefix='D:/Gowin/oss-cad-suite/'
report={'api_set_identity':meta,'api_set_first_names':list(apis.items())[:8],
 'tool_PE_files':[{'path':p['path'],'bytes':p['bytes'],'sha256':p['sha256'],'imports':[i['dll'] for i in p['imports']],'dynamic_process_imports':p['dynamic_or_process_imports']} for p in j['PE_files'] if p['path'].startswith(toolprefix)],
 'unresolved_count':len(j['unresolved_static_entries']),
 'unresolved_reason_count':dict(Counter(u['reason'] for u in j['unresolved_static_entries'])),
 'unresolved_tool_entries':[u for u in j['unresolved_static_entries'] if u['importer'].replace('\\','/').startswith(toolprefix)],
 'unique_unresolved_names_count':len({u['dll'] for u in j['unresolved_static_entries']}),
 'binary_hints':{p:v for p,v in j['binary_string_hints_untrusted_not_behavior_proof'].items() if p.endswith(('iverilog.exe','vvp.exe'))}}
(O/'COMPONENT_SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
