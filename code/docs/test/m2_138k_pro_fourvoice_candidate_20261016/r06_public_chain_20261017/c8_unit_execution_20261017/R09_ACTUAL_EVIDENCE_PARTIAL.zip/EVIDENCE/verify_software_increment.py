"""One <=60 s affected increment: recursive catalog enumeration only."""
import importlib.util
import json
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
HERE = ROOT / 'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c8_unit_execution_20261017'
sys.path.insert(0, str(HERE))
spec = importlib.util.spec_from_file_location('m2_r09_repair_entry', HERE / 'run_r09.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
inputs = m.base_inputs()
group, deadline = m.begin_group('SW_FIX_01', 60, inputs)
start = time.monotonic()
passed = False
checks = {}
parent = json.loads((OUT / 'SW_01/GROUP_RECEIPT.json').read_text(encoding='utf-8'))
try:
    assert parent['passed'] is True and parent['inputs_unchanged'] is True and parent['group_deadline_kept'] is True
    previous = (OUT / 'SW_FIX_BEFORE/run_r09.py').read_bytes()
    expected = previous.replace(b'IVL.iterdir()', b"IVL.rglob('*')").replace(
        b"proof_path = OUT / 'SW_01/GROUP_RECEIPT.json'", b"proof_path = OUT / 'SW_FIX_01/GROUP_RECEIPT.json'")
    assert previous != expected and (HERE / 'run_r09.py').read_bytes() == expected
    assert m.identity(OUT / 'SW_FIX_BEFORE/run_r09.py') == parent['inputs'][str((HERE / 'run_r09.py').resolve())]
    for path, value in inputs.items():
        if path != str((HERE / 'run_r09.py').resolve()):
            assert value == parent['inputs'][path]
    checks['only_two_outside_lifecycle_controller_lines_changed'] = True
    tools = m.required_tool_files()
    assert len(tools) == 50
    actual = {str(p.resolve()).casefold() for p in m.IVL.rglob('*') if p.is_file()}
    top = {str(p.resolve()).casefold() for p in m.IVL.iterdir() if p.is_file()}
    assert len(actual) == 36 and len(top) == 34 and len(actual - top) == 2
    checks['all_36_recursive_IVL_files_in_50_file_union'] = True
    assert all(m.identity(path) == value for path, value in tools.items())
    checks['all_50_actual_file_identities_equal_frozen_catalog'] = True
    altered = dict(tools)
    altered.pop(next(path for path in altered if path.endswith('constants.vams')))
    assert altered != m.required_tool_files() and {} != m.required_tool_files()
    checks['empty_or_missing_nested_header_catalog_not_equal'] = True
    m.check_tool_startup_inputs()
    checks['startup_inputs_rechecked'] = True
    passed = True
finally:
    result = {'scope': 'R09_EXECUTOR_SW01', 'passed': passed,
              'results': parent['results'], 'inputs': inputs,
              'inputs_unchanged': all(m.identity(path) == value for path, value in inputs.items()),
              'group_deadline_kept': time.monotonic() <= deadline,
              'parent_software_proof': m.identity(OUT / 'SW_01/GROUP_RECEIPT.json'),
              'increment_scope': 'recursive IVL collection and exact current controller delta; no lifecycle rerun',
              'increment_results': checks, 'HDL_calls': 0, 'fixture_launches': 0,
              'elapsed_seconds': time.monotonic() - start, 'ended_utc': m.utc(),
              'old_executor_changed': False, 'board_release_allowed': False}
    result['passed'] = passed and result['inputs_unchanged'] and result['group_deadline_kept']
    m.save(group / 'GROUP_RECEIPT.json', result)
print(json.dumps(result, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['passed'] else 1)
