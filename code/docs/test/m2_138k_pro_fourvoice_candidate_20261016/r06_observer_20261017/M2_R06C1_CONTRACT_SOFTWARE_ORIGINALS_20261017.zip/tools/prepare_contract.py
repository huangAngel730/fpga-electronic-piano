"""Create source-bound M2 contract candidates in the authorized R06 roots."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / "code/output/m2_live_tasks_publish_20261017"
SOURCE = OUT / "READ_ONLY_SOURCE"
DOC = "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017"
BUILD = "code/build/138k_pro_fourvoice_candidate_20261016/r06_observer_20261017"
BASE = "42d28c4ad8250b9064099da4742fbde12a254444"
ARCHIVE = "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip"
ARCHIVE_SHA = "931b7d2bbfd7ac056707542931101ff844b125936762748e344536d9be6c1ba2"
COLLAB = "code/docs/M2双窗口协作与公共采样合同_R06C1_2026-10-17.md"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-c", "core.longpaths=true", *args], cwd=TREE).decode("utf-8").strip()


assert git("rev-parse", "HEAD") == git("rev-parse", "origin/develop") == BASE
assert not git("status", "--porcelain")
assert sha(TREE / ARCHIVE) == ARCHIVE_SHA
for path in (TREE / DOC, TREE / BUILD):
    assert not path.exists(), path
    path.mkdir(parents=True)
mapping = json.loads((SOURCE / "PUBLIC_OBSERVATION_MAP.json").read_text(encoding="utf-8"))
bindings = {}
for field in mapping["fields"]:
    for ref in field["references"]:
        path = SOURCE / ref["path"]
        assert sha(path) == ref["sha256"]
        assert path.read_text(encoding="utf-8").splitlines()[ref["line"] - 1].strip() == ref["text"].strip(), ref
        bindings[ref["path"]] = ref["sha256"]
fields = copy.deepcopy(mapping["fields"])
for field in fields:
    category = field["category"]
    name = field["name"]
    field["owner"] = "M1" if category == "M1_INTERNAL_PENDING_OWNER_MAPPING" else "M2"
    if name in ("cycle", "epoch", "finish"):
        field["owner"] = "M3_CAPTURE_USING_M2_CONTRACT"
    if name == "apply_event_seq":
        field["owner"] = "M1_SEMANTICS_M2_ROUTE"
    if name == "config_payload":
        field["owner"] = "M1_COMPONENTS_M2_PACKING"
    field["sampling_phase"] = "POSEDGE_PRE_NBA"
    field["route_implemented_by_this_change"] = False
    field["contract_status"] = "PENDING_M1_SEMANTICS" if field["owner"].startswith("M1") else "M2_SOURCE_RULE_BOUND_ROUTE_PENDING"
    if name == "audio_stable":
        field["contract_status"] = "PENDING_STABILITY_POLICY_AND_IMPLEMENTATION"
    if field["width"] is None:
        field["contract_status"] = "PENDING_WIDTH_AND_IMPLEMENTATION"
    if name == "result_clip_mask":
        field["normalized_packing"] = {"bit0": "clip_left", "bit1": "clip_right"}
    if name.startswith("tx_"):
        field["adoption_rule"] = "PRE_NBA selection; source tuple sidecar required; no reconstruction from last commit or PCM equality"
contract = {
    "schema": "M2_R06_PUBLIC_CAPTURE_CONTRACT_V1", "status": "PARTIAL_CANDIDATE_PENDING_M1_AND_PUBLIC_EXPORT",
    "base_commit": BASE, "source_archive": ARCHIVE, "source_archive_sha256": ARCHIVE_SHA,
    "source_observation_map_sha256": sha(SOURCE / "PUBLIC_OBSERVATION_MAP.json"),
    "sampling_phase": "POSEDGE_PRE_NBA", "clock_domain": "actual core_clk; expose obs_core_clk explicitly",
    "candidate_core_hz": 40000000, "clock_identity": "P10 simulation source only; actual Pro PLL unverified",
    "field_count": 61, "category_counts": mapping["category_counts"], "fields": fields,
    "time_bases": {
        "cycle": "Monotonic actual core posedge count; never infer from 50MHz board clock or frame rows",
        "epoch": "Initial observed reset entry is0; increment on each independently recorded reset entry; no frame-derived epochs",
        "frame_origin_cycle": "F: independently scheduled and publicly observed FRAME, not an accepted request",
        "request_first_valid_cycle": "Actual req_valid first assertion; source may queue under backpressure",
        "accept_cycle": "A: actual PRE_NBA req_valid && req_ready; earliest F+1, may be later",
        "return_cycle": "Actual result_valid && result_ready tuple capture",
        "commit_cycle": "Actual pcm_valid && pcm_ready buffer acceptance; distinct from RETURN",
        "tx_cycle": "Actual frame_start && TX-valid sampling of PRE_NBA play tuple"
    },
    "deadline": {"budget_origin": "frame_origin_cycle", "strict_bound_cycles": 833,
                 "return_commit_cleanup": "t-F <833 AND t < next_independent_FRAME; no clearing overdue work",
                 "processing_age": "Report t-A separately; never replace actual acceptance timestamp by F",
                 "consume": "At actual independently scheduled next FRAME, gap833/834 from F; not a late-completion allowance",
                 "statistics_only": "max_processing_cycles excludes unfinished/overwritten requests; cannot prove per-ID deadlines"},
    "same_edge_priority": [
        "Reset asserted: invalidate old epoch; no valid normal handshake/adoption; retain independent asynchronous reset/lock event log",
        "Normal FRAME: TX samples PRE_NBA pending/held tuple; frame rollover updates state by NBA; result/commit ready gates are0",
        "FRAME raw cancel is window control even without a transaction; overdue rollover is a deadline failure, never a fabricated legal cleanup",
        "Non-FRAME: capture all simultaneous PRE_NBA event/req/result/commit/config handshakes atomically; input accept is not allocator apply"
    ],
    "tx_sidecar": {"status": "NOT_IMPLEMENTED", "pending_held_tuple": ["epoch", "req_id", "clip", "id_valid"],
                   "commit": "write pending tuple on same control branch and edge as pending PCM",
                   "frame": "Select old pending if valid, else old held; record actual TX tuple first, then move pending to held",
                   "startup": "zero PCM; no valid request identity; req_id null, never reserve numeric0",
                   "hold": "inherit held tuple, including epoch/id/clip; equal PCM proves no identity",
                   "tx_frame_id": "per-epoch actual TX-adoption ordinal, first0; distinct from request ID",
                   "overflow": "stop capture before cycle/epoch/ordinal ambiguity; preserve actual request ID modulo32 with epoch binding"},
    "legacy_D3_projection": {"source_sha256": "eb74ca9ef3cc363163d51e0c8af1a3f9bd8d15905ba3307a5ea1ab8d1c6ed764",
                             "status": "EXPLICIT_FRAME_BUDGET_DIAGNOSTIC_ONLY",
                             "REQUEST": "Derived frame-budget reservation at F; never label it actual production handshake",
                             "ACCEPT": "Actual A retained with raw row link; never shift A to F",
                             "LANE_TICK": "Only expand a real common mask1111 into same-cycle diagnostic rows with same source event; no staggered fake ticks",
                             "real_acceptance": "Separate new actual-handshake/TX/continuous-frame checks required for G1; old L1 does not certify them",
                             "old_tests_rerun": False},
    "completion": {"independent_window_required": True, "window": "Freeze active epoch windows/start/stop before execution, independent of observed FRAME or cancellation",
                   "reset_phase": "Require reset/lock input event log, known zero accumulator/BCLK/slot and exact first PRE_NBA local-reset-high edge; otherwise PENDING_RESET_PHASE",
                   "tail": "Declare last required TX adoption and full serial decode boundary in input plan; retain later guard/adoption as UNKNOWN tail, never claim decoded",
                   "finish": "Match planned stop and actual successful finish, unique MONITOR_END/END, exit0/no-timeout/cleanup receipt; EOF or old END REAL_M1 alone is insufficient",
                   "missing_plan": "PENDING_FRAME_PLAN; never derive expected frames from observed trace",
                   "empty_ledger": "Does not end frame coverage; check every planned FRAME after legitimate cancel/idle through stop"},
    "formal_interface_changed": False, "real_public_trace_exported": False, "pro_dut_pass": False, "board_release_allowed": False
}
rules = {"schema": "M2_R06_INDEPENDENT_FRAME_RULES_V1", "status": "SOURCE_DERIVATION_ONLY_NOT_EXECUTED_RTL",
         "acc_bits": 32, "phase_step": 659706977, "core_hz_candidate": 40000000, "bclk_hz_nominal": 3072000,
         "half_bclk_toggles_per_frame": 128,
         "initial_state": {"accumulator": 0, "bclk": 0, "slot_count": 0},
         "edge_index": "n=1 is first functional core edge seeing PRE_NBA rst_sync_n==1",
         "formula": "n_k=ceil(128*k*2**32/659706977); cycle_k=release_cycle+n_k-1; k>=1",
         "first_edge_indices": [834, 1667, 2500, 3334, 4167, 5000],
         "expected_input": ["frozen source/parameters SHA", "independent reset/lock event plan", "known local reset phase", "planned active windows and real finish bound"],
         "forbidden_inputs": ["observed FRAME rows as schedule authority", "transaction existence or cancellation as stop condition"],
         "unknown_action": "PENDING_RESET_PHASE or PENDING_FRAME_PLAN, no real verdict"}
schema = {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "M2_R06_NORMALIZED_ROW_CANDIDATE_V1",
          "title": "61-field PRE_NBA row; validates representation only, not provenance or G1", "type": "object",
          "required": [f["name"] for f in fields], "additionalProperties": False, "properties": {}}
for field in fields:
    name, width = field["name"], field["width"]
    value = {"type": "integer"}
    if width is not None:
        value.update({"minimum": -(1 << (width - 1)) if field["signed"] else 0,
                      "maximum": (1 << (width - int(field["signed"]))) - 1})
    schema["properties"][name] = {"anyOf": [value, {"type": "null"}, {"type": "string", "pattern": "^[01xXzZ]+$"}],
                                  "description": field["contract_status"] + "; preserve X/null; no fill0"}
routes = {"schema": "M2_R06_DIAGNOSTIC_ROUTE_PLAN_V1", "status": "NOT_IMPLEMENTED_NO_FORMAL_INTERFACE_CHANGE",
          "actual_public_four": [f["name"] for f in fields if f["bound_at_pro_top"]],
          "existing16": [f["name"] for f in fields if f["category"] == "EXISTING_PUBLIC_PORT" and not f["bound_at_pro_top"]],
          "M2_internal9": [f["name"] for f in fields if f["category"] == "M2_INTERNAL_PENDING_CONTROLLED_EXPORT"],
          "extra_clock": "obs_core_clk: actual core clock, read-only candidate port required",
          "M1_19": [f["name"] for f in fields if f["category"] == "M1_INTERNAL_PENDING_OWNER_MAPPING"],
          "missing13": [f["name"] for f in fields if f["category"] == "NOT_IMPLEMENTED_IN_CURRENT_SOURCE"],
          "R6_2_write_boundary": "Only isolated M2 five roots/r06_observer_20261017; no production top/CST/audio_defs/interface-spec edit",
          "candidate_cancel": "Raw FRAME window control; needs real ledger and reason, not unconditional transaction CANCEL",
          "audio_stable": "PENDING_STABILITY_POLICY_AND_IMPLEMENTATION; PA cannot silently be renamed stable"}
communication = {"schema": "M2_COLLABORATION_R06C1_V1", "human_authorization": "User directly designated 官_主开发2 for review communication and 官_主开发1 for integration",
                 "integration_thread": "01a147b7-00f0-7521-89ae-e7178d744be0", "review_thread": "01a148c0-8067-7781-b1c6-edbac30e355a",
                 "review_title": "官_主开发2", "status": "AUTHORIZED_BUT_SEND_BLOCKED_NOT_DELIVERED",
                 "attempted_tool": "mcp__codex_app__send_message_to_thread", "attempts_this_window": 1,
                 "error": "MCP tool call requires approval, but approval policy is never",
                 "task": "M2-R6-1 exact-source public sampling/9+16 mapping/TX sidecar/deadline/frame-plan read-only review",
                 "review_write_permission": False, "review_compile_sim_EDA_hardware_permission": False,
                 "named_auditor_previewer_system_enabled": False, "final_M2_signoff": "integration window retains responsibility",
                 "delivered": False, "accepted": False, "completed": False, "bypass_attempts": 0}
payloads = {"CAPTURE_CONTRACT.json": contract, "FRAME_PLAN_RULES.json": rules, "NORMALIZED_ROW_SCHEMA.json": schema,
            "SOURCE_BINDINGS.json": {"archive": ARCHIVE, "sha256": ARCHIVE_SHA, "files": bindings},
            "ROUTING_PLAN.json": routes, "COMMUNICATION_STATUS.json": communication}
paths = []
for name, value in payloads.items():
    relative = DOC + "/" + name
    (TREE / relative).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    paths.append(relative)
readme = """# M2-R6-1 公共采样合同候选\n\n基线42d28c4；来源ZIP931b7d2b…；仅源端静态合同与新软件校验，真实公开端口、TX旁带、M1语义、Pro身份/PLL/物理/板测尚缺，整个R6-1保持PARTIAL。CAPTURE_CONTRACT、61字段schema、SOURCE_BINDINGS和ROUTING_PLAN供M1/M3实现；FRAME_PLAN_RULES只给独立时钟/复位推导，不是已运行RTL结果。\n\n采样固定POSEDGE_PRE_NBA。保留FRAME预算起点F、请求首valid和真实握手A；原严格t-F<833预算不放宽，并同时早于独立下一FRAME。t-A独立报告。TX取该沿NBA前pending/held元组，当前源码没有ID/clip旁带。raw cancel每FRAME都有，不能无条件变成合法交易取消。D3只作为明确标注的帧预算诊断视图，REQUEST不是实际握手，不能改写真实时间；原25CLI不重跑。\n\n独立FRAME规则从reset零态和S=659706977推导第k边界ceil(128*k*2^32/S)，首有效沿序号834/1667/2500/3334…；来源是冻结输入/复位/clock计划，不能用实际FRAME行反推。无计划或未知相位PENDING；空账本/合法取消不提前结束覆盖。真实finish须计划、尾段、退出码及唯一结束标记齐套。\n\n官_主开发2由用户授权为只读复核协作窗口，但实际跨对话消息因平台approval policy=never被拒，未送达/未接单/未复核；未换工具绕过。正式审核员/预审员制度未启用。M2集成窗口继续已授权独立工作，最终签收责任不转移。\n"""
(TREE / DOC / "README.md").write_text(readme, encoding="utf-8", newline="\n")
paths.append(DOC + "/README.md")
report = """# M2双窗口协作与公共采样合同 R06-C1（2026-10-17）\n\n## 用户授权与实际送达\n\n用户指定“官_主开发1”为M2集成窗口，“官_主开发2”（01a148c0-8067-7781-b1c6-edbac30e355a）为只读复核协作窗口，允许直接通信并派发复核。职责补充只覆盖本次M2主线及其精确增量，不改变R06十五包优先级/岗位写集，不启动旧审核员/预审员双窗口流程，不转移M2最终责任。\n\n本窗口已一次调用send_message_to_thread派发M2-R6-1源端复核，接口返回`MCP tool call requires approval, but approval policy is never`。实际未送达、未接收、未复核；用户已授权与平台实际送达分开记录。不重试该审批拒绝，不改用界面/文件信箱轮询/其他工具绕过。独立主线继续，协作窗口只读任务全文由用户可手动转发；状态见COMMUNICATION_STATUS。\n\n## 本轮主线增量与边界\n\nM2在R06授权的docs/test与build新r06_observer_20261017目录产出61字段CAPTURE_CONTRACT、机器表示schema、同源引用绑定、16既有口/9内部口路由计划、TX tuple更新表及独立FRAME规则。没有修改正式接口组、原候选RTL、D3、M1/M3源或执行器。全部字段的实际导出仍pending，19项M1语义待本人确认，audio_stable真实策略和config/cancel宽度仍明确待定；不能把这份候选合同当完整R6-1/G1/Pro通过。\n\n静态原件显示FRAME沿TX采旧pending/held，而buffer同沿NBA才置sample_req/id++；实际请求接受最早F+1，背压更晚。合同分别保留F/首valid/A/RETURN/commit/TX沿，沿用严格t-F<833并严格早于下一独立FRAME，另报t-A。旧D3的REQUEST固定F，只能作为帧预算诊断保留原时间和行链接，不得当真实接受或挪动A。共同lane_tick仅一个mask1111事件，不合成错开的四拍。\n\nFRAME预期由冻结ACC_BITS32、翻转step659706977、reset零态与独立窗口给出n_k=ceil(128*k*2^32/S)，n=1是首个PRE_NBA同步复位已高的功能沿，首FRAME n=834。两级reset同步第二沿NBA释放，该沿功能逻辑仍读旧低，下一沿才n=1。取消/空闲不终止覆盖，缺独立reset/clock/stop计划PENDING。此公式为静态推导，未新跑RTL。\n\nTX旁带需随真实commit写pending(epoch,id,clip,id_valid)，FRAME按pre-NBA pending/held选取，记录采纳后搬held；startup无合法ID、HOLD继承held，不能从最后commit或PCM相等反推。raw cancel=FRAME并不等于每帧取消一笔交易。统计max只覆盖成功commit，不能证明逐笔期限。\n\n## 接手与未完成\n\nM2下一步按R6-2在独占候选实现公开出口和真实TX旁带；M1确认19语义/配置分量后再冻结对应部分；M3按R6-1..6接机器合同、双时间基点和独立FRAME期望。实际Icarus/完整链/EDA/码流/SRAM仍需另签精确准入，P7保持停止，owned_executor仅Python dummy。Pro实物身份/电气/商业许可/完整物理/板测继续待核，board_release_allowed=false。\n\n软件自检/发布实绩以本次独立回执为准；本报告形成时尚未执行新软件组、尚未提交/推送本轮增量，后续记录不回填不存在的外部复核。\n"""
(TREE / COLLAB).write_text(report, encoding="utf-8", newline="\n")
paths.append(COLLAB)
head = """## 2026-10-17 M2双窗口协作与合同推进 R06-C1\n\n用户指定官_主开发1继续M2集成、官_主开发2承担本范围只读复核并允许直接通信；实际send_message_to_thread因平台approval policy=never拒绝，**未送达/未接单/未复核**，不换工具绕过。具体任务与范围见`M2双窗口协作与公共采样合同_R06C1_2026-10-17.md`和R06新`r06_observer_20261017/COMMUNICATION_STATUS.json`；旧审核员/预审员制度未启动。\n\nM2已推进公共采样合同候选：61字段/精确源引用、pre-NBA采样、FRAME原点F与实际接受A分开、严格t-F<833且早于下一实际FRAME、TX pending/held身份旁带更新规则、独立FRAME公式/复位/finish窗口。原D3仅限定帧预算诊断，不能把A挪成F或重跑旧25。M2-R6-1整体仍PARTIAL，M1语义与实际公开出口/TX旁带待齐；R6-2为下一实现，R06十五包顺序/预算不变，P7/真实工具/物理/下载不新增许可，board_release_allowed=false。新软件组/发布状态另留原件，不冒称已由协作窗口复核。\n\n"""
headers = ["code/docs/M2_完赛任务单_2026-10-15.md", "code/docs/138K四声部后续集成任务总览_2026-10-15.md", "code/docs/当前状态.md", "code/docs/任务看板.md", "code/docs/Pro四声基础三岗扩充任务单_R06_2026-10-17.md"]
before = {}
for relative in headers:
    path = TREE / relative
    before[relative] = sha(ROOT / relative)
    text = path.read_text(encoding="utf-8")
    first, rest = text.split("\n", 1)
    path.write_text(first + "\n\n" + head + rest.lstrip("\n"), encoding="utf-8", newline="\n")
    paths.append(relative)
prior = json.loads((ROOT / "code/output/m2_pro_task_r06_20261017/PREPARED.json").read_text(encoding="utf-8"))
prepared = {"base": BASE, "paths": paths, "doc_root": DOC, "build_root": BUILD, "main_before": before,
            "main_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
            "protected": {key: prior[key] for key in ("other_dirty", "protected_old_candidate_files", "protected_old_d3_history")},
            "active_D3": "eb74ca9ef3cc363163d51e0c8af1a3f9bd8d15905ba3307a5ea1ab8d1c6ed764"}
(OUT / "PREPARED.json").write_text(json.dumps(prepared, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"files": len(paths), "status": "CONTRACT_CANDIDATE_WRITTEN_NO_RUNTIME_OR_EXTERNAL_REVIEW"}))
