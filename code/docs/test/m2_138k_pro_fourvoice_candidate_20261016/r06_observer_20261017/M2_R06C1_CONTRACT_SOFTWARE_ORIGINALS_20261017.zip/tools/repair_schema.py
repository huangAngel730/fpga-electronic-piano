"""Repair string-width representation and clarify the functional edge anchor."""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / "code/output/m2_live_tasks_publish_20261017"
DOC = TREE / "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017"


def write(name, data):
    (DOC / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


contract = json.loads((DOC / "CAPTURE_CONTRACT.json").read_text(encoding="utf-8"))
schema = json.loads((DOC / "NORMALIZED_ROW_SCHEMA.json").read_text(encoding="utf-8"))
for field in contract["fields"]:
    if field["width"] is not None:
        schema["properties"][field["name"]]["anyOf"][2]["maxLength"] = field["width"]
write("NORMALIZED_ROW_SCHEMA.json", schema)
contract["time_bases"]["request_first_valid_cycle"] = "First PRE_NBA sample with req_valid==1; not its prior NBA transition; source may queue under backpressure"
write("CAPTURE_CONTRACT.json", contract)
rules = json.loads((DOC / "FRAME_PLAN_RULES.json").read_text(encoding="utf-8"))
rules["release_cycle"] = "Global cycle of first functional core edge with PRE_NBA rst_sync_n==1; not the preceding edge whose NBA releases reset"
write("FRAME_PLAN_RULES.json", rules)
print(json.dumps({"status": "MINIMAL_SCHEMA_AND_FIXED_LEDGER_REPAIR_PREPARED", "old_group_rerun": False}))
