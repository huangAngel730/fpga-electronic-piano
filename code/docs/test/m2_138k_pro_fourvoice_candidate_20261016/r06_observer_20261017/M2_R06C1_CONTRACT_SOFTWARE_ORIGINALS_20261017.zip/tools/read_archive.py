"""Copy source evidence to a new output snapshot, preserving original bytes."""
import json
from pathlib import Path, PurePosixPath
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / "code/output/m2_live_tasks_publish_20261017"
archive = TREE / "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip"
snapshot = OUT / "READ_ONLY_SOURCE"
snapshot.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as bundle:
    for name in bundle.namelist():
        part = PurePosixPath(name)
        assert not part.is_absolute() and ".." not in part.parts and "\\" not in name
        destination = snapshot.joinpath(*part.parts)
        assert destination.resolve().is_relative_to(snapshot.resolve())
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(bundle.read(name))
mapping = json.loads((snapshot / "PUBLIC_OBSERVATION_MAP.json").read_text(encoding="utf-8"))
contract = json.loads((snapshot / "references/B1_OBSERVATION_CONTRACT.json").read_text(encoding="utf-8"))
print(json.dumps({"mapping": mapping, "B1_keys": list(contract), "source_names": [p.name for p in (snapshot / "source_closure/inputs/sources").iterdir()]}, ensure_ascii=False, indent=2))
