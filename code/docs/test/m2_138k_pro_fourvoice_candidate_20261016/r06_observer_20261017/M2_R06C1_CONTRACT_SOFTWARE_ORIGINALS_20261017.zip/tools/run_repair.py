"""Run the single <=60s repair group; preserve both earlier defects and bytes."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / "code/output/m2_live_tasks_publish_20261017"
BUILD = TREE / "code/build/138k_pro_fourvoice_candidate_20261016/r06_observer_20261017"
DOC = TREE / "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017"
BEFORE = OUT / "REPAIR_01/BEFORE"
RUN = OUT / "REPAIR_01/RUN"
FILES = ("CAPTURE_CONTRACT.json", "FRAME_PLAN_RULES.json", "ROUTING_PLAN.json", "NORMALIZED_ROW_SCHEMA.json", "SOURCE_BINDINGS.json")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def main():
    assert (OUT / "CONSUMPTION_M2_R6_1.json").is_file()
    RUN.mkdir(exist_ok=False)
    inputs = {str(path): sha(path) for path in [Path(__file__), BUILD / "validate_capture_contract.py", BUILD / "selftest_capture_contract.py", *[DOC / name for name in FILES], Path(sys.executable), OUT / "CONSUMPTION_M2_R6_1.json"]}
    with (OUT / "CONSUMPTION_M2_R6_1_REPAIR_01.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"package": "M2-R6-1", "group": "SINGLE_MINIMAL_REPAIR", "bound_seconds": 60, "inputs": inputs}, stream, indent=2)
    old = json.loads((BEFORE / "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017/NORMALIZED_ROW_SCHEMA.json").read_text(encoding="utf-8"))
    static = {}
    for field, value in (("rst_n", "10"), ("result_left", "0" * 25)):
        rule = old["properties"][field]["anyOf"][2]
        static[field] = {"value": value, "old_rule": rule, "permitted_by_old_rule": re.fullmatch(rule["pattern"], value) is not None and "maxLength" not in rule}
        assert static[field]["permitted_by_old_rule"]
    write(RUN / "FIRST_FINDINGS.json", {"level": "STATIC_SCHEMA_RULE_EVALUATION_NOT_OLD_VALIDATOR_ROW_RUN", "overwidth": static, "movable_marker": "Old output.parent-derived marker allowed changing parent; original source retained BEFORE"})
    names = json.loads((DOC / "NORMALIZED_ROW_SCHEMA.json").read_text(encoding="utf-8"))["required"]
    baseline = {name: None for name in names}
    baseline.update(cycle=0, epoch=0, rst_n=1, frame_tick=0, result_left="x" * 24)
    cases = [("final_candidate_and_known_width_X", 0, None),
             ("reject_two_bit_reset", 1, "ROW_BITSTRING_WIDTH_rst_n"),
             ("reject_25bit_PCM", 1, "ROW_BITSTRING_WIDTH_result_left"),
             ("reject_bool_as_integer_row", 1, "ROW_TYPE_rst_n"),
             ("reject_bool_width_metadata", 1, "SOURCE_FIELD_METADATA_rst_n"),
             ("reject_schema_without_width_limit", 1, "SCHEMA_BINARY_ENCODING_rst_n"),
             ("reject_new_output_parent", 2, "BLOCKED_ALREADY_CONSUMED"),
             ("reject_another_output_parent", 2, "BLOCKED_ALREADY_CONSUMED")]
    start = time.monotonic()
    results = []
    try:
        for index, (name, expected_code, expected_reason) in enumerate(cases):
            case = RUN / name
            case.mkdir()
            for filename in FILES:
                shutil.copyfile(DOC / filename, case / filename)
            row = dict(baseline)
            if index == 1:
                row["rst_n"] = "10"
            elif index == 2:
                row["result_left"] = "0" * 25
            elif index == 3:
                row["rst_n"] = True
            elif index == 4:
                path = case / "CAPTURE_CONTRACT.json"
                data = json.loads(path.read_text(encoding="utf-8"))
                next(field for field in data["fields"] if field["name"] == "rst_n")["width"] = True
                write(path, data)
            elif index == 5:
                path = case / "NORMALIZED_ROW_SCHEMA.json"
                data = json.loads(path.read_text(encoding="utf-8"))
                del data["properties"]["rst_n"]["anyOf"][2]["maxLength"]
                write(path, data)
            write(case / "row.json", row)
            argv = [sys.executable, "-X", "utf8", str(BUILD / "validate_capture_contract.py"), str(case), "--row", str(case / "row.json")]
            destination = OUT / ("ALT_PARENT_A" if index == 6 else "ALT_PARENT_B") / "NEW_GROUP"
            if index in (6, 7):
                assert not destination.exists()
                argv = [sys.executable, "-X", "utf8", str(BUILD / "selftest_capture_contract.py"), "--output", str(destination)]
            remaining = 60 - (time.monotonic() - start)
            assert remaining > 0
            before = datetime.datetime.now(datetime.timezone.utc).isoformat()
            with (case / "stdout.raw").open("xb") as stdout, (case / "stderr.raw").open("xb") as stderr:
                process = subprocess.run(argv, cwd=TREE, stdout=stdout, stderr=stderr, timeout=remaining)
            result = json.loads((case / "stdout.raw").read_text(encoding="utf-8"))
            passed = process.returncode == expected_code
            passed = passed and (result["status"] == "SOURCE_BOUND_CONTRACT_CANDIDATE_VALID" if index == 0 else (result.get("first_failure") == expected_reason if index < 6 else result["status"] == expected_reason and not destination.exists()))
            item = {"case": name, "argv": argv, "cwd": str(TREE), "start_utc": before, "end_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit_code": process.returncode, "expected_first_failure": expected_reason, "passed": passed, "stdout_sha256": sha(case / "stdout.raw"), "stderr_sha256": sha(case / "stderr.raw")}
            write(case / "RECEIPT.json", item)
            results.append(item)
            assert passed, name
        assert all(sha(Path(name)) == value for name, value in inputs.items())
        elapsed = time.monotonic() - start
        assert elapsed <= 60
        receipt = {"status": "PASS", "level": "L1_MINIMAL_REPAIR_SOFTWARE_ONLY", "cases": results, "positive": 1, "expected_rejections": 7, "bound_seconds": 60, "elapsed_seconds": elapsed, "inputs_stable": True, "inputs": inputs, "initial8_cases_rerun": False, "old_project_tests_rerun": 0, "HDL_EDA_hardware_runs": 0, "external_review_delivered": False, "pro_dut_pass": False, "board_release_allowed": False}
        write(RUN / "RECEIPT.json", receipt)
        print(json.dumps({key: receipt[key] for key in ("status", "level", "positive", "expected_rejections", "elapsed_seconds", "inputs_stable")}))
        return 0
    except (AssertionError, ValueError, OSError, subprocess.TimeoutExpired) as error:
        write(RUN / "RECEIPT.json", {"status": "FAIL", "error": str(error), "elapsed_seconds": time.monotonic() - start, "completed_cases": results})
        print(json.dumps({"status": "FAIL", "error": str(error)}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
