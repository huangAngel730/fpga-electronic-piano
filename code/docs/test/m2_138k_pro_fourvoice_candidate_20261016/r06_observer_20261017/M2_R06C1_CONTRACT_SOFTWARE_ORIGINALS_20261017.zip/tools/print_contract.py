"""Print bounded summaries of the existing public observation proposal."""
import json
from pathlib import Path

SOURCE = Path(__file__).resolve().parent / "READ_ONLY_SOURCE"
mapping = json.loads((SOURCE / "PUBLIC_OBSERVATION_MAP.json").read_text(encoding="utf-8"))
contract = json.loads((SOURCE / "references/B1_OBSERVATION_CONTRACT.json").read_text(encoding="utf-8"))
print(json.dumps({"fields": [{key: item[key] for key in ("name", "width", "signed", "category", "bound_at_pro_top")} for item in mapping["fields"]],
                  "B1_policy": {key: value for key, value in contract.items() if key != "fields"}}, ensure_ascii=False, indent=2))
