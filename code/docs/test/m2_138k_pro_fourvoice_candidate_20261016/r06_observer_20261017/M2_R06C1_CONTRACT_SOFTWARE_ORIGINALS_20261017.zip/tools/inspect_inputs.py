"""Read the already published source archive without executing its code."""
import hashlib
import json
from pathlib import Path
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / "code/output/m2_live_tasks_publish_20261017"
relative = "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip"
archive = TREE / relative
assert hashlib.sha256(archive.read_bytes()).hexdigest() == "931b7d2bbfd7ac056707542931101ff844b125936762748e344536d9be6c1ba2"
with zipfile.ZipFile(archive) as bundle:
    names = bundle.namelist()
    selected = [name for name in names if any(key in name.lower() for key in ("observation", "clock", "wrapper", "frame_buffer", "hold", "contract", "readme", "manifest"))]
    print(json.dumps({"members": len(names), "selected": selected}, ensure_ascii=False, indent=2))
    (OUT / "ARCHIVE_INVENTORY.json").write_text(json.dumps(names, indent=2) + "\n", encoding="utf-8", newline="\n")
