"""Seal existing R06C1 software originals without executing reviewed programs."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import zipfile
import zlib


OUT = Path(__file__).resolve().parent
TREE = OUT.parent / "m2_live_tasks_publish_20261017"
SEAL = OUT / "SOFTWARE_SEAL"
ARCHIVE = OUT / "M2_R06C1_CONTRACT_SOFTWARE_ORIGINALS_20261017.zip"
BUILD_REL = Path("code/build/138k_pro_fourvoice_candidate_20261016/r06_observer_20261017")
DOC_REL = Path("code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017")
SOURCE_ZIP = TREE / DOC_REL.parent / "same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip"
SOURCE_SHA = "931b7d2bbfd7ac056707542931101ff844b125936762748e344536d9be6c1ba2"
METADATA = (
    "CAPTURE_CONTRACT.json", "FRAME_PLAN_RULES.json", "ROUTING_PLAN.json",
    "NORMALIZED_ROW_SCHEMA.json", "SOURCE_BINDINGS.json",
)
TOOLS = (
    "inspect_inputs.py", "read_archive.py", "print_contract.py",
    "prepare_contract.py", "snapshot_repair.py", "repair_schema.py",
    "run_repair.py",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha(path: Path) -> str:
    return digest(path.read_bytes())


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def encoded(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def require(condition, message: str) -> None:
    if not condition:
        raise ValueError(message)


def verify_cases(folder: Path, summary: dict, *, repaired: bool) -> list[dict]:
    checks = []
    require(summary["status"] == "PASS" and summary["inputs_stable"] is True,
            "GROUP_NOT_PASS_OR_UNSTABLE")
    require(len(summary["cases"]) == 8, "GROUP_NOT_EIGHT_CASES")
    require(summary["positive"] == 1, "GROUP_NOT_ONE_POSITIVE")
    require(summary["expected_rejections" if repaired else "negative"] == 7,
            "GROUP_NOT_SEVEN_REJECTIONS")
    require(summary["elapsed_seconds"] <= (60 if repaired else 90), "GROUP_BOUND")
    for item in summary["cases"]:
        case_dir = folder / item["case"]
        require(load(case_dir / "RECEIPT.json") == item, "CASE_SUMMARY_DIFFERENCE")
        stdout = (case_dir / "stdout.raw").read_bytes()
        stderr = (case_dir / "stderr.raw").read_bytes()
        require(digest(stdout) == item["stdout_sha256"], "STDOUT_IDENTITY")
        require(digest(stderr) == item["stderr_sha256"], "STDERR_IDENTITY")
        require(not stderr and item["passed"] is True, "CASE_STDERR_OR_FAILED")
        actual = json.loads(stdout)
        positive = item["expected_first_failure"] is None
        blocked = item["expected_first_failure"] == "BLOCKED_ALREADY_CONSUMED"
        expected_code = 0 if positive else 2 if blocked else 1
        require(item["exit_code"] == expected_code, "CASE_EXIT_CODE")
        if positive:
            require(actual["status"] == "SOURCE_BOUND_CONTRACT_CANDIDATE_VALID",
                    "POSITIVE_STATUS")
        elif blocked:
            require(actual["status"] == "BLOCKED_ALREADY_CONSUMED", "MARKER_STATUS")
            require(Path(actual["ledger"]).resolve() ==
                    (OUT / "CONSUMPTION_M2_R6_1.json").resolve(), "MARKER_MOVED")
            destination = Path(item["argv"][-1])
            require(not destination.exists(), "DENIED_DESTINATION_EXISTS")
        else:
            require(actual["status"] == "REJECT", "REJECTION_STATUS")
            require(actual["first_failure"] == item["expected_first_failure"],
                    "EXACT_FIRST_FAILURE")
        for name in ("pro_dut_pass", "board_release_allowed"):
            if name in actual:
                require(actual[name] is False, "CASE_INFLATED_CLAIM")
        require(item["start_utc"] <= item["end_utc"], "CASE_UTC_ORDER")
        require("timeout" not in item or item["timeout"] is False,
                "CASE_RECORDED_TIMEOUT")
        checks.append({
            "case": item["case"], "exit_code": item["exit_code"],
            "first_failure": actual.get("first_failure"),
            "status": actual["status"], "raw_stream_sha_matches": True,
            "case_receipt_matches_summary": True,
            "timeout_evidence": "normal returned process and complete receipt; no explicit timeout field",
            "denied_destination_absent": True if blocked else None,
        })
    return checks


def main() -> None:
    require(not SEAL.exists(), "SOFTWARE_SEAL_ALREADY_EXISTS")
    require(not ARCHIVE.exists(), "ARCHIVE_ALREADY_EXISTS")
    initial = load(OUT / "SOFTWARE_01/RECEIPT.json")
    final = load(OUT / "REPAIR_01/RUN/RECEIPT.json")
    marker = load(OUT / "CONSUMPTION_M2_R6_1.json")
    repair_marker = load(OUT / "CONSUMPTION_M2_R6_1_REPAIR_01.json")
    before = OUT / "REPAIR_01/BEFORE"
    old_manifest = load(before / "MANIFEST.json")
    require(marker["inputs"] == initial["inputs"], "INITIAL_MARKER_INPUTS_DIFFER")
    require(repair_marker["inputs"] == final["inputs"], "FINAL_MARKER_INPUTS_DIFFER")
    require(load(before / "SOFTWARE_01/RECEIPT.json") == initial,
            "BEFORE_INITIAL_RECEIPT_DIFFERS")
    require((before / "CONSUMPTION_M2_R6_1.json").read_bytes() ==
            (OUT / "CONSUMPTION_M2_R6_1.json").read_bytes(), "OLD_MARKER_CHANGED")
    old_checks = []
    for path_string, expected in initial["inputs"].items():
        current_path = Path(path_string)
        old_path = None
        try:
            relative = current_path.relative_to(TREE)
            candidate = before / relative
            if candidate.is_file():
                old_path = candidate
        except ValueError:
            pass
        actual_path = old_path or current_path
        require(sha(actual_path) == expected, "INITIAL_INPUT_HAS_NO_MATCHING_OLD_BODY")
        old_checks.append({
            "recorded_path": path_string, "sha256": expected,
            "matched_body": str(actual_path),
            "version": "BEFORE_INITIAL_VERSION" if old_path else "UNCHANGED_SHARED_INPUT",
        })
    for relative, expected in old_manifest.items():
        require(sha(before / relative) == expected, "BEFORE_MANIFEST_MISMATCH")
    final_checks = []
    for path_string, expected in final["inputs"].items():
        require(sha(Path(path_string)) == expected, "FINAL_INPUT_NOT_CURRENT")
        final_checks.append({"path": path_string, "sha256": expected})
    require(final["initial8_cases_rerun"] is False, "INITIAL_GROUP_WAS_RERUN")
    require(final["old_project_tests_rerun"] == 0, "OLD_GROUP_RERUN")
    for summary in (initial, final):
        require(summary["HDL_EDA_hardware_runs"] == 0, "UNEXPECTED_HDL_RUN")
        require(summary["external_review_delivered"] is False,
                "EXTERNAL_DELIVERY_WAS_INFLATED")
        require(summary["pro_dut_pass"] is False and
                summary["board_release_allowed"] is False, "GROUP_INFLATED_CLAIM")
    require(sha(SOURCE_ZIP) == SOURCE_SHA, "SOURCE_ZIP_SHA")
    with zipfile.ZipFile(SOURCE_ZIP) as source_archive:
        require(source_archive.testzip() is None, "SOURCE_ZIP_CRC")
    initial_cases = verify_cases(OUT / "SOFTWARE_01", initial, repaired=False)
    final_cases = verify_cases(OUT / "REPAIR_01/RUN", final, repaired=True)
    require(sum(item["exit_code"] == 2 for item in final_cases) == 2,
            "NOT_TWO_MARKER_DENIALS")
    findings = load(OUT / "REPAIR_01/RUN/FIRST_FINDINGS.json")
    require(findings["level"] == "STATIC_SCHEMA_RULE_EVALUATION_NOT_OLD_VALIDATOR_ROW_RUN",
            "STATIC_FINDINGS_VERSION_INFLATED")
    communication = load(TREE / DOC_REL / "COMMUNICATION_STATUS.json")
    require(communication["delivered"] is False and communication["accepted"] is False
            and communication["completed"] is False, "EXTERNAL_REVIEW_CLAIM")
    require(communication["bypass_attempts"] == 0, "UNEXPECTED_COMMUNICATION_BYPASS")
    require(not (OUT / "ALT_PARENT_A/NEW_GROUP").exists()
            and not (OUT / "ALT_PARENT_B/NEW_GROUP").exists(), "ALT_GROUP_CREATED")
    require(len([p for p in (OUT / "SOFTWARE_01").iterdir() if p.is_dir()]) == 8,
            "INITIAL_GROUP_OUTPUT_COUNT_CHANGED")
    payload: dict[str, bytes] = {}
    originals: dict[str, dict] = {}

    def add(name: str, path: Path) -> None:
        require(name not in payload, "DUPLICATE_ARCHIVE_PATH")
        data = path.read_bytes()
        payload[name] = data
        originals[name] = {"path": str(path), "bytes": len(data), "sha256": digest(data)}

    for folder_name in ("SOFTWARE_01", "REPAIR_01"):
        for path in sorted((OUT / folder_name).rglob("*")):
            if path.is_file():
                require("__pycache__" not in path.parts, "UNEXPECTED_CACHE_INPUT")
                add("control/" + path.relative_to(OUT).as_posix(), path)
    for filename in ("CONSUMPTION_M2_R6_1.json", "CONSUMPTION_M2_R6_1_REPAIR_01.json", "PREPARED.json"):
        add("control/" + filename, OUT / filename)
    for filename in TOOLS:
        add("tools/" + filename, OUT / filename)
    add("tools/build_software_seal.py", Path(__file__))
    build_files = sorted(path for path in (TREE / BUILD_REL).iterdir() if path.is_file())
    require({p.name for p in build_files} ==
            {"selftest_capture_contract.py", "validate_capture_contract.py"},
            "UNEXPECTED_CANDIDATE_BUILD_SET")
    for path in build_files:
        add(path.relative_to(TREE).as_posix(), path)
    contract_files = sorted(path for path in (TREE / DOC_REL).iterdir() if path.is_file())
    require(all(path.stat().st_size <= 200000 for path in contract_files),
            "UNEXPECTED_LARGE_CANDIDATE_METADATA")
    for path in contract_files:
        add(path.relative_to(TREE).as_posix(), path)
    add("source_archive/" + SOURCE_ZIP.name, SOURCE_ZIP)
    verification = {
        "status": "PASS_EXISTING_SOFTWARE_ORIGINALS_FILE_VERIFICATION",
        "level": "L1_SOFTWARE_CONTRACT_ONLY",
        "overall_R6_1": "PARTIAL",
        "initial_version": {"cases": initial_cases, "elapsed_seconds": initial["elapsed_seconds"],
                            "bound_seconds": 90, "input_body_mapping": old_checks},
        "final_repair_version": {"cases": final_cases, "elapsed_seconds": final["elapsed_seconds"],
                                 "bound_seconds": 60, "current_inputs": final_checks},
        "initial_group_rerun": False,
        "initial_marker_unchanged": True,
        "alternate_output_groups_absent": True,
        "new_test_or_reviewed_program_launches": 0,
        "HDL_EDA_hardware_runs": 0,
        "static_findings_are_not_old_validator_executions": True,
        "communication": {
            "status": communication["status"], "delivered": False,
            "accepted": False, "completed": False,
            "reason": communication["error"], "internal_helper_is_external_reviewer": False,
        },
        "pending": ["M1 semantics", "public observer export", "TX sidecar", "real Pro evidence"],
        "tool_runtime_identity_recorded_not_copied": {
            "path": sys.executable, "bytes": Path(sys.executable).stat().st_size,
            "sha256": sha(Path(sys.executable)),
        },
        "pro_dut_pass": False, "board_release_allowed": False,
    }
    scope = {
        "schema": "M2_R06C1_SOFTWARE_ORIGINALS_SEAL_V1",
        "utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Existing raw originals at their actual initial and final repair versions; no tested program executed by sealing",
        "canonical_raw_bytes": True,
        "initial_1_positive_7_negative_not_final_rerun": True,
        "repair_1_positive_7_rejections_includes_2_marker_denials": True,
        "overall_status": "PARTIAL",
        "level": "L1_SOFTWARE_CONTRACT_ONLY",
        "external_review": "BLOCKED_NOT_DELIVERED_NOT_REVIEWED",
        "pro_dut_pass": False, "board_release_allowed": False,
    }
    payload["seal/VERIFICATION.json"] = encoded(verification)
    payload["seal/ARCHIVE_SCOPE.json"] = encoded(scope)
    manifest = {
        "schema": "M2_R06C1_SOFTWARE_ORIGINALS_MANIFEST_V1",
        "files": [{"path": name, "bytes": len(data), "sha256": digest(data)}
                  for name, data in sorted(payload.items())],
        "pro_dut_pass": False, "board_release_allowed": False,
    }
    manifest_bytes = encoded(manifest)
    SEAL.mkdir()
    (SEAL / "MANIFEST.json").write_bytes(manifest_bytes)
    (SEAL / "VERIFICATION.json").write_bytes(encoded(verification))
    (SEAL / "ARCHIVE_SCOPE.json").write_bytes(encoded(scope))
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payload.items()):
            archive.writestr(name, data)
        archive.writestr("MANIFEST.json", manifest_bytes)
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(archive.testzip() is None, "SEALED_ARCHIVE_CRC")
        require(set(archive.namelist()) == set(payload) | {"MANIFEST.json"}, "ZIP_MEMBER_SET")
        require(len(archive.namelist()) == len(payload) + 1, "DUPLICATE_ZIP_MEMBER")
        require(archive.read("MANIFEST.json") == manifest_bytes, "ZIP_MANIFEST_BODY")
        for item in manifest["files"]:
            data = archive.read(item["path"])
            info = archive.getinfo(item["path"])
            require(data == payload[item["path"]], "ZIP_ORIGINAL_BYTE_DIFF")
            require(len(data) == item["bytes"] and digest(data) == item["sha256"],
                    "ZIP_MEMBER_SHA_OR_SIZE")
            require(zlib.crc32(data) == info.CRC, "ZIP_MEMBER_INDEPENDENT_CRC")
    for item in originals.values():
        require(Path(item["path"]).stat().st_size == item["bytes"]
                and sha(Path(item["path"])) == item["sha256"], "SOURCE_CHANGED_WHILE_SEALING")
    receipt = {
        "status": "PASS_CRC_MANIFEST_SHA_AND_CURRENT_ORIGINAL_BYTES",
        "utc": datetime.now(timezone.utc).isoformat(),
        "archive": {"path": str(ARCHIVE), "bytes": ARCHIVE.stat().st_size,
                    "sha256": sha(ARCHIVE), "members": len(payload) + 1,
                    "payloads": len(payload), "manifest_sha256": digest(manifest_bytes)},
        "checks": {"crc": True, "independent_crc32": True, "exact_member_set": True,
                   "all_manifest_sizes_sha": True, "all_original_bytes": True,
                   "original_inputs_unchanged": True,
                   "initial_inputs_match_before_version": True,
                   "final_inputs_match_current_version": True,
                   "initial_marker_unchanged": True, "both_new_parent_groups_absent": True},
        "version_counts": {"initial_positive": 1, "initial_negative": 7,
                           "final_repair_positive": 1, "final_repair_rejections": 7,
                           "final_repair_marker_denials": 2,
                           "initial_group_rerun": False},
        "level": "L1_SOFTWARE_CONTRACT_ONLY", "overall_R6_1": "PARTIAL",
        "new_test_or_reviewed_program_launches": 0,
        "external_review_delivered": False, "external_review_completed": False,
        "source_zip_sha256": SOURCE_SHA,
        "original_file_count": len(originals),
        "candidate_contract_file_count": len(contract_files),
        "pro_dut_pass": False, "board_release_allowed": False,
    }
    (SEAL / "RECEIPT.json").write_bytes(encoded(receipt))
    print(json.dumps({"status": receipt["status"], **receipt["archive"],
                      "receipt": str(SEAL / "RECEIPT.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
