"""Keep the first implementation and initial-group evidence before repair."""
import hashlib
import json
from pathlib import Path
import shutil

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / "code/output/m2_live_tasks_publish_20261017"
prepared = json.loads((OUT / "PREPARED.json").read_text(encoding="utf-8"))
target = OUT / "REPAIR_01/BEFORE"
target.mkdir(parents=True, exist_ok=False)
names = [prepared["doc_root"] + "/" + name for name in ("CAPTURE_CONTRACT.json", "FRAME_PLAN_RULES.json", "NORMALIZED_ROW_SCHEMA.json")]
names += [prepared["build_root"] + "/" + name for name in ("validate_capture_contract.py", "selftest_capture_contract.py")]
manifest = {}
for name in names:
    source = TREE / name
    destination = target / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    manifest[name] = hashlib.sha256(source.read_bytes()).hexdigest()
for name in ("CONSUMPTION_M2_R6_1.json", "SOFTWARE_01/RECEIPT.json"):
    destination = target / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(OUT / name, destination)
(target / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"status": "INITIAL_VERSION_PRESERVED", "files": len(manifest), "defects": ["known-width raw bit strings have no maxLength", "one-shot marker depends on chosen output parent"]}))
