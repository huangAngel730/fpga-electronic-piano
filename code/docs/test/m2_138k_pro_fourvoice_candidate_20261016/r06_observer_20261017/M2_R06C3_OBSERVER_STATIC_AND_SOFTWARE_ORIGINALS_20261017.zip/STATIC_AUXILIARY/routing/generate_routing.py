"""Prepare isolated R06 public observation copies, without invoking HDL tools."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / "code/output/m2_r06_observer_20261017/routing"
ORIGINAL = BASE / "originals"
DEST = ROOT / "code/rtl/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017"


def replace_once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new, 1)


INTERNAL = [
    ("req_valid", ""), ("req_ready", ""),
    ("result_valid", ""), ("result_ready", ""),
    ("result_id", "[31:0] "),
    ("result_left", "signed [23:0] "),
    ("result_right", "signed [23:0] "),
    ("result_clip_mask", "[1:0] "),
]
SIDECAR = [
    ("tx_sample_valid", ""), ("tx_metadata_valid", ""),
    ("tx_req_id_valid", ""), ("tx_frame_id", "[31:0] "),
    ("tx_req_id", "[31:0] "), ("tx_clip_mask", "[1:0] "),
    ("tx_clip_any", ""), ("tx_hold", ""),
    ("tx_startup_zero", ""), ("metadata_error", ""),
    ("frame_id_overflow", ""),
]
BOARD = [
    ("core_clk", ""), ("polyphonic_valid", ""),
    ("rst_n", ""), ("frame_tick", ""),
    ("event_valid", ""), ("event_ready", ""),
    ("event_data", "[63:0] "),
    *INTERNAL,
    ("req_id", "[31:0] "), ("commit", ""),
    ("commit_id", "[31:0] "),
    ("commit_left", "signed [23:0] "),
    ("commit_right", "signed [23:0] "),
    ("commit_clip", ""), ("cancel", ""),
    ("config_valid", ""), ("config_ready", ""),
    ("tx_left", "signed [23:0] "),
    ("tx_right", "signed [23:0] "),
    ("pll_locked", ""),
    *SIDECAR,
]


def ports(fields):
    return ",\n".join(f"    output wire {kind}obs_{name}" for name, kind in fields)


core_original = (ORIGINAL / "m2_fourvoice_timbre_delay_frame_core.sv").read_text(encoding="utf-8")
core = replace_once(core_original,
    "module m2_fourvoice_timbre_delay_frame_core (",
    "module m2_fourvoice_timbre_delay_frame_core_r06 (")
core = replace_once(core, "    output wire committed_clip\n);",
    "    output wire committed_clip,\n" + ports(INTERNAL + [("cancel", "")] + SIDECAR) + "\n);")
core = replace_once(core,
    "    assign request_accept = request_valid && request_ready;",
    "    assign request_accept = request_valid && request_ready;\n\n"
    "    // Explicit diagnostics. Capture on clk posedge PRE_NBA; never infer A from FRAME F.\n"
    "    assign obs_req_valid = request_valid;\n"
    "    assign obs_req_ready = request_ready;\n"
    "    assign obs_result_valid = result_valid;\n"
    "    assign obs_result_ready = result_ready;\n"
    "    assign obs_result_id = result_id;\n"
    "    assign obs_result_left = result_left;\n"
    "    assign obs_result_right = result_right;\n"
    "    assign obs_result_clip_mask = {clip_right, clip_left};\n"
    "    // Raw frame-window cancel; an observer must not invent a transaction CANCEL.\n"
    "    assign obs_cancel = candidate_cancel;")
sidecar_instance = """
    // The sidecar mirrors result-hold, pending and held identity only. It does
    // not drive PCM, reset, ready, valid, or any mathematical datapath control.
    // The board connects TX valid to 1 and its frame_tick to this same FRAME.
    // Reset invalidates identities; capture assigns epoch from independent reset edges.
    m2_r06_tx_identity_sidecar u_tx_identity_sidecar (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick), .tx_valid(1'b1),
        .result_valid(result_valid), .result_ready(result_ready),
        .result_id(result_id), .result_clip_mask({clip_right, clip_left}),
        .commit_pulse(commit_pulse), .commit_id(committed_id),
        .commit_left(committed_left), .commit_right(committed_right),
        .buffer_pending_valid(pending_valid),
        .play_left(play_left), .play_right(play_right),
        .tx_sample_valid(obs_tx_sample_valid),
        .tx_metadata_valid(obs_tx_metadata_valid),
        .tx_req_id_valid(obs_tx_req_id_valid),
        .tx_frame_id(obs_tx_frame_id), .tx_req_id(obs_tx_req_id),
        .tx_clip_mask(obs_tx_clip_mask), .tx_clip_any(obs_tx_clip_any),
        .tx_hold(obs_tx_hold), .tx_startup_zero(obs_tx_startup_zero),
        .tx_left(), .tx_right(),
        .metadata_error(obs_metadata_error),
        .frame_id_overflow(obs_frame_id_overflow)
    );
"""
core = replace_once(core, "endmodule", sidecar_instance + "endmodule")
core = "// R06 isolated observation successor. M1 chain and PCM math remain frozen.\n" + core

board_original = (ORIGINAL / "m2_fourvoice_timbre_delay_board_top.sv").read_text(encoding="utf-8")
board = board_original.replace("M2_FOURVOICE_TIMBRE_DELAY_TOP_SV", "M2_FOURVOICE_TIMBRE_DELAY_TOP_R06_SV")
board = replace_once(board, "module m2_fourvoice_timbre_delay_board_top #(",
    "module m2_fourvoice_timbre_delay_board_top_r06 #(")
board = replace_once(board, "    output wire [2:0] tmds_data_p,tmds_data_n\n);",
    "    output wire [2:0] tmds_data_p,tmds_data_n,\n" + ports(BOARD) + "\n);")
globals_map = {
    "core_clk": "core_clk", "rst_n": "rst_sync_n", "frame_tick": "i2s_frame_tick",
    "event_valid": "shared_event_valid", "event_ready": "shared_event_ready",
    "event_data": "shared_event_data", "req_id": "sample_req_id",
    "commit": "pcm_valid_q && pcm_ready", "commit_id": "produced_req_id",
    "commit_left": "produced_left", "commit_right": "produced_right",
    "tx_left": "buffered_left", "tx_right": "buffered_right",
    "pll_locked": "visual_pll_locked",
}
global_assigns = "\n    // Read-only R06 public observation routes; all use the actual core axis.\n"
global_assigns += "".join(f"    assign obs_{key} = {value};\n" for key, value in globals_map.items())
board = replace_once(board, "    assign sample_tick = frame_sample_req;",
    "    assign sample_tick = frame_sample_req;\n" + global_assigns)
invalid_fields = INTERNAL + [("cancel", ""), ("config_valid", ""), ("config_ready", ""), ("commit_clip", "")] + SIDECAR
fixed_assigns = "\n        // SOURCE_MODE=1 is legacy fixed-tone diagnostics, not a four-voice trace.\n"
fixed_assigns += "        assign obs_polyphonic_valid = 1'b0;\n"
fixed_assigns += "".join(f"        assign obs_{name} = '0;\n" for name, _ in invalid_fields)
board = replace_once(board,
    "      if (SOURCE_MODE == 1) begin:g_fixed_tone",
    "      if (SOURCE_MODE == 1) begin:g_fixed_tone" + fixed_assigns)
board = replace_once(board,
    "      end else begin:g_polyphonic\n",
    "      end else begin:g_polyphonic\n"
    "        assign obs_polyphonic_valid = 1'b1;\n"
    "        assign obs_config_valid = m1_config_pending;\n"
    "        assign obs_config_ready = m1_config_ready;\n")
board = replace_once(board, "        m2_fourvoice_timbre_delay_frame_core u_audio_core (",
    "        m2_fourvoice_timbre_delay_frame_core_r06 u_audio_core (")
new_core_connections = ",\n".join(f"          .obs_{name}(obs_{name})" for name, _ in INTERNAL + [("cancel", "")] + SIDECAR)
board = replace_once(board,
    "          .committed_right(produced_right), .committed_clip()\n",
    "          .committed_right(produced_right), .committed_clip(obs_commit_clip),\n" + new_core_connections + "\n")
board = "// R06 isolated public-observation successor; not a physical Pro board release.\n// Legacy comments below describe frozen source history; no pin/clock changes here.\n" + board

wrapper_original = (ORIGINAL / "m2_138k_pro_fourvoice_candidate_top.sv").read_text(encoding="utf-8")
wrapper = replace_once(wrapper_original, "module m2_138k_pro_fourvoice_candidate_top (",
    "module m2_138k_pro_fourvoice_observer_top_r06 (")
wrapper = replace_once(wrapper, "    output wire [2:0]  tmds_data_n\n);",
    "    output wire [2:0]  tmds_data_n,\n" + ports(BOARD) + "\n);")
wrapper = replace_once(wrapper, "    m2_fourvoice_timbre_delay_board_top u_legacy (",
    "    // Explicit SOURCE_MODE=0 prevents fixed-tone input from posing as four voices.\n"
    "    m2_fourvoice_timbre_delay_board_top_r06 #(.SOURCE_MODE(0)) u_legacy (")
wrapper_connections = ",\n".join(f"        .obs_{name}(obs_{name})" for name, _ in BOARD)
wrapper = replace_once(wrapper, "        .tmds_data_n(tmds_data_n)\n",
    "        .tmds_data_n(tmds_data_n),\n" + wrapper_connections + "\n")
wrapper = "// R06 simulation observation surface. No package pins or physical admission.\n// Capture obs_* at posedge obs_core_clk PRE_NBA and require obs_polyphonic_valid.\n" + wrapper

DEST.mkdir(parents=True, exist_ok=True)
receipt = []
for old_name, new_name, old_text, text in [
    ("m2_fourvoice_timbre_delay_frame_core.sv", "m2_fourvoice_timbre_delay_frame_core_r06.sv", core_original, core),
    ("m2_fourvoice_timbre_delay_board_top.sv", "m2_fourvoice_timbre_delay_board_top_r06.sv", board_original, board),
    ("m2_138k_pro_fourvoice_candidate_top.sv", "m2_138k_pro_fourvoice_observer_top_r06.sv", wrapper_original, wrapper),
]:
    target = DEST / new_name
    if target.exists():
        assert target.read_text(encoding="utf-8") == text, f"Refusing overwrite: {target}"
    else:
        target.write_text(text, encoding="utf-8", newline="\n")
    diff = "".join(difflib.unified_diff(old_text.splitlines(True), text.splitlines(True),
        fromfile=old_name, tofile=new_name))
    (BASE / (new_name + ".diff")).write_text(diff, encoding="utf-8", newline="\n")
    receipt.append({"source": old_name, "target": str(target.relative_to(ROOT)),
        "source_sha256": hashlib.sha256((ORIGINAL / old_name).read_bytes()).hexdigest(),
        "target_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "diff_lines": len(diff.splitlines())})
(BASE / "ROUTING_COPY_RECEIPT.json").write_text(json.dumps({
    "status": "IMPLEMENTED_STATIC_ONLY_NO_HDL_RUN", "files": receipt,
    "public_ports": [{"name": "obs_" + name, "declaration": "output wire " + kind} for name, kind in BOARD],
    "formal_interface_changed": False, "M1_19_implemented": False,
    "stability_policy_implemented": False,
    "pending": ["M1_19_EXPLICIT_EXPORTS", "AUDIO_STABLE_POLICY", "REAL_HDL_ADMISSION_AND_VERIFICATION"]
}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt, ensure_ascii=False, indent=2))
