# M2-R6-2 只读验证设计（2026-10-17）

本文件是根代理委派的内部设计意见，未执行被审代码、测试、编译、仿真、EDA、设备或 Git 写命令。只写本独占 output/tb_plan。没有取得或代签 HDL 执行许可。候选 RTL 与 TB 的最终实现、精确准入、状态及发布由根 M2 负责。

## 阅读依据与真实链路

已读根/code/rtl 三份 AGENTS、协作入口、历史三人开工说明、最新任务看板/总览头部、R06 三岗任务单和 R06-C1 合同/路由/FRAME 规则。真实来源是本轮 FROZEN/source_closure/inputs/sources 的同版副本；其绑定原包 SHA 为 931b7d2bbfd7ac056707542931101ff844b125936762748e344536d9be6c1ba2。

| 文件 | SHA256 |
| --- | --- |
| pcm_frame_buffer.sv | f8bc454a2e627809c2f9f9029c1e5128acf2fd543d7fcc2d3d83b50685f40997 |
| pcm_result_hold.sv | 7656fd0089efd140de784352d1e7809169240e6a09263c8ce9428298b424d52f |
| premixed_frame_adapter.sv | d7952a5f986eb8b609cbe657907e418cfe751c6492d6e49469b5e37c390bb56c |
| i2s_tx.sv | 6c703e31064e5943df4e310b3baddd8935362a1c028828d8e11f8f3c016267ad |
| m2_fourvoice_timbre_delay_frame_core.sv | 6d32ddc33aa0fed39ea1290f1d6e490f241c7b20fb6c9d8f02e7317e45201e2e |
| m2_fourvoice_timbre_delay_board_top.sv | f2a8f30fef8ad2da26d1d3b80793b727f45806b6d5c78f2a071fb383322639be |

各握手在 actual core_clk 的 posedge PRE_NBA 判定。F 沿 buffer 在 NBA 才置 frame_sample_req/id++，adapter 的 !frame_tick 使实际 A 最早 F+1；背压时更晚。R 沿 result_valid&&result_ready 后，result_hold 在 NBA 才置 pcm_valid，故 commit 最早 R+1；commit 只是写 pending，TX 仍到下一实际 FRAME 才采 old pending。frame_tick 分支优先，两级 ready 均有 !frame_tick，FRAME 同沿结果不能救回过期一代。

TX 的输入 play=pending_valid?pending:held，与旁带的 ID/clip 选择必须使用同一 PRE_NBA 值。FRAME 记录的实际 TX 采纳 tuple 与 NBA 后的 held/pending 状态分开。对公开观察口只能选一种清楚语义：建议 tx_sample_valid 是本沿采纳事件，tuple 是本沿 pre-NBA 所选数据；若输出改为注册记录，必须另给明确有效相位/延迟，不能在 PRE_NBA 行把上一帧记录说成本沿采纳。

原链已在 frame_core 将双 clip OR 后送进 adapter/result_hold，因此不能在 commit 时再取实时 result_clip_mask；新旁带需在实际 R 握手锁存双 clip，并于实际 commit 将锁存双 clip 与同代 PCM/ID 一起写 pending。双 clip 左 bit0/右 bit1。正常链路没有现成的双 clip committed 口。

## 未来自检 HDL TB 必须覆盖的分支

以下为设计矩阵，全部 NOT_RUN。一个用例可含多行，但须逐沿比对独立状态机期望，不能只检查最终计数。

| 编号 | 刺激/故障 | 精确期望 |
| --- | --- | --- |
| T01 | 异步 reset 在非 clk 沿拉低；首个 FRAME，无任何 commit | pending/held/result metadata 立即失效；首零 PCM 不携合法请求 ID，startup=1，hold=0。数值0不得替代 id_valid=0/null。 |
| T02 | F 产生请求，A=F+1；另例 readiness 故意低3拍 | 公开 req_valid/id 在背压时稳定，A 是实际握手沿；F 与 A 分列，不能用 F 代 A。 |
| T03 | 在 A 前送一个看似同 ID 的 result | 不得接受或生成 commit；dispatched 限制真实存在。 |
| T04 | 正常 R 后下一沿 commit；FRAME 前插若干空沿 | R 只锁 result tuple，commit 只锁 pending，tx_sample_valid=0；TX 仍是旧held/启动零。 |
| T05 | R 双 clip=01，R+1 上游立即改 clip=10/00；再将 result PCM/id 任意改变 | commit/pending 仍为 R 的双 clip=01、PCM、ID。另将01/10/11各跑一次以检左右独立与OR兼容；不得从 committed_clip 单比特还原双 clip。 |
| T06 | pending 后下一 F | 本沿 TX 采 old pending 全 tuple，startup=0/hold=0；NBA 后 pending_valid=0、held=该 tuple，PCM 与元数据原子移动。 |
| T07 | 之后两个 F 无新 commit | 每次 TX 均继承 held 的 ID/PCM/双 clip，hold=1；不能从当前 request_id、最后结果或新frame ordinal重算请求ID。 |
| T08 | 连续两笔不同 ID，PCM 完全相同但 clip 不同 | 两次 TX 身份按真实 pending来源改变；后续 HOLD 继承第二笔 ID 与 clip。PCM 相等不推导身份相等。 |
| T09 | result/commit 候选与 F 同沿 | FRAME 先发生，不能接受新result/commit；TX 只能采 old pending/held；若监视到 frame&&commit 是源合同故障，应显式拒收/标错而非让旁带伪装成功。 |
| T10 | 错ID/stale ID结果、重复结果、重复commit候选 | result_ready或pcm_ready为0，不能覆盖一代已占pending，不增真实commit计数；异常监测与合法状态机区分。 |
| T11 | pending占用时继续送新结果/commit，直到F消费 | 不覆盖pending；错误输入明确阻断。真实 frame_buffer 一代只准一次 commit，不以覆盖为合法队列。 |
| T12 | result已接受但commit前非沿reset；pending持有时reset；held/TX串行中reset | 三种路径均清理旧epoch状态，不得重启后泄漏旧ID/双clip/PCM；被截断串行帧UNKNOWN，不误报完整零帧。 |
| T13 | PLL失锁导致 core_async_rst_n 拉低，即使 core_clk暂停 | PA立即禁用/本地复位拉低；同步释放仍两FF，首个功能PRE_NBA沿晚于第二FF释放NBA，不能偏移一拍计首FRAME。 |
| T14 | 请求ID在同epoch回绕或跨reset重用同值 | frame ordinal与req ID分开；跨reset必须有采集epoch区分，不以req ID单独作全局键。回绕未获明确规则时拒绝跨度混合。 |
| T15 | 833/834实际下一FRAME，分别在age832与age833 result/commit | 依合同严格 t-F<833 且早于下一独立FRAME；实际A年龄另报，不能因A晚而放宽F预算。下一FRAME833/834可消费先前合法commit。 |
| T16 | 四种符号/舍入边界，TX tuple录入后，公开pins解码 | 引脚按LSBJ、WS低右、左右各末16上升沿、24→16有符号舍入饱和；帧首标签对后续完整串行帧，最后半帧不得硬配。属于后续真实数字链，不能由旁带软件模型声称通过。 |

最后须有机器watchdog、唯一正常finish、实际退出0、尾部未消费/未知帧策略；不能从EOF推导成功。所有 reset/PLL/stability 状态不应把现有 PA 谓词改名 audio_stable；真实稳定策略未实现仍PENDING。

## 当前一次 ≤90s 软件组能证明什么

M2-R6-2 的新组与已消费 M2-R6-1 组分开；消费固定 task ledger，不能按新输出目录、新窗口或日期恢复。执行前冻结精确cases/源码/输入/依赖/独占输出/总时限，记录双流、退出码和开始结束时间。只允许新的纯Python/纯文件检查，不启动iverilog/vvp/ModelSim/Gowin或任何HDL编译器。

根M2随后明确本轮组只做文件/装配核查，以下规范模型/合成行仅留未来设计，不在本轮执行。建议本轮实际组冻结第1部分的正负例；第2/3部分不能据此启动或报已通过：

1. 静态来源/路由合同核查：真实旧源SHA、候选新名、显式逐层端口连接、所有16既有口+9内部口+core_clk、位宽/符号/双clip位序/复位极性；拦缺口、接错ready、把last_commit当TX以及从顶层私有层级偷读。使用受限端口/实例解析时标注解析器支持范围；正则文本匹配不能当HDL语义或综合证明。
2. 按上表提炼独立 Python 规范状态机，手写跨沿输入序列与预期tuple，覆盖startup→result→commit→FRAME→HOLD及reset。把旁带/公开口候选只作文本输入，Python结果只签“规范状态机/检查器软件自检”，不能声称DUT与模型一致。
3. 故障注入到合成观察行：不同ID同PCM冒认、采lastcommit、R后clip变化误取实时值、FRAME同沿commit、pending覆盖、跨epoch旧tuple、startup伪ID0、缺独立FRAME/提前END各至少一项预期拒收。正例/负例在receipt逐项记录。不重复旧D3 24或C1原组。

软件模型未执行RTL；静态路由核查也不能证明nonblocking竞态、SV signedness实际仿真、I2S引脚或复位毛刺安全。新模块附自检TB源码后仍标 NOT_RUN，G1/P7/物理/板测无升级。

## 最小精确 HDL 准入输入

可先申请仅 observer/sidecar 单元的精确准入，不必伪等19项M1字段已齐，也不能混入完整Pro链。需要：

- 冻结一个候选top/TB与source-list/每个源SHA，ROM和include显式列出（若单位测试确实不需则空表说明），无重复模块/路径逃逸；仅外部端口激励/观察，不窥私有层级。
- 新工具受控执行器的原件与实际能力证明；当前 owned_executor 仅Python dummy，不能直接把allowlist改名后启动真实HDL。执行器方案必须限制已核EXE/依赖、子进程、独占输出、墙钟、异常/取消/超时的Job清理并保存原双流。
- 精确EXE路径/hash/版本及编译/运行argv/cwd/必要环境、输出路径、并发锁和固定消费键；M2签发最多一次编译与一次运行、共同总时限以及不成功时的停止动作。次数/时限由实际准入填写，本分析不预授权。
- 精确cases覆盖边界、PASS/FAIL判据、watchdog/退出码、最大预期时长、首失败保留、no-rerun条款；旧P7、旧allow变量、旧R05额度继续无效。
- 实际合同相位与返回/commit/TX区分、双clip保存、startup无ID、reset后epoch策略和finish齐套。

由M2最终决定；单元仿真若通过仍只签该单元，完整公开口数字链、实际Pro PLL/约束、EDA/STA、新.fs和SRAM各保持独立门槛。

## M3 八包扩充至十二个实施包的建议

保留原R6-1..8名称与优先级。新增4个叶子只细分旧包内部的真实缺口，不能把旧准备改名当新完成；不改变 M1算法、M2旁带/正式接口/工具准入所有权。任务单生效时应明确允许新增目录，以下优先放旧包子目录，无论是否改名都共享原R6消费键。

| 编号与单写者叶子 | 实现输出与真实新增价值 | 旧包归属/预算；依赖 |
| --- | --- | --- |
| 1 source_target_audit | 新候选实际compile闭包生成/模块重复/ROM路径/target模式校验CLI，pin所有真实来源 | 原R6-1原一次组；无板立即，M2最终冻结闭包 |
| 2 midi_stimulus | 独立外部MIDI字节/时刻计划与driver及seq/窗口本体 | 原R6-2原一次组；不得把串行四条说成同拍 |
| 3 normalized_intake（排除provenance_roundtrip子树） | 61原字段保留→B2 29视图→D3投影，X/null与cycle/epoch排序保真 | 原R6-3组，与12共享一次；冻结C1和新导出字段 |
| 4 tool_plan_adapter | EXE/输入/输出/超时/消费计划审计CLI，默认真实启动0 | 原R6-4原一次组；不修改M2 executor、不自签许可 |
| 5 event_calendar（排除public_port_capture子树） | 以独立MIDI与M1实际apply/slot/advance建立每seq/req/epoch账本；非推断式关联 | 原R6-5组，与9共享一次；真实结项依赖M1字段 |
| 6 tx_clock_reset_checker（排除frame_calendar/reset_finish子树） | 只负责TX采纳/ID/双clip与独立pins解码的逐帧核同，startup/HOLD/同PCM异ID | 原R6-6组，与10/11共享一次；M2 sidecar到件后真实接入 |
| 7 hardware_identity | 芯片完整料号/板Dock修订/Bank/PA/MIDI真实来源与安全测试点原件校验器 | 原R6-7原一次组仅软件；实际测量先核条件，不含下载 |
| 8 board_capture_acceptance | 同版输入/数字pins/模拟音频采集编排与验收、失败首现场/延迟误差 | 原R6-8无新增软件组/设备额度；实际等M2物理与精确SRAM许可 |
| 9 event_calendar/public_port_capture | 新被动observer/记录器：仅公开口按PRE_NBA采actualcore，保留RAW61/行号/原timestamp/epoch和采样相位；无私有层级，无写M2 RTL | R6-5共享一次，不给第二组；与5交换只读版本化行文件，写集互斥 |
| 10 tx_clock_reset_checker/frame_calendar | 独立reset/PLL/stop输入→FRAME预期公式与实际全帧覆盖检查CLI，覆盖idle/legalcancel后到truefinish | R6-6共享一次；期望不得来自观测FRAME列表，缺相位PENDING |
| 11 tx_clock_reset_checker/reset_finish | 异步reset/失锁/PA/tail/END/exit receipt关联检查CLI，截断串行帧UNKNOWN、唯一真实finish、尾段漏帧拒收 | R6-6共享一次；实际时间轴依赖9/10/M2导出，不能把PA当stable |
| 12 normalized_intake/provenance_roundtrip | RAW→61→29/D3各视图的line/cycle/epoch/id可逆索引与SHA闭环检查，识别缺行/重复/错源/跨会话，说明29列不可重建缺13项 | R6-3共享一次；与3只读互喂版本化本体，不改旧B1/B2/D3 |

十二包不是十二份软件执行额度。调度必须在原包组开始前把同父包各叶子cases一起冻结，由唯一预算负责人一次运行；原组已消费则新叶子只能做源码/静态阅读，除非出现新具体缺陷且原repair尚未消费，才可按已有≤60秒增量规则；不能为新功能伪造缺陷。实物/EDA/真实编译/完整链始终不包含。

建议最多3写者：A做1/4，B做2/5/9，C做3/6/10/11/12；这不是三人可同时写同一包，须以精确目录和时间分配互斥。有真实板条件时7由硬件负责人独立推进、8继续等待准入，不能超过总体同时3个独立写者限制。每叶子交实际代码、命令、原件与缺口，软件PASS、合成checker PASS、真实trace PASS逐项区分。

新组计时/消费账本、原失败和原预算由M2统一登记；本建议没有执行任何组，没有建立新额度，没有发送给M3真人或窗口。
