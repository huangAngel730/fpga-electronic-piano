"""Freeze actual candidate bodies and explicit static-only route bindings."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / 'code/output/m2_live_tasks_publish_20261017'
RTL = 'code/rtl/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'
DOC = 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'
NAMES = ['m2_fourvoice_timbre_delay_frame_core_r06.sv', 'm2_fourvoice_timbre_delay_board_top_r06.sv',
         'm2_138k_pro_fourvoice_observer_top_r06.sv', 'm2_r06_tx_identity_sidecar.sv']
ports = ('core_clk polyphonic_valid rst_n frame_tick event_valid event_ready event_data req_valid req_ready '
         'result_valid result_ready result_id result_left result_right result_clip_mask req_id commit '
         'commit_id commit_left commit_right commit_clip cancel config_valid config_ready tx_left tx_right '
         'pll_locked tx_sample_valid tx_metadata_valid tx_req_id_valid tx_frame_id tx_req_id tx_clip_mask '
         'tx_clip_any tx_hold tx_startup_zero metadata_error frame_id_overflow').split()
assert len(ports) == 38
expected = {'obs_' + n: {'width': 1, 'signed': False} for n in ports}
for n in ('req_id', 'result_id', 'commit_id', 'tx_frame_id', 'tx_req_id'):
    expected['obs_' + n]['width'] = 32
expected['obs_event_data']['width'] = 64
for n in ('result_left', 'result_right', 'commit_left', 'commit_right', 'tx_left', 'tx_right'):
    expected['obs_' + n] = {'width': 24, 'signed': True}
for n in ('result_clip_mask', 'tx_clip_mask'):
    expected['obs_' + n]['width'] = 2
archive = 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
binding = {'schema': 'M2_R06_OBSERVER_EXPORTS_V1', 'status': 'IMPLEMENTED_STATIC_NOT_SIMULATED',
           'baseline_commit': '8b92d9cfa07e69d5bb2ce1eefef9d3355ceac1f0',
           'sampling_phase': 'POSEDGE_PRE_NBA', 'top': 'm2_138k_pro_fourvoice_observer_top_r06',
           'source_archive': archive, 'source_archive_sha256': sha(TREE / archive),
           'source_sha256': {n: sha(TREE / RTL / n) for n in NAMES},
           'expected_observation_ports': expected,
           'old_tx_clip_mapping': 'obs_tx_clip_any (one-bit OR preserved)',
           'extensions': {'tx_clip_mask': 'bit0 left / bit1 right',
                          'tx_req_id_valid': 'false means req_id null; numeric0 remains legal',
                          'tx_metadata_valid': 'label usable; does not suppress actual TX sample',
                          'metadata_error': 'sticky mismatch; no production feedback',
                          'frame_id_overflow': 'sticky after max ordinal adoption; later labels unusable'},
           'epoch': 'M3 independent RESET_EDGES binds current reset epoch; all RTL tuples reset-invalidated',
           'remaining_missing': ['M1 nineteen real semantics/exports', 'apply_event_seq', 'config_payload',
                                 'cancel_reason', 'audio_stable policy', 'independent capture cycle/epoch/finish'],
           'HDL_executed': False, 'real_Pro_capture': False, 'board_release_allowed': False}
write(TREE / DOC / 'OBSERVER_EXPORTS_R06C3.json', binding)
compile_original = (OUT / 'FROZEN/source_closure/inputs/compile.f').read_text(encoding='utf-8').splitlines()
print(json.dumps({'ports': len(expected), 'candidate_RTL_files': len(NAMES),
                  'original_compile_first_lines': compile_original[:5], 'original_compile_lines': len(compile_original),
                  'TB': sha(TREE / 'code/tb/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017/tb_m2_r06_tx_identity_sidecar.sv'),
                  'HDL_executed': False}, ensure_ascii=False))
