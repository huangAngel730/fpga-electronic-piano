"""Single authorized M2-R6-2 pure-file group. No HDL tools or DUT execution."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import time

OUT = Path('D:/17/project_17/fpga_gowin/code/output/m2_r06_observer_20261017')
ROOT = OUT.parents[2]
TREE = ROOT / 'code/output/m2_live_tasks_publish_20261017'
BUILD = 'code/build/138k_pro_fourvoice_candidate_20261016/r06_observer_20261017/check_observer_routes.py'
DOC = 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'
RTL = 'code/rtl/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def main():
    marker = OUT / 'CONSUMPTION_M2_R6_2.json'
    if marker.exists():
        print('BLOCKED_ALREADY_CONSUMED_M2_R6_2')
        return 2
    run = OUT / 'SOFTWARE_01'
    run.mkdir(exist_ok=False)
    start = time.monotonic()
    binding = json.loads((TREE / DOC / 'OBSERVER_EXPORTS_R06C3.json').read_text(encoding='utf-8'))
    inputs = {BUILD: sha(TREE / BUILD), DOC + '/OBSERVER_EXPORTS_R06C3.json': sha(TREE / DOC / 'OBSERVER_EXPORTS_R06C3.json')}
    inputs.update({RTL + '/' + n: sha(TREE / RTL / n) for n in binding['source_sha256']})
    with marker.open('x', encoding='utf-8', newline='\n') as f:
        json.dump({'package': 'M2-R6-2', 'group': 'ONE_PURE_FILE_GROUP', 'max_seconds': 90,
                   'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   'HDL_EDA_hardware_runs': 0, 'inputs': inputs}, f, indent=2)
    core, board, top, sidecar = list(binding['source_sha256'])
    cases = [
        ('positive_real_files', None, None, None, 0, 'PASS_STATIC_FILE_PORT_CHECKS_ONLY'),
        ('wrong_port_width', top, '[31:0] obs_result_id', '[30:0] obs_result_id', 2, 'PUBLIC_PORT_WIDTH_OR_SIGN'),
        ('wrapper_constant_route', top, '.obs_req_id(obs_req_id)', ".obs_req_id(32'd0)", 2, 'WRAPPER_ROUTE'),
        ('changed_producer_input', core, '.event_data(event_data)', ".event_data(64'd0)", 2, 'PRODUCTION_CONNECTION_DRIFT'),
        ('reversed_clip_mask', core, 'assign obs_result_clip_mask = {clip_right, clip_left};',
         'assign obs_result_clip_mask = {clip_left, clip_right};', 2, 'CLIP_PACKING'),
        ('diagnostic_feedback', core, '.metadata_error(obs_metadata_error)', '.metadata_error(request_ready)', 2, 'DIAGNOSTIC_FEEDBACK'),
        ('instantaneous_clip_on_commit', sidecar, 'pending_clip_mask <= result_hold_clip_mask;',
         'pending_clip_mask <= result_clip_mask;', 2, 'CLIP_HOLD_TO_COMMIT'),
        ('wrong_TX_sampling_edge', sidecar, 'assign tx_sample_valid = rst_n && frame_tick && tx_valid;',
         'assign tx_sample_valid = rst_n && tx_valid;', 2, 'TX_ADOPTION_PREDICATE'),
        ('false_HDL_pass_claim', 'BINDING', None, None, 2, 'FALSE_VERIFICATION_LEVEL'),
    ]
    rows = []
    for name, changed_file, old, new, expected_exit, expected_text in cases:
        case = run / name
        candidate = case / 'candidate'
        (candidate / RTL).mkdir(parents=True)
        (candidate / DOC).mkdir(parents=True)
        b = json.loads(json.dumps(binding))
        for filename in b['source_sha256']:
            data = (TREE / RTL / filename).read_text(encoding='utf-8')
            if filename == changed_file:
                assert old in data, 'MUTATION_ANCHOR_MISSING_' + name
                data = data.replace(old, new, 1)
            target = candidate / RTL / filename
            target.write_text(data, encoding='utf-8', newline='\n')
            b['source_sha256'][filename] = sha(target)
        if changed_file == 'BINDING':
            b['HDL_executed'] = True
        original = candidate / b['source_archive']
        original.parent.mkdir(parents=True)
        shutil.copyfile(TREE / b['source_archive'], original)
        write(candidate / DOC / 'OBSERVER_EXPORTS_R06C3.json', b)
        argv = [sys.executable, '-B', '-X', 'utf8', str(TREE / BUILD), '--root', str(candidate)]
        remaining = 90 - (time.monotonic() - start)
        assert remaining > 0, 'GROUP_BUDGET_EXHAUSTED'
        result = subprocess.run(argv, cwd=TREE, capture_output=True, timeout=remaining)
        (case / 'stdout.raw').write_bytes(result.stdout)
        (case / 'stderr.raw').write_bytes(result.stderr)
        passed = result.returncode == expected_exit and expected_text in result.stdout.decode('utf-8')
        row = {'case': name, 'argv': argv, 'cwd': str(TREE), 'exit': result.returncode,
               'expected_exit': expected_exit, 'expected_marker': expected_text, 'passed': passed,
               'stdout_sha256': sha(case / 'stdout.raw'), 'stderr_sha256': sha(case / 'stderr.raw')}
        write(case / 'RECEIPT.json', row)
        rows.append(row)
        if not passed:
            break
    stable = all(sha(TREE / n) == value for n, value in inputs.items())
    receipt = {'status': 'PASS' if len(rows) == 9 and all(r['passed'] for r in rows) and stable else 'FAIL',
               'level': 'L1_NEW_FILE_CHECKER_SELFTEST_ONLY_CANDIDATE_RTL_STILL_L0',
               'positive': sum(r['passed'] and r['expected_exit'] == 0 for r in rows),
               'negative': sum(r['passed'] and r['expected_exit'] == 2 for r in rows),
               'seconds': time.monotonic() - start, 'inputs_stable': stable, 'inputs': inputs,
               'python': str(Path(sys.executable).resolve()), 'python_sha256': sha(Path(sys.executable)),
               'cases': rows, 'HDL_EDA_hardware_runs': 0, 'board_release_allowed': False}
    write(run / 'RECEIPT.json', receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('cases','inputs')}, ensure_ascii=False))
    return 0 if receipt['status'] == 'PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
