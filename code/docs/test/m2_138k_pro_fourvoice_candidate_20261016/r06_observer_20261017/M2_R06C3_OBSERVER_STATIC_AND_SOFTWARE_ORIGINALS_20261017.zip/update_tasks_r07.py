"""Record the user's R07 work allocation without restoring consumed permits."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / 'code/output/m2_live_tasks_publish_20261017'
DOCS = ['M1_完赛任务单_2026-10-15.md', 'M2_完赛任务单_2026-10-15.md',
        'M3_完赛任务单_2026-10-15.md', 'M3_当日任务单_2026-10-17.md',
        '138K四声部后续集成任务总览_2026-10-15.md', '任务看板.md', '当前状态.md',
        'Pro四声基础三岗扩充任务单_R06_2026-10-17.md']
name = 'Pro基础持续推进与M3扩充分工任务单_R07_2026-10-17.md'
text = '''# Pro基础持续推进与M3扩充分工任务单 R07（2026-10-17）

## 生效顺序与现有结果

用户本轮要求继续按最新任务单完成M2任务，并更新三岗任务单、让成员持续推进，尤其增交M3基础实施工作。本R07发布后覆盖R06的下一动作、下述实施归属及新四包写集；未覆盖的R06技术合同、原八包验收/预算、失败/完成项和G0–G3门槛继续有效。优先级仍Pro四声基础→M2双音色→E1→E2→E3→E4/N32。当前事实基线为`8b92d9cfa07e69d5bb2ce1eefef9d3355ceac1f0`；这是任务安排，不是成员已启动或硬件通过的证明。

M1第17批A0/A1/B0已限定接入L0准备：129原载荷ZIP、89分散文件、40原始双流仅ZIP，最终32+新增1并非单次33全跑；REAL仍PENDING。M3旧79文件已有5aa4959/V0389限定签收，不重复导入/重跑。D3期限缺陷沿用当前修复SHA`eb74ca9ef3cc363163d51e0c8af1a3f9bd8d15905ba3307a5ea1ab8d1c6ed764`及新24例原件；旧25CLI不重跑、不用历史R02补丁。

M2当前已落三份R06命名候选与TX旁带RTL，9项内部和16项既有口显式路由，仍只是静态候选；双clip在真实result握手保存，按result-hold→pending→held传递。自检TB、文件/装配检查原件及明确未验项随本次候选交付；实际结果以该交付收据为准，不在本任务单预写仿真PASS。M1的19项真实语义/出口、audio_stable策略、config payload和实际应用seq仍未闭合。

## 持续推进规则

每人按下面队列连续推进一项**当前已授权、写集独占、输入可得**的工作，不在一个软件组或普通中间步骤后停下等用户催促。遇到依赖，先交精确缺件列表和已有原件，在同一队列切换到无依赖项；不可为保持忙碌重跑已签组、扩大目录、进入后置E/N32或制造合成实测。

每次开工核最新已发布R07/三岗卡、source/ROM/合同SHA、当前机器条件和本包共享消费台账。状态区分ASSIGNED、IMPLEMENTING、SOFTWARE_READY、PENDING_REAL_INPUT、BLOCKED_PERMISSION、REAL_VERIFIED；准备级不得标G1/G3通过。无人回复/日期变化/新窗口不产生许可。所有当前可执行项用尽或需要实际许可时一次集中交具体阻断，不用无变化重试凑次数。

一个包只有一名写者，跨包只读引用。可开最多三名M3实施写者，Git索引/发布由M3主窗口串行汇合；不能三窗口各发一套互不兼容top。普通进度不触发例行发布；按根规范仅在完整任务完成、授权内确实穷尽阻断或需要M2准入节点集中交付。任务单不等于已送达或窗口已自动运行，M1/M3真人通知仍待用户转发。

## M1队列：先解除真实语义阻断

1. **M1-R6-1**：19项逐项交真实源/位宽/采样沿/更新条件、slot释放与退休/世代及共同mask1111语义；需要时在已授权M1候选副本增加显式输出。允许逐项完成候选，但整包验收仍按19项齐套，不把部分完成拆小发布。
2. **M1-R6-2**：读取M3新`oracle_bundle_bridge`的独立输入/格式差额，复用已接入冻结模型；数学重建、实际PCM24/ID/clip比较、首差异解释仍由M1负责。机械包读取/来源关联和跨格式投影实施转给M3，M1不再另外造一套采集工具。schema/算术profile由M1确认，旧B0不能硬接新的FRAME/ACCEPT/TX语义。
3. **M1-R6-3**：同版板采到件后解释四音/逐放/力度/削波；此前可完成测量与计算判据，真实未到不假结项。等待M2/M3时可做R6-1未闭字段或R6-2新schema正负例，禁止重写算法/ROM或恢复旧黄金测试。

写集和原两组软件预算仍用R06，不新增M1轮次，不改M2/M3源。

## M2队列：以实现和准入解除系统阻断

1. **立即完成M2-R6-2自身部分**：38项obs观察面/真实采样时钟、25项原字段路由、TX旁带；正向数据流仍是冻结M1链/adapter/buffer/I2S，诊断不反馈。新TX扩展字段显式版本化，保留原单bit tx_clip，另给双clip mask、IDvalid/metadata_valid/错误与溢出。cycle/epoch由M3独立RESET_EDGES绑定，不伪造常数epoch。配新模块自检TB、精确源差异和有界软件/静态检查；未执行HDL如实写待准入。
2. **M2-R6-1余项**：M1语义到件后合并真实出口映射与打包/稳定策略；无出处字段保留UNRESOLVED。已有C1一次初组及一次修复组均已消费，不重跑恢复。
3. **M2-R6-3**：由M3承担公开口采集TB、行为等价回归框架、源装配与工具计划的实施，M2只保留技术合同、代码集成、执行安全/精确准入和最终签收。收齐可运行TB/observer/checker/计划后签第一次明确组合，真实capture随后回流M1/M3；不让“先验真trace”成为首次运行的循环前置。
4. **M2-R6-4**：真实商业许可/完整Part/version/板修订/Bank及电气到件后做正确Pro PLL/CST/SDC、综合/PnR/完整STA/CDC、新.fs和恢复SHA，再单独精确SRAM决定。旧PG484、模拟时钟或预计许可日期不能代签。

M2原五根/r06_observer、r06_public_chain、r06_pro_physical写集及预算继续，真实工具默认不新增。本次任务重排不解除P7，不扩权Python-dummy owned_executor。

## M3：原8包继续，新增4包实际接管工具实施，共12条队列

原八包保留其ID、完成条件及独占目录，避免重命名后恢复消费：

| 原包 | 当前交付重点与可先做部分 | 后续依赖/止损 |
| --- | --- | --- |
| R6-1 source_target_audit | 装配冻结源、M2新4候选和后续M1出口，实际生成source-list/ROM/IP/模块端口清单；wrapper必须入list，错误/旧top/重复模块拒收 | simulation stub/旧60K header在physical模式不可PASS；缺实物身份只让该子项PENDING，不阻断仿真候选装配 |
| R6-2 midi_stimulus | 独立字节/时间计划与外部driver：四独奏/四音同时保持、逐放/力度/NoteOn0/重触发/第五音/reset | 串行四NoteOn不伪造同拍；slot/退休据M1语义，先保留差额不套toy规则 |
| R6-3 normalized_intake | 保留61原字段和新增TX扩展，生成B2/D3投影，保留cycle/epoch/原行/输入SHA/X/null原因 | 不用29列补全缺项；旧D3投影仅帧预算诊断，真实ACCEPT A不得改成FRAME F |
| R6-4 tool_plan_adapter | 绑定精确EXE/依赖/argv/cwd/输出/timeout/消费与原双流的审计器；真实工具未准入必须拒绝 | 不修改/扩权M2旧执行器；所有旧消费保持，软件计划PASS不是执行许可 |
| R6-5 event_calendar | 独立输入与实际应用/slot/释放/退休/世代/共同advance、req/result/commit/cancel账本 | 公开采样器改由R7-A唯一实施，本包只读其原始行；不再另写一套采集observer；真语义缺项保持PENDING |
| R6-6 tx_clock_reset_checker | 独立全FRAME计划、严格t-F<833、F/A分开；真实TX采纳/HOLD/startup/ID/clip/pins及reset/finish检查 | 即使idle/合法取消也核全FRAME至真实finish；缺初相位/旁带/结束收据保持PENDING/UNKNOWN，不能EOF代结束 |
| R6-7 hardware_identity | 核是否有实物/仪器/实际商业许可；完整丝印/板与Dock修订/Bank电压/MIDI/PA/PT8211路径与原件索引 | 有板优先收真实原件；无板给官方来源差额与测试点，不填假测量、不改供电/下载 |
| R6-8 board_capture_acceptance | 准备同版静音/固定音/四音/逐放/力度/reset恢复脚本和原件格式 | 真执行只在新.fs、完整物理、电气和精确一次SRAM许可齐备后；Flash及追加下载不在本单授权 |

新增四包是从M2/M1机械工具工作中转移的实施责任，不能与原包重复写者或重复算完成：

| 新包/目录 | 实施和可执行交付 | 接口/验收边界 |
| --- | --- | --- |
| **M3-R7-A public_capture_tb** | 接管M2-R6-3后继公开口采集TB及可复用passive observer，读取真实obs_core_clk/rst_n/公开口，输出原行号/cycle/FRAME F/真实A/result/commit/TX、独立RESET_EDGES、唯一END/MONITOR_END和真实结束原因。复用R6-2driver；不驱动私有DSP状态 | 无HDL许可先交源码/输出schema/合成软件夹具。实际TB执行仍M2逐组合准入。M2自己的sidecar单元TB不转移，本包负责整机公开采样；缺M1字段必须显式缺项，不补0 |
| **M3-R7-B public_equivalence_tb** | 接管候选集成前的行为回归框架：同一外部输入并行驱动冻结原候选与新观察候选，公开比较I2S/PA/UART/既有状态，证明诊断接入不影响原生产行为；交精确允许差异表、source装配和首差异记录器 | 不层级窥探M1数学，不把静态diff当形式等价或未运行TB当PASS；clock stub身份/起相位、reset和输出比较窗口先冻结。实际编译/仿真待M2，不重复旧T007或P7 |
| **M3-R7-C oracle_bundle_bridge** | 接管独立输入/公开样本的机械包装：读取R6-2/3/5及R7-A原件，生成M1可核bundle与逐行关联索引，保留原样本、SHA和时间基点。格式无法表达HOLD/startup/F-A/reset时给可机器读合同差额 | 数学、已应用语义、舍入/饱和由M1确认；不从DUT wave/env/phase反填期望，不改M1源码。旧B0窄profile不兼容时必须PENDING_UNSUPPORTED_PROFILE，不能删数据硬套 |
| **M3-R7-D capture_provenance** | 接管同版capture的封存/一致性工具：source/ROM/observer/driver/tool/argv/双流/退出/消费、raw trace/日历/投影/PCM/TX/结束收据的关联清单与原件ZIP；拒同capture_id异源码、换日志、编辑投影、缺原始输入或错误finish | M2冻结可信准入/最终签收，M3不能自报approved/authenticated。文件身份匹配仅签结构/来源链检查；真实独立性或工具执行真实性未证明的项继续PENDING。只在整包完成/真实阻断节点封存交付，不为普通进度造新包 |

**新增四包精确写集**只在三条既有M3根下新增`pro_basis_r07_20261017/<目录>/`：`code/software/m3_pro_fourvoice_trace_20261016/`、`code/tb/board/m3_pro_fourvoice_trace_20261016/`、`code/docs/test/m3_pro_fourvoice_trace_20261016/`。目录分别`public_capture_tb`、`public_equivalence_tb`、`oracle_bundle_bridge`、`capture_provenance`。旧R6八包路径不搬动、不覆盖；M2五根、M1模型/RTL、正式top/pkg/CST/公共规范、状态/看板均不在M3写集。

## M3三名写者的连续队列

| 写者 | 当前立即队列 | 依赖到件后 |
| --- | --- | --- |
| A：来源/数据 | R6-1→R7-B源码与计划→R6-3→R7-D | 汇合实际capture原件，运行准入后做真实一致性/封存 |
| B：输入/公开采样 | R6-2→R7-A→R6-5 | 接M1语义和M2公开口；缺字段先做明确拒收/缺件处理 |
| C：工具/比较/实物 | R6-4→R7-C→R6-6 | 有板优先R6-7；新物理/精确许可齐后R6-8 |

已有窗口可按这三条队列认领，未确认认领前状态仍ASSIGNED_NOT_STARTED，不能记作三窗口正在运行。R7-C先以冻结schema/合成输入开发机械包装，不必等真实trace；R6-6先完成独立FRAME公式/复位/finish软件规则；缺真实输入不妨碍工具准备。核心数据链实际闭环仍需M2/M1，不能以准备级完成冒签真实验收。

## 软件额度、执行边界和交付

原R06各包的共享软件额度及一次最小定向修复继续，先核实际已消费记录，拆分/转移/换日不重置。M2-R6-1初组与修复已消费；M2-R6-2未执行前先锁固定包台账。旧黄金303/512/1280、B1/B2/monitor、D3旧组和原工具执行不重跑。

针对**新增四个不同实施包**，本R07只新增A/B/C/D各一组≤90秒的**纯软件/schema/静态装配/新合成夹具检查**，每包在M3主窗口统一台账一次消费，不因三名写者增加。先冻结源码/输入/case/工具/输出/总时限，拒绝把原R6或旧已签案例换名计入。每包若新组暴露具体新实现缺陷，保留首件后仅一次≤60秒对应增量；不全量重跑。没有新代码/新断言不得消费。A/B的HDL源码可写，以上预算不包含编译/仿真。

真实Icarus/ModelSim/完整链/Gowin/设备默认新增0。旧P7停跑、Python-dummy边界、商业许可/Part/Bank/新PLL与完整STA、精确新.fs/恢复/SRAM双门槛不变。首次真实数字执行由M2另据具体闭包/安全执行器/工具/预算签精确准入，不能只设环境变量或替换工具绕过。仓库强制九门禁仍单列，不冒充Pro功能测试。

每包实际交代码/自检/可逆diff、source/ROM/依赖/产物SHA、原argv/cwd/UTC/退出码/双流、首失败/正负例、实际验证等级和精确缺件。G0–G3完成条件完全沿用R06，整体保持PARTIAL、board_release_allowed=false，直到真实证据齐套并由M2签收。
'''
target = TREE / 'code/docs' / name
assert not target.exists()
target.write_text(text, encoding='utf-8', newline='\n')
header = (f'## 2026-10-17 当前实施任务单 R07（用户本轮更新）\n\n'
          f'以`{name}`为最新下一动作/分工入口；未覆盖的R06技术合同、旧完成/失败/额度和G0–G3继续。'
          'M2继续当前R6-2实际公开路由/TX旁带→R6-1余项→R6-3精确准入→正确Pro物理；'
          'M1先19项真实语义/候选出口，再复用已接模型核真PCM；'
          'M3保留原8包并新增4个实际工具实施包：公开采集TB、公开行为等价TB、oracle机械包装桥、capture来源封存，共12条队列。'
          '新四包仅在M3三根下pro_basis_r07_20261017独占目录，各一组新≤90秒纯软件检查；原R6消费不重置，HDL/EDA/设备新增许可0。'
          '三名M3写者可按来源数据/输入采样/工具实物队列持续推进，依赖受阻转独立项，不重跑旧组、不跳E/N32。'
          '任务已安排不等于已送达或已启动；M1/M3通知待用户转发，尚未送达，board_release_allowed=false。\n\n')
before = {}
for doc in DOCS:
    path = TREE / 'code/docs' / doc
    before[doc] = hashlib.sha256(path.read_bytes()).hexdigest()
    first, rest = path.read_text(encoding='utf-8').split('\n', 1)
    path.write_text(first + '\n\n' + header + rest.lstrip('\n'), encoding='utf-8', newline='\n')
packages = []
for letter, directory, responsibility in (
        ('A', 'public_capture_tb', 'M2后继公开口采集TB/observer实施'),
        ('B', 'public_equivalence_tb', 'M2候选行为等价回归框架实施'),
        ('C', 'oracle_bundle_bridge', 'M1独立输入与公开样本机械包装实施'),
        ('D', 'capture_provenance', 'M2同版capture封存与来源一致性实施')):
    packages.append({'id': 'M3-R7-' + letter, 'owner': 'M3', 'directory': directory,
                     'responsibility_transferred': responsibility, 'status': 'ASSIGNED_NOT_STARTED',
                     'write_roots': [base + '/pro_basis_r07_20261017/' + directory + '/' for base in (
                         'code/software/m3_pro_fourvoice_trace_20261016',
                         'code/tb/board/m3_pro_fourvoice_trace_20261016',
                         'code/docs/test/m3_pro_fourvoice_trace_20261016')],
                     'new_software_groups': 1, 'max_seconds': 90,
                     'Pro_HDL_EDA_device_runs_authorized': 0})
machine = {'version': 'R07', 'baseline': '8b92d9cfa07e69d5bb2ce1eefef9d3355ceac1f0',
           'supersedes': 'R06 next actions/role transfer/new four write sets only',
           'R06_original_packages_preserved': 15, 'M3_original_packages': 8, 'M3_new_packages': packages,
           'M3_total_work_items': 12, 'consumed_budgets_restored': False,
           'human_notifications_delivered': False, 'threads_started_by_this_plan': False,
           'board_release_allowed': False}
evidence = TREE / 'code/docs/test/m2_pro_task_allocation_r07_20261017'
evidence.mkdir(parents=True, exist_ok=False)
(evidence / 'ASSIGNMENTS.json').write_text(json.dumps(machine, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
(OUT / 'R07_DOC_PATHS.json').write_text(json.dumps({'before': before, 'paths': ['code/docs/' + name,
        'code/docs/test/m2_pro_task_allocation_r07_20261017/ASSIGNMENTS.json'] + ['code/docs/' + d for d in DOCS]}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': 'R07_ASSIGNED_NOT_STARTED', 'M3_original': 8, 'M3_added': 4,
                  'M3_total': 12, 'new_real_tool_permits': 0}, ensure_ascii=False))
