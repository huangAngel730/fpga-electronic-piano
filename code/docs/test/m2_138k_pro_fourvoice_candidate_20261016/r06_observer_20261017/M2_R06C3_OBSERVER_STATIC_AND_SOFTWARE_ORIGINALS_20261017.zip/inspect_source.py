"""Read frozen input bodies and compact observation metadata for R6-2."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / 'code/output/m2_live_tasks_publish_20261017'
DOC = TREE / 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016'
archive = DOC / 'same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '931b7d2bbfd7ac056707542931101ff844b125936762748e344536d9be6c1ba2'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for info in z.infolist():
        p = PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename
        if info.is_dir():
            continue
        dst = OUT / 'FROZEN' / info.filename
        payload = z.read(info)
        if dst.exists():
            assert dst.read_bytes() == payload
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(payload)
contract = json.loads((DOC / 'r06_observer_20261017/CAPTURE_CONTRACT.json').read_text(encoding='utf-8'))
print('CONTRACT_KEYS', list(contract))
for key, value in contract.items():
    if isinstance(value, list) and value and isinstance(value[0], dict) and 'name' in value[0]:
        print(json.dumps([{'name': x['name'], 'width': x.get('width'),
                           'category': x.get('category'), 'bound': x.get('bound_at_pro_top'),
                           'refs': [{'file':r['path'].split('/')[-1], 'line':r['line'], 'text':r['text']}
                                    for r in x.get('references', [])]}
                          for x in value if x.get('owner') == 'M2'], ensure_ascii=False, indent=2))
print('RUNNERS', [p.name for p in (TREE / 'code/scripts').glob('*iverilog*')])
