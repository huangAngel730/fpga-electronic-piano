"""Seal static RTL/software evidence and the R07 task update; no HDL execution."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TREE = ROOT / 'code/output/m2_live_tasks_publish_20261017'
RTL = 'code/rtl/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'
BUILD = 'code/build/138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'
DOC = 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017'
TB = 'code/tb/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017/tb_m2_r06_tx_identity_sidecar.sv'
BASE = '8b92d9cfa07e69d5bb2ce1eefef9d3355ceac1f0'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def git(*args, cwd=TREE):
    return subprocess.check_output(['git', '-c', 'core.longpaths=true', *args], cwd=cwd).decode('utf-8').strip()

def main():
    assert git('rev-parse', 'HEAD') == git('rev-parse', 'origin/develop') == BASE
    assert not git('diff', '--cached', '--name-only')
    old = read(ROOT / 'code/output/m2_attachment_intake_20261017/PREPARED.json')
    for group in old['protected'].values():
        for name, item in group.items():
            assert sha(ROOT / name) == (item['sha256'] if isinstance(item, dict) else item), name
    receipt = read(OUT / 'SOFTWARE_01/RECEIPT.json')
    assert receipt['status'] == 'PASS' and receipt['positive'] == 1 and receipt['negative'] == 8
    assert receipt['seconds'] <= 90 and receipt['inputs_stable'] and receipt['HDL_EDA_hardware_runs'] == 0
    for name, value in receipt['inputs'].items():
        assert sha(TREE / name) == value, name
    binding = read(TREE / DOC / 'OBSERVER_EXPORTS_R06C3.json')
    lines = (OUT / 'FROZEN/source_closure/inputs/compile.f').read_text(encoding='utf-8').splitlines()
    excluded = [line for line in lines if Path(line).name in (
        'm2_fourvoice_timbre_delay_board_top.sv', 'm2_fourvoice_timbre_delay_frame_core.sv') or Path(line).name.startswith('tb_')]
    policy = {'schema': 'M2_R06_STATIC_SOURCE_REPLACEMENT_PLAN_V1',
              'baseline_archive': binding['source_archive'], 'baseline_archive_sha256': binding['source_archive_sha256'],
              'original_compile_member': 'source_closure/inputs/compile.f', 'original_units': len(lines),
              'exclude_from_observer_list': excluded, 'add_R06_files': [RTL + '/' + n for n in binding['source_sha256']],
              'new_observer_top': binding['top'], 'observer_compile_units_planned': len(lines) - len(excluded) + 4,
              'M1_math_and_ROM': 'frozen unchanged; not replaced',
              'unit_top': 'tb_m2_r06_tx_identity_sidecar',
              'unit_sources': ['archive:source_closure/inputs/sources/pcm_result_hold.sv',
                               'archive:source_closure/inputs/sources/pcm_frame_buffer.sv',
                               RTL + '/m2_r06_tx_identity_sidecar.sv', TB],
              'unit_TB_sha256': sha(TREE / TB), 'unit_TB_status': 'NOT_RUN',
              'execution_admission': None, 'physical_mode_allowed': False, 'board_release_allowed': False}
    write(TREE / DOC / 'SOURCE_REPLACEMENTS_R06C3.json', policy)
    originals = OUT / 'ORIGINALS'
    originals.mkdir(exist_ok=False)
    # All nine raw cases and mutated candidate bodies, with repeated frozen ZIP
    # copies represented by explicit byte-identical aliases to one real body.
    baseline = TREE / binding['source_archive']
    (originals / 'INPUTS').mkdir()
    shutil.copyfile(baseline, originals / 'INPUTS/BASELINE_SOURCE.zip')
    aliases = {}
    for f in (OUT / 'SOFTWARE_01').rglob('*'):
        if not f.is_file():
            continue
        relative = 'SOFTWARE_01/' + f.relative_to(OUT / 'SOFTWARE_01').as_posix()
        if f.suffix == '.zip':
            assert sha(f) == sha(baseline)
            aliases[relative] = {'body': 'INPUTS/BASELINE_SOURCE.zip', 'bytes': f.stat().st_size, 'sha256': sha(f)}
        else:
            dst = originals / relative
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, dst)
    write(originals / 'EXACT_FILE_ALIASES.json', aliases)
    for f in OUT.iterdir():
        if f.is_file() and f.suffix in ('.py', '.json'):
            shutil.copyfile(f, originals / f.name)
    for sub in ('routing', 'sidecar', 'tb_plan'):
        for parent in (OUT, TREE / 'code/output/m2_r06_observer_20261017'):
            source = parent / sub
            if source.is_dir():
                for f in source.rglob('*'):
                    if f.is_file():
                        dst = originals / 'STATIC_AUXILIARY' / sub / f.relative_to(source)
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        if dst.exists():
                            assert dst.read_bytes() == f.read_bytes()
                        else:
                            shutil.copyfile(f, dst)
    paths = [RTL + '/' + n for n in binding['source_sha256']] + [TB, BUILD + '/check_observer_routes.py',
             DOC + '/OBSERVER_EXPORTS_R06C3.json', DOC + '/SOURCE_REPLACEMENTS_R06C3.json']
    for name in paths:
        dst = originals / 'CANDIDATE' / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(TREE / name, dst)
    manifest = {f.relative_to(originals).as_posix(): {'bytes': f.stat().st_size, 'sha256': sha(f)}
                for f in sorted(originals.rglob('*')) if f.is_file()}
    write(originals / 'MANIFEST.json', manifest)
    archive = TREE / DOC / 'M2_R06C3_OBSERVER_STATIC_AND_SOFTWARE_ORIGINALS_20261017.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for name in [*manifest, 'MANIFEST.json']:
            z.write(originals / name, name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, item in manifest.items():
            raw = z.read(name)
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    software = {'status': 'L1_FILE_CHECKER_SELFTEST_ONLY', 'positive': 1, 'negative': 8,
                'seconds': receipt['seconds'], 'inputs_stable': True, 'candidate_RTL_level': 'L0_STATIC_ONLY',
                'HDL_EDA_hardware_runs': 0, 'TB_status': 'NOT_RUN',
                'fixed_consumption_marker_sha256': sha(OUT / 'CONSUMPTION_M2_R6_2.json'),
                'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
                'manifest_payloads': len(manifest), 'alias_payloads': len(aliases), 'board_release_allowed': False}
    write(TREE / DOC / 'SOFTWARE_RECEIPT_R06C3.json', software)
    report_name = 'code/docs/M2_R06公开出口与TX旁带静态候选_2026-10-17.md'
    report = '''# M2 R06公开出口与TX旁带静态候选（2026-10-17）

本轮按用户“继续按最新任务单完成M2任务”推进R6-2，同时按后续要求发布R07三岗持续实施队列。M2已实现独立候选自身25项路由和TX身份旁带，**候选只到L0静态实现，自检TB未运行，R6-2整体仍PARTIAL**。M1的19项真实语义/候选出口未到，真实Pro数字链/物理/板测未闭合，board_release_allowed=false。

四份RTL位于`code/rtl/board/m2_138k_pro_fourvoice_candidate_20261016/r06_observer_20261017/`：命名后继frame_core、board_top、Pro observer wrapper及`m2_r06_tx_identity_sidecar.sv`。旧源/正式top/pkg/CST/公共接口文档、M1数学和ROM未修改。wrapper固定原默认SOURCE_MODE0；board保留原分支，fixed模式专用诊断无效，采集必须检查obs_polyphonic_valid。

外层38项obs包括：9项M2内部req/result/PLL、16项尚未到外层的旧公开口、core采样时钟/模式有效性，以及11项TX旁带/诊断。原I2S/PA物理输出保持；tx_left/right取实际I2S PCM24输入。完整端口位宽/有符号和精确SHA在OBSERVER_EXPORTS_R06C3.json；此新实施映射补充旧C1，不改写旧C1形成时的“未实施”事实，也不把61字段全部标已实现。

双clip在真实result_valid&&result_ready沿保存，经老result-hold对应标签传到commit，再到pending/held；不得给旧commit贴当前result clip。FRAME TX按PRE_NBA老pending否则held采纳，commit与TX分开；相同PCM不代表相同ID。旧tx_clip保留1bit OR，新增tx_clip_mask2。startup零帧metadata有效但req_id_valid=0，归一器产生null；数值ID0仍合法。epoch由独立RESET_EDGES绑定，RTL所有元组复位失效，不伪造硬件epoch常数。frame ordinal32首0饱和后错误sticky，保留真实sample_valid但使后续标签无效。诊断无任何生产反馈。

自检TB在对应`code/tb/board/.../r06_observer_20261017/`，实例化冻结result_hold/frame_buffer与新sidecar，只用公开口。源码包含26次逐沿刺激检查，**没有运行，因此没有实际checks/PASS计数**。已静态阅读startup、错ID、result后改clip/PCM、commit与TX分离、相等PCM异ID、HOLD、01/10/11、FRAME拒收、异步reset、非法commit诊断；未覆盖32位max→overflow、合法数值ID0等边界。该TB不实例化I2S，不签完整串行/adapter dispatched/PLL/物理。

本轮M2-R6-2唯一新≤90秒纯文件检查组实际1正8负、4.361123秒、exit0，输入前后SHA稳定。正例检查真实4候选/38端口/冻结生产连接；反例更新候选SHA后分别测试错位宽、wrapper常量冒路由、生产输入漂移、clip左右反打、诊断反馈、commit错取即时clip、TX采样条件错误、冒称HDL通过，均预期exit2。**L1仅签新文件checker软件自检，不证明RTL功能等价或仿真通过**。没有运行被审RTL/新Icarus/ModelSim/EDA/设备，旧测试/已消费额度未恢复，软件修复增量未消费。

SOURCE_REPLACEMENTS_R06C3.json给冻结69单元的替换/旧TB排除规则、新top与4源单元TB计划；它不是执行准入。旧模拟clock/DVI/60K header不能物理使用。原件ZIP保留真实9例argv/cwd/退出/双流、输入/源码/工具SHA和静态差异；重复冻结ZIP以一份本体+9个精确SHA别名保存，全部其他载荷与manifest CRC/大小/SHA核同。复现需先按别名还原文件布局；不能因此重跑已消费组。

下一责任：M1交19项语义/出口；M2汇合后完成R6-1余项和R6-3精确准入；M3按R07接来源装配/driver/摄取/计划与新公开采集TB、公开行为等价TB、oracle包装桥、capture来源封存。M3-R6-5唯一生成独立FRAME_PLAN，R6-6只读核全窗覆盖；实物/许可未知不阻断软件准备，但真实测试必须另据具体工具/输入准入，不换工具绕过P7或Python-dummy边界。

R07新增四包各一组≤90秒纯软件，原八包及预算继续、旧消费不重置；新增四包仍ASSIGNED_NOT_STARTED。三岗首页/总览/状态已更新任务顺序，任务已安排不代表已送达或窗口正在运行。M1/M3真人消息待用户转发，尚未送达。九项仓库门禁/实际提交/推送/远端SHA另留回执，门禁不是新Pro功能证据。
'''
    (TREE / report_name).write_text(report, encoding='utf-8', newline='\n')
    (TREE / DOC / 'README_R06C3.md').write_text('# R06-C3静态候选入口\n\n实施映射见OBSERVER_EXPORTS_R06C3.json，替换规则见SOURCE_REPLACEMENTS_R06C3.json。4RTL+自检TB仅L0未运行；新checker软件1正8负通过仅L1，不签RTL。原件ZIP/软件收据给完整身份。后续任务以R07为准，M1语义/真实HDL/Pro物理待齐，board_release_allowed=false。\n', encoding='utf-8', newline='\n')
    paths += [DOC + '/' + archive.name, DOC + '/SOFTWARE_RECEIPT_R06C3.json', DOC + '/README_R06C3.md', report_name]
    task = read(OUT / 'R07_DOC_PATHS.json')
    paths += task['paths']
    progress = '\n本轮实际M2进展：R6-2自身25项显式路由+TX三层身份旁带与公开38项已写候选；TB仅源码未执行，候选L0。新文件checker唯一软件组1正8负/4.361123秒/exit0，仅L1软件自检，旧组未跑；详见M2_R06公开出口与TX旁带静态候选_2026-10-17.md和R06C3原件。R6-2整体仍PARTIAL，M1语义/出口、稳定策略、真实执行/物理/板测仍待，不冒签Pro通过。\n'
    for name in task['paths']:
        if name.endswith('.md'):
            path = TREE / name
            path.write_text(path.read_text(encoding='utf-8').rstrip('\n') + '\n' + progress, encoding='utf-8', newline='\n')
    before = {n: sha(ROOT / n) for n in paths if (ROOT / n).is_file()}
    before['code/docs/验证记录.md'] = sha(ROOT / 'code/docs/验证记录.md')
    prepared = {'base': BASE, 'main_head': git('rev-parse', 'HEAD', cwd=ROOT),
                'main_before': before, 'protected': old['protected'], 'active_D3': old['active_D3'],
                'paths': paths, 'final_bytes': {n: sha(TREE / n) for n in paths},
                'new_Pro_HDL_EDA_hardware_runs': 0, 'candidate_RTL_level': 'L0',
                'M2_R6_2': 'PARTIAL', 'M3_new_packages': 4, 'M3_total_packages': 12,
                'originals': software}
    assert len(paths) == len(set(paths))
    write(OUT / 'PREPARED.json', prepared)
    old_launcher = (ROOT / 'code/output/m2_attachment_intake_20261017/run_gate.py').read_text(encoding='utf-8')
    (OUT / 'run_gate.py').write_text(old_launcher, encoding='utf-8', newline='\n')
    print(json.dumps({'owned_files': len(paths), 'candidate_RTL_level': 'L0',
                      'software_positive': 1, 'software_negative': 8, 'M3_work_items': 12,
                      'originals_sha256': sha(archive), 'originals_payloads': len(manifest)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
