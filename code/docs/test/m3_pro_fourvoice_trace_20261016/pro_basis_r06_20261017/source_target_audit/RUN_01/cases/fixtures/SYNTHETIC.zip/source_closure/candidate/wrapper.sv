module wrapper(input wire a, output wire b); leaf u(.a(a), .b(b)); endmodule
