// SYNTHETIC PG484 old header
module pll; endmodule
