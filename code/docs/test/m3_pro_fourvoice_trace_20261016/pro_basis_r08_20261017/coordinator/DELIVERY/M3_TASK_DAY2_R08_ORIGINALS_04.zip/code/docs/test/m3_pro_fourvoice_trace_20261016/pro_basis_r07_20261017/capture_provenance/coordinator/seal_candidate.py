"""Archive R07 original bytes and choose an explicit publication list.

This is a coordinator file-identity operation, not a package functional test.
Run only after all writers have frozen their delivered files.
"""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[7]
DOC = ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017'
HERE = Path(__file__).resolve().parent
ROOTS = [
    ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017',
    ROOT / 'code/tb/board/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017',
    DOC,
]
PACKAGES = ['public_capture_tb', 'public_equivalence_tb', 'oracle_bundle_bridge', 'capture_provenance']


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main():
    output = HERE / 'DELIVERY'
    output.mkdir(exist_ok=False)
    original = json.loads((HERE / 'TRACKED_PUBLICATION_BASELINE.json').read_text(encoding='utf-8'))
    changed = [p for p, expected in original.items() if not (ROOT / p).is_file() or identity((ROOT / p).read_bytes()) != expected]
    save(output / 'BASELINE_COMPARISON.json', {'changed_existing_files': changed})
    if changed:
        raise RuntimeError('Existing tracked bytes changed; inspect before sealing')
    payloads = []
    publish = []
    for group in ROOTS:
        if not group.exists():
            continue
        for p in sorted(group.rglob('*')):
            if not p.is_file() or '__pycache__' in p.parts or p.suffix == '.pyc':
                continue
            rel = p.relative_to(group)
            if rel.parts[0] not in PACKAGES:
                raise RuntimeError(f'Out of assigned package: {p}')
            if 'DELIVERY' in rel.parts or 'HANDOFF_FINAL' in rel.parts or any(x.startswith('GATE_') for x in rel.parts):
                continue
            payloads.append(p)
            if group != DOC:
                publish.append(p)
            elif len(rel.parts) == 2 and p.suffix in {'.json', '.md'}:
                publish.append(p)
            elif rel.parts[:2] == ('capture_provenance', 'dependency_audit') and p.suffix in {'.json', '.md'}:
                publish.append(p)
            elif len(rel.parts) >= 3 and rel.parts[1].startswith('c5_') and p.suffix in {'.json', '.md', '.f', '.zip'}:
                publish.append(p)
    extra_path = HERE / 'EXTRA_FILES.json'
    if extra_path.exists():
        extra = json.loads(extra_path.read_text(encoding='utf-8'))
        extra_publish = set(extra['publication_paths'])
        for name in extra['paths']:
            p = (ROOT / name).resolve()
            p.relative_to(ROOT)
            if name in original:
                raise RuntimeError('R06 continuation must be new files, not old-source overwrite')
            allowed = ['event_calendar', 'board_capture_acceptance', 'normalized_intake', 'tool_plan_adapter', 'tx_clock_reset_checker']
            if not any('/pro_basis_r06_20261017/' + package + '/' in name for package in allowed):
                raise RuntimeError('Unexpected R06 continuation scope')
            payloads.append(p)
            if name in extra_publish:
                publish.append(p)
        payloads.append(extra_path)
        publish.append(extra_path)
    payloads = sorted(set(payloads))
    manifest = {p.relative_to(ROOT).as_posix(): identity(p.read_bytes()) for p in payloads}
    archive = output / 'M3_R07_PREPARATION_ORIGINALS_20261017.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in payloads:
            z.write(p, p.relative_to(ROOT).as_posix())
        z.writestr('MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
        for name, expected in manifest.items():
            assert identity(z.read(name)) == expected, name
    receipt = {'status': 'CRC_SIZE_SHA_PASS', 'archive': archive.name,
               **identity(archive.read_bytes()), 'payloads': len(payloads),
               'new_functional_runs': 0, 'board_release_allowed': False}
    save(output / 'RECEIPT.json', receipt)
    publish += [archive, output / 'RECEIPT.json', output / 'BASELINE_COMPARISON.json']
    for name in ['PLAN.md', 'RESULT.md', 'PACKAGE_STATUS.json', 'M2_INTAKE_RECEIPT.json', 'C5_INTAKE_RECEIPT.json', 'M2_BASELINE_ADVANCE.json', 'seal_candidate.py', 'verify_c5_intake.py']:
        p = HERE / name
        if p.exists():
            publish.append(p)
    plan = HERE / 'PUBLICATION_FILES.json'
    publish.append(plan)
    save(plan, {'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
                'paths': sorted({p.relative_to(ROOT).as_posix() for p in publish})})
    print(json.dumps({**receipt, 'publication_paths': len(publish)}))


if __name__ == '__main__':
    main()
