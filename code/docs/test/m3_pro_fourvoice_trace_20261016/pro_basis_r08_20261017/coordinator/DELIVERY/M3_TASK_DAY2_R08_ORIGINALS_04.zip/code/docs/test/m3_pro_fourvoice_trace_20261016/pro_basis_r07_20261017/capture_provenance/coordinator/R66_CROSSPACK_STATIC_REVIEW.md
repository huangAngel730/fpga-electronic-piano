# R6-6 跨包与期限增量自审

只读自审未发现本次指定增量的明确阻断；未执行、导入、编译或修改，未重审serial_core全篇或旧20例。

- TX_ADOPT 按复位有效时所有TX sample校验，覆盖STARTUP/HOLD。
- R6-5观察账本保留非独立属性，强制PENDING_TX_SELECTION_PLAN，不能反填期望后误PASS。
- global cycle允许0，局部公式k从1起。
- A及result/commit/cancel受t-F<833和t<next_FRAME限制，缺下一独立FRAME则PENDING。

所读精确SHA256：

- crosspack.py：1f265393a378b8c8c870354817e5381e4a6e1013bfd6528f2c2b2175a53f39fa
- checker.py：55f6217399c5deb1b44d374895c6753db0d3836a2462aff3a4e175c598d6350d
- boundaries.py：1b076fbc98b471df8a7f8342713c2704c972b04249a2a3b3b52e477da5003c42
