"""Reuse the existing repository-gate supervisor with this delivery directory."""
import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/coordinator_20261017/run_gate.py'

if __name__ == '__main__':
    spec = importlib.util.spec_from_file_location('r07_repository_gate', SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.DOC = HERE
    raise SystemExit(module.main())
