"""Verify staged scope and exact staged bytes before the repository gate."""
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    plan = json.loads((HERE / 'PUBLICATION_FILES.json').read_text(encoding='utf-8'))
    names = sorted(plan['paths'])
    staged = sorted(p for p in git('diff', '--cached', '--name-only', '-z').decode().split('\0') if p)
    assert staged == names, {'unexpected': sorted(set(staged)-set(names)), 'missing': sorted(set(names)-set(staged))}
    assert not git('diff', '--name-only').strip(), 'Unstaged tracked bytes changed'
    subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, check=True)
    records = {}
    for name in names:
        raw = (ROOT / name).read_bytes()
        blob = git('show', ':' + name)
        assert blob == raw, 'Index byte conversion: ' + name
        records[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    out = HERE / 'INDEX_RECEIPT.json'
    with out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump({'status': 'EXACT_SCOPE_AND_BYTES_PASS', 'head': git('rev-parse', 'HEAD').decode().strip(), 'count': len(names), 'files': records}, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'PASS', 'count': len(names)}))


if __name__ == '__main__':
    main()
