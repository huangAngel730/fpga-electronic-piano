"""Read-only Git/source identity audit; writes only coordinator receipts."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]


def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    with (HERE / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    assert head == '40d78131e8ed50643dd169816f7bfc7149a8ced9'
    changed = subprocess.check_output(['git', 'diff', '--name-only', '-z', '4fd3366e42fd2356e56eb96eee70b6771afd4bb1', head], cwd=ROOT).decode().split('\0')
    changed = [p for p in changed if p]
    original = json.loads((HERE / 'TRACKED_BASELINE.json').read_text(encoding='utf-8'))
    deviations = [p for p, v in original.items() if not (ROOT / p).is_file() or ident((ROOT / p).read_bytes()) != v]
    assert set(deviations).issubset(changed), deviations
    status = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=ROOT)
    assert not status.strip(), status
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    snapshot = {p: ident((ROOT / p).read_bytes()) for p in tracked if p}
    save('TRACKED_PUBLICATION_BASELINE.json', snapshot)
    save('M2_BASELINE_ADVANCE.json', {'old_head': '4fd3366e42fd2356e56eb96eee70b6771afd4bb1', 'new_head': head, 'remote_changed_paths': changed, 'old_snapshot_deviations': deviations, 'worktree_tracked_delta': [], 'tracked_count': len(snapshot)})
    base = ROOT / 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017'
    decision_path = base / 'SOURCE_DECISION_R06C5.json'
    decision = json.loads(decision_path.read_text(encoding='utf-8'))
    archive = ROOT / decision['archive']['path']
    assert ident(archive.read_bytes()) == {k: decision['archive'][k] for k in ('bytes', 'sha256')}
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(set(z.namelist())) == len(z.namelist())
        for name, expected in decision['payloads'].items():
            assert ident(z.read(name)) == expected, name
        names = [s.strip() for s in z.read('inputs/compile.f').decode().splitlines() if s.strip() and not s.startswith('#')]
        assert len(names) == 71
        assert all('inputs/' + name in z.namelist() for name in names)
        original_dds = z.read('provenance/ORIGINAL_dds_oscillator.sv')
        assert original_dds[:1240] + b'\n' == z.read('inputs/selected/dds_oscillator_leaf.sv')
    save('C5_INTAKE_RECEIPT.json', {'status': 'CRC_SIZE_SHA_DERIVATION_PASS_STATIC_ONLY', 'head': head, 'archive': decision['archive'], 'decision': ident(decision_path.read_bytes()), 'payload_count': len(decision['payloads']), 'selected_units': len(names), 'rom_count': decision['rom_count'], 'HDL_runs': 0, 'board_release_allowed': False})
    print(json.dumps({'head': head, 'tracked': len(snapshot), 'remote_changes': len(changed), 'c5_payloads': len(decision['payloads']), 'c5_units': len(names)}))


if __name__ == '__main__':
    main()
