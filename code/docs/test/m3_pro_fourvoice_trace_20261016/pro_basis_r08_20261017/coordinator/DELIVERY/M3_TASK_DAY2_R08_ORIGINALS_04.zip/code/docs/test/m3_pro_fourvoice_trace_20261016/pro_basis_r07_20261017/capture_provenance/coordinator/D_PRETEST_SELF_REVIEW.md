# D 首轮前只读自审

被读capture_provenance.py SHA c7b84abe990536c235cd9cdfedb11bccfa30314ee61fb09d8c79bee031092290。子智能体未执行程序/测试或修改文件，两个具体点已发夜间3于D初组前修复：

1. 140–141/159–160要求cycle=source_line、finish_cycle=row_count，与A的source_line从1、cycle从0矛盾。统一cycle=line-1及finish_cycle=row_count-1，结束time=first_core_ps+finish_cycle*period；用A真实格式做新合成正例。
2. 171–177只核projection manifest外层文件SHA，不读normalized原行关联。capture_id/raw/reset SHA/source.line/cycle/time_ps可能指向别的capture而外层自洽。须机械交叉核原始行；数学PCM无需重算，不因此升级真实性。

其余已读：路径逃逸、同capture_id重绑、双流绑定及finish/结束标记缺失有拒收；真实性UNKNOWN、M2准入PENDING，无自认证。selftest当时未出现不视作缺陷。后继版本按新SHA自审，本报告不代完整签收。
