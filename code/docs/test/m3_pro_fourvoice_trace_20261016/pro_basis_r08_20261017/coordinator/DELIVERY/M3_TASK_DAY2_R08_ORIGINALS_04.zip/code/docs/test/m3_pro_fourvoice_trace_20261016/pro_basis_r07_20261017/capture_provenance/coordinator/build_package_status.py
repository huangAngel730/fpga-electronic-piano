"""Summarize collected receipts without executing any candidate package."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
BASE = ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016'


def evidence(relative):
    p = BASE / relative
    raw = p.read_bytes()
    return {'path': p.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    rows = [
        ('R7-A', 'public_capture_tb', 'L1_SOFTWARE_L0_HDL', 'PENDING_REAL_INPUT',
         [2.061999999990803], [0], 1, 0, '7 positive + 29 negative + 2 CLI; no HDL'),
        ('R7-B', 'public_equivalence_tb', 'L1_SOFTWARE_FINAL_TB_DELTA_L0', 'PENDING_REAL_INPUT',
         [0.531, 0.187], [0, 0], 1, 1, '15 initial and 4 targeted; final <=stop TB change NOT_RUN'),
        ('R7-C', 'oracle_bundle_bridge', 'L1_TARGETED_SYNTHETIC_ONLY', 'PARTIAL_SOFTWARE_VALIDATION',
         [0.20785880088806152, 0.2173755168914795], [1, 0], 1, 1, 'first failure preserved; 1 targeted positive passed; 6 cases NOT_RUN'),
        ('R7-D', 'capture_provenance', 'L1_STRUCTURAL_IDENTITY_ONLY', 'PENDING_REAL_INPUT',
         [1.1410000000032596], [0], 1, 0, '22 checks; no producer authentication'),
    ]
    packages = {}
    for key, folder, level, status, seconds, exits, initial, repair, limits in rows:
        packages[key] = {'level': level, 'status': status, 'seconds': seconds,
                         'group_exit_codes': exits, 'initial_groups_consumed': initial,
                         'repair_groups_consumed': repair, 'limits': limits,
                         'receipt': evidence('pro_basis_r07_20261017/' + folder + '/RECEIPT.json')}
    for key, folder, seconds, limits in [
        ('R6-4-fix', 'tool_plan_adapter', 9.062999999994645,
         '25 new cases (1 control/24 reject) + 2 CLI rejects; fixed worker only; true executor NOT_QUALIFIED'),
        ('R6-6-fix', 'tx_clock_reset_checker', 8.671999999991385,
         '28 expected outcomes; 6 local/mechanical checks + 10 PENDING + 12 rejects; no full positive serial regression')]:
        packages[key] = {'level': 'L1_TARGETED_SOFTWARE', 'status': 'PENDING_M2_ACCEPTANCE_AND_REAL_INPUT',
                         'seconds': [seconds], 'group_exit_codes': [0],
                         'original_initial_groups_already_consumed': 1,
                         'original_repair_groups_consumed_now': 1, 'repair_groups_remaining': 0,
                         'limits': limits,
                         'receipt': evidence('pro_basis_r06_20261017/' + folder + '/r07_fix/RECEIPT.json')}
    for key, folder in [('R6-3-fix', 'normalized_intake'), ('R6-5-fix', 'event_calendar')]:
        packages[key] = {'level': 'L0', 'status': 'NEW_CANDIDATE_NOT_RUN',
                         'new_functional_groups': 0, 'remaining_software_permission': 0,
                         'receipt': evidence('pro_basis_r06_20261017/' + folder + '/r07_fix/RECEIPT.json')}
    packages['R6-5-frame-generator'] = {'level': 'L0', 'status': 'NOT_RUN', 'new_functional_groups': 0,
        'receipt': evidence('pro_basis_r06_20261017/event_calendar/FRAME_PLAN_CANDIDATE_RECEIPT.json')}
    packages['R6-8'] = {'level': 'L0_OFFLINE_PREPARATION', 'status': 'DEVICE_NOT_RUN_BLOCKED_PREFLIGHT',
        'device_calls': 0, 'receipt': evidence('pro_basis_r06_20261017/board_capture_acceptance/RECEIPT.json')}
    result = {'schema': 'M3_TASK_DAY2_R07_V0396_STATUS_V1', 'status': 'PARTIAL_NEEDS_M2_ADMISSION',
              'baseline': '40d78131e8ed50643dd169816f7bfc7149a8ced9', 'packages': packages,
              'software_group_seconds_this_task': sum(sum(p.get('seconds', [])) for p in packages.values()),
              'model_tokens_and_cost': 'UNKNOWN_NOT_PROVIDED', 'HDL_EDA_device_new_rounds': 0,
              'mandatory_repository_gate': 'SEPARATE_RECEIPT_NOT_PRO_FUNCTIONAL_EVIDENCE',
              'whole_Pro_complete': False, 'board_release_allowed': False,
              'M2_delivery': 'WAITING_USER_FORWARD_NOT_DELIVERED'}
    with (HERE / 'PACKAGE_STATUS.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'packages': len(packages), 'software_group_seconds_this_task': result['software_group_seconds_this_task']}))


if __name__ == '__main__':
    main()
