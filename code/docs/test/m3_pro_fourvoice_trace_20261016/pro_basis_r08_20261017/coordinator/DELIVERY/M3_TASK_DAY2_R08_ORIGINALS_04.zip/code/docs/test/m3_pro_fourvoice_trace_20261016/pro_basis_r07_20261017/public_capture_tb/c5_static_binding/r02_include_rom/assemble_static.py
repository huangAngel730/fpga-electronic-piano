"""Standard-library byte assembly only. No A/repair imports or HDL calls."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

ROOT = Path.cwd().resolve()
DEST = Path(__file__).resolve().parent
A = DEST.parents[1]
R01 = DEST.parent
M2 = ROOT / "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016"
B = ROOT / "code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017/public_equivalence_tb/c5_dual_assembly"
BASE = M2 / "same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip"
PREVIOUS = R01 / "C5_SELECTED_71_PLUS_R7A_3_STATIC.zip"
BZIP = B / "M3_R7B_C5_DUAL_SOURCE_20261017.zip"
HEADERS = ("sine_table.svh", "sustain_controller_ports.svh")
ALIASES = ("sine_wavetable.hex", "triangle_wavetable.hex")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(raw), "sha256": sha(raw)}


def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def snapshots():
    files = [p for p in A.rglob("*") if p.is_file() and not p.is_relative_to(DEST)]
    files += [BASE, BZIP, B / "RESULT.md", B / "ASSEMBLY.json",
              ROOT / "code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r06_20261017/tool_plan_adapter/r07_fix/R6_4_R07_FIX_ORIGINALS_20261017.zip"]
    return {p.relative_to(ROOT).as_posix(): identity(p) for p in sorted(set(files))}


def safe_member(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and ".." not in path.parts and ":" not in name and "\\" not in name, name
    return name


def main():
    assert (ROOT / "AGENTS.md").is_file() and DEST.is_relative_to(ROOT)
    assert identity(BASE)["sha256"] == "931b7d2bbfd7ac056707542931101ff844b125936762748e344536d9be6c1ba2"
    assert identity(PREVIOUS)["sha256"] == "2906dd137d821de49ec2674386997ef6d4dec5a99ca3a6f826f5a2d1f2a89b4f"
    assert identity(BZIP)["sha256"] == "8cdc01ccf36ee4a91d61ca270c076fcf8d20560465679a2a9b52e09f5ea0155d"
    before = snapshots()
    save(DEST / "OLD_IDENTITIES_BEFORE.json", before)
    payload = {}
    with zipfile.ZipFile(PREVIOUS) as z:
        assert z.testzip() is None
        for name in z.namelist():
            if not name.endswith("/"):
                safe_member(name)
                payload[name if name.startswith(("inputs/", "provenance/")) else "provenance/R01_" + name] = z.read(name)
    original_compile = payload["inputs/compile_r7a.f"]
    units = [s.strip() for s in original_compile.decode("utf-8").splitlines() if s.strip()]
    assert len(units) == 74 and not any(s.startswith("+") for s in units)
    payload["provenance/R01_compile_r7a.f"] = original_compile
    origins = []
    b_report = json.loads((B / "ASSEMBLY.json").read_text(encoding="utf-8"))
    with zipfile.ZipFile(BASE) as base, zipfile.ZipFile(BZIP) as bz:
        assert base.testzip() is None and bz.testzip() is None
        for name in HEADERS:
            member = "source_closure/inputs/include/" + name
            duplicate = "source_closure/inputs/sources/" + name
            raw = base.read(member)
            assert raw == base.read(duplicate) == bz.read("inputs/include/" + name)
            published = next(x for x in b_report["source_and_input_origins"] if x["relative_path"] == "include/" + name)
            assert len(raw) == published["bytes"] and sha(raw) == published["sha256"]
            payload["inputs/include/" + name] = raw
            origins.append({"output": "inputs/include/" + name, "archive": identity(BASE),
                            "member": member, "duplicate_member": duplicate,
                            "B_archive_member": "inputs/include/" + name, "bytes": len(raw), "sha256": sha(raw)})
        for name in ALIASES:
            raw = payload["inputs/rom/" + name]
            assert raw == bz.read("inputs/" + name)
            payload["inputs/" + name] = raw
            origins.append({"output": "inputs/" + name, "source": "inputs/rom/" + name,
                            "operation": "BYTE_IDENTICAL_ALIAS_NO_CONTENT_EDIT", "bytes": len(raw), "sha256": sha(raw)})
    payload["inputs/compile_r7a.f"] = ("+incdir+include\n" + "\n".join(units) + "\n").encode("utf-8")
    # Only literal paths. No preprocessor/elaboration or parameter inference.
    includes, rom_refs, module_map = [], [], {}
    queue = ["inputs/" + safe_member(name) for name in units]
    visited = set()
    while queue:
        source = queue.pop(0)
        if source in visited:
            continue
        visited.add(source)
        text = payload[source].decode("utf-8")
        text = re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.S)
        for module in re.findall(r"\bmodule\s+(\w+)", text):
            module_map.setdefault(module, []).append(source)
        for name in re.findall(r'`include\s+"([^"\n]+)"', text):
            safe_member(name)
            options = [str(PurePosixPath(source).parent / name), "inputs/include/" + name]
            resolved = next((p for p in options if p in payload), None)
            assert resolved is not None, (source, "MISSING_INCLUDE", name)
            includes.append({"source": source, "literal": name, "resolved": resolved, "sha256": sha(payload[resolved])})
            queue.append(resolved)
        for name in re.findall(r'"([^"\n]+\.(?:mem|hex))"', text):
            safe_member(name)
            resolved = "inputs/" + name
            assert resolved in payload, (source, "MISSING_LITERAL_ROM", name)
            rom_refs.append({"source": source, "literal": name, "resolved": resolved, "sha256": sha(payload[resolved])})
    duplicates = {name: locations for name, locations in module_map.items() if len(locations) != 1}
    assert not duplicates and len(module_map) == 76
    assert {r["literal"] for r in includes} == set(HEADERS)
    assert {r["literal"] for r in rom_refs} == set(b_report["ROM_literals"])
    assert len([n for n in payload if n.startswith("inputs/rom/")]) == 9
    report = {"schema": "M3_R7A_C5_INCLUDE_ROM_COMPLETION_V2", "state": "L0_LITERAL_PATHS_MATERIALIZED_NOT_COMPILED",
              "created_utc": datetime.now(timezone.utc).isoformat(), "baseline": "40d78131e8ed50643dd169816f7bfc7149a8ced9",
              "previous_A_C5": identity(PREVIOUS), "same_version_original_M2": identity(BASE),
              "cross_package_B_zip": identity(BZIP), "B_report": identity(B / "ASSEMBLY.json"),
              "top": "tb_r7a_public_capture", "compile_list": "inputs/compile_r7a.f", "cwd": "unpacked inputs directory",
              "incdir": "include", "source_units": 74, "literal_module_count": 76, "duplicate_literal_modules": duplicates,
              "original_ROM_payloads": 9, "same_byte_ROM_aliases": 2, "header_count": 2, "added_origins": origins,
              "units": [{"path": n, "bytes": len(payload['inputs/' + n]), "sha256": sha(payload['inputs/' + n])} for n in units],
              "include_references": includes, "ROM_literal_references": rom_refs,
              "payloads": {n: {"bytes": len(raw), "sha256": sha(raw)} for n, raw in sorted(payload.items())},
              "A_functional_scripts_called": 0, "R6_4_called": 0, "software_functional_groups_added": 0,
              "HDL_EDA_hardware_calls": 0, "execution_admission": None, "board_release_allowed": False,
              "limits": "Literal include and .mem/.hex paths only; no preprocessing, elaboration, runtime file/parameter or physical proof"}
    for name, raw in payload.items():
        path = DEST / safe_member(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as f:
            f.write(raw)
    save(DEST / "ASSEMBLY.json", report)
    archive = DEST / "M3_R7A_C5_INCLUDE_ROM_COMPLETE_20261017.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
        for name in sorted(payload):
            z.write(DEST / name, name)
        z.write(DEST / "ASSEMBLY.json", "ASSEMBLY.json")
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert all(z.read(n) == raw for n, raw in payload.items())
    after = snapshots()
    save(DEST / "OLD_IDENTITIES_AFTER.json", after)
    assert before == after, "OLD_OR_CROSS_PACKAGE_BYTES_CHANGED"
    receipt = {"schema": "M3_R7A_STATIC_COMPLETION_RECEIPT_V2", "state": "STATIC_INCLUDE_ROM_CLOSURE_COMPLETE",
               "archive": identity(archive), "assembly": identity(DEST / "ASSEMBLY.json"),
               "preserved_old_files": len(before), "all_old_identities_unchanged": True,
               "ZIP_CRC_and_payload_identity": "PASS", "source_units": 74, "literal_modules": 76,
               "headers": 2, "original_ROMs": 9, "same_byte_ROM_aliases": 2,
               "compile_elaboration": "NOT_RUN", "new_functional_groups": 0,
               "HDL_EDA_hardware": 0, "git_writes": 0, "board_release_allowed": False}
    save(DEST / "RECEIPT.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
