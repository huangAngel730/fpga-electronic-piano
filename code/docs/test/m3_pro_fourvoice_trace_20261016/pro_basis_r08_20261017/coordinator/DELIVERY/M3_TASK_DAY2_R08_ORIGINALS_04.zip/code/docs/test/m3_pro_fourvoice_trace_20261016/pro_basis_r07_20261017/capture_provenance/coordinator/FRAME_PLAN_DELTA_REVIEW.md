# FRAME_PLAN 定向静态复查

只读子智能体复查前次两个具体问题，未运行、导入或编译候选。

相邻段现要求 reset_cycle == previous_stop + 1，gap/overlap 拒绝；RESET_ONLY 要求 release=null 并产空帧。ACTIVE 的首功能沿与截止检查保留。公式未变，window_kind/release/stop 进入 canonical 身份，两个旧格式投影共用该身份。本次修改范围内未发现新的公式或投影身份阻断。

新增 gap、reset-only 及伪造 release 的用例仍 NOT_RUN，不提升到软件通过。

- frame_plan_generator_candidate.py SHA256：38c4314b1e5f2f1a49c225e3d03ba9908f8f27c1769603399a07a14e2980ad53
- frame_plan_selftest_candidate.py SHA256：e4c2354ac0cc2e1d0e33711f79b10f085481becda7d6c90bf4996baf1ebf1445
