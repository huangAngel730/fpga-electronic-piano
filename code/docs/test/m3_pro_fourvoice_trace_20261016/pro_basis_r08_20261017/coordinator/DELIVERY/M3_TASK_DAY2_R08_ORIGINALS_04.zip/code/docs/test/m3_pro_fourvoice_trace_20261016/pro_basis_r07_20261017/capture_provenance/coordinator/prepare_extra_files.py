"""Select new R06 additions only; raw run files stay in the evidence archive."""
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
BASES = ['code/software/m3_pro_fourvoice_trace_20261016/',
         'code/tb/board/m3_pro_fourvoice_trace_20261016/',
         'code/docs/test/m3_pro_fourvoice_trace_20261016/']
ALLOWED = {'normalized_intake', 'tool_plan_adapter', 'event_calendar',
           'tx_clock_reset_checker', 'board_capture_acceptance'}


def main():
    args = ['git', 'ls-files', '--others', '--exclude-standard', '-z', '--']
    args += [base + 'pro_basis_r06_20261017/' for base in BASES]
    names = [p for p in subprocess.check_output(args, cwd=ROOT).decode().split('\0') if p]
    payloads, published = [], []
    for name in names:
        p = Path(name)
        if '__pycache__' in p.parts or p.suffix == '.pyc':
            continue
        prefix = next(base for base in BASES if name.startswith(base))
        rel = name[len(prefix + 'pro_basis_r06_20261017/'):].split('/')
        assert rel[0] in ALLOWED, name
        if rel[0] in {'normalized_intake', 'tool_plan_adapter', 'tx_clock_reset_checker'}:
            assert rel[1] == 'r07_fix', name
        payloads.append(name)
        if prefix != BASES[2]:
            published.append(name)
        elif p.suffix in {'.json', '.md'} and (len(rel) == 2 or (len(rel) == 3 and rel[1] == 'r07_fix')):
            published.append(name)
    with (HERE / 'EXTRA_FILES.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump({'paths': sorted(payloads), 'publication_paths': sorted(published)}, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'raw_payloads': len(payloads), 'publication_paths': len(published)}))


if __name__ == '__main__':
    main()
