"""Check delivered file identities without running package code."""
import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
DOC = HERE.parent.parent


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


result = {'functional_runs': 0, 'packages': {}}
for name, list_name in [('public_capture_tb', 'FILELIST.json'), ('oracle_bundle_bridge', 'FILE_SHA.json')]:
    source = DOC / name / list_name
    records = json.loads(source.read_text(encoding='utf-8'))['files']
    mismatches = []
    for row in records:
        p = ROOT / row.get('relative_path', row['path'])
        if not p.is_file() or identity(p.read_bytes()) != {k: row[k] for k in ('bytes', 'sha256')}:
            mismatches.append(str(p))
    result['packages'][name] = {'manifest': identity(source.read_bytes()), 'files': len(records), 'mismatches': mismatches}
archive_receipt = json.loads((DOC / 'public_capture_tb/ARCHIVE_RECEIPT.json').read_text(encoding='utf-8'))
a = Path(archive_receipt['archive']['path'])
assert identity(a.read_bytes()) == {k: archive_receipt['archive'][k] for k in ('bytes', 'sha256')}
with zipfile.ZipFile(a) as z:
    assert z.testzip() is None
    assert len(set(z.namelist())) == len(z.namelist())
    result['packages']['public_capture_tb']['archive_payloads'] = len(z.namelist())
with (HERE / 'AC_COLLECTION_CHECK.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result))
assert all(not p['mismatches'] for p in result['packages'].values())
