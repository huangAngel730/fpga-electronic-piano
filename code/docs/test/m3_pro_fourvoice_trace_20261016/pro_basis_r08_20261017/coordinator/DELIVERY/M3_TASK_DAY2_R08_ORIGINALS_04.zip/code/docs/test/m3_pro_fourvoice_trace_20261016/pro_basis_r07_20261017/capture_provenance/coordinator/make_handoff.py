"""Package immutable originals and later publication-gate receipts together."""
import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]


def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    out = HERE / 'HANDOFF_FINAL'
    out.mkdir(exist_ok=False)
    files = [p for p in (HERE / 'DELIVERY').rglob('*') if p.is_file()]
    files += [p for p in (HERE / 'GATE_R01').rglob('*') if p.is_file()]
    for name in ['INDEX_RECEIPT.json', 'FINAL_PUBLICATION.json', 'FORWARD_M2.md', 'PACKAGE_STATUS.json', 'RESULT.md', 'PUBLICATION_FILES.json', 'C5_INTAKE_RECEIPT.json']:
        files.append(HERE / name)
    c5 = ROOT / 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017'
    files += [c5 / 'SOURCE_CLOSURE_R06C5.zip', c5 / 'SOURCE_DECISION_R06C5.json']
    manifest = {p.relative_to(ROOT).as_posix(): ident(p.read_bytes()) for p in files}
    archive = out / 'M3_TASK_DAY2_R07_V0396_HANDOFF_20261017.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            z.write(p, p.relative_to(ROOT).as_posix())
        z.writestr('MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
        for name, expected in manifest.items():
            assert ident(z.read(name)) == expected
    receipt = {'status': 'CRC_SIZE_SHA_PASS', 'archive': archive.name,
               **ident(archive.read_bytes()), 'payloads': len(manifest),
               'M2_delivery': 'WAITING_USER_FORWARD_NOT_DELIVERED', 'board_release_allowed': False}
    with (out / 'HANDOFF_RECEIPT.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
