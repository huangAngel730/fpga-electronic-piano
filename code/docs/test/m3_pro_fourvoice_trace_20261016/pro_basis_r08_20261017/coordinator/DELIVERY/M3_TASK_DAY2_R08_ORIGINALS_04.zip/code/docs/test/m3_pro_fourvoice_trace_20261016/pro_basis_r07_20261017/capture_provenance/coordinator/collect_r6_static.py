"""Read-only identity checks for R6-3/5/8 static additions."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
DOC = ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r06_20261017'
names = ['normalized_intake/r07_fix/FILE_SHA.json', 'event_calendar/r07_fix/FILE_SHA.json',
         'event_calendar/FRAME_PLAN_INCREMENT_FILE_SHA.json', 'board_capture_acceptance/FILE_SHA.json']
result = {'functional_runs': 0, 'source_imports': 0, 'manifests': {}}
for name in names:
    p = DOC / name
    data = json.loads(p.read_text(encoding='utf-8'))
    mismatches = []
    for row in data['files']:
        source = ROOT / row['path']
        raw = source.read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            mismatches.append(row['path'])
    result['manifests'][name] = {'count': len(data['files']), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'mismatches': mismatches}
with (HERE / 'R6_STATIC_COLLECTION_CHECK.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result))
assert all(not v['mismatches'] for v in result['manifests'].values())
