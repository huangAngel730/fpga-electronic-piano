"""Collect fixed-consumer evidence and A-C5 identity without executing code."""
import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
DOC = ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r06_20261017/tool_plan_adapter/r07_fix'


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


manifest = json.loads((DOC / 'FILELIST.json').read_text(encoding='utf-8'))
mismatches = []
for row in manifest['files']:
    p = ROOT / row.get('relative_path', row['path'])
    if not p.is_file() or identity(p.read_bytes()) != {k: row[k] for k in ('bytes', 'sha256')}:
        mismatches.append(str(p))
receipt = json.loads((DOC / 'RECEIPT.json').read_text(encoding='utf-8'))
arc_receipt = json.loads((DOC / 'ARCHIVE_RECEIPT.json').read_text(encoding='utf-8'))
archives = [arc_receipt['archive'], receipt['C5_static_binding_receipt']['archive']]
for item in archives:
    p = Path(item['path'])
    assert identity(p.read_bytes()) == {k: item[k] for k in ('bytes', 'sha256')}
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
result = {'files': len(manifest['files']), 'mismatches': mismatches,
          'archives': archives, 'functional_runs': 0,
          'consumer_sha256': receipt['key_files'][0]['sha256'],
          'matches_root_static_review': receipt['key_files'][0]['sha256'] == '56ba0c5615cbe98094e5d37dc72e9e92002ce4976169723b2fd6f5ba8217bb69'}
with (HERE / 'R64_COLLECTION_CHECK.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result))
assert not mismatches and result['matches_root_static_review']
