# R6-4 消费端定向自审

自审子智能体只读 consumer.py 与必需旧 normalize_spec 上下文；未执行、导入或改文件。

所读 consumer SHA256：56ba0c5615cbe98094e5d37dc72e9e92002ce4976169723b2fd6f5ba8217bb69。

在独立 spec 路径/SHA 保持固定的边界下，未发现 M2 V0396 指出的计划篡改绕过仍可成立：audit 重建spec并比全部字段；rebuild 固定Python、-I/-S/-B、worker及stream/error模式，另限cwd、输入角色、helper身份、输出和marker范围；Popen紧前再audit并核kwargs、独占输出和本PID消费claim。修改plan并重算SHA会字段不符，修改spec但保持冻结pin会SHA不符。

该结论不认证调用端的新准入：spec pin仍来自调用端，文件SHA不产生执行权限；真实工具执行始终关闭。未覆盖孙进程、超时、日志溢出和异常清退的真实工具生命周期，不以本次静态结论补签旧P7。

最终版本及实际定向软件结果以实现窗口冻结收据为准；若源码变化仅核对应增量。
