# B 首轮后只读子智能体自审

未运行任何程序/测试/HDL，未写实现。读取身份：

- assembly.py: e8fa8b5b33058ad1fc8320801580df2b7bd8c60bb2e9d2b74fd25ab85f9a3eca
- equivalence.py: 35d822839f71047cbe574e8649c2c9a09d9ed446e267c7db1e913103e8be1ee2
- selftest.py: 1ca8eee96b33af675c2774c0561523ee22eeacd47dae95180e3459871fe989db
- tb_public_equivalence.sv: 7066923292b1343c7d64664d7fe7cc2a5131345c10b992ffde26983dd6943329

具体阻断：TB34–41仅40MHz上升沿比较13位公开输出。冻结时钟模型含25/125MHz域，采样间短差异/X可漏掉（如87.5与112.5ns采样之间95–100ns的单方PA/TMDS异常）。仅签采样点相等不足以签完整公开行为。
最小修法：在冻结窗口增加有明确delta稳定及终止相位的引脚变更比较，保存首次差异真实时间，并以一次<=60秒定向软件增量核沿间短差异/未知；不全组重跑。已发送夜间3，D仍由其串行实施。
其余已核：共享时钟/MIDI/reset、行数/time/cycle/唯一END及窗口X拒收、UART bit4/347拍一致；旧DVI stub六数据脚常量只为模型限制，真实视频内容仍未验。本结论不用于后继新SHA，不代M2签收。
