"""Collect R6-6 and completed B dual-source static evidence."""
import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
DOC = ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016'
result = {'functional_runs': 0, 'manifests': {}}
for name in ['pro_basis_r06_20261017/tx_clock_reset_checker/r07_fix/FILE_SHA.json',
             'pro_basis_r07_20261017/public_equivalence_tb/c5_dual_assembly/FILE_SHA.json']:
    p = DOC / name
    data = json.loads(p.read_text(encoding='utf-8'))
    mismatches = []
    for row in data['files']:
        source = ROOT / row['path']
        raw = source.read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            mismatches.append(row['path'])
    result['manifests'][name] = {'count': len(data['files']), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'mismatches': mismatches}
receipt = json.loads((DOC / 'pro_basis_r07_20261017/public_equivalence_tb/c5_dual_assembly/RECEIPT.json').read_text(encoding='utf-8'))
archive = receipt['archive']
raw = Path(archive['path']).read_bytes()
assert len(raw) == archive['bytes'] and hashlib.sha256(raw).hexdigest() == archive['sha256']
with zipfile.ZipFile(archive['path']) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
result['B_dual_archive'] = archive
with (HERE / 'R66_B_COLLECTION_CHECK.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result))
assert all(not v['mismatches'] for v in result['manifests'].values())
