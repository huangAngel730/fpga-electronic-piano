# 跨包静态发现与最小返修

以下仅静态读源发现，未运行新反例，已在实现窗口冻结前告知各独占写者。

1. R7-A assemble.py:194–199 的 TX_ADOPT 事件标签等于 rst_n==1 且 tx_sample_valid==1，覆盖启动、HOLD及新pending采纳。R6-3 新摄取候选初稿曾只允许 kind=ADOPTION 时出现该标签，会拒合法启动/HOLD。要求事件一致性按A实际合同处理，业务kind/consumes_pending独立保存；其他事件复位门控也一致，不改A已签源。通知夜间4及R6-6写者夜间3。
2. A 首行 source_line=1、global cycle=0。M2 FRAME_PLAN_RULES 的 n=1 是释放后局部首功能沿，不是全局坐标下界。R6-5 生成器及calendar初稿对reset/release/stop/finish要求>=1，会拒初始reset cycle0及只含cycle0的RESET_ONLY。要求统一非负global坐标、n_k仍从1起算，并更新schema及NOT_RUN边界用例。通知夜间4及夜间3。

修后源码身份和静态确认另记最终收据；不把新候选的静态修法当已运行通过，不恢复R6-3/5软件额度。

## 修后只读确认

自审子智能体确认上述两项已修正，指定增量内未见残留阻断；没有执行/import/compile。TX_ADOPT严格按rst_n==1 && tx_sample_valid==1核事件，ADOPTION才消费pending；全局坐标允许0，局部序号从1起，RESET_ONLY空窗和段间连续约束仍保留。

- intake_r07_fix_candidate.py：d8bae7b015e1fd19a9e7af917c3b238f828833abaf0b227db25407faa534831d
- frame_plan_generator_candidate.py：38592faebeeeb0a2022668785453760a5b58babd24af6ff18a96f15790597191
- calendar_r07_fix_candidate.py：9af7022b0a228e0f8e180fd6a3c58646757cb407dfb132726c8ae0ace28413a5
- FRAME_PLAN_INPUT_SCHEMA.json：9664fb978afee6c5946d2ea6d3cb32d06e7f5770a0195896bed0eb428c55dc1f

动态边界用例仍NOT_RUN，不扩大为整包通过。
