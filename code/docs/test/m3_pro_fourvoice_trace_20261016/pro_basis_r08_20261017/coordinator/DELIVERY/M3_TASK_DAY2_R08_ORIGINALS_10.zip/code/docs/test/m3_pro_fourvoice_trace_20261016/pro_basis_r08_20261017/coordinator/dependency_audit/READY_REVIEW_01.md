# R08 READY增量只读结论（C/R与H21/22，首组NOT_RUN）

本报告续接READY_INCREMENTAL_FINDINGS.md。只读主窗口及两名只读子智能体，没有运行/import候选、测试、HDL/EDA/设备或修改实现/消费。代码正在并发预冻结修订，下列结论只绑定所列读取版本，不能套到尚未复读的新SHA。

## 新发现、尚需原写者处理

1. **C11结束身份漏核。** `finish_protocol_recorder.py:21–26,39–43`（SHA f85afbff7247fc33f5e507365c45f07efc3adf29f27f68dc7b3c52ef0049c602）只核两个list长度和末帧相等。空END `[{}]`＋任意单MONITOR_END，以及两个末帧都null，可走到SYNTHETIC_FINISH_ACCEPTED/finish_cycle=null；END2000/MONITOR1也未拒。最小修法：按A合同核完整epoch/cycle/capture/来源、相同结束及与冻结finish/末帧的时序关系；缺身份PENDING/拒收，不能null==null就完整。加对应新反例。
2. **C07/08实际输入/组件产物未封存。** `capture_csv_codec/selftest.py:43–46,58–74`（3209d5a362b176a64b78b7df0776bec123578eff51f20e10b40b63d547fd4f12）实际传startup双行或29列表CSV，但总写原row；只有通用wrapper结果，未存encoded/decoded/实际异常。`async_reset_events/selftest.py:31–57`（d3ebf05e65c6024964d6345f03470d8f7eb574efda6e16836d074ff202536e93）实际传切片却写完整samples，组件RESET_EDGES report被通用PASS覆盖。最小修法：写真正传入payload、组件真实输出/异常，另列断言结果，保证可核独立产物。
3. **C09自洽hash后非法窗口仍可过。** 修后frame_coverage_diff.py:68–87（e3d62cd81bd68645abf9ae33766bbef3a9ff329199c534ed786b354be0a161d0）没有reset<=release<=stop/严格整数非负检查。把首epoch reset改9999，仍release0/stop1666/cycles[833,1666]并自洽重算canonical hash，比较这些帧静态仍可PASS。最小补唯一生产者同一窗口约束，保留R6-5唯一生产，不另认证REAL。
4. **R组GEN正例不验证生成的帧。** `normalized_intake/r08_integration/selftest.py:245`（读取SHA a2e0a08e3417fbb4b7614112ad602dd983fa7db3586dbf6414dd0c8ae8b5fb58）两个GEN正例仅断言reset_assert_cycle==0，ACTIVE错产[]/[834]或RESET_ONLY错含帧仍可能绿。269–279的CROSS仍手造_plan。最小用独立常量核ACTIVE=[833]、RESET_ONLY=[]，并让一个真实generator canonical产物进入R6-5消费器；不启动旧generator自测。
5. **R63输入随被审常量变化。** 同R selftest:42–61从被审候选EXPECTED_FIELD_NAMES/EXTENSION_KEYS/SCHEMA构造所有正例。候选漏字段或错版本，夹具自动跟错，正例不再独立。最小冻结合同61字段/扩展/schema的测试常量，先逐项核候选一致，再构造输入；不修改旧M1/DSP黄金。
6. **H22的profile仅ID字符串，没有21的有效性绑定。** `latency_alignment.py:58–74`，主窗口再读版本884e184045f225a8ee3b8de59bf9b900c387861963d3488f65d35629e1022354：不存在或PENDING_CALIBRATION的三个非空profile ID仍能ALIGNED并算under_10ms。还没有原始事件行/样本索引或首合法阈值匹配依据，调用方任选晚一次analog_response就成first_match。最小消费SHA绑定的21记录，核READY/会话/时基/误差来源，并消费16及冻结触发/阈值下的原事件索引核首响应；否则UNKNOWN，不仅复述自填时间和ID。

H21当前已给sample/edge/required_resolution及校准uncertainty补finite检查，先前NaN发现不重复报告。但本次主窗口复读SHA8569c78340cb16afccb3b61cc6c5afbd4888205598d25573e8d86690873bc392的第33–34行`range_min>=range_max`仍没有finite/type约束；range_min=NaN时比较为假且可继续PROFILE_READY。将量程两端也纳入同一有限实数校验即可；这是余量补漏，不再报告已修sample/uncertainty。

## 已看到修正／不重复报旧项

- C09已补independent_of_trace、canonical_plan_id/hash、core_hz及initial_state，旧“完全无身份检查”不再成立；上面只列窗口合法性余项。
- 总控已报C10负龄/next_F缺失/全None总体PASS、C12无source依赖边，等待其精确新版本，不再次发相同返工。
- H21已补timebase/settings/trigger；H22已补非空共同会话/时基及有限非负误差。不能把旧代码问题继续套给新版本。上述H22 profile/首匹配是独立未闭项。
- R29例读取范围仅调用新R6-3/5候选及新生成器；未见旧R6-4/6、D3、旧runner或子进程启动，PENDING断言保留组件输出。但“未见违规调用”不替代上述独立期望/覆盖缺口，不签运行通过。

## 读取边界与后续

当前C六组件/其病例、H21/22及R29已读。S/T其它组件与H19/20/23/24尚未收到整组READY范围，不提前验收、不扩展全仓。H仍须六项三写者汇合一次；测试入口须无导入期子进程，不能import旧selftest/runner。CONSUMPTION最新读取五组仍NOT_STARTED；本窗口新增消费0。

应先由原写者修完并发布新READY/SHA/CASES，总控在唯一冻结规格内再启动首组。这里只提供静态反例和最小修法，无实际PASS/FAIL数据。若上述SHA已漂移，只复查该修复增量和对应反例，不全面重审或重跑旧组。
