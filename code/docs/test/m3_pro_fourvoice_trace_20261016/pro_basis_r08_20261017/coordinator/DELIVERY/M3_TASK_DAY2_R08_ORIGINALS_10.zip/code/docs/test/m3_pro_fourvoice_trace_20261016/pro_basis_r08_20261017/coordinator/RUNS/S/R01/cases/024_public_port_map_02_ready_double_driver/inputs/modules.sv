module fixture_dut(input wire clk,input wire rst_n,output wire ready,output wire [7:0] data); endmodule
module fixture_driver(input wire clk,output wire ready); endmodule
