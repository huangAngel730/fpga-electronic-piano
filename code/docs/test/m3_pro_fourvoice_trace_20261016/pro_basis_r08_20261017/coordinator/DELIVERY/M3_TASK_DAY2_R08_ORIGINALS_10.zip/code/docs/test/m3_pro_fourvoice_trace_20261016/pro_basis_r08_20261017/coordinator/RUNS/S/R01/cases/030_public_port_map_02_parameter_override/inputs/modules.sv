module fixture_dut #(parameter N=8)(input wire clk,input wire rst_n,output wire ready,output wire [N-1:0] data); endmodule
module fixture_driver(input wire clk,output wire ready); endmodule
