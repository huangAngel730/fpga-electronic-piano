module fixture_top; logic clk=0,rst_n=0; wire ready,unused_ready; wire [7:0] data; fixture_dut dut(.clk(clk),.ready(ready),.data(data)); fixture_driver drv(.clk(clk),.ready(unused_ready)); endmodule
