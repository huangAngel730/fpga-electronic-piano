module fixture_observer(input wire clk,input wire rst_n,input wire ready,input wire [7:0] data); endmodule
