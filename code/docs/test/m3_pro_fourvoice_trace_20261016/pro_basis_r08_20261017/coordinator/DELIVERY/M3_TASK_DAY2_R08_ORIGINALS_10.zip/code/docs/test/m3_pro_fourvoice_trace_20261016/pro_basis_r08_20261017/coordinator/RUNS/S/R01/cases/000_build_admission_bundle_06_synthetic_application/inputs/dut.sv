module fixture_dut(input wire clk,input wire rst_n,output wire ready,output wire [7:0] data);
`include "fixture.svh"
reg [7:0] mem[0:1]; initial $readmemh("rom/mock.hex",mem); endmodule
