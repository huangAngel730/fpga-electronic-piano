"""Coordinator metadata audit only; does not import or execute candidates."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[5]


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    with (HERE / name).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main():
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip()
    assert head == "ef4fbc74b9d24e08de1e09d0be0eb3163118f258"
    old = ROOT / "code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017/capture_provenance/coordinator"
    prior = json.loads((old / "TRACKED_PUBLICATION_BASELINE.json").read_text(encoding="utf-8"))
    changed = subprocess.check_output(["git", "diff", "--name-only", "-z", "40d78131e8ed50643dd169816f7bfc7149a8ced9", head], cwd=ROOT).decode().split("\0")
    changed = [p for p in changed if p]
    deviations = [p for p, v in prior.items() if not (ROOT / p).is_file() or identity((ROOT / p).read_bytes()) != v]
    assert set(deviations).issubset(changed), deviations
    assert not subprocess.check_output(["git", "diff", "--name-only", "HEAD"], cwd=ROOT).strip()
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0")
    snapshot = {p: identity((ROOT / p).read_bytes()) for p in tracked if p}
    save("TRACKED_BASELINE.json", snapshot)
    save("M2_BASELINE_ADVANCE.json", {"old_head": "40d78131e8ed50643dd169816f7bfc7149a8ced9", "head": head, "published_changes": changed, "prior_deviations": deviations, "tracked_count": len(snapshot)})
    base = ROOT / "code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017"
    decision_path = base / "SOURCE_DECISION_R06C6.json"
    decision = json.loads(decision_path.read_text(encoding="utf-8"))
    archive = ROOT / decision["archive"]["path"]
    assert identity(archive.read_bytes()) == {k: decision["archive"][k] for k in ("bytes", "sha256")}
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(set(z.namelist())) == len(z.namelist())
        for name, expected in decision["payloads"].items():
            assert identity(z.read(name)) == expected, name
        compile_lines = z.read("inputs/compile.f").decode().splitlines()
        units = [s.strip() for s in compile_lines if s.strip() and not s.startswith(("#", "+"))]
        assert len(units) == 71
        assert "+incdir+include" in compile_lines
        assert all("inputs/" + p in z.namelist() for p in units)
        for edge in decision["include_coverage"]["edges"]:
            assert edge["include"].encode() in z.read(edge["source"])
            assert identity(z.read(edge["resolved"]))["sha256"] == edge["sha256"]
        assert len(decision["headers"]) == 2
        assert len(decision["include_coverage"]["edges"]) == 3
        assert z.read("provenance/ORIGINAL_dds_oscillator.sv")[:1240] + b"\n" == z.read("inputs/selected/dds_oscillator_leaf.sv")
    save("C6_INTAKE_RECEIPT.json", {"status": "CRC_SIZE_SHA_DERIVATION_PASS_STATIC_ONLY", "archive": decision["archive"], "decision": identity(decision_path.read_bytes()), "payload_count": len(decision["payloads"]), "selected_units": len(units), "headers": 2, "include_edges": 3, "rom_count": decision["rom_count"], "HDL_runs": 0, "board_release_allowed": False})
    a = old.parent.parent / "public_capture_tb/c5_static_binding/r02_include_rom"
    manifest = json.loads((a / "FILELIST.json").read_text(encoding="utf-8"))
    for entry in manifest["files"]:
        assert identity((a / entry["relative_path"]).read_bytes()) == {k: entry[k] for k in ("bytes", "sha256")}, entry
    archives = []
    for path in a.glob("*.zip"):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            assert len(z.namelist()) == len(set(z.namelist()))
        archives.append({"path": str(path.relative_to(ROOT)), **identity(path.read_bytes())})
    save("A_C5_SUPPLEMENT_COLLECTION.json", {"files_verified": len(manifest["files"]), "mismatches": [], "archives": archives, "candidate_executions": 0})
    print(json.dumps({"head": head, "tracked": len(snapshot), "c6_payloads": len(decision["payloads"]), "a_c5_files": len(manifest["files"])}))


if __name__ == "__main__":
    main()
