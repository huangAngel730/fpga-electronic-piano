module fixture_driver(input wire clk,output wire ready); endmodule
