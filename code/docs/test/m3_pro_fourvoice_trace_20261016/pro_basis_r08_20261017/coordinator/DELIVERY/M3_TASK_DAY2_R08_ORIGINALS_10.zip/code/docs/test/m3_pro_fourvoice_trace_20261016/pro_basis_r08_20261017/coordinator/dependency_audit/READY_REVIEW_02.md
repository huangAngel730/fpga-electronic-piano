# READY_REVIEW_02：前次问题的只读增量复核

结论：前次 READY_REVIEW_01 所列修复已在当前源码中静态可见；仍有一条 H22 首阈值事件削波边界需修正。等级 L0 / STATIC / NOT_RUN，不代表组测试、真实测量或 M2 准入通过。

本次只核前次问题与总控明确追加的 H22 边界，不重做全面审核。源版本以同名 JSON 中 SHA 为准；并发后续修改不在本结论覆盖内。未导入、编译或执行候选；未运行测试、HDL、EDA、设备；未写消费账、实现、共享状态或 Git。所有命令仅阅读文本、列目录和计算文件哈希，退出码均 0。

## 唯一保留阻断：H22 会跳过首个已削波阈值事件

- 文件：`code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/latency_alignment/latency_alignment.py`，145–149 行；源码 SHA256 `3d32e21cc8397df3f0bfd7c00a6ee8af7c1b30aa5fb45f7532780ead1b7be1ca`。
- 触发条件：全局 `analog_clipped=False`，但数字事件后首个匹配冻结阈值规则的模拟事件 `clipped=True`，后续存在未削波匹配事件；声明的 `analog_response_ns` 指向后者。
- 静态路径：93 行仅检查全局声明；`_events` 仅验证逐事件 clipped 的布尔类型；145–149 行 `next(... and not event["clipped"])` 过滤首行，取后续未削波行。该行与外层时间声明相符后可走到 `ALIGNED`，并可能 `under_10ms=True`。没有检查逐事件事实与全局 False 的矛盾。
- 最小静态反例（NOT_RUN）：使用当前 `latency_alignment/selftest.py` 的 `_input()` 所定义有效输入，其他字段及 profile 本体/SHA 不变；在 `event_evidence.analog` 索引 1 插入下述事件，保留原有 8,001,000 ns 未削波事件、`analog_response_ns=8001000` 和全局 False：

```json
{"time_ns":7500000,"sample_index":75000,"source_line":75001,"threshold_rule_sha256":"1111111111111111111111111111111111111111111111111111111111111111","clipped":true}
```

此时输入、数字、模拟时间分别为 1000 / 2000 / 8001000 ns，不确定度 100+200 ns；静态推导当前路径 nominal=8000000、upper=8000300、ALIGNED/under_10ms=True，首个匹配阈值事件实际在 7500000 ns 且已削波。以上是源码路径推导，没有运行结果或伪造日志。

- 最小修法：先按时间和冻结阈值选取首个匹配事件，再检查其 clipped；保持 UNKNOWN，或拒绝全局 False 与事件事实矛盾。不能通过过滤已削波首事件而继续签后续延迟。由原写者添加对应负例，总控仅按有效组许可执行；本复核未消费额度。

## 前次问题的修复核对

| 范围 | 当前源码可见增量 | 本轮判定 |
|---|---|---|
| C11 END/MONITOR/末帧 | END 与 MONITOR 含 capture/source/epoch/cycle 并一致，绑定 frozen_finish；末帧必须为非空结构且与观测一致 | 原具体反例已被对应检查阻断，静态关闭 |
| 07 证据 | STARTUP 保存实际两行输入，另存 encoded_csv/decoded_rows；组件输出与 wrapper 结果分开 | 原输入不一致/结果缺失问题静态关闭 |
| 08 证据 | 缺 release 用例保存实际切片 actual_samples；组件报告另存 component_output.json | 原输入不一致/报告被 wrapper 代替问题静态关闭 |
| C09 窗口 | reset/stop 严格非负整数，ACTIVE release 严格非负整数且 reset<=release<=stop | 原 reset=9999/release=0 反例静态关闭 |
| H21 范围 | range_min/range_max 均检查数字类型及 math.isfinite，再比较大小 | 原 NaN 范围反例静态关闭 |
| H22 profile 与首事件依据 | 校验 profile 本体、规范化 SHA、READY、同 session/timebase/trigger、不确定度绑定；事件含 sample_index/source_line 并按规则选择 | 前次“只有 ID/时间声明”问题已补；上节削波首事件另保留 |
| R 固定合同与链路 | R7 字段/扩展集合及 schema 本地冻结后比对候选；GEN ACTIVE 明确 [833]、RESET_ONLY 明确 []；CROSS 实际调用 generator.build_documents 并以 canonical 送 R65 | 前次三处具体断言/依赖问题静态关闭 |

“静态关闭”仅指前次具体源码缺口已补，不代签组件全面通过，也未重审 C10/C12 或扩大测试范围。

## 边界与交接

- ROLE_B_READY 所列上述源码/selftest 的 SHA 与本次读取的八个文件一致。READY 是待执行声明，不能代替运行回执。
- T/H17 已由总控冻结并核身份，本轮未重读；未发现需要扩大 T 阅读的跨包依赖。
- 本次目录快照未发现 S/ROLE_A 完整 READY；因此未开始 S 合同/配额/独立输入检查，不对 S 作通过结论。
- 消费账快照 R/S/C/T/H 均 NOT_STARTED、initial_consumed=0、repair_consumed=0；本轮写入消费次数 0。不得据静态修复自行恢复或消费额度。
- 报告只落本地 dependency_audit，供总控只读取件；未发送跨窗口消息，未提交、未推送。需要原写者处理的精确事项只有上节 H22 边界。
