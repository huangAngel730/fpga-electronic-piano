# R08 READY前增量阻断（静态NOT_RUN，首轮尚未启动）

本次只读C组实际源码/CASES及R/H关联。总控已报10/12/21/22问题，不重复列为新发现；09初版canonical身份缺失已看到并发修正，本文件仅列修后尚存项。没有运行/import候选。行号/SHA指本次读取快照，不覆盖实现窗口修订。

## 1. 11：结束记录只核数量，空/互相矛盾身份与缺末帧可被接受

`finish_protocol_recorder/finish_protocol_recorder.py:21–26,39–43`，本次SHA `f85afbff7247fc33f5e507365c45f07efc3adf29f27f68dc7b3c52ef0049c602`。保留selftest._input其它合法值，令`end_rows=[{}]`、`monitor_end_rows=[{"cycle":1}]`，再令`last_plan_frame=observed_last_frame=null`。两列表长度都1，末帧相等，其它flag/exit0满足；静态走到SYNTHETIC_FINISH_ACCEPTED，finish_cycle=null。即使保留真实末帧，END cycle2000/MONITOR cycle1也未比较，正常结束身份与先后关系漏核。

影响：任务11要求错误finish、真实结束/尾段收据的关系核验，当前工具只验证caller flag和数量，不能拒空身份/矛盾结束。最小修法：严格定义并校验END/MONITOR_END的epoch/cycle/capture等必要身份、与冻结finish及末计划帧的关系；允许字段差别只能按A合同显式映射。两边null不是完整末帧，无权威来源保持PENDING/UNKNOWN，不能互相等于就接受。补空记录/矛盾epoch-cycle/双null末帧的冻结新反例；不要重跑旧R07结束组。

## 2. 07/08：病例原件没有保存真正组件输入/输出

- `capture_csv_codec/selftest.py:43–46,58–62,69–74`，SHA `3209d5a362b176a64b78b7df0776bec123578eff51f20e10b40b63d547fd4f12`：startup例实际传[startup,row]，29列表例实际传CSV header，但input.json一律只写原row；result.json只写case/status/expected，没有实际encoded/decoded或捕获的拒收结果。不能从封存复核实际输入和产物。
- `async_reset_events/selftest.py:31–57`，SHA `d3ebf05e65c6024964d6345f03470d8f7eb574efda6e16836d074ff202536e93`：MISSING_RELEASE_PENDING实际传samples[:2]却写完整samples；所有分支的组件report最终被通用{case_id,status:PASS}替换，RESET_EDGES等独立产物没有写入result.json。

影响：违反总控“每例保留实际输入及结果”，软件断言即使将来通过也无法交足原件。最小修法：调用前记录实际payload（包括CSV文本/数组切片/多行），写组件真实输出/实际exception类型与首拒收码，并单列wrapper测试断言结果。仍在预冻结阶段修，不额外消费功能组。

## 3. 09：修后仍未核reset/release/stop窗口有效性

`frame_coverage_diff/frame_coverage_diff.py:68–87`，读取快照SHA `e3d62cd81bd68645abf9ae33766bbef3a9ff329199c534ed786b354be0a161d0`。现已核canonical自洽hash、independent_of_trace及完整parameters，先前问题不再重报。新静态反例：保留合法计划release=0、stop=1666、cycles=[833,1666]，把首epoch.reset_assert_cycle改9999并重算它的canonical自洽hash，观察帧仍833/1666。首epoch没有prior_stop检查，代码也没有reset<=release<=stop检查，仍可比较为PASS，尽管两帧发生在该epoch所声明reset以前。

最小修法：按唯一生产者输入合同核严格整数/非负、epoch连续、reset<=stop、ACTIVE的reset<=release<=stop、RESET_ONLY无release/帧，以及finish属于最后有效窗口。来源SHA自洽不等于输入合法或独立真实性；若只核本体，报告不要把自填independent标签当M2真实认证。补自洽hash下非法窗口新例，不另造FRAME权威生产者。

以上均为静态控制流反例，未实际调用或产生PASS/FAIL运行结果；应先由原写者修正并重新READY/冻结case，再由总控按已有唯一组启动。后续新版本须只复查修法/对应反例，避免对已修项重复报告。
