module foreign; endmodule
