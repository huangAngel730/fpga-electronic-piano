"""Publishable metadata/originals from actual source gate and remote proof."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys
import zipfile

R = Path.cwd()
D = R / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/morning_r11_20261018'
O = R / 'code/output/m3_c9_chain_night_r10_20261017/MORNING_R11_20261018'
N = R / 'code/output/m3_m2_night_drill_20261017/runs'
commit = sys.argv[1]


def load(p):
    return json.loads(p.read_text('utf-8'))


def save(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(v, f, ensure_ascii=False, indent=2)
        f.write('\n')


def ref(p):
    with p.open('rb') as f:
        sha = hashlib.file_digest(f, 'sha256').hexdigest()
    return {'path': p.relative_to(R).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha}


gate = load(D / 'publication_source_final/GATE_R01/GATE_RECEIPT.json')
proof = load(O / 'SOURCE_REMOTE_PROOF/RESULT.json')
assert gate['status'] == 'PASS' and gate['exit_code'] == 0 and gate['pass_count'] == 9 and gate['input_bytes_unchanged']
assert proof['status'] == 'REMOTE_CONTAINS' and proof['commits'] == [commit]
files = set()
for directory in [D / 'publication_source', D / 'publication_source_final', O / 'INDEX_BEFORE_SOURCE_COMMIT', O / 'INDEX_FINAL_SOURCE', O / 'SOURCE_REMOTE_PROOF']:
    files.update(p for p in directory.rglob('*') if p.is_file())
files.update(O / name for name in ('run_publication_gate.py', 'verify_publication.py', 'make_receipts.py', 'GOAL_BEFORE_RECEIPT.json', 'SOURCE_PUBLICATION_QUEUE_FINAL.json'))
for run in N.glob('morning_r11_*_01'):
    files.update(p for p in run.iterdir() if p.is_file())
outputs = {}


def walk(v):
    if isinstance(v, dict):
        if {'path', 'bytes', 'sha256'} <= v.keys() and isinstance(v['path'], str):
            p = Path(v['path'])
            p = p if p.is_absolute() else R / p
            if p.is_relative_to(R / 'code/output'):
                assert p.is_file()
                actual = ref(p)
                assert all(actual[k] == v[k] for k in ('bytes', 'sha256')), p
                outputs[str(p)] = {'descriptor_in_handoff': v, 'archive_member': p.relative_to(R).as_posix()}
                files.add(p)
        for item in v.values():
            walk(item)
    elif isinstance(v, list):
        for item in v:
            walk(item)


walk(load(D / 'INTEGRATION_HANDOFF.json'))
identity = [ref(p) for p in sorted(files)]
archive = D / 'DELIVERY/PUBLICATION_ORIGINALS.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(files):
        z.write(p, p.relative_to(R).as_posix())
    z.writestr('ORIGINALS_MANIFEST.json', json.dumps({'files': identity, 'legacy_output_resolution': list(outputs.values())}, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(files) + 1
    for item in identity:
        raw = z.read(item['path'])
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
save(D / 'PUBLICATION_MANIFEST.json', {'archive': ref(archive), 'files': identity, 'CRC': 'MATCHED', 'legacy_output_resolution': list(outputs.values())})
payload = [ref(D / 'DELIVERY/SOURCE_PAYLOAD.zip')]
receipt = {
    'schema': 'NIGHT_HANDOFF_V1', 'handoff_id': 'M3-R11-20261018-STATIC-01',
    'task_id': 'M3-MORNING-R11-20261018', 'plan_version': 'R11', 'producer': 'M3', 'consumer': 'M2',
    'base_commit': '3202946161f6df6985effe7f2824c97cc4daf03f', 'result_commit': commit,
    'manifest': payload, 'current_INTEGRATION_HANDOFF': ref(D / 'INTEGRATION_HANDOFF.json'),
    'publication_originals': ref(archive),
    'publication_originals_resolution': 'Evidence-only metadata tail in the envelope commit, not claimed inside earlier result_commit. Every manifest payload is present byte-for-byte in result_commit.',
    'next_action': 'M2 limited review and exact admission decisions; synchronize effective morning cards/overview/state/board. M1 returns one consumer compatibility decision. Source publication does not constitute receipt/acceptance.',
    'validation': {'status': 'STATIC_HANDOFF_UNIT_COMPLETE_OVERALL_PARTIAL_WAITING_INPUT', 'level': 'L0',
        'candidate_runtime': 'NOT_RUN', 'whole_route': 'NOT_RUN',
        'repository_gate': {k: gate[k] for k in ('status', 'exit_code', 'pass_count', 'seconds', 'input_bytes_unchanged', 'candidate_input_count')},
        'gate_scope': 'Actual workspace/index source tree, no separate clean checkout; gate old T007/T019 only, not new C9/Pro. Metadata tail gate performed before receipt commit.',
        'index_bytes': 'All final candidate staged blobs matched working/archive source bytes',
        'first_gate_history': 'Initial9/9/0 working-tree gate retained; one raw baseline CRLF index mismatch found separately, fixed through LF logical snapshot plus raw ZIP; final gate rerun on successor.'},
    'original_START': '2026-10-18T11:57:42+08:00', 'deadline': '2026-10-18T16:57:42+08:00',
    'Goal_meter': load(O / 'GOAL_BEFORE_RECEIPT.json'),
    'consumption': {'candidate_software_groups': 0, 'worker': 0, 'new_HDL_ModelSim_C9': 0, 'EDA': 0, 'devices': 0, 'old_consumption_preserved': True,
                    'currency_cost': None, 'currency_note': 'No per-task currency meter available; no inferred member tokens or purchase value'},
    'pending': ['M1 unique consumer compatibility/version/SHA/capacity and independent plan/math profile', 'M2 finish phase/write set, native executor mapping/dynamic closure and exact new processing/HDL admission', 'M2 audio_stable and actual DUT backpressure policy', 'same-run actual raw/pins/reset/END/stdout/stderr/exit/cleanup and actual mathematical/physical evidence'],
    'publication_state': 'REMOTE_VERIFIED', 'source_remote_tip': proof['remote_tip'], 'source_ancestor_exit_code': 0,
    'receiver_status': 'NOT_OBSERVED', 'M2_acceptance': 'NOT_OBSERVED', 'human_notification': 'NOT_CLAIMED',
    'receipt_commit': None, 'receipt_commit_note': 'Envelope is a later metadata commit; final remote inclusion proof local outbox plus actual Git ancestry, no self-reference',
    'originals_resolution': 'ZIP members retain repository-relative original paths. PUBLICATION_MANIFEST resolves 11 legacy output descriptors. Source archive contains all new bodies and unchanged source/archive dependencies. No RAW/FRAME/math fabricated.',
    'execution_allowed': False, 'real_verified': False, 'math_verified': False, 'board_release_allowed': False}
save(D / 'RESULT_RECEIPT.json', receipt)
save(D / 'RESULT_RECEIPT_M1.json', {**receipt, 'consumer': 'M1', 'next_action': 'One M1 consumer compatibility response and independent mapping/profile; no request to rerun old cases or generate fake actual math'})
save(O / 'CONSUMER_DEDUP_AND_DELIVERY.json', {'state': 'SOURCE_REMOTE_VERIFIED_RECEIPT_PENDING_GATE', 'rows': [
    {'key': hashlib.sha256(json.dumps([receipt['handoff_id'], commit, consumer], separators=(',', ':')).encode()).hexdigest(),
     'handoff_id': receipt['handoff_id'], 'result_commit': commit, 'consumer': consumer, 'REMOTE_VERIFIED': True,
     'RECEIVED': False, 'ACCEPTED': False, 'INTEGRATED': False} for consumer in ('M1', 'M2')],
    'no_automatic_receiving_or_acceptance_claim': True})
gate_doc = D / 'publication_receipt'
gate_doc.mkdir()
paths = [D / 'RESULT_RECEIPT.json', D / 'RESULT_RECEIPT_M1.json', D / 'PUBLICATION_MANIFEST.json', archive, gate_doc / 'PUBLICATION_FILES.json']
save(gate_doc / 'PUBLICATION_FILES.json', {'paths': [p.relative_to(R).as_posix() for p in paths], 'scope': 'Metadata/originals tail only; source already remote verified'})
print(json.dumps({'source_commit': commit, 'raw_payloads': len(files), 'legacy_output_originals_resolved': len(outputs), 'archive': ref(archive), 'metadata_files': len(paths)}))
