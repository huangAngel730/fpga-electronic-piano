"""Hash/archive and publication-metadata preparation only; no business imports."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import zipfile

ROOT = Path.cwd()
BASE = Path('code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017')
DOC = BASE / 'morning_r11_20261018'
ADR = BASE / 'night_drill_r01/morning_r11_20261018'
SOFT = Path('code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017')
OUT = Path('code/output/m3_c9_chain_night_r10_20261017/MORNING_R11_20261018')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def ref(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


save(DOC / 'A_ROOT_STATIC_REVIEW.json', {
    'schema': 'M3_R11_A_COORDINATOR_SELFREVIEW_V1',
    'reviewer': '/root/r11_drill_selfaudit plus root',
    'source': [ref(SOFT / 'night_drill_r01/morning_r11_20261018' / name) for name in ('binding.py', 'transport.py')],
    'read_scope': 'Two new sources, old Store/network related paths, binding examples/validation request',
    'conclusion': 'No new concrete blocker found in limited static reading. Historical examples refuse queue/receive; declared provenance is not actual execution. Source connects Store.enqueue/begin_attempt/network.run/finish_attempt with stable full key, old ledger prefix, IN_FLIGHT/UNKNOWN and two-attempt cap.',
    'level': 'L0', 'import_compile_run': 0,
    'real_integration_fault_boundary': 'NOT_RUN'})
checks_path = DOC / 'REMOTE_CHECKS.json'
checks = read(checks_path)
operation = 'morning_r11_unit_prepublication_20261018_01'
run = Path('code/output/m3_m2_night_drill_20261017/runs') / (operation + '_01')
record = read(run / 'RESULT.json')
checks['checks'].append({'operation_id': operation, 'UTC': record['utc'], 'exit': record['exit_code'], 'seconds': record['elapsed_seconds'], **{name: ref(run / file) for name, file in [('result', 'RESULT.json'), ('stdout', 'stdout.bin'), ('stderr', 'stderr.bin')]}})
checks['next_periodic_due_from_last_check_UTC'] = (datetime.fromisoformat(record['utc']) + timedelta(minutes=30)).isoformat()
checks_path.write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

# The raw task/card/sources are immutable content. Envelope/result-commit proof
# is published separately so a commit never includes its own unknown SHA.
owned = sorted({p for d in (DOC, ADR, SOFT / 'capture_complete_r11', SOFT / 'night_drill_r01/morning_r11_20261018') for p in d.rglob('*') if p.is_file()})
dependencies = set()
for directory in (SOFT / 'night_drill_r01', SOFT / 'capture_link_r01'):
    dependencies.update(p for p in directory.rglob('*.py') if 'morning_r11_20261018' not in p.parts)
dependencies.update(SOFT.glob('*.py'))
dependencies.update([
    Path('code/software/t052_runner_acceptance_candidate_20261012/windows_job.py'),
    BASE / 'intake_20261018/INTEGRATION_HANDOFF.json',
    BASE / 'intake_20261018/RESULT_RECEIPT.json',
    BASE / 'intake_20261018/DELIVERY/M3_OCT18_CAPTURE_LINK_AND_INTAKE_ORIGINALS.zip',
    BASE / 'intake_20261018/DELIVERY/PUBLICATION_ORIGINALS.zip',
    BASE / 'admission/APPLICATION_REQUEST.json',
    BASE / 'night_drill_r01/CONSUMPTION.json',
    BASE / 'night_drill_r01/RUN_CONTRACT_FROZEN.json',
    OUT / 'START/WORKTREE_PORCELAIN.bin',
    OUT / 'prepare_delivery.py', OUT / 'seal_source.py',
])
application = read(BASE / 'admission/APPLICATION_REQUEST.json')
for desc in [application['source']['base'], application['source']['application'], *application['source']['capture_sources'].values()]:
    dependencies.add(Path(desc['path']))
for check in checks['checks']:
    run_dir = Path(check['result']['path']).parent
    dependencies.update(run_dir / name for name in ('LAUNCH.json', 'RESULT.json', 'stdout.bin', 'stderr.bin'))
paths = sorted({(ROOT / path).resolve() for path in [*owned, *dependencies]})
for path in paths:
    assert path.is_relative_to(ROOT) and path.is_file(), str(path)
payload = [ref(path) for path in paths]
archive_dir = DOC / 'DELIVERY'
archive_dir.mkdir(exist_ok=True)
archive = archive_dir / 'SOURCE_PAYLOAD.zip'
manifest_body = {'schema': 'M3_R11_ARCHIVE_PAYLOAD_MANIFEST_V1', 'level': 'STATIC_ONLY', 'files': payload,
                 'note': 'Source/preparation body and original dependencies, not actual capture. Old published receipt ZIPs retain their internal output-path resolution. M1/M2 source closure archives unchanged; commercial binaries identity-only.'}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in paths:
        z.write(path, path.relative_to(ROOT).as_posix())
    z.writestr('ORIGINALS_MANIFEST.json', json.dumps(manifest_body, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(payload) + 1
    for item in payload:
        raw = z.read(item['path'])
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], item['path']
save(DOC / 'SOURCE_MANIFEST.json', {**manifest_body, 'archive': ref(archive), 'CRC': 'ALL_MEMBERS_MATCHED',
    'old_unchanged_18': 'MEMBER_INTAKE_RECEIPT.json', 'new_candidate_runs': 0})

gate_doc = DOC / 'publication_source'
gate_doc.mkdir()
publication = sorted(p.relative_to(ROOT).as_posix() for p in [*owned, archive, DOC / 'SOURCE_MANIFEST.json', gate_doc / 'PUBLICATION_FILES.json'])
save(gate_doc / 'PUBLICATION_FILES.json', {'paths': publication, 'scope': 'Only current R11 exclusive source/docs, no historical untracked artifacts'})
save(OUT / 'SOURCE_PUBLICATION_QUEUE.json', {'state': 'PENDING_GATE_AND_COMMIT', 'handoff_id': 'M3-R11-20261018-STATIC-01',
    'publisher': 'night1 root only', 'source_commit': None, 'paths': publication,
    'network_entry': ref(SOFT / 'night_drill_r01/network.py'), 'new_transport_used': False,
    'attempts': [], 'retry_rule': 'One evidence-based temporary retry maximum, unknown queries remote first, reject stops; no fault reset'})
print(json.dumps({'owned_files': len(owned), 'archive_payloads': len(payload), 'archive': ref(archive), 'publication_files': len(publication)}, ensure_ascii=False))
