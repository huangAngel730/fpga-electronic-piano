"""R11 archival metadata only. Never imports or executes candidate sources."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import zipfile

ROOT = Path.cwd()
BASE = Path('code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017')
DOC = BASE / 'morning_r11_20261018'
SOFT = Path('code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017')
ADR = BASE / 'night_drill_r01/morning_r11_20261018'
OUT = Path('code/output/m3_c9_chain_night_r10_20261017/MORNING_R11_20261018')


def read(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))


def save(path, value):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def ref(path):
    target = ROOT / path
    with target.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': target.relative_to(ROOT).as_posix(), 'bytes': target.stat().st_size, 'sha256': digest}


def verify(desc):
    actual = ref(desc['path'])
    assert all(actual[key] == desc[key] for key in ('bytes', 'sha256')), desc['path']
    return actual


now = datetime.now(timezone.utc).isoformat()
ready_paths = {'A': ADR / 'READY.json', 'B': DOC / 'mechanical/READY.json', 'C': DOC / 'finish/READY.json'}
ready = {key: read(path) for key, path in ready_paths.items()}
checked = []
for key, value in ready.items():
    if key == 'A':
        payloads = value['manifest']
    elif key == 'B':
        payloads = [value['manifest'], *value['files']]
    else:
        payloads = value['payload']
    checked.extend(verify(item) for item in payloads)
protected = [verify(item) for item in read(DOC / 'PROTECTED_BASELINE.json')['files']]
save(DOC / 'MEMBER_INTAKE_RECEIPT.json', {
    'schema': 'M3_R11_LOCAL_MEMBER_INTAKE_V1', 'UTC': now,
    'read_by': 'night1 root; shared-files fallback authorized by dispatch',
    'ready_refs': {k: ref(p) for k, p in ready_paths.items()},
    'verified_payloads': checked, 'protected_files_matched': protected,
    'receipt_scope': 'Local read and static integration only; no upstream M1/M2 acceptance',
    'A_message': 'Automatic approval rejected exact direct return; files read instead; no retry or bypass',
    'C_message_status_ref': ref(DOC / 'finish/COMMUNICATION_STATUS.json'),
    'candidate_execution': 0, 'new_budget': 0})

entry = ref(SOFT / 'capture_complete_r11/entry.py')
assert entry['sha256'] == '7f90353342048118aea1ef1e0ea9509dc022482db46fabec7f081d71d2de95e0'
save(DOC / 'COMPLETE_ORIGINALS_INTERFACE.json', {
    'schema': 'M3_R11_COMPLETE_ORIGINALS_INTERFACE_NOTE_V1', 'source': entry,
    'validation': 'L0_STATIC_ONLY_NOT_IMPORTED_NOT_COMPILED_NOT_RUN',
    'envelope': 'Existing N10_M3_UNIFIED_PIPELINE_REQUEST_V1 schema/mode/request; same PROCESS_CAPTURE/PREPARE_APPLICATION_ONLY',
    'request_inputs_new_required': ['stderr', 'source_manifest', 'rom_manifest', 'tool_manifest'],
    'receipt_ref': 'existing request.math_inputs.execution_receipt',
    'existing_receipt_schema': 'M3_R7D_DECLARED_EXECUTION_V1',
    'receipt_fields': ['schema', 'capture_id', 'argv', 'cwd', 'bindings', 'exit_code', 'timeout', 'cleanup_complete', 'consumption'],
    'bound_roles': ['source_manifest', 'rom_manifest', 'tool_manifest', 'driver', 'observer', 'input_plan', 'window_plan', 'raw_stdout', 'raw_stderr', 'raw_trace', 'reset_edges', 'finish_receipt'],
    'binding_values': 'Exact SHA per role, checked descriptor bytes; 12 roles and receipt require 13 distinct canonical casefold paths. Equal hashes permitted for distinct files.',
    'consumption': 'pid positive int, group_id nonempty string, started_utc/ended_utc timezone-aware and ordered; declaration only',
    'existing_closure_schema': 'M3_R7D_FILE_CLOSURE_V1',
    'closure_source_ROM_fields': ['schema', 'files'],
    'closure_tool_fields': ['schema', 'files', 'argv', 'cwd', 'version'],
    'closure_members': '1..4096 exact path/bytes/sha256 descriptors, no canonical duplicate; every byte checked',
    'application_cross_binding': 'Source includes existing base/application ZIPs and driver/observer/TB. ROM includes unchanged application ZIP containing original 9 ROM. Tool includes application-declared 3 PEs and listed DLLs; native outside-repository paths only when exact application-declared. No invented ZIP-member identity format.',
    'argv': 'Receipt equals tool closure, equals proposed existing vsim step; vlib/vlog not capture proof',
    'actual_native_C9_executor_mapping': 'PENDING_M2; existing R09 owned-step receipt is not automatically a complete C9 receipt',
    'tool_dynamic_closure': 'NOT_VERIFIED; listed PE/DLL bytes only',
    'outputs_proposed': ['R11_DECLARED_ORIGINALS.json', 'R11_HANDOFF.json'],
    'authority': {'execution_allowed': False, 'real_verified': False, 'math_verified': False, 'board_release_allowed': False},
    'new_validation_cases_proposed_NOT_RUN': ['missing stderr', 'missing receipt', 'capture_id/role digest mismatch', 'role path alias', 'closure empty/member mismatch/duplicate', 'application ZIP or capture-source omission', 'native PE/DLL mismatch', 'non-vsim argv or cwd mismatch', 'bad exit/timeout/cleanup', 'missing/invalid pid/group/time', 'inputs mutate during old pipeline', 'prepare remains limited', 'all authority flags remain false'],
    'new_validation_granted': 0,
    'request_status': 'Runner/fixture/output/budget must be frozen and admitted by M2 before any execution'})
save(DOC / 'ROOT_STATIC_REVIEW.json', {
    'schema': 'M3_R11_ROOT_ROUTE_STATIC_REVIEW_V1', 'UTC': now, 'final_source': entry,
    'reviewer': '/root/r11_route_selfaudit plus root', 'actual_level': 'L0_READ_ONLY',
    'first_review_source_sha256': '794c3bb24ff853016a9358ae07693aac9d4a61cf5293f8a3c54893e60146551c',
    'first_review_not_runtime_failure': True,
    'findings_and_resolution': [
        {'finding': '13 receipt/material roles could canonical-path alias', 'fix': 'casefold unique canonical paths, not digest dedup'},
        {'finding': 'File-closure outer identity did not check members or bind actual application', 'fix': 'exact existing closure schema/member identities and application archive/capture/ROM/native tool coverage'}],
    'final_conclusion': 'No new concrete blocker found within increment static reading; dynamic closure, actual launch cwd/native mapping and execution authenticity remain pending. This is not runtime PASS.',
    'candidate_import_compile_execute': 0,
    'history': 'First draft was unexecuted and replaced during implementation; exact old source bytes are not separately archived. Recorded old SHA/findings are review history, not a retained executable test result.'})
save(DOC / 'CAPACITY_AMENDMENT.json', {
    'schema': 'M3_R11_CAPACITY_STATIC_AMENDMENT_V1', 'format_note': ref(DOC / 'mechanical/CURRENT_FORMAT.md'),
    'existing_common': ref(SOFT / 'common.py'),
    'finding': 'Existing common.ref uses Path.read_bytes for hashing. Full route may read whole RAW files even though downstream stream.py iterates rows.',
    'consequence': 'Whole-pipeline peak RAM and full-window capacity NOT_VERIFIED. Streaming module ceilings are not verified pipeline/M1 capacity.',
    'actual_full_window_bytes': None, 'actual_full_window_rows': None,
    'no_source_modified_for_capacity': True, 'M1_consumer_capacity': 'PENDING',
    'resume': 'M1 selects one compatible consumer format/capacity; M2 freezes allowed exact processing and memory/output limits before whole-window invocation. No cropping or per-part independent row reindex.'})
save(DOC / 'PREPARATION_DIAGNOSTICS.json', {
    'schema': 'M3_R11_ROOT_METADATA_DIAGNOSTICS_V1',
    'records': [{'tool_chunk': '51b6a3', 'exit_code': 1, 'operation': 'Metadata exploration mistakenly decoded base source ZIP as JSON', 'error': 'UnicodeDecodeError byte 0xa5 position10', 'candidate_executed': False},
                {'tool_chunk': '559836', 'exit_code': 0, 'operation': 'Corrected metadata read through zipfile; ZIP MANIFEST.json/source identities inspected', 'candidate_executed': False}],
    'no_business_test_consumption': True, 'member_diagnostics_preserved': True})

request = read(DOC / 'FULL_ROUTE_ADMISSION_REQUEST.json')
request['previous_limited_entry'] = request['current_entry']
request['current_entry'] = entry
request['complete_originals_interface'] = ref(DOC / 'COMPLETE_ORIGINALS_INTERFACE.json')
request['static_successor'] = 'L0_ONLY_NOT_RUN; reuses old algorithms plus declared stderr/receipt/closure identity guard, never authenticates real execution'
request['capacity_amendment'] = ref(DOC / 'CAPACITY_AMENDMENT.json')
request['finish_proposal'] = ref(DOC / 'finish/EXECUTION_REQUEST.json')
request['software_validation_not_granted'] = {'drill': ref(ADR / 'VALIDATION_REQUEST.json'), 'complete_originals': ref(DOC / 'COMPLETE_ORIGINALS_INTERFACE.json')}
save(DOC / 'FULL_ROUTE_ADMISSION_REQUEST.json', request)
pending = read(DOC / 'PIPELINE_PENDING.json')
pending['previous_entry'] = pending['source_entry']
pending['source_entry'] = entry
pending['admission_request'] = ref(DOC / 'FULL_ROUTE_ADMISSION_REQUEST.json')
pending['source_level'] = 'L0_STATIC_ONLY_NOT_RUN'
pending['declared_identity_is_not_native_execution'] = True
save(DOC / 'PIPELINE_PENDING.json', pending)

previous = BASE / 'intake_20261018/INTEGRATION_HANDOFF.json'
handoff = copy.deepcopy(read(previous))
handoff['status'] = 'R11_STATIC_HANDOFF_UNIT_READY_OVERALL_PARTIAL_WAITING_INPUT'
handoff['successor_of'] = ref(previous)
handoff['previous_goal_lineage_correction'] = handoff.pop('goal_lineage_correction')
handoff['goal_lineage'] = {'threadId': '01a14050-cd98-7c41-8004-5d3e25765167', 'createdAt': 1792296002, 'actual_START': '2026-10-18T11:57:42+08:00', 'deadline': '2026-10-18T16:57:42+08:00', 'new_morning_window_authority': ref(DOC / 'R11_TASK_ORIGINAL.md'), 'old_night_expired_and_all_consumption_preserved': True}
handoff['software_continuation']['previous_limited_entry'] = handoff['software_continuation']['entry']
handoff['software_continuation']['entry'] = entry
handoff['software_continuation']['R11_validation'] = 'L0_STATIC_ONLY_NOT_RUN'
handoff['R11_components'] = {k: ref(p) for k, p in ready_paths.items()}
handoff['R11_complete_originals_interface'] = ref(DOC / 'COMPLETE_ORIGINALS_INTERFACE.json')
handoff['R11_admission_request'] = ref(DOC / 'FULL_ROUTE_ADMISSION_REQUEST.json')
handoff['R11_mechanical_format'] = ref(DOC / 'mechanical/MECHANICAL_INPUTS.json')
handoff['R11_capacity_amendment'] = ref(DOC / 'CAPACITY_AMENDMENT.json')
handoff['R11_finish_proposal'] = ref(DOC / 'finish/EXECUTION_REQUEST.json')
handoff['R11_local_intake'] = ref(DOC / 'MEMBER_INTAKE_RECEIPT.json')
handoff['R11_current_budget'] = request['new_budget_currently_available']
handoff['R11_delivery_state_at_freeze'] = 'LOCAL_PREPARED; source full commit and REMOTE_VERIFIED proof supplied separately in RESULT_RECEIPT to avoid self-reference'
handoff['R11_next_owners'] = read(DOC / 'UPSTREAM_PENDING.json')
handoff['R11_history_boundary'] = 'Old 14 canonical fields and source/history refs retained. Old synthetic/dispatch receipts are historical only; no R11 runtime pass. No actual RAW/FRAME/PCM created.'
save(DOC / 'INTEGRATION_HANDOFF.json', handoff)

summary = '''# M3 晨接 R11 当前交付

本交付完成 task-day1 卡当前允许的静态实现和准备单元，整体 Pro 仍 PARTIAL。

| 包 | 本次成果 | 当前验证 |
|---|---|---|
| A / 夜间任务2 | 安全 outbox 的实际 transport 后继、冻结 HANDOFF/结果 provenance 绑定 | L0 自审；新源码 NOT_RUN；历史 provenance 缺边拒收 |
| B / 夜间任务3 | 现有 bundle/74字段索引/稀疏历史、全局行序、大整数、可达原件和无损分卷说明 | 仅元数据核验；完整窗口未采集，容量未实测 |
| C / 夜间任务4 | D/D+1 调度合同、最小可逆提案、受影响断言及精确 M2 申请 | 未改 RTL/TB；1130660/1130661 原件保留 |
| D / 夜间总控 | 整链完整原件声明绑定后继、stderr/同次回执/闭包核对、唯一 INTEGRATION_HANDOFF | L0 自审；声明身份不等于真实执行；整链 NOT_RUN |

请以本目录 INTEGRATION_HANDOFF.json 为唯一当前交接入口。R11_TASK_ORIGINAL.md 为用户原始任务卡；START_RECEIPT.json 为实际11:57:42至16:57:42的晨间窗口。M2尚未发布的晨接总卡/R01/状态更新不冒称已经取得。旧 R10/演练源、失败与消费保留；本次没有恢复旧预算。

机械格式沿用 M3_D4_C9_MATH_INPUT_BUNDLE_V1，不新增数学格式。请 M1 一次决定兼容消费端版本/SHA/容量及独立事件因果映射/数学 profile。完整实际窗口 bytes/rows 为 null；模组上限不等于全链实测容量，额外限制见 CAPACITY_AMENDMENT.json。无损分卷恢复同一全局流后再处理，不按分卷重置行序。

请 M2 决定 finish 相位及精确可逆写集，冻结新候选的可信执行者、原生 C9 回执映射、动态工具闭包、argv/cwd/env、组数/秒数/内存/输出限制，以及 audio_stable/实际 DUT 背压合同。ModelSim版本认可、旧Icarus单元和旧120/60/60组不覆盖新运行。A的13项及D的拟验证项均未获新许可，runner/fixtures未冻结，NOT_RUN。

目前缺同次真实 raw/pins/reset_edges/END/stdout/stderr/exit/cleanup 原件、独立事件因果材料、M1实际数学输出和全部实物证据。缺件保持 PENDING，不能签 DIGITAL/REAL/MATH/上板通过。无已授权可执行业务时本单元封存交接，不无限等待。

各成员只读自审；未启用审核员/预审员制度。总控独占 Git 发布。ROOT_STATIC_REVIEW.json、MEMBER_INTAKE_RECEIPT.json 和各包 READY 保存实际边界；门禁、原始双流、完整提交及远端包含证明见后续 RESULT_RECEIPT。仓库门禁运行旧基线回归，不是新C9/Pro运行。

M2登记建议：限定接收本次静态后继与准备包，整体仍PARTIAL；共享状态/看板由M2更新。GitHub发布、AI接收、M2接受与真人通知分别记载。SOURCE_PAYLOAD.zip 为本次可达正文及依赖原件，不是实际capture包；SOURCE_MANIFEST.json记逐字节身份和已有来源入口。
'''
(ROOT / DOC / 'README.md').write_text(summary, encoding='utf-8', newline='\n')
print(json.dumps({'ready_components': list(ready), 'payloads_matched': len(checked), 'protected_matched': len(protected), 'entry': entry, 'handoff': ref(DOC / 'INTEGRATION_HANDOFF.json')}, ensure_ascii=False))
