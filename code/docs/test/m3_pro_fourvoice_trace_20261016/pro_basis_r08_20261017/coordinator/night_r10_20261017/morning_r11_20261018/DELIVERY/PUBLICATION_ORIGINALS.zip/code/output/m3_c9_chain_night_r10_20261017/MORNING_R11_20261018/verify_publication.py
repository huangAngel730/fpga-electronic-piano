"""Record read-only Git publication identity/ancestry checks, with raw streams."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / 'code/output/m3_c9_chain_night_r10_20261017/MORNING_R11_20261018'
DOC = ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/morning_r11_20261018'
GIT = 'C:/Program Files/Git/cmd/git.exe'
mode, name = sys.argv[1:3]
dest = OUT / name
dest.mkdir(exist_ok=False)
records = []


def query(argv, label):
    value = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=20, check=False)
    (dest / (label + '.stdout.bin')).write_bytes(value.stdout)
    (dest / (label + '.stderr.bin')).write_bytes(value.stderr)
    records.append({'argv': argv, 'cwd': str(ROOT), 'exit_code': value.returncode,
                    'stdout': str((dest / (label + '.stdout.bin')).relative_to(ROOT)),
                    'stderr': str((dest / (label + '.stderr.bin')).relative_to(ROOT))})
    return value


if mode == 'index':
    planned = json.loads((DOC / sys.argv[3] / 'PUBLICATION_FILES.json').read_text('utf-8'))['paths']
    actual = query([GIT, 'diff', '--cached', '--name-only', '-z'], 'cached_paths')
    assert actual.returncode == 0
    assert set(p.decode('utf-8') for p in actual.stdout.split(b'\0') if p) == set(planned)
    matches = []
    for idx, path in enumerate(planned):
        value = query([GIT, 'show', ':' + path], 'blob_' + str(idx).zfill(3))
        raw = (ROOT / path).read_bytes()
        assert value.returncode == 0 and value.stdout == raw, path
        matches.append({'path': path, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    result = {'status': 'MATCHED', 'exact_index_files': matches}
else:
    commits = sys.argv[3:]
    tip = query([GIT, 'rev-parse', 'origin/develop'], 'remote_tip')
    assert tip.returncode == 0
    for idx, commit in enumerate(commits):
        assert len(commit) == 40 and all(c in '0123456789abcdef' for c in commit)
        value = query([GIT, 'merge-base', '--is-ancestor', commit, 'origin/develop'], 'ancestor_' + str(idx))
        assert value.returncode == 0, commit
    result = {'status': 'REMOTE_CONTAINS', 'remote_tip': tip.stdout.decode().strip(), 'commits': commits}
result.update(UTC=datetime.now(timezone.utc).isoformat(), commands=records, timeout_per_read_command_s=20)
(dest / 'RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('commands', 'exact_index_files')}))
