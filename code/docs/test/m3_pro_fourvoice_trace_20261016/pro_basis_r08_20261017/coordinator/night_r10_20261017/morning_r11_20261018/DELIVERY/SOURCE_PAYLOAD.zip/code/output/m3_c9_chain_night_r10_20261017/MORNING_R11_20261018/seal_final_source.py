"""Final archival revision after exact-index evidence, stdlib metadata only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

R = Path.cwd()
B = R / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
D = B / 'morning_r11_20261018'
A = B / 'night_drill_r01/morning_r11_20261018'
S = R / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
O = R / 'code/output/m3_c9_chain_night_r10_20261017/MORNING_R11_20261018'


def load(p):
    return json.loads(p.read_text('utf-8'))


def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def ref(p):
    p = (R / p).resolve()
    with p.open('rb') as f:
        digest = hashlib.file_digest(f, 'sha256').hexdigest()
    return {'path': p.relative_to(R).as_posix(), 'bytes': p.stat().st_size, 'sha256': digest}


ready = load(A / 'READY.json')
for item in ready['manifest']:
    assert ref(Path(item['path'])) == item, item['path']
assert b'\r\n' not in (A / 'LEGACY_NETWORK_BASELINE.json').read_bytes()
assert '75e9ed9eb1421e3ea7b1cf924213bdd08b143b1538d9b84c45f9d931a4e189c7' != hashlib.sha256((A / 'LEGACY_NETWORK_BASELINE.json').read_bytes()).hexdigest()
# Preserve the prior archive and manifest as failed-to-publish archival history.
for src, dst in [(D / 'DELIVERY/SOURCE_PAYLOAD.zip', O / 'INDEX_REVISION_PRIOR_ARCHIVE.zip'), (D / 'SOURCE_MANIFEST.json', O / 'INDEX_REVISION_PRIOR_MANIFEST.json')]:
    assert src.is_relative_to(D) and dst.is_relative_to(O) and not dst.exists()
    src.rename(dst)
v = load(D / 'MEMBER_INTAKE_RECEIPT.json')
v['ready_refs']['A'] = ref(A / 'READY.json')
v['verified_payloads'] = [x for x in v['verified_payloads'] if '/night_drill_r01/morning_r11_20261018/' not in x['path']] + ready['manifest']
v['A_index_revision'] = 'Original CRLF bytes retained in ZIP; logically identical LF JSON baseline and updated transport constant/refs'
save(D / 'MEMBER_INTAKE_RECEIPT.json', v)
v = load(D / 'A_ROOT_STATIC_REVIEW.json')
v['initial_sources_before_storage_revision'] = v['source']
v['source'] = [ref(S / 'night_drill_r01/morning_r11_20261018' / name) for name in ('binding.py', 'transport.py')]
v['storage_revision_review'] = 'Root compares source diff: only pinned legacy LF baseline identity and explanatory comment changed; JSON semantics match raw archive. Candidate remains NOT_RUN.'
save(D / 'A_ROOT_STATIC_REVIEW.json', v)
v = load(D / 'INTEGRATION_HANDOFF.json')
v['R11_components']['A'] = ref(A / 'READY.json')
v['R11_local_intake'] = ref(D / 'MEMBER_INTAKE_RECEIPT.json')
save(D / 'INTEGRATION_HANDOFF.json', v)
save(D / 'INDEX_STORAGE_REVISION.json', {
    'UTC': datetime.now(timezone.utc).isoformat(), 'first_check_tool_chunk': '14036a', 'exit_code': 1,
    'finding': 'Only LEGACY_NETWORK_BASELINE.raw index bytes differed: working36202B/1295CRLF versus index34907B/LF. No publish was attempted.',
    'old_gate': 'publication_source/GATE_R01:9/9 exit0,142.75s,working bytes unchanged; not final index attestation',
    'resolution': 'M3 member A keeps raw JSON byte-for-byte in ZIP, publishes LF JSON logical copy; all descriptors and transport constant refreshed. No gitattributes change. Final index comparison and final source gate required.',
    'new_candidate_runtime': 'NOT_RUN', 'old_network_and_consumption': 'UNCHANGED'})

exclude = {'DELIVERY', 'publication_source', 'publication_source_final', 'publication_receipt'}
owned = {p for base in (D, A, S / 'capture_complete_r11', S / 'night_drill_r01/morning_r11_20261018') for p in base.rglob('*') if p.is_file() and (not p.is_relative_to(D) or not any(x in exclude for x in p.relative_to(D).parts))}
owned.discard(D / 'SOURCE_MANIFEST.json')
owned.discard(A / 'LEGACY_NETWORK_BASELINE.raw')
owned.discard(A / 'READY_BEFORE_MESSAGE.raw')
previous_manifest = load(O / 'INDEX_REVISION_PRIOR_MANIFEST.json')
dependencies = {(R / x['path']).resolve() for x in previous_manifest['files'] if not any((R / x['path']).resolve().is_relative_to(d) for d in (D, A, S / 'capture_complete_r11', S / 'night_drill_r01/morning_r11_20261018'))}
dependencies.update([O / 'seal_final_source.py', O / 'verify_publication.py', O / 'INDEX_REVISION_PRIOR_ARCHIVE.zip', O / 'INDEX_REVISION_PRIOR_MANIFEST.json'])
paths = sorted(owned | dependencies)
payload = [ref(p) for p in paths]
body = {'schema': 'M3_R11_ARCHIVE_PAYLOAD_MANIFEST_V1', 'level': 'STATIC_ONLY', 'files': payload,
        'note': 'Final LF/index storage revision; original prior archive preserved; no actual capture'}
archive = D / 'DELIVERY/SOURCE_PAYLOAD.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in paths:
        z.write(p, p.relative_to(R).as_posix())
    z.writestr('ORIGINALS_MANIFEST.json', json.dumps(body, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(paths) + 1
    for item in payload:
        raw = z.read(item['path'])
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
save(D / 'SOURCE_MANIFEST.json', {**body, 'archive': ref(archive), 'CRC': 'ALL_MEMBERS_MATCHED', 'new_candidate_runs': 0})
gate = D / 'publication_source_final'
gate.mkdir(exist_ok=False)
publication = sorted(p.relative_to(R).as_posix() for p in owned | {archive, D / 'SOURCE_MANIFEST.json', gate / 'PUBLICATION_FILES.json'})
save(gate / 'PUBLICATION_FILES.json', {'paths': publication, 'scope': 'Final R11 source/preparation only; exact index and archive bodies must match'})
save(O / 'SOURCE_PUBLICATION_QUEUE_FINAL.json', {'state': 'PENDING_FINAL_GATE_AND_COMMIT', 'paths': publication, 'source_commit': None, 'attempts': [], 'publisher': 'night1 root only', 'new_transport_used': False})
print(json.dumps({'owned': len(owned), 'payloads': len(paths), 'archive': ref(archive), 'publication_files': len(publication)}))
