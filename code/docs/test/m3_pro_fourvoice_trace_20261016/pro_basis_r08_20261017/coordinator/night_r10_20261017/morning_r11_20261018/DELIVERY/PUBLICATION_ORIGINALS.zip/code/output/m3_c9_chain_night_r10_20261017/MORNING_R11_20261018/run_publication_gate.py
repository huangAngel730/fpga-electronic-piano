"""Reuse the pinned established repository gate; no R11 business imports."""
from pathlib import Path
import hashlib
import json
import sys
import types

ROOT = Path.cwd()
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/coordinator_20261017/run_gate.py'
OLD_SHA = '3fcd3a5f036e4aa9bd4f3d2ccd15e6bcfd327154d1522552528894c584a61543'
HOST_SHELL = b'C:/Users/songdongkuan/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
old = SOURCE.read_bytes()
assert hashlib.sha256(old).hexdigest() == OLD_SHA
old_shell = b'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
assert old.count(old_shell) == 1
derived = old.replace(old_shell, HOST_SHELL)
doc = ROOT / sys.argv[1]
assert doc.is_relative_to(ROOT / 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/morning_r11_20261018')
assert not (doc / 'GATE_R01').exists()
metadata = {'schema': 'M3_R11_PUBLICATION_GATE_DERIVATION_V1', 'source': str(SOURCE), 'source_sha256': OLD_SHA,
            'only_source_change': 'Existing proven host PowerShell7 path replacement, same established check_repo wrapper/job/900s gate',
            'derived_sha256': hashlib.sha256(derived).hexdigest(), 'DOC_redirect': str(doc),
            'business_candidates_imported_or_executed': False}
(doc / 'GATE_DERIVATION.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8', newline='\n')
(doc / 'GATE_DERIVED.raw').write_bytes(derived)
module = types.ModuleType('_r11_existing_publication_gate')
module.__file__ = str(SOURCE)
exec(compile(derived, str(SOURCE), 'exec', dont_inherit=True), module.__dict__)
module.DOC = doc
raise SystemExit(module.main())
