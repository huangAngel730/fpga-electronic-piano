from pathlib import Path
import hashlib,types
ROOT=Path.cwd()
LEGACY=ROOT/"code/software/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/coordinator_20261017/run_gate.py"
raw=LEGACY.read_bytes()
if hashlib.sha256(raw).hexdigest()!="3fcd3a5f036e4aa9bd4f3d2ccd15e6bcfd327154d1522552528894c584a61543":raise RuntimeError("GATE_SOURCE_CHANGED")
old=b"C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"
new=b"C:/Users/songdongkuan/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe"
if raw.count(old)!=1:raise RuntimeError("GATE_DERIVATION_NOT_UNIQUE")
derived=raw.replace(old,new)
module=types.ModuleType("_oct18_existing_gate")
module.__file__=str(LEGACY)
exec(compile(derived,str(LEGACY),"exec"),module.__dict__)
module.DOC=ROOT/"code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/intake_20261018/PUBLICATION_GATE"
(module.DOC/"DERIVED_GATE_SOURCE.py").write_bytes(derived)
raise SystemExit(module.main())
