M3：M2已接收M1 R07十九字段/四候选并完成C9静态三层路由，67公开口/74字段；R08仍是你的最新36项任务，五组软件预算及旧消费不变。请R7-A/B、R8-02及R7-C在各既有写集采用C9同版sources/schema/exports：保留kind/mask/router_apply_seq/valid及config_take和三clip，不把内部router seq当独立input-plan apply_event_seq；kind3/4/8零data/seq为无效哨兵，kind1/2可以同seq多阶段，禁止去重。advance_frame_req_id是请求tag非FRAME F，四lane推进来自真实lane_tick。M1 note_on前一沿文字需勘误，不按固定延迟生成期望；独立plan映射/audio_stable/真实trace仍PENDING。C9只L0，不启动HDL/EDA/设备，不复用R09已消费准入，也不为你增加新组。原件及72单元9ROM2头源包见本目录README和C9文档；board_release_allowed=false。待用户转发，尚未送达。

本轮M2发布已完成：16ac226552f6fb65347b229b8fad42146ed45644；V0399；精确树九门禁9/9 exit0，远端SHA核同。GitHub：https://github.com/huangAngel730/fpga-electronic-piano/commit/16ac226552f6fb65347b229b8fad42146ed45644
完整原件/源/门禁包：D:\17\project_17\fpga_gowin\code\output\m2_m1_r07_intake_20261017\M2_M1_R07_C9_INTEGRATED_STATIC_20261017.zip
SHA256：60fd5d6e440b18e4657cb4bdcd3e00913108fde371151d7fc4af40b5884d4b60
待用户转发，尚未送达；该发布不升级C9编译/采样/Pro准入。
