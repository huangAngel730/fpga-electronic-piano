# 自有 worker 中断恢复（静态 READY，NOT_RUN）

仅夜间1总控调用 `run_recovery.py:run(out: Path, context: dict) -> dict`，本成员没有导入、编译或执行候选。两个软件文件均无导入期文件读写或进程启动；只有显式调用run/worker CLI才产生动作。

context限256KiB，应只传下列最小字段，不要传含全量dirty快照的整个RUN_CONTRACT；状态JSON读取限1MiB，文件SHA逐块计算。

context最小字段：

```json
{
  "original_START": "2026-10-17T21:52:00+08:00",
  "deadline": "2026-10-18T02:52:00+08:00",
  "goal": {"threadId": "01a14050-cd98-7c41-8004-5d3e25765167", "createdAt": 1792253457, "status": "active"},
  "consumption": {"...": "总控在调用前已落盘的完整本次消费快照，不能用此示例字符串代替"}
}
```

由总控先在自己的唯一消费台账落盘1次worker组消费，再将实际快照放入consumption。可在context.handoff传入handoff_id/result_commit；省略时用本轮固定样本NIGHT-RULES-GOAL-20261017-01/30a8cd5474e6ff485ce0bf8fd5f3c1d51643123a/consumer=M3。不会重建Goal、重置START或写真实消费文件。out必须是 `code/output/m3_m2_night_drill_20261017/` 下不存在的新独占子目录，不能指向整个根或其他模块。

内部总时限55秒，预留清理；**总控仍须以本组60秒硬上限约束整个调用**。准备checkpoint最多15秒；准备worker等待持有者中断最多20秒；resume等待最多15秒，所有wait还受同一剩余时限约束。源码/解释器及父进程已加载标准库文件与现存缓存SHA、真实argv/cwd/最小env、seed在Popen前落盘，两次Popen前检查至少剩5秒。worker使用同一解释器及-I -S -B -X utf8，屏蔽site/PYTHONPATH启动行为。只启动同目录的纯Python worker，无shell/网络/Git/业务工具。依赖表只称父进程已加载标准库文件/缓存快照，不能称worker完整闭包；worker惰性导入与动态系统DLL闭包仍PENDING。-B不阻止读取已有pyc，因此现存__cached__也纳入快照。

prepare原子发布fsync后的CHECKPOINT指针，绑定PID/token/源SHA和generation_0001里的IDENTITY/DEDUP/OUTBOX/CONSUMPTION。runner核checkpoint owner_pid等于实际持有Popen句柄的PID后，terminate并wait；只对仍活跃的这些持有句柄kill，不按任意PID、进程名或进程树操作。恢复worker核每个持久文件哈希、原START/Goal和消费快照；同key重复发现保持receipt_count=advance_count=1，outbox保留精确目标/attempts=1/原LOCAL_SYNTHETIC_UNKNOWN_RESPONSE。resume不重写业务状态，前后state字节必须完全相同。

精确预期：成功返回status=PASS_LOCAL_SYNTHETIC，两个实际worker PID分别与checkpoint/恢复报告对应，prepare被持有者中断，resume exit0，dedup_receipts=1/task_advances=1/outbox_attempts=1/consumption_not_reset=true/same_state_bytes_before_after=true。FIRST_FAILURE保留首异常，部分原件不删；finally保留所有已启动worker最终退出码、双流SHA和清理是否确认。

输出含CONTEXT/SEED、两次*_BEFORE_START与*_PID、原始stdout/stderr、prepare_EXIT/resume_EXIT、state持久原件、BEFORE_INTERRUPTION/AFTER_RECOVERY、RESUME_REPORT、RESULT及FINAL_PROCESS_RECEIPTS。启动前拒收由总控外层双流记录，不冒称已执行恢复。所有状态位于本独占输出，不触碰夜间2真实state/outbox或任何旧消费。

总控恢复后立即用唯一network.py补查真实远端并保存遗漏窗口/队列重算；本包仅明确返回该必做项，不调用它。没有真实App/机器重启、双机断线恢复或真实发送失败，因此这些均PENDING/false；本机合成通过不能升级双机演练4/4。

R10_READINESS.json另列只读差额：task_day4旧75+新39=114匹配、累计组119.343秒；旧额度不恢复。最新R10未发现“一个多小时连续测试”许可，阶段建议工时和发布门禁不能代作业务运行许可。原START文本旧6小时/03:52只保留历史，按最新5小时及当前RUN_CONTRACT截止02:52。

本包未Git写入/网络/自测，由夜间1唯一冻结、消费、执行、封存、发布；审核员制度未启用。
