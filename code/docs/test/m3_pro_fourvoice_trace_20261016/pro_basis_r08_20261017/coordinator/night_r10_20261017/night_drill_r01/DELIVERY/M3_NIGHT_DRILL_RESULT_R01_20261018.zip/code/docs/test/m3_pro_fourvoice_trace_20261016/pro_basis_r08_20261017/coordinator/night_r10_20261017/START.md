# M3 R10 实际启动与独占分工

START：2026-10-17 21:52北京时间；最长6小时，截止2026-10-18 03:52，必要结果达到即提前结束。已发布R10明确覆盖当夜下一动作和时间盒，旧R08 18:55–22:55记录保留，不把旧时间盒自行延长。HEAD/origin为21c040199ff7fdf4eb889c3457169ec45fc3d6f3；最新总单、M3岗位单和DELIVERY_CONTRACT已读。当前按无实物；用户/真人成员可回复性未知，不据沉默扩权。

开工前状态：R08/C9本地432文件已暂存，未commit/push/运行九门禁。旧R08十卷和新C9补包已封且逐件核SHA/CRC；所有旧源码/已暂存文件冻结，不覆盖、不重建其测试结论。M2本次新增26文件与M3写集不重叠，已快进。C9 74字段/67口、72单元9ROM2头；M1 NEXT_INPUT_CONTRACT已读，仍不替M1造黄金。

旧消费：R/S/C/T/H五个初组均已消费，S/T唯一修复已消费；R/C/H未发生首组缺陷，没有理由使用其条件修复。T27、旧R7-C6和C9新增42例均NOT_RUN，不借R10换名重跑。唯一新增N10-M3-LINK：初组120秒，首个具体缺陷最多一次60秒定向增量；仅本夜新增跨组件接缝断言。统一总控冻结/执行/记账，成员不导入、编译或运行候选。子进程/HDL/EDA/设备新增0，M2 R09许可不转移。

## 独占写者与交付

新根仅 software和docs/test的 m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/；输出为code/output/m3_c9_chain_night_r10_20261017/。

- 夜间2：新根/admission/，source/include/ROM/TB/driver/tool身份与安全计划/独占消费接缝，机器可读精确HDL执行申请。旧R6-4与C9 A/R8-02只读复用。
- 夜间4：新根/pipeline/，唯一C9 A codec→R6-5 FRAME_PLAN→C9机械bridge→M1 MATH_INPUT_BUNDLE接缝，原始来源完整保留，不造DSP黄金。
- 夜间3：新根/serial/，接同一PUBLIC_ROWS/FRAME_PLAN的TX/startup/HOLD/ID/clip与固定PinDecoder核验接缝；无第二FRAME生产者。
- 夜间5：仅docs新根/dependency_audit/，只读合同/接缝缺口和最终增量，不执行、不写实现。
- 总控：新根根目录/common.py、chain.py、统一CASE/冻结/消费/同进程有界runner、整链fixture及最终INTEGRATION_HANDOFF/封包/串行Git。至多三实现写者，不启用审核员制度。

成员只写新增子目录，旧R06/R07/R08及c9_binding已封原字节不得改；需要修既有缺陷先保留原件并向总控列最小差额，不自行更新旧封包。可用自己的只读子智能体自审；通信只在READY、具体阻断或必要接口变更时一次汇总。平台拒绝回传时本地READY供总控读取，禁止反复重试或绕过。

## 统一软件接口

各stage模块提供 run_stage(request:dict, output_dir:Path)->dict，无导入副作用；output_dir由stage以exist_ok=False创建。request.schema=N10_M3_CHAIN_REQUEST_V1；capture_id、origin、refs（name→path/bytes/sha256）、parameters（子键admission/pipeline/serial）、upstream（总控按顺序放入前stage实际结果）。origin只接受SYNTHETIC_SCHEMA_FIXTURE或HDL_PUBLIC_CAPTURE_UNVERIFIED，不自行签REAL。

顺序 admission→pipeline→serial→总控同源来源图/INTEGRATION_HANDOFF。pipeline产物约定：report.artifacts.public_rows/frame_plan/math_input_bundle/mechanical_index为path/bytes/sha256，report.capture_id与request相同；缺真实产物显式PENDING，不造空文件替代。serial只读这些实际产物，不能另造frame calendar或用预期填实际。每stage返回status、capture_id、artifacts、pending、real_verified=false、board_release_allowed=false。最终链CLI需要真实输入才能产生真实候选产物，静态执行申请不依赖尚未运行的真实trace。

每写者新增selftest.py run_case(id,out)->dict和CASES.json（schema=N10_M3_LINK_CASES_V1，group=N10-M3-LINK，id/expected/description），约4–6个本夜独有接缝用例，禁止调用旧selftest。保留实际输入/输出，失败抛断言且输出原件不删。总控汇成唯一≤120秒组，各成员只静态准备。共享common.py仅总控写；新入口固定SHA从源码字节加载依赖，不使用旧pyc。读JSON/哈希/封包可做，不执行候选。

阶段目标：约22:35先收到各stage接口及第一份整链申请，23:15前软件READY候选，余时集成/必要定向修复/封存。不是最低工时。超写集/缺准入立即停该依赖，不重复已签组、不启动双音色/E/N32。最终一份INTEGRATION_HANDOFF和本体包，M2最终复核/状态登记仍待用户转发、尚未送达。
