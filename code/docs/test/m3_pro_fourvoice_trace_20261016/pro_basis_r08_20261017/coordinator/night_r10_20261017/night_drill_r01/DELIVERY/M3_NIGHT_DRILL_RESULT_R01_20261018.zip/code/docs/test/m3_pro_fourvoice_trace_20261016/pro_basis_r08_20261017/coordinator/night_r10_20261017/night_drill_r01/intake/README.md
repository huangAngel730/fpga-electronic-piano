# 双机演练：持久收件和待发队列

本包由夜间2静态准备，状态 PREPARED_NOT_RUN。只写本项 software/docs 的 intake 新目录；无 Git 写入、网络、候选导入/编译/AST、自检运行、worker、HDL/EDA/设备。夜间1是唯一执行者和发布者，统一冻结后使用本项新的一组≤120秒额度。沿用原 START 2026-10-17 21:52、截止2026-10-18 02:52，不新建 Goal 或发布者。

`engine.py` 和 `selftest.py` 只依赖标准库，不依赖 coordinator common。导入不创建文件、加载候选或启动进程。`selftest.run_case(case_id, out:Path)->dict` 要求 out 不存在，自行 mkdir(exist_ok=False)；读取本包 CASES/BINDING 后仅在被总控调用时从固定SHA源码字节加载 engine，不用旧pyc。十例全部标 LOCAL_SYNTHETIC，包括“中断”例也只是未完成发送检查点的文件级重载，不能据此签真实 worker/App/机器中断通过。

## 调用接口

```python
store = engine.Store(output_root / "state" / "intake", consumer="M3", owner="night_task_1")
received = store.receive(handoff, snapshot_root,
                         task_id=expected_task_id,
                         plan_version=expected_plan_version,
                         origin="LOCAL_REPOSITORY_SNAPSHOT")
# 此时 STATE.json 已持久化 RECEIVED，advance_count 仍为0。
store.advance(received["key"])
state = store.snapshot()
```

任务派发收据与八规范样本分别使用其实际 task_id/plan_version，不能把样本的版本字符串硬套 R01。snapshot_root 应由总控提供所核 result_commit 的精确字节快照；本引擎核实际 manifest 本体，但不会查询 Git 或证明该目录来自指定提交。总控须另保留 fetch/ancestry 原件。receipt 的 result_commit 是所收上游身份，不是包含本地 receipt 的提交。

去重键是 canonical JSON `[handoff_id,完整40hex result_commit,consumer]` 的 SHA256；完整三元组同时存在回执中，不按短SHA去重。要求 schema NIGHT_HANDOFF_V1、精确任务/版本/M3消费方、非空 manifest、文件尺寸/SHA/路径边界。相对路径拒绝逃逸、绝对/UNC/设备名、反斜线/驱动器、别名、Windows尾点空格、大小写重复和敏感元目录。每文件≤64MiB、总声明≤256MiB、最多4096项，实际哈希分块读取。总控提供的只读原件不会被物化或改写。

`receive` 完成所有本体检查后先原子落 RECEIVED；`advance(key)` 必须已有该记录，第二次为 ALREADY_ADVANCED。advance 只持久标记一次队列接入，不执行下游任务、不创建 Goal、不消耗业务测试额度。重载重复收据返回 DUPLICATE，保留第一次回执和推进数，不重新接入。相同三元组但完整 handoff 内容改变，拒 HANDOFF_KEY_COLLISION。

## 单写者和恢复

唯一权威状态是传入 Store 根的 `STATE.json`，同一原子 JSON 中包含 receipts、advance_count、outbox 与 revision，避免多个独立文件半提交。writer.lock 用 O_EXCL，内容为本次随机 token/PID/owner；正常退出只移除字节仍属本人的锁。STATE 同目录唯一临时文件经 flush/fsync 再 os.replace；失败临时文件保留，恢复不擅自重放。进程崩溃后遗留锁不自动抢占；总控必须先核本任务自有 worker 身份、其已退出且锁属于它，再按授权清理锁并读取状态。此文件锁只针对同一主机/同一目录，不证明两台机器的全局互斥；断电/App/机器重启耐久性仍待真实演练。

Store 根必须位于 `code/output/m3_m2_night_drill_20261017/`。总控可将 snapshot 中 outbox 部分另外封存到该任务 `outbox/`；该副本不是第二份可写账本。不要让 intake Store 与总控 network.json、CONSUMPTION 或 worker 状态争写同一文件。

## outbox

```python
item = store.enqueue(outgoing_handoff, task_id=task_id, plan_version=plan_version)
store.begin_attempt(item["key"])  # 必须先保存尝试数，再由外部适配器发送
store.finish_attempt(item["key"], outcome="FAILED_TEMPORARY", error=exact_error,
                     argv=actual_argv, exit_code=actual_exit, elapsed_seconds=elapsed,
                     origin="ACTUAL_ADAPTER_REPORTED")
```

outgoing_handoff 必须引用已形成的完整成果提交和精确 manifest，目标固定 origin/develop；其 consumer 可为 M2，与本岗 M3 收件记录分开。outbox 保存完整 handoff、目标、绑定SHA、原错误/argv/退出/实际耗时/次序；排队不核远端或执行 Git。总控网络适配器负责真正≤30秒进程上限及双流原件，引擎只保存实得时间，超过30秒也保留预算超限标记，不丢失失败证据。

FAILED_TEMPORARY 最多初次+一次重试，重载不清零；DENIED/REJECTED/NON_FAST_FORWARD 都停在相应边界，不能当作临时故障盲重试。UNKNOWN 拒绝重发；`recover_in_flight()` 把中断前的 IN_FLIGHT 变成 UNKNOWN，已占尝试数不退还。SUCCESS_REPORTED 仍 AWAITING_REMOTE_VERIFICATION。所有路径 remote_verified=false，没有字符串自签 REMOTE_VERIFIED 的入口。未知/成功后的真实远端包含查询和后续准入由总控独立记录，本引擎不提供自动解锁重发。outbox 的角色是保全，不替代已获授权的唯一 Git 发布者。

## 验收与当前缺项

CASES.json 的十个案例覆盖首次收件/推进、重载重复、四个 manifest 坏输入、四个合同坏输入、精确待发身份及持久一次重试、未知、拒绝、文件级中断恢复、单写者互斥及收件后未推进的恢复间隙。总控应逐例保存完整 INPUT/ACTUAL/RESULT 或 FAILURE。各例不运行旧组或真实网络。

当前只做静态文本/JSON/文件身份检查，不称软件通过。必需后续：总控冻结并运行唯一有界合组；真实样本精确提交快照及远端包含证明；真实两机收件/发送确认、真实 worker 中断/遗漏区间、实际半小时触发及恢复入口；M2 最终限定复核。完整双机演练、业务链和板测均未由本包签通过。
