"""Root-only R12 evidence integration; no edits after final gate."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

R = Path.cwd().resolve()
O = R / "code/output/m3_frontend_close_r12_20261018"
Q = O / "RECOVERY_R02_20261018"
OLD = O / "RESUME_R01_20261018"
N = "m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018"
S, D = R / "code/software" / N, R / "code/docs/test" / N


def read(p):
    return json.loads(p.read_text("utf-8"))


def save(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def stamp(p):
    sha, size = hashlib.sha256(), 0
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            size += len(block)
            sha.update(block)
    return {"path": p.relative_to(R).as_posix(), "bytes": size, "sha256": sha.hexdigest()}


parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=("software", "candidate", "pre-s2"))
args = parser.parse_args()
ledger = read(Q / "CONSUMPTION.json")
if args.phase == "software":
    assert ledger["slots"]["CAPTURE_EVIDENCE_DELTA"]["state"] == "PASS"
    delta_path = Q / "RUNS/CD/worker/GROUP_RESULT.json"
    delta = read(delta_path)
    assert delta["status"] == "PASS" and len(delta["cases"]) == 2
    assert all(c["status"] == "PASS" for c in delta["cases"])
    for ref in read(D / "SOURCE_MANIFEST.json")["files"]:
        assert stamp(R / ref["path"]) == ref
    matrix = read(D / "CASE_MATRIX.json")
    assert len(matrix["cases"]) == 40
    for case in delta["cases"]:
        matrix["cases"].append({"id": "R02_" + case["case"], "passed": True,
             "result": case, "group_original": stamp(delta_path),
             "parent_owned_Job0": ledger["slots"]["CAPTURE_EVIDENCE_DELTA"]["actual_result"]})
    matrix["pass_scope"] = "Original40 frozen-harness assertion cases reused plus2 actual R02 evidence delta cases; L1software only"
    matrix["R01_evidence_limits_resolved_by_R02_delta"] = True
    save(D / "CASE_MATRIX.json", matrix)
    for name in ("RESULT_RECEIPT.json", "INTEGRATION_HANDOFF.json"):
        obj = read(D / name)
        obj.update(status="SOFTWARE_FRONTEND_READY_FOR_M2_REVIEW_PENDING_GATES_PUBLICATION",
             verified_level="L1_SOFTWARE_ONLY", whole_R12_complete=False,
             three_findings_runtime_closed=True, three_findings_frozen_harness_passed=True,
             evidence_limitations=[], previous_R01_limitations_preserved_in_before_snapshot=True,
             R02_delta=stamp(delta_path), R02_authorization=stamp(Q / "EXECUTION_PLAN.json"),
             R02_parent_owned_result=ledger["slots"]["CAPTURE_EVIDENCE_DELTA"]["actual_result"],
             software_assertions=42, original40_reused_without_rerun=True,
             C02_ordered_dynamic_key_function_trace_persisted=True,
             C12_active_text_exception_no_drain_proved=True,
             runtime_closed_scope="Frozen R12 front-end only; original synthetic C and private D4 W plus2 actual private diagnostic probes",
             gates_complete=False, published=False, M2_ACCEPTED=False, INTEGRATED=False,
             real_verified=False, math_verified=False, board_release_allowed=False,
             source_final_gate_and_publication_actuals={"future_path": str(Q / "FINAL_HANDOFF_R02.zip"), "exists_at_freeze": False},
             S2_actuals={"future_path": str(Q / "FINAL_HANDOFF_R02.zip"), "exists_at_freeze": False},
             next_action="Root completes newly admitted candidate, S1, original final gate and publication; M2 increment-only final review")
        save(D / name, obj)
    ack = read(D / "ACK_M2_REVIEW.json")
    ack["R02_user_resumed_authority"] = stamp(Q / "EXECUTION_PLAN.json")
    ack["old_actual_time_and_SHA_fields_are_historical_preserved"] = True
    save(D / "ACK_M2_REVIEW.json", ack)
    failure = read(D / "FAILURE_HISTORY.json")
    failure["R01_preserved_tree"] = stamp(Q / "BEFORE_TREE.json")
    failure["R02_preparation_failure_and_located_fix"] = stamp(Q / "INIT_ATTEMPT_01.json")
    failure["R01_candidate_gate_failed_consumed_not_refunded"] = stamp(OLD / "RUNS/GATE_01/RESULT.json")
    save(D / "FAILURE_HISTORY.json", failure)
    save(D / "GATE_01.json", {"id": "NEW_GATE_ENV_R02", "state": "PENDING_NEW_USER_RESUMED_CANDIDATE",
         "old_failed_Gate01": stamp(OLD / "RUNS/GATE_01/RESULT.json"),
         "old_slot_not_reused": True, "current_actual_future_path": str(Q / "RUNS/GATE_ENV_R02/RESULT.json")})
    save(D / "GATE_02.json", {"id": "ORIGINAL_UNCONSUMED_GATE_02", "state": "PENDING_FINAL_TREE_AFTER_S1_R02",
         "pass": False, "exit_code": None, "future_actual": str(Q / "RUNS/GATE_02/RESULT.json"),
         "retry_of_failed_candidate_forbidden": True})
    save(D / "PUBLICATION_RECEIPT.json", {"state": "PENDING_TWO_GATES", "result_commit": None,
         "receipt_commit": None, "remote_containment": False, "actual_output": str(Q / "PUBLICATION_ACTUAL.json"),
         "tracked_bytes_immutable_after_final_gate": True})
    allow = read(D / "PUBLISH_ALLOWLIST.json")
    allow["publication_state"] = "PENDING_R02_CANDIDATE_AND_FINAL_GATES"
    save(D / "PUBLISH_ALLOWLIST.json", allow)
    outbox = read(D / "OUTBOX_REFERENCE.json")
    outbox["R02_receipt_only_no_competing_queue"] = str(Q / "PUBLICATION_ACTUAL.json")
    outbox["publication_state"] = "PENDING_R02_GATES"
    outbox["S2"] = {"future_path": str(Q / "FINAL_HANDOFF_R02.zip"), "exists_at_freeze": False}
    save(D / "OUTBOX_REFERENCE.json", outbox)
    (D / "GIT_WRITE_RECEIPTS.jsonl").write_text(json.dumps({"state": "PENDING_R02_GATES_GIT_NOT_STARTED",
          "future_path": str(Q / "GIT_WRITE_RECEIPTS.jsonl"), "actual_receipt_exists": False}) + "\n", encoding="utf-8", newline="\n")
    paragraph = ("\nR02最新用户已明确允许继续并解除20:09截止；实际恢复计划及全部新/旧消费见封存原件中的EXECUTION_PLAN和CONSUMPTION。"
        "生产9文件保持原已测SHA，原40项不重跑。新增120秒一次组的两项证据补测通过：持久化实际关键函数有序嵌套调用轨迹，"
        "并在已成功读1字节的私有verified文本读取路径第二次物理读取注入同一OSError，异常传播、无关闭排空/追加读取及所有reader/context关闭均有实际证据。"
        "历史R01两项未验描述保留为当时快照，本轮由增量闭合。新候选门禁及剩余最终门禁仍分别一次，不互作重试；"
        "最终门禁后受跟踪字节不再修改，最终结果/提交SHA/包含性只在ignored输出S2实际包。真实capture/数学/RTL/时序/板卡仍未验证。\n")
    for name in ("README.md", "SELF_REVIEW.md"):
        with (D / name).open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(paragraph)
elif args.phase == "candidate":
    candidate_name = "GATE_ENV_R02_ACTUAL" if "GATE_ENV_R02_ACTUAL" in ledger["slots"] else "GATE_ENV_R02"
    candidate_run = Q / "RUNS" / candidate_name
    slot = ledger["slots"][candidate_name]
    assert slot["state"] == "PASS"
    save(D / "GATE_01.json", {"id": "NEW_GATE_ENV_R02", "state": "PASS", "pass": True,
         "actual_result": slot["actual_result"], "raw_stdout": stamp(candidate_run / "stdout.bin"),
         "raw_stderr": stamp(candidate_run / "stderr.bin"),
         "environment_proof": stamp(candidate_run / "ENVIRONMENT_PROOF.json"),
         "nine_checks": read(candidate_run / "NINE_CHECKS.json"),
         "old_failed_Gate01": stamp(OLD / "RUNS/GATE_01/RESULT.json"), "old_consumption_preserved": True})
    for name in ("RESULT_RECEIPT.json", "INTEGRATION_HANDOFF.json"):
        obj = read(D / name)
        obj["status"] = "SOFTWARE_FRONTEND_READY_FOR_M2_REVIEW_FINAL_GATE_PUBLICATION_PENDING"
        obj["candidate_gate_passed"] = True
        obj["candidate_actual_original"] = stamp(candidate_run / "RESULT.json")
        obj["current_unresolved_execution_blockers"] = []
        obj["recovery_conditions"] = ["Final frozen tree must pass original final gate then ordinary publication; actual receipts in ignored S2"]
        obj["gate_failure"] = {"historical_R01_only": stamp(OLD / "RUNS/GATE_01/RESULT.json"),
                               "resolved_by_new_R02_candidate": True}
        save(D / name, obj)
    with (D / "SELF_REVIEW.md").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write("\nR02候选标准九门禁已实际9/9 PASS、自然退出0，实际子进程Python在enter_fpga_env前后均核同冻结解释器；原失败及900秒消费保留。下一步S1冻结后只运行剩余最终门禁，不改原门禁标准。\n")
else:
    assert ledger["slots"]["S1_R02"]["state"] == "PASS"
    assert ledger["slots"]["GATE_02"]["state"] == "PASS"
    final = read(Q / "CONTRACT_GATE_02.json")
    for ref in final["files"]:
        assert stamp(R / ref["path"]) == ref
    save(Q / "PRE_S2_RECEIPT.json", {"state": "SOFTWARE_FRONTEND_M3_DELIVERABLE_READY_PENDING_OUTER_SEAL_M2_REVIEW",
         "final_gate": ledger["slots"]["GATE_02"], "candidate_gate": ledger["slots"].get("GATE_ENV_R02_ACTUAL", ledger["slots"]["GATE_ENV_R02"]),
         "all42_software_assertions_passed": True, "old40_reused": True,
         "source9_unchanged_from_R01": True, "old_failures_and_consumption_preserved": True,
         "final_tree": final, "publication": read(Q / "PUBLICATION_ACTUAL.json"),
         "M2_ACCEPTED": False, "INTEGRATED": False, "real_capture_math_RTL_timing_board_verified": False,
         "S2_parent_actual_outside_own_zip": True, "recorded_utc": datetime.now(timezone.utc).isoformat()})
print(json.dumps({"phase": args.phase, "state": "METADATA_INTEGRATED"}))
