# Proposal only. Never launches a gate or mutates any environment.
# Root must integrate this into its separately admitted Job supervisor.
[CmdletBinding()]
param(
    [switch]$PrepareEnvironmentOnly,
    [string]$GateContractPath,
    [string]$GateContractSha256,
    [string]$ApprovalReceiptPath,
    [string]$ApprovalReceiptSha256,
    [string]$BaseChildPath
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $PrepareEnvironmentOnly) { throw 'DEFAULT_DENY_NO_GATE_EXECUTION' }
$pythonExe = 'C:\Users\songdongkuan\miniconda3\python.exe'
$pythonSha = '4e5a83fcdcd12bcb9ae4dc98c5405effe35dc5ac10d89982c6a6a3646493f88a'
$pythonSize = 104208
$oldDeadline = [DateTimeOffset]::Parse('2026-10-18T20:09:21+08:00')
function Require-True([bool]$Value, [string]$Reason) {
    if (-not $Value) { throw $Reason }
}
function Assert-PinnedFile([string]$Path, [string]$Sha256, [long]$Bytes = -1) {
    Require-True ([IO.Path]::IsPathRooted($Path)) 'ABSOLUTE_FILE_REQUIRED'
    Require-True ($Sha256 -cmatch '^[0-9a-f]{64}$') 'SHA256_REQUIRED'
    $item = Get-Item -LiteralPath $Path -Force
    Require-True (-not $item.PSIsContainer) 'FILE_REQUIRED'
    $cursor = $item
    while ($null -ne $cursor) {
        Require-True (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) 'PATH_ALIAS_DENIED'
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory }
        else { $cursor = $cursor.Parent }
    }
    if ($Bytes -ge 0) { Require-True ($item.Length -eq $Bytes) 'FILE_SIZE_CHANGED' }
    Require-True ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() -ceq $Sha256) 'FILE_SHA_CHANGED'
}
Require-True (-not [string]::IsNullOrWhiteSpace($BaseChildPath)) 'EXACT_CHILD_BASE_PATH_REQUIRED'
Assert-PinnedFile $GateContractPath $GateContractSha256
Assert-PinnedFile $ApprovalReceiptPath $ApprovalReceiptSha256
$contract = Get-Content -LiteralPath $GateContractPath -Raw -Encoding UTF8 | ConvertFrom-Json
$approval = Get-Content -LiteralPath $ApprovalReceiptPath -Raw -Encoding UTF8 | ConvertFrom-Json
Require-True ($contract.schema -ceq 'M3_NEW_GATE_ENV_RECOVERY_CONTRACT_V1') 'NEW_CONTRACT_REQUIRED'
Require-True ($approval.schema -ceq 'M2_EXPLICIT_GATE_ENV_APPROVAL_V1') 'NEW_EXPLICIT_APPROVAL_REQUIRED'
Require-True ($approval.approved -is [bool] -and $approval.approved) 'APPROVAL_REQUIRED'
Require-True ($approval.gate_contract_sha256 -ceq $GateContractSha256) 'APPROVAL_CONTRACT_MISMATCH'
Require-True ($approval.status -ceq 'VALID_FOR_ONE_NEW_RECOVERY_GATE') 'NO_REUSE_OF_OLD_GATE_SLOT'
Require-True (-not [string]::IsNullOrWhiteSpace($approval.approval_id)) 'APPROVAL_ID_REQUIRED'
Require-True ($contract.purpose -ceq 'NEW_GATE_ENVIRONMENT_RECOVERY') 'WRONG_PURPOSE'
Require-True ($contract.slot -ceq 'NEW_RECOVERY_GATE_NOT_GATE02') 'GATE02_RETRY_FORBIDDEN'
Require-True ($contract.budget.invocations -eq 1 -and $contract.budget.remaining -eq 1) 'ONE_NEW_INVOCATION_REQUIRED'
Require-True ($contract.budget.cap_seconds -is [long] -or $contract.budget.cap_seconds -is [int]) 'INTEGER_CAP_REQUIRED'
Require-True ($contract.budget.cap_seconds -gt 0) 'POSITIVE_NEW_CAP_REQUIRED'
Require-True ($approval.budget_cap_seconds -eq $contract.budget.cap_seconds) 'BUDGET_NOT_APPROVED'
$notBefore = [DateTimeOffset]::Parse($contract.window.not_before)
$notAfter = [DateTimeOffset]::Parse($contract.window.not_after)
$now = [DateTimeOffset]::UtcNow
Require-True ($now -ge $notBefore -and $now -lt $notAfter) 'OUTSIDE_NEW_APPROVED_WINDOW'
Require-True ($approval.not_before -ceq $contract.window.not_before -and $approval.not_after -ceq $contract.window.not_after) 'WINDOW_NOT_APPROVED'
Require-True (($notAfter - $now).TotalSeconds -ge $contract.budget.cap_seconds) 'INSUFFICIENT_WINDOW_FOR_CAP'
if ($notAfter -gt $oldDeadline) {
    Require-True ($approval.explicit_deadline_extension -is [bool] -and $approval.explicit_deadline_extension) 'OLD_DEADLINE_NOT_EXTENDED'
}
Require-True ($contract.python.path -ieq $pythonExe) 'PYTHON_PATH_MISMATCH'
Require-True ($contract.python.sha256 -ceq $pythonSha -and $contract.python.bytes -eq $pythonSize) 'PYTHON_IDENTITY_MISMATCH'
Assert-PinnedFile $pythonExe $pythonSha $pythonSize
Assert-PinnedFile $contract.frozen_manifest.path $contract.frozen_manifest.sha256 $contract.frozen_manifest.bytes
Require-True ($approval.frozen_manifest_sha256 -ceq $contract.frozen_manifest.sha256) 'FROZEN_TREE_NOT_APPROVED'
$manifest = Get-Content -LiteralPath $contract.frozen_manifest.path -Raw -Encoding UTF8 | ConvertFrom-Json
Require-True ($manifest.schema -ceq 'M3_GATE_FROZEN_9_SOURCE_23_EVIDENCE_V1') 'EXACT_FROZEN_MANIFEST_REQUIRED'
Require-True (@($manifest.sources).Count -eq 9 -and @($manifest.evidence).Count -eq 23) 'FROZEN_9_23_REQUIRED'
$seen = @{}
foreach ($entry in (@($manifest.sources) + @($manifest.evidence))) {
    Require-True (-not $seen.ContainsKey($entry.path.ToLowerInvariant())) 'DUPLICATE_FROZEN_FILE'
    $seen[$entry.path.ToLowerInvariant()] = $true
    Assert-PinnedFile $entry.path $entry.sha256 $entry.bytes
}
foreach ($name in @('gate_script', 'enter_environment', 'supervisor', 'powershell')) {
    $pin = $contract.$name
    Assert-PinnedFile $pin.path $pin.sha256 $pin.bytes
    Require-True ($approval.tool_sha256.$name -ceq $pin.sha256) 'TOOL_NOT_APPROVED'
}
Require-True ($contract.supervisor_policy -ceq 'EXISTING_JOB_OWNER_ONLY_NO_DIRECT_LAUNCH') 'MANAGED_SUPERVISOR_REQUIRED'
# No SetEnvironmentVariable, env: assignment, native command or child launch.
# The existing admitted supervisor alone may assign this value to its child.
$pythonRoot = [IO.Path]::GetDirectoryName($pythonExe)
$parts = @($BaseChildPath.Split(';') | Where-Object {
    -not [string]::IsNullOrWhiteSpace($_) -and $_.TrimEnd('\') -ine $pythonRoot.TrimEnd('\')
})
$childPath = (@($pythonRoot) + $parts) -join ';'
[pscustomobject]@{
    Status = 'PREPARED_ONLY_NOT_PERMISSION_TO_START'
    ChildEnvironment = @{ Path = $childPath }
    Python = @{ path = $pythonExe; bytes = $pythonSize; sha256 = $pythonSha }
    ContractSha256 = $GateContractSha256
    ApprovalReceiptSha256 = $ApprovalReceiptSha256
    MandatorySupervisorActions = @(
        'Authenticate approval outside this preparer; JSON text alone is not authority',
        'Atomically reserve exactly the new recovery slot before process creation',
        'Revalidate time, source tree, tools and environment at the actual spawn',
        'Use the pinned absolute PowerShell with NoProfile',
        'Prove bare python resolves to the pinned executable before gate dispatch',
        'Check later enter_fpga_env PATH prefixes do not shadow pinned python',
        'Keep Job ownership, finite cap, dual streams and Job-zero cleanup evidence',
        'Stop after any failure; do not consume Gate02 as a retry',
        'No software40 replay, Git, network, alternate worker or automatic retry'
    )
    StartsAnyProcess = $false
    MutatesCurrentOrPermanentEnvironment = $false
}
