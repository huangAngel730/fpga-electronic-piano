# R12 R02 child-only gate wrapper. Root-owned Job supervisor is mandatory.
# This artifact was prepared statically; it has not been parsed or run.
[CmdletBinding()]
param([string]$ContractPath, [string]$ContractSha256)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$failureExit = 97
$logRoot = $null
$proof = [ordered]@{ schema = 'M3_R12_R02_ENVIRONMENT_PROOF_V1'; phases = [ordered]@{} }
$repoFixed = 'E:\FPGA\GAOYUNFPGA\team\fpga-electronic-piano'
$recoveryFixed = $repoFixed + '\code\output\m3_frontend_close_r12_20261018\RECOVERY_R02_20261018'
$pythonFixed = 'C:\Users\songdongkuan\miniconda3\python.exe'
$pythonSha = '4e5a83fcdcd12bcb9ae4dc98c5405effe35dc5ac10d89982c6a6a3646493f88a'
$sourceStem = 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018/'
$evidenceStem = 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018/'
$sourceExpected = @{
    'json_identity.py' = @{ bytes = 6234; sha256 = 'd601d68bb2ee5d4ba4c4a435bdf3709dc943f05bb4858d516b854c507c9e6ae4' }
    'delivery_binding.py' = @{ bytes = 10662; sha256 = 'bd8bc9a6f3b40dc793db8a32a91b5d4eb464d783f5166f2976e6a73d0a83844d' }
    'delivery_transport.py' = @{ bytes = 14594; sha256 = '075ebb9af73b6218d3e15aa64e32c9f78f5e959b1390e4053e4616738b1b1cef' }
    'capture_identity.py' = @{ bytes = 21815; sha256 = '360731186004a9008e8a5e1cac1bb32c059b8653a380dc39ee3bb9be45b17bbb' }
    'capture_link_successor.py' = @{ bytes = 20407; sha256 = '369b6f5b4f692ea86013ce02c92bf411e7469175a3b8671f1ba2abcdcd551328' }
    'capture_entry.py' = @{ bytes = 3132; sha256 = 'b993a2cfd35cb2b435cda5ce2be1533c2f8836f8448b2aa7dd5237f2c6e5699e' }
    'selftest.py' = @{ bytes = 72764; sha256 = '5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c' }
    'DEPENDENCIES.json' = @{ bytes = 9918; sha256 = '73525eaa939c0b9627e42d9e763d93e206028102d8e7fed07350a493a8aac731' }
    'CALL_CHAIN_BINDINGS.json' = @{ bytes = 7750; sha256 = '3fac8cbe6ea6d54d4c47cd4e22051c8aa5fd89dc2fbdb69785be0a712ecaa4f9' }
}
$evidenceNames = @('README.md', 'TASK_ORIGINAL.md', 'PLAN.json', 'AUTHORIZATION.json', 'BASELINE.json', 'SOURCE_MANIFEST.json', 'CASE_MATRIX.json', 'CAPACITY_PROFILE.json', 'CONSUMPTION.json', 'RESULT_RECEIPT.json', 'INTEGRATION_HANDOFF.json', 'SELF_REVIEW.md', 'FAILURE_HISTORY.json', 'GATE_01.json', 'GATE_02.json', 'PUBLISH_ALLOWLIST.json', 'PUBLICATION_RECEIPT.json', 'ORIGINALS_MANIFEST.json', 'SOURCE_PAYLOAD.zip', 'PUBLICATION_ORIGINALS.zip', 'GIT_WRITE_RECEIPTS.jsonl', 'ACK_M2_REVIEW.json', 'OUTBOX_REFERENCE.json')
function Need([bool]$Ok, [string]$Why) { if (-not $Ok) { throw $Why } }
function Absolute([string]$Path) {
    Need (-not [string]::IsNullOrWhiteSpace($Path)) 'PATH_REQUIRED'
    Need ([IO.Path]::IsPathRooted($Path)) 'ABSOLUTE_PATH_REQUIRED'
    return [IO.Path]::GetFullPath($Path).TrimEnd('\')
}
function Reject-Alias([string]$Path) {
    $node = Get-Item -LiteralPath $Path -Force
    while ($null -ne $node) {
        Need (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) 'REPARSE_PATH_DENIED'
        if ($node -is [IO.FileInfo]) { $node = $node.Directory } else { $node = $node.Parent }
    }
}
function Pin([object]$Item, [string]$Path) {
    Need ($Item.sha256 -cmatch '^[0-9a-f]{64}$') 'FULL_SHA_REQUIRED'
    Need (($Item.bytes -is [int] -or $Item.bytes -is [long]) -and $Item.bytes -ge 0) 'SIZE_REQUIRED'
    Reject-Alias $Path
    $file = Get-Item -LiteralPath $Path -Force
    Need (-not $file.PSIsContainer -and $file.Length -eq $Item.bytes) 'PIN_SIZE_CHANGED'
    Need ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() -ceq $Item.sha256) 'PIN_SHA_CHANGED'
}
function Relative-File([string]$Path) {
    Need (-not [IO.Path]::IsPathRooted($Path)) 'RELATIVE_PATH_REQUIRED'
    $full = [IO.Path]::GetFullPath((Join-Path $repoFixed $Path))
    Need ($full.StartsWith($repoFixed + '\', [StringComparison]::OrdinalIgnoreCase)) 'PATH_ESCAPES_ROOT'
    return $full
}
function Save([string]$Name, [object]$Value) {
    Need ($Name -cmatch '^[A-Z0-9_]+\.json$') 'BAD_LOG_NAME'
    $encoder = New-Object System.Text.UTF8Encoding($false)
    $text = ($Value | ConvertTo-Json -Depth 20) + [char]10
    $bytes = $encoder.GetBytes($text)
    $stream = [IO.File]::Open((Join-Path $logRoot $Name), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $stream.Write($bytes, 0, $bytes.Length) } finally { $stream.Dispose() }
}
function Window {
    $now = [DateTimeOffset]::UtcNow
    $begin = [DateTimeOffset]::Parse($gateContract.not_before)
    $end = [DateTimeOffset]::Parse($gateContract.deadline)
    $limit = [DateTimeOffset]::Parse('2026-10-18T21:20:12+08:00')
    Need ($begin -lt $end -and $end -le $limit) 'WINDOW_OUTSIDE_R02'
    Need ($now -ge $begin -and ($end - $now).TotalSeconds -ge 900) 'FULL_900_SECONDS_NOT_AVAILABLE'
}
function Profile {
    Need ((Get-FileHash -Algorithm SHA256 -LiteralPath $ContractPath).Hash.ToLowerInvariant() -ceq $ContractSha256) 'CONTRACT_CHANGED'
    Need ($gateContract.cap_seconds -eq 900) 'EXACT_CAP_REQUIRED'
    Need ($gateContract.slot -cin @('GATE_ENV_R02', 'GATE_02')) 'SLOT_DENIED'
    $set = @{}
    foreach ($item in @($gateContract.files)) {
        $full = Relative-File $item.path
        Need (-not $set.ContainsKey($full)) 'DUPLICATE_PROFILE_FILE'
        $set[$full] = $item
        Pin $item $full
    }
    foreach ($name in $sourceExpected.Keys) {
        $full = Relative-File ($sourceStem + $name)
        Need ($set.ContainsKey($full)) 'MISSING_FROZEN_SOURCE'
        Need ($set[$full].sha256 -ceq $sourceExpected[$name].sha256 -and $set[$full].bytes -eq $sourceExpected[$name].bytes) 'FROZEN_SOURCE_IDENTITY_CHANGED'
    }
    foreach ($name in $evidenceNames) {
        Need ($set.ContainsKey((Relative-File ($evidenceStem + $name)))) 'MISSING_FROZEN_EVIDENCE'
    }
    Need (@($gateContract.files).Count -ge 32) 'INCOMPLETE_9_PLUS_23_PROFILE'
    foreach ($name in @('python', 'gate_script', 'enter_environment', 'shell')) {
        Pin $gateContract.$name (Absolute $gateContract.$name.path)
    }
    Need ((Absolute $gateContract.python.path) -ieq $pythonFixed) 'FROZEN_PYTHON_PATH_REQUIRED'
    Need ($gateContract.python.bytes -eq 104208 -and $gateContract.python.sha256 -ceq $pythonSha) 'FROZEN_PYTHON_CHANGED'
    Need ((Absolute $gateContract.gate_script.path) -ieq ($repoFixed + '\code\scripts\check_repo.ps1')) 'GATE_PATH_CHANGED'
    Need ($gateContract.gate_script.sha256 -ceq '23c69c10bd84c968f4ee23d186205d47075bfda8359f4df4e8d4196f9891ecaa') 'GATE_BODY_CHANGED'
    Need ((Absolute $gateContract.enter_environment.path) -ieq ($repoFixed + '\code\scripts\enter_fpga_env.ps1')) 'ENV_PATH_CHANGED'
    Need ($gateContract.enter_environment.sha256 -ceq '6582e41b598b207f5fac8fc74a8690a18de7778a53a0146d270f1747f4e4d866') 'ENV_BODY_CHANGED'
    Need ((Absolute $gateContract.shell.path) -ieq ((Get-Process -Id $PID).Path)) 'ACTUAL_CHILD_SHELL_MISMATCH'
    Need ($gateContract.shell.sha256 -ceq '60c9b29843624dd8af6b6a7b26147753be6aeef65098b9a503cc50850afe410f') 'SHELL_BODY_CHANGED'
    Pin $gateContract.authority (Relative-File $gateContract.authority.path)
    Need ((Relative-File $gateContract.authority.path) -ieq ($recoveryFixed + '\EXECUTION_PLAN.json')) 'AUTHORITY_PLAN_REQUIRED'
    Need ($gateContract.authority.sha256 -ceq '6e07d2fa7e956e83e712553ab14be17c15e183595b244d4b84c0207f4e4b1745') 'AUTHORITY_PLAN_CHANGED'
    Window
}
function Python-Resolution([string]$Stage, [bool]$Required) {
    $all = @(Get-Command -Name python -All -ErrorAction SilentlyContinue)
    $entries = @($all | ForEach-Object { [ordered]@{ name = $_.Name; type = [string]$_.CommandType; source = $_.Source; definition = $_.Definition } })
    $match = $false
    if ($all.Count -gt 0 -and $all[0].CommandType -eq [System.Management.Automation.CommandTypes]::Application) {
        $match = (Absolute $all[0].Definition) -ieq $pythonFixed
    }
    $record = [ordered]@{ utc = [DateTimeOffset]::UtcNow.ToString('o'); path = $env:PATH; commands = $entries; first_is_frozen_python = $match; match_required = $Required }
    $proof.phases[$Stage] = $record
    Save ($Stage + '.json') $record
    if ($Required) { Need $match 'BARE_PYTHON_NOT_FROZEN_EXECUTABLE'; Pin $gateContract.python $pythonFixed }
}
try {
    Need (-not [string]::IsNullOrWhiteSpace($ContractPath)) 'DEFAULT_DENY_NO_CONTRACT'
    $ContractPath = Absolute $ContractPath
    Reject-Alias $ContractPath
    Need ($ContractSha256 -cmatch '^[0-9a-f]{64}$') 'EXTERNAL_CONTRACT_SHA_REQUIRED'
    Need ((Get-FileHash -Algorithm SHA256 -LiteralPath $ContractPath).Hash.ToLowerInvariant() -ceq $ContractSha256) 'CONTRACT_SHA_MISMATCH'
    $gateContract = Get-Content -LiteralPath $ContractPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Need ($gateContract.schema -ceq 'M3_R12_R02_GATE_CONTRACT_V1') 'WRONG_CONTRACT_SCHEMA'
    Need ($gateContract.approved -is [bool] -and $gateContract.approved) 'ROOT_APPROVED_RESUMED_CONTRACT_REQUIRED'
    Need ((Absolute $gateContract.root) -ieq $repoFixed) 'ROOT_MISMATCH'
    Profile
    $logRoot = Absolute $gateContract.output
    Need ($logRoot.StartsWith($recoveryFixed + '\', [StringComparison]::OrdinalIgnoreCase)) 'OUTPUT_OUTSIDE_R02'
    Need ((Get-Item -LiteralPath $logRoot).PSIsContainer) 'ROOT_PRECREATED_OUTPUT_REQUIRED'
    Reject-Alias $logRoot
    Need (-not (Test-Path -LiteralPath (Join-Path $logRoot 'ENVIRONMENT_PROOF.json'))) 'PROOF_ALREADY_EXISTS_NO_RETRY'
    $proof.contract_sha256 = $ContractSha256
    $proof.contract_path = $ContractPath
    $proof.contract_original = [IO.File]::ReadAllText($ContractPath)
    $proof.slot = $gateContract.slot
    $proof.pid = $PID
    Python-Resolution 'RESOLUTION_ORIGINAL' $false
    # This is the root-supervised child process. No user/machine environment API.
    $env:PATH = ([IO.Path]::GetDirectoryName($pythonFixed)) + ';' + $env:PATH
    Python-Resolution 'RESOLUTION_BEFORE_ENTER_ENV' $true
    Profile
    . $gateContract.enter_environment.path
    Python-Resolution 'RESOLUTION_AFTER_ENTER_ENV' $true
    Profile
    Python-Resolution 'RESOLUTION_IMMEDIATELY_BEFORE_GATE' $true
    $proof.status = 'ACTUAL_RESOLUTION_VERIFIED_BEFORE_GATE_NOT_A_GATE_PASS'
    $proof.verified_utc = [DateTimeOffset]::UtcNow.ToString('o')
    Save 'ENVIRONMENT_PROOF.json' $proof
    # Full contract, source/evidence, tool hashes and 900-second margin again.
    Profile
    Push-Location -LiteralPath $repoFixed
    try {
        $global:LASTEXITCODE = 97
        & $gateContract.gate_script.path
        $actualGateExit = [int]$LASTEXITCODE
    } finally { Pop-Location }
    # Preserve gate stdout/stderr for the owned supervisor; no capture/rewrite.
    exit $actualGateExit
} catch {
    if ($null -ne $logRoot) {
        try { Save 'WRAPPER_FAILURE.json' ([ordered]@{ utc = [DateTimeOffset]::UtcNow.ToString('o'); status = 'FAIL_CLOSED'; error = $_.Exception.Message; no_retry = $true }) } catch { [Console]::Error.WriteLine('FAILURE_LOG_WRITE_FAILED') }
    }
    [Console]::Error.WriteLine('R12_R02_GATE_CHILD_FAIL_CLOSED: ' + $_.Exception.Message)
    exit $failureExit
}
