"""Unique R12 recovery controller: carried budgets, once-only slots, frozen inputs."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import types

ROOT = Path.cwd().resolve()
O = ROOT / "code/output/m3_frontend_close_r12_20261018"
OLD = O / "RESUME_R01_20261018"
Q = O / "RECOVERY_R02_20261018"
N = "m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018"
S, D = ROOT / "code/software" / N, ROOT / "code/docs/test" / N
BASE = "f1991b2ffdb64783fe71e19b5eb7d2dea9844613"
GIT = "C:/Program Files/Git/cmd/git.exe"


def read(p):
    return json.loads(p.read_text("utf-8"))


def save(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    temporary = p.with_suffix(p.suffix + ".tmp")
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    temporary.replace(p)


def stamp(p):
    digest, count = hashlib.sha256(), 0
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            count += len(block)
            digest.update(block)
    return {"path": p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else str(p),
            "bytes": count, "sha256": digest.hexdigest()}


def verify(ref):
    p = Path(ref["path"])
    if not p.is_absolute():
        p = ROOT / p
    assert stamp(p) == ref, "FROZEN_FILE_CHANGED:" + str(p)


def query(*args):
    result = subprocess.run([GIT, *args], cwd=ROOT, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
    assert result.returncode == 0, "LOCAL_GIT_QUERY_FAILED:" + result.stderr.decode("utf-8", "replace")
    return result.stdout.decode("utf-8").strip()


def clean_base():
    assert query("rev-parse", "HEAD") == BASE, "BASE_HEAD_CHANGED"
    assert query("status", "--porcelain", "--untracked-files=no") == "", "TRACKED_OR_INDEX_CHANGED"


def owner():
    source = S / "selftest.py"
    ref = next(x for x in read(D / "SOURCE_MANIFEST.json")["files"] if x["path"] == source.relative_to(ROOT).as_posix())
    verify(ref)
    module = types.ModuleType("_r12_r02_frozen_owner")
    module.__file__ = str(source)
    exec(compile(source.read_bytes(), str(source), "exec", dont_inherit=True), module.__dict__)
    return module


def check_window(seconds):
    deadline = datetime.fromisoformat(read(Q / "EXECUTION_PLAN.json")["operational_deadline"])
    assert (deadline - datetime.now(timezone.utc)).total_seconds() >= seconds + 1, "WINDOW_INSUFFICIENT"


def verify_admission(path, digest):
    raw = path.read_bytes()
    assert len(raw) <= 8 * 1024 * 1024 and hashlib.sha256(raw).hexdigest() == digest
    admission = json.loads(raw)
    assert admission["approved"] and admission["writers_frozen"]
    for name, ref in admission["source_pins"].items():
        verify({"path": name, "bytes": ref["bytes"], "sha256": ref["sha256"]})
    return admission


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("init", "admit-delta", "run", "freeze-gate", "network"))
parser.add_argument("item", nargs="?")
parser.add_argument("--admission", type=Path)
parser.add_argument("--sha256")
parser.add_argument("--operation")
args = parser.parse_args()
assert sys.dont_write_bytecode and not sys.flags.optimize
plan = read(Q / "EXECUTION_PLAN.json")
if args.mode == "init":
    clean_base()
    assert not (Q / "CONSUMPTION.json").exists()
    old_terminal = read(OLD / "LOCAL_TERMINAL_RECEIPT_R01.json")
    verify({k: old_terminal["final_archive"][k] for k in ("path", "bytes", "sha256")})
    before = []
    for root in (S, D):
        for path in sorted(root.iterdir()):
            if path.is_file():
                ref = stamp(path)
                target = Q / "BEFORE" / ("source" if root == S else "evidence") / path.name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)
                assert target.read_bytes() == path.read_bytes()
                before.append({"original": ref, "preserved": stamp(target)})
    assert len(before) == 32
    save(Q / "BEFORE_TREE.json", {"base": BASE, "files": before})
    old_ledger = read(OLD / "CONSUMPTION.json")
    save(Q / "R01_CONSUMPTION_AT_RESUME.json", old_ledger)
    assert all(x["state"] == "OK" for x in old_ledger["network"]["operations"])
    slots = {k: {"state": "NOT_STARTED", "attempts": 0, "charged_seconds": 0, **v}
             for k, v in plan["new_recovery_slots"].items()}
    slots["GATE_02"] = {"state": "NOT_STARTED", "attempts": 0, "charged_seconds": 0,
                        "cap_seconds": 900, "carried_original_unused_slot": True}
    save(Q / "CONSUMPTION.json", {"schema": "M3_R12_R02_CONSUMPTION_V1", "slots": slots,
         "deadline": plan["operational_deadline"], "old_charge_snapshot": stamp(Q / "R01_CONSUMPTION_AT_RESUME.json"),
         "network": {"operations": [], "ops_max": 12 - len(old_ledger["network"]["operations"]),
                     "seconds_max": 720 - sum(x["charged_seconds"] for x in old_ledger["network"]["operations"])},
         "old_consumption_refunded": False, "publisher": plan["only_publisher_and_test_executor"]})
elif args.mode == "admit-delta":
    clean_base()
    assert read(Q / "WRITE_LEASES_CLOSED.json")["all_closed"]
    admission = read(OLD / "ADMISSION_REPAIRED.json")
    admission.update(schema="M3_R12_R02_WORKER_ADMISSION_V1", approved=True,
                     allowed_groups=["CAPTURE_EVIDENCE_DELTA"],
                     group_caps_seconds={"CAPTURE_EVIDENCE_DELTA": 120},
                     deadline=plan["operational_deadline"], authority=stamp(Q / "EXECUTION_PLAN.json"),
                     writers_frozen=True)
    for name in ("capture_evidence_delta.py", "root_r02.py", "seal_r02.py", "GATE_CHILD_R02.ps1"):
        path = Q / name
        ref = stamp(path)
        admission["source_pins"][ref["path"]] = {"bytes": ref["bytes"], "sha256": ref["sha256"]}
    target = Q / "ADMISSION_DELTA.json"
    assert not target.exists()
    save(target, admission)
    print(json.dumps(stamp(target)))
elif args.mode == "freeze-gate":
    clean_base()
    assert args.item in ("GATE_ENV_R02", "GATE_02")
    ledger = read(Q / "CONSUMPTION.json")
    assert ledger["slots"]["CAPTURE_EVIDENCE_DELTA"]["state"] == "PASS"
    if args.item == "GATE_02":
        assert ledger["slots"]["GATE_ENV_R02"]["state"] == "PASS"
        assert ledger["slots"]["S1_R02"]["state"] == "PASS"
    files = [stamp(p) for root in (S, D) for p in sorted(root.iterdir()) if p.is_file()]
    assert len(files) == 32
    for relative in ("code/scripts/check_repo.ps1", "code/scripts/enter_fpga_env.ps1", "code/scripts/run_t007_sim.ps1",
                     "code/scripts/run_t019_sim.ps1", "code/scripts/run_t025_top_stat.py"):
        files.append(stamp(ROOT / relative))
    def absolute_pin(path):
        ref = stamp(path)
        ref["path"] = str(path)
        return ref
    contract = {"schema": "M3_R12_R02_GATE_CONTRACT_V1", "approved": True,
                "root": str(ROOT), "output": str(Q / "RUNS" / args.item),
                "not_before": datetime.now(timezone.utc).isoformat(), "deadline": plan["operational_deadline"],
                "cap_seconds": 900, "slot": args.item, "base_commit": BASE,
                "tracked_base_tree": query("rev-parse", "HEAD^{tree}"),
                "python": absolute_pin(Path(sys.executable)),
                "shell": absolute_pin(Path("C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe")),
                "gate_script": absolute_pin(ROOT / "code/scripts/check_repo.ps1"),
                "enter_environment": absolute_pin(ROOT / "code/scripts/enter_fpga_env.ps1"),
                "files": files, "authority": stamp(Q / "EXECUTION_PLAN.json"),
                "worker": stamp(Q / "GATE_CHILD_R02.ps1"),
                "native_caps": plan["native_caps_per_gate"]}
    target = Q / ("CONTRACT_" + args.item + ".json")
    assert not target.exists()
    save(target, contract)
    print(json.dumps(stamp(target)))
elif args.mode == "run":
    assert args.item in ("CAPTURE_EVIDENCE_DELTA", "GATE_ENV_R02", "GATE_02", "S1_R02", "S2_R02")
    ledger = read(Q / "CONSUMPTION.json")
    slot = ledger["slots"][args.item]
    assert slot["state"] == "NOT_STARTED" and slot["attempts"] == 0, "CONSUMED_SLOT"
    assert args.item in ("S1_R02", "S2_R02") or not any(x["state"] == "FAILED_STOP" for x in ledger["slots"].values()), "FIRST_FAILURE_STOP"
    admission = verify_admission(args.admission, args.sha256)
    assert read(Q / "WRITE_LEASES_CLOSED.json")["all_closed"]
    cap = slot["cap_seconds"]
    if args.item == "CAPTURE_EVIDENCE_DELTA":
        remaining_caps = sum(x["cap_seconds"] for x in ledger["slots"].values() if x["state"] == "NOT_STARTED")
        remaining_network = ledger["network"]["seconds_max"] - sum(x["charged_seconds"] for x in ledger["network"]["operations"])
        check_window(remaining_caps + remaining_network + 60)
    check_window(cap + (120 if args.item in ("CAPTURE_EVIDENCE_DELTA", "GATE_ENV_R02") else 60 if args.item == "GATE_02" else 0))
    run = Q / "RUNS" / ("CD" if args.item == "CAPTURE_EVIDENCE_DELTA" else args.item)
    if args.item.startswith("GATE_"):
        contract_path = Q / ("CONTRACT_" + args.item + ".json")
        contract = read(contract_path)
        for ref in contract["files"]:
            verify(ref)
        clean_base()
        argv = [contract["shell"]["path"], "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
                str(Q / "GATE_CHILD_R02.ps1"), "-ContractPath", str(contract_path),
                "-ContractSha256", stamp(contract_path)["sha256"]]
    else:
        worker = "capture_evidence_delta.py" if args.item == "CAPTURE_EVIDENCE_DELTA" else "seal_r02.py"
        argv = [sys.executable, "-X", "utf8", "-B", str(Q / worker)]
        if worker == "seal_r02.py":
            argv.append(args.item)
        argv += ["--admission", str(args.admission), "--admission-sha256", args.sha256,
                 "--output", str(run / "worker")]
    slot.update(state="CONSUMED_BEFORE_LAUNCH", attempts=1, charged_seconds=cap,
                started_utc=datetime.now(timezone.utc).isoformat(), admission=stamp(args.admission))
    save(Q / "CONSUMPTION.json", ledger)
    result = owner().owned_call(argv, ROOT, run, cap)
    good = result["exit_code"] == 0 and result["within_cap"] and result["job_zero_observed_before_job_close"] and result["job_handle_closed"] and result["root_process_handle_closed"]
    verify_admission(args.admission, args.sha256)
    if args.item.startswith("GATE_"):
        import re
        for ref in contract["files"]:
            verify(ref)
        clean_base()
        stream = (run / "stdout.bin").read_text("utf-8", errors="replace")
        checks = re.findall(r"^\s*\[(PASS|FAIL)\] (.+)$", stream, re.M)
        good = good and len(checks) == 9 and all(x[0] == "PASS" for x in checks) and "All repository checks passed." in stream
        save(run / "NINE_CHECKS.json", {"checks": checks, "all_pass": good, "contract": stamp(contract_path)})
    slot.update(state="PASS" if good else "FAILED_STOP", ended_utc=datetime.now(timezone.utc).isoformat(), actual_result=result)
    save(Q / "CONSUMPTION.json", ledger)
    print(json.dumps({"slot": args.item, "state": slot["state"], "exit": result["exit_code"], "elapsed_seconds": result["elapsed_seconds"]}))
    raise SystemExit(0 if good else result["exit_code"] or 3)
else:
    ledger = read(Q / "CONSUMPTION.json")
    rows, net = ledger["network"]["operations"], ledger["network"]
    assert args.item in ("fetch", "remote", "push")
    assert args.operation and all(x["operation_id"] != args.operation for x in rows)
    assert len(rows) < net["ops_max"] and sum(x["charged_seconds"] for x in rows) + 60 <= net["seconds_max"]
    assert all(x["state"] == "OK" for x in rows), "PERSISTENT_NETWORK_FAILURE"
    check_window(60)
    if args.item == "push":
        assert ledger["slots"]["GATE_02"]["state"] == "PASS"
    source = ROOT / "code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/night_drill_r01/network.py"
    assert stamp(source)["sha256"] == "add7a4195f70e8ad7dd23fb50b46892cda1d5d3a09edefd70794a145579016c5"
    row = {"operation_id": args.operation, "kind": args.item, "state": "CONSUMED_BEFORE_LAUNCH", "charged_seconds": 60}
    rows.append(row)
    save(Q / "CONSUMPTION.json", ledger)
    module = types.ModuleType("_r12_r02_unchanged_network")
    module.__file__ = str(source)
    exec(compile(source.read_bytes(), str(source), "exec", dont_inherit=True), module.__dict__)
    module.OUTPUT = Q / "NETWORK"
    code = module.run(args.item, args.operation)
    actual = read(module.OUTPUT / "runs" / (args.operation + "_01") / "RESULT.json")
    row.update(state="OK" if code == 0 else "FAILED_STOP", result=actual)
    save(Q / "CONSUMPTION.json", ledger)
    raise SystemExit(code)
