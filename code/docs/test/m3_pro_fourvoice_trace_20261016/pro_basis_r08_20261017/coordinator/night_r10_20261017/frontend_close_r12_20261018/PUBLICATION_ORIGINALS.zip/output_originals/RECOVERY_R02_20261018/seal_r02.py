"""Two admitted R02 seal purposes, each once, actual CRC and member SHA."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path.cwd().resolve()
O = ROOT / "code/output/m3_frontend_close_r12_20261018"
Q = O / "RECOVERY_R02_20261018"
N = "m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018"
S, D = ROOT / "code/software" / N, ROOT / "code/docs/test" / N


def read(path):
    return json.loads(path.read_text("utf-8"))


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def stamp(path):
    sha, count = hashlib.sha256(), 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            sha.update(block)
            count += len(block)
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": count, "sha256": sha.hexdigest()}


def archive(path, payload, manifest_path):
    entries = []
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as out:
        for name, original in sorted(payload.items()):
            ref = stamp(original)
            entries.append({"path": name, "bytes": ref["bytes"], "sha256": ref["sha256"]})
            out.write(original, name)
        raw = (json.dumps({"files": entries}, indent=2) + "\n").encode("utf-8")
        out.writestr("MANIFEST.json", raw)
    with zipfile.ZipFile(path) as inp:
        assert len(inp.namelist()) == len(set(inp.namelist()))
        for ref in entries:
            sha, count = hashlib.sha256(), 0
            with inp.open(ref["path"]) as stream:
                for chunk in iter(lambda: stream.read(1048576), b""):
                    sha.update(chunk)
                    count += len(chunk)
            assert count == ref["bytes"] and sha.hexdigest() == ref["sha256"]
        assert inp.read("MANIFEST.json") == raw
    result = {**stamp(path), "payload_members": len(entries), "CRC_verified": True, "member_SHA_verified": True}
    save(manifest_path, {"archive": result, "members": entries})
    return result


parser = argparse.ArgumentParser()
parser.add_argument("slot", choices=("S1_R02", "S2_R02"))
parser.add_argument("--admission", type=Path, required=True)
parser.add_argument("--admission-sha256", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
raw = args.admission.read_bytes()
assert hashlib.sha256(raw).hexdigest() == args.admission_sha256
admission = json.loads(raw)
for name, ref in admission["source_pins"].items():
    actual = stamp(ROOT / name)
    assert actual["bytes"] == ref["bytes"] and actual["sha256"] == ref["sha256"]
args.output.mkdir(parents=True, exist_ok=False)
if args.slot == "S1_R02":
    # Both R01 ZIPs and its entire32-file tree remain reachable in BEFORE.
    for name in ("SOURCE_PAYLOAD.zip", "PUBLICATION_ORIGINALS.zip"):
        path = D / name
        old = Q / "BEFORE/evidence" / name
        assert old.read_bytes() == path.read_bytes(), "PRESERVED_R01_ZIP_CHANGED"
        path.unlink()
    save(D / "CONSUMPTION.json", {"R02_at_S1": read(Q / "CONSUMPTION.json"),
         "R01_at_resume": read(Q / "R01_CONSUMPTION_AT_RESUME.json"),
         "snapshot": "CurrentS1 charged before launch; actual final gate/publication/S2 evidence is ignored output only"})
    src = archive(D / "SOURCE_PAYLOAD.zip", {p.relative_to(ROOT).as_posix(): p for p in S.iterdir() if p.is_file()}, Q / "SOURCE_ARCHIVE_MANIFEST.json")
    payload = {p.relative_to(ROOT).as_posix(): p for root in (S, D) for p in root.iterdir() if p.is_file()}
    excluded = []
    for path in O.rglob("*"):
        if not path.is_file() or path.name.endswith(".tmp"):
            continue
        relative = path.relative_to(Q).as_posix() if path.is_relative_to(Q) else ""
        if relative.startswith(("RUNS/S1_R02/", "RUNS/S2_R02/")):
            continue
        if path.stat().st_size > 64 * 1024 * 1024:
            assert path.name == "LARGE_SYNTHETIC_STDERR.bin", "UNDECLARED_LARGE_ORIGINAL"
            excluded.append({"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size,
                 "sha256": "bf14f893cdc16e9007c4bd70b36aa43990abfbf9b70b751f68221fc540682ceb",
                 "portable_originals": "RESUME_R01_20261018/RUNS/W/worker/PORTABLE_ORIGINALS/PARTS.json",
                 "lossless21_compressed_pieces_included": True})
            continue
        payload["output_originals/" + path.relative_to(O).as_posix()] = path
    for ref in read(S / "DEPENDENCIES.json")["old_source_files"]:
        path = ROOT / ref["path"]
        assert stamp(path) == ref
        payload["readonly_dependencies/" + ref["path"]] = path
    fixture = ROOT / "code/output/m3_c9_complete_d4_20261017/R03/cases/009"
    for path in fixture.rglob("*"):
        if path.is_file():
            payload["readonly_fixture_originals/" + path.relative_to(ROOT).as_posix()] = path
    refs = [{"path": name, "bytes": stamp(path)["bytes"], "sha256": stamp(path)["sha256"]}
            for name, path in sorted(payload.items()) if path != D / "ORIGINALS_MANIFEST.json"]
    save(D / "ORIGINALS_MANIFEST.json", {"schema": "M3_R12_R02_ORIGINALS_V1", "files": refs,
         "excluded_large_raw": excluded, "self_and_publication_zip_digest_excluded": True,
         "R01_originals": stamp(Q / "BEFORE_TREE.json"),
         "S1_current_state": "CONSUMED_RUNNING_ACTUAL_RESULT_NOT_YET_AVAILABLE",
         "actual_final_results_future_path": str(Q / "FINAL_HANDOFF_R02.zip")})
    pub = archive(D / "PUBLICATION_ORIGINALS.zip", payload, Q / "PUBLICATION_ARCHIVE_MANIFEST.json")
    save(Q / "S1_ARCHIVES.json", {"source": src, "publication": pub, "old_failed_and_R01_bytes_preserved": True})
else:
    payload = {p.relative_to(ROOT).as_posix(): p for p in D.iterdir() if p.is_file()}
    for name in ("CONSUMPTION.json", "PUBLICATION_ACTUAL.json", "GIT_WRITE_RECEIPTS.jsonl",
                 "CONTRACT_GATE_ENV_R02.json", "CONTRACT_GATE_02.json", "S1_ARCHIVES.json",
                 "PRE_S2_RECEIPT.json", "PUBLISHED_TREE_VERIFICATION.json"):
        path = Q / name
        if path.is_file():
            payload["actual/" + name] = path
    for slot in ("CD", "GATE_ENV_R02", "GATE_02", "S1_R02"):
        for path in (Q / "RUNS" / slot).rglob("*"):
            if path.is_file():
                payload["actual/" + path.relative_to(Q).as_posix()] = path
    for path in (Q / "NETWORK").rglob("*"):
        if path.is_file():
            payload["actual/" + path.relative_to(Q).as_posix()] = path
    result = archive(Q / "FINAL_HANDOFF_R02.zip", payload, Q / "FINAL_HANDOFF_MANIFEST.json")
    print(json.dumps(result))
print(json.dumps({"slot": args.slot, "exit": 0, "utc": datetime.now(timezone.utc).isoformat()}))
