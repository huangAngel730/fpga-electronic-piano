R12 自审：精确写集并行实现后统一冻结；J/G/C/W 40 项实际软件结果见 CASE_MATRIX 与原始双流。

同缓冲 JSON、Git cwd/双流、私有 capture streaming 的验证范围仅为软件；C 使用明确合成的小窗，W 使用私有 D4 边界替身。未签真实采集、数学、RTL、时序或板卡。

旧窗口与失败 S1 保留。Job 修复以释放 root process handle 后、关闭原 Job 前观察真实 active=0；自然结束、晚退子进程及超时清理诊断均留原件。

候选/最终门禁各仅一次；最终门禁后不修改 tracked 字节。Gate02 为 NOT_STARTED，publication 为 FAILED_STOP；S2路径只是尚未生成的未来引用，实际结果仅交 S2。M2 只复核 R12 增量。

门禁前漏核子PowerShell的python命令解析，导致候选Gate01失败；本轮明确保留该失败，不修改共享门禁或换工具重跑。需要新的精确环境/门禁准入，软件40项无需重复。

封存前自审限定：40项是已执行夹具断言的PASS，不是整体R12通过。C02保存模块basename与准入pin/静态映射，未持久化逐函数有序动态轨迹；C12仅在convert_files入口注错，活跃文本解析异常的no-drain分支未独立动态覆盖。按实际未验边界交M2判断，不新增重跑或外推真实Pro。
