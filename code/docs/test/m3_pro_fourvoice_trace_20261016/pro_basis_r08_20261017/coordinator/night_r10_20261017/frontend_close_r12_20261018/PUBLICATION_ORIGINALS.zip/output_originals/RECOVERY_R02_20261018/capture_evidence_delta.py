"""R12 R02 two-case capture evidence delta. No candidate execution at import."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import types

ROOT = Path(__file__).resolve().parents[4]
SOURCE = ROOT / "code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018"
R02 = ROOT / "code/output/m3_frontend_close_r12_20261018/RECOVERY_R02_20261018"
CHUNK, MAX_JSON = 1024 * 1024, 8 * 1024 * 1024
NAMES = {"json_identity.py", "delivery_binding.py", "delivery_transport.py",
         "capture_identity.py", "capture_link_successor.py", "capture_entry.py",
         "selftest.py", "DEPENDENCIES.json", "CALL_CHAIN_BINDINGS.json"}
KEY_NAMES = {"process", "process_request", "process_capture", "checked",
             "checked_descriptor", "checked_file", "ref", "artifact", "descriptor",
             "read", "read_json", "read_ref", "read_verified", "json_record",
             "identity", "convert_files", "build_bundle", "build_application",
             "generate", "verify", "check", "load_source", "load", "helpers",
             "support", "no_alias", "_json_meta", "close"}


def need(ok, reason):
    if not ok:
        raise AssertionError(reason)


def path(value):
    result = Path(value)
    result = result if result.is_absolute() else ROOT / result
    for part in (result, *result.parents):
        need(not part.is_symlink() and not part.is_junction(), "PATH_ALIAS")
    result = result.resolve()
    need(result.is_relative_to(ROOT), "PATH_SCOPE")
    return result


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def number(value):
    result = float(value)
    need(math.isfinite(result), "NONFINITE_JSON")
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=pairs, parse_float=number,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("NONFINITE_JSON")))


def raw_small(value, cap=MAX_JSON):
    blocks, count = [], 0
    with path(value).open("rb", buffering=0) as stream:
        while True:
            block = stream.read(min(CHUNK, cap + 1 - count))
            if not block:
                break
            count += len(block)
            need(count <= cap, "CONTROL_OR_SOURCE_BOUND")
            blocks.append(block)
    return b"".join(blocks)


def stamp(value):
    value = path(value)
    digest, count = hashlib.sha256(), 0
    with value.open("rb", buffering=0) as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            digest.update(block)
            count += len(block)
    return {"path": value.relative_to(ROOT).as_posix(), "bytes": count,
            "sha256": digest.hexdigest()}


def verified(ref, cap=MAX_JSON):
    need(type(ref) is dict and {"path", "bytes", "sha256"} <= ref.keys(), "DESCRIPTOR")
    need(type(ref["bytes"]) is int and 0 <= ref["bytes"] <= cap, "DESCRIPTOR_BOUND")
    raw = raw_small(ref["path"], cap)
    need(len(raw) == ref["bytes"] and hashlib.sha256(raw).hexdigest() == ref["sha256"],
         "FROZEN_BYTES_CHANGED:" + str(ref["path"]))
    return raw


def write(value, body):
    raw = (json.dumps(body, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    with path(value).open("xb") as stream:
        stream.write(raw)
    return stamp(value)


def descriptors(value):
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"} <= value.keys():
            yield value
        for child in value.values():
            yield from descriptors(child)
    elif isinstance(value, list):
        for child in value:
            yield from descriptors(child)


class OrderedTrace:
    """Current-thread profile of real pinned code calls, not a module-load list."""
    def __init__(self, destination, sources, stop):
        self.destination, self.sources, self.stop = destination, sources, stop
        self.sequence, self.calls = 0, 0
        self.active, self.selected = {}, []
        self.previous, self.stream = None, None
        self.filename_cache = {}

    def emit(self, body):
        self.sequence += 1
        body = {"sequence": self.sequence, "monotonic_ns": time.monotonic_ns(), **body}
        self.stream.write((json.dumps(body, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8"))

    def profile(self, frame, event, arg):
        if event not in ("call", "return"):
            return
        filename = frame.f_code.co_filename
        if filename not in self.filename_cache:
            self.filename_cache[filename] = str(Path(filename).resolve()).casefold()
        key = self.filename_cache[filename]
        descriptor = self.sources.get(key)
        if descriptor is None or frame.f_code.co_name not in KEY_NAMES:
            return
        need(time.monotonic() < self.stop, "DELTA_WALL_BUDGET")
        if event == "call":
            self.calls += 1
            parent, cursor = None, frame.f_back
            while cursor is not None:
                if id(cursor) in self.active:
                    parent = self.active[id(cursor)]
                    break
                cursor = cursor.f_back
            item = {"event": "call", "call_id": self.calls, "parent_call_id": parent,
                    "source": descriptor, "function": frame.f_code.co_name,
                    "qualname": frame.f_code.co_qualname,
                    "first_line": frame.f_code.co_firstlineno, "call_line": frame.f_lineno}
            self.active[id(frame)] = self.calls
            self.selected.append(item)
            self.emit(item)
        elif id(frame) in self.active:
            self.emit({"event": "return", "call_id": self.active.pop(id(frame)),
                       "source": descriptor, "qualname": frame.f_code.co_qualname,
                       "return_type": type(arg).__name__,
                       "return_is_not_success_proof": True})

    def __enter__(self):
        self.stream = self.destination.open("xb")
        self.previous = sys.getprofile()
        if self.previous is not None:
            self.stream.close()
            raise AssertionError("EXISTING_THREAD_PROFILE_NOT_REPLACED")
        sys.setprofile(self.profile)
        return self

    def __exit__(self, *exc):
        sys.setprofile(self.previous)
        self.stream.close()
        return False

    def assert_chain(self):
        def exact(relative, function):
            choices = [x for x in self.selected if x["source"]["path"] == relative
                       and x["function"] == function]
            need(choices, "DYNAMIC_REQUIRED_CALL_MISSING:" + relative + ":" + function)
            return choices[0]
        base = SOURCE.relative_to(ROOT).as_posix()
        n10 = SOURCE.parent.relative_to(ROOT).as_posix()
        routes = [
            exact(base + "/capture_entry.py", "process"),
            exact(n10 + "/capture_complete_r11/entry.py", "process"),
            exact(n10 + "/capture_link_r01/entry.py", "process"),
            exact(SOURCE.parent.parent.relative_to(ROOT).as_posix()
                  + "/task_day4_completion_20261017/chain.py", "process"),
        ]
        by_id = {x["call_id"]: x for x in self.selected}
        def beneath(item, parent):
            cursor = item["parent_call_id"]
            while cursor is not None:
                if cursor == parent["call_id"]:
                    return True
                cursor = by_id[cursor]["parent_call_id"]
            return False
        for parent, child in zip(routes, routes[1:]):
            need(beneath(child, parent), "DYNAMIC_ROUTE_NOT_NESTED")
        helpers = {}
        for name in ("checked", "ref"):
            hits = [x for x in self.selected
                    if x["source"]["path"] == base + "/capture_identity.py"
                    and x["qualname"] == "IdentityFacade." + name
                    and beneath(x, routes[-1])]
            need(hits, "D4_ACTUAL_HELPER_CALL_MISSING:" + name)
            helpers[name] = hits[0]
        return {"routes": routes, "helpers_beneath_D4": helpers,
                "selected_python_calls": self.calls, "events": self.sequence,
                "all_selected_events_persisted_in_order": True}


def tracked_class(base, owners):
    class Tracked(base):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            owners.append(self)
    return Tracked


def active_text_case(helper, pins, dependency_ref, envelope, request, output):
    harness = helper.CaptureHarness(pins, dependency_ref)
    owners, state = [], {"injected": False, "target_physical_attempts": 0,
                         "successful_reads": 0, "after_fault_attempts": 0}
    for name in ("ArtifactReader", "ArtifactTextReader", "MemoryReader"):
        setattr(harness.ci, name, tracked_class(getattr(harness.ci, name), owners))
    tracked_reader = harness.ci.ArtifactReader
    class OneByteDiagnosticReader(tracked_reader):
        # TextIOWrapper may request read1(8192) even for read(1). The frozen
        # read1 alias fills a requested buffer; limit this private diagnostic
        # boundary so the first successful character precedes the injected IO.
        def read1(self, size=-1):
            if state.get("source") is self.source:
                return super().read(1)
            return super().read1(size)
    harness.ci.ArtifactReader = OneByteDiagnosticReader
    stdout = path(request["inputs"]["stdout"]["path"])
    original_context = harness.entry.DependencyContext
    marker = OSError("R02_INJECTED_ACTIVE_VERIFIED_TEXT_READ")
    class FaultContext(original_context):
        def load(self, source, *args, **kwargs):
            module = super().load(source, *args, **kwargs)
            stream_source = ROOT / "code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017/public_capture_tb/c9_completion_r01/c9_stream.py"
            if Path(source).resolve() == stream_source.resolve() and not getattr(module, "_r02_text_probe", False):
                original_metadata = module.bounded_metadata
                def metadata(value):
                    if path(value) != stdout:
                        return original_metadata(value)
                    need(self.io.expected(stdout)["declared"], "TEXT_ROLE_NOT_DECLARED")
                    text = self.io.path(stdout).open("r", encoding="utf-8", errors="strict")
                    binary = text.buffer
                    need(isinstance(text, harness.ci.ArtifactTextReader)
                         and isinstance(binary, harness.ci.ArtifactReader)
                         and binary.expected is not None and binary.streaming,
                         "NOT_ACTUAL_VERIFIED_TEXT_READER")
                    original_file = binary.source
                    state["text"], state["binary"] = text, binary
                    class PhysicalReadFault:
                        # This wrapper owns the actual open file; only its
                        # second read raises. It never substitutes file bytes.
                        def __getattr__(self, name):
                            return getattr(original_file, name)
                        def read(self, size):
                            state["target_physical_attempts"] += 1
                            if state["injected"]:
                                state["after_fault_attempts"] += 1
                                raise marker
                            if state["successful_reads"]:
                                state["injected"] = True
                                state["calls_at_fault"] = self_context.io.metrics["calls"]
                                state["bytes_at_fault"] = self_context.io.metrics["bytes"]
                                raise marker
                            block = original_file.read(min(size, 1))
                            need(len(block) == 1, "TEXT_ROLE_EMPTY_BEFORE_INJECTION")
                            state["successful_reads"] += 1
                            return block
                    self_context = self
                    binary.source = PhysicalReadFault()
                    state["source"] = binary.source
                    try:
                        with text:
                            first = text.read(1)
                            need(len(first) == 1 and binary.count == 1
                                 and binary.position == 1 and not binary.eof,
                                 "ACTIVE_TEXT_READ_NOT_PROVEN")
                            state["first_character_read"] = True
                            text.read(1)
                            raise AssertionError("ACTIVE_READ_EXCEPTION_NOT_INJECTED")
                    finally:
                        state["calls_after_close"] = self.io.metrics["calls"]
                        state["bytes_after_close"] = self.io.metrics["bytes"]
                        state["io_metrics"] = dict(self.io.metrics)
                module.bounded_metadata = metadata
                module._r02_text_probe = True
            return module
    harness.entry.DependencyContext = FaultContext
    try:
        harness.process(envelope, output)
    except OSError as error:
        need(error is marker, "ACTIVE_READ_ERROR_REPLACED_OR_SWALLOWED")
    else:
        raise AssertionError("FAULT_CASE_UNEXPECTED_SUCCESS")
    need(state["injected"] and state.get("first_character_read"), "ACTIVE_PATH_NOT_REACHED")
    need(state["successful_reads"] == 1 and state["target_physical_attempts"] == 2
         and state["after_fault_attempts"] == 0, "READ_AFTER_FAULT_OR_CLOSE_DRAIN")
    need(state["calls_at_fault"] == state["calls_after_close"]
         and state["bytes_at_fault"] == state["bytes_after_close"], "CLOSE_APPENDED_IO")
    need(state["text"].closed and state["binary"].closed and state["source"].closed,
         "ACTIVE_TEXT_FILE_NOT_CLOSED")
    need(state["binary"].drain_on_close is False and not state["binary"].verified
         and not state["binary"].eof and state["binary"].drained == 0,
         "FAULT_STREAM_FALSE_EOF_OR_DRAIN")
    need(harness.contexts and all(c.test_closed for c in harness.contexts), "CONTEXT_NOT_CLOSED")
    need(owners and all(x.closed for x in owners), "TRACKED_ARTIFACT_READER_NOT_CLOSED")
    need(all(getattr(x, "source", None) is None or x.source.closed
             for x in owners), "TRACKED_PHYSICAL_FILE_NOT_CLOSED")
    need(not harness.backend_calls, "FAULT_CASE_BACKEND_STUB_FORBIDDEN")
    return {**{k: v for k, v in state.items()
               if k not in ("text", "binary", "source", "io_metrics")},
            "injected_error": str(marker), "same_error_propagated": True,
            "all_tracked_readers_closed": True, "tracked_reader_count": len(owners),
            "all_contexts_closed": True, "context_count": len(harness.contexts),
            "io_metrics": state["io_metrics"],
            "injection_boundary": "Private c9_stream.bounded_metadata(stdout) -> declared ArtifactIO text reader -> second physical read",
            "binary_to_text_boundary_is_test_only": True,
            "parent_Job0": "REQUIRES_CONTROLLER_ACTUAL_PROOF",
            "new_native_execution": 0}


def run(args):
    started = time.monotonic()
    need(sys.dont_write_bytecode and not sys.flags.optimize, "REQUIRES_B_ASSERTIONS_ON")
    admission_raw = raw_small(args.admission)
    need(hashlib.sha256(admission_raw).hexdigest() == args.admission_sha256, "ADMISSION_RAW_SHA")
    admission = parse(admission_raw)
    need(admission.get("approved") is True and admission.get("writers_frozen") is True,
         "ADMISSION_NOT_APPROVED_FROZEN")
    need("CAPTURE_EVIDENCE_DELTA" in admission["allowed_groups"]
         and admission["group_caps_seconds"]["CAPTURE_EVIDENCE_DELTA"] == 120,
         "EXACT_DELTA_ADMISSION")
    deadline = datetime.fromisoformat(admission["deadline"])
    need(deadline.tzinfo is not None and
         (deadline - datetime.now(timezone.utc)).total_seconds() >= 120,
         "FULL_DELTA_WINDOW_REQUIRED")
    own = stamp(__file__)
    named_pin = (admission["source_pins"].get(own["path"])
                 if isinstance(admission["source_pins"], dict) else None)
    need((named_pin is not None and identity_fields(named_pin) == identity_fields(own))
         or any(path(r["path"]) == path(__file__) and identity_fields(r) == identity_fields(own)
                for r in descriptors(admission)), "WORKER_SOURCE_NOT_PINNED")
    output = path(args.output)
    need(output != R02 and output.is_relative_to(R02), "DELTA_OUTPUT_SCOPE")
    output.mkdir(parents=True, exist_ok=False)
    result = {"schema": "M3_R12_CAPTURE_EVIDENCE_DELTA_RESULT_V1",
              "status": "RUNNING", "cases": [], "admission": stamp(args.admission),
              "worker": own, "native_tool_calls": 0, "real_verified": False,
              "math_verified": False, "board_release_allowed": False,
              "parent_Job0": "REQUIRES_CONTROLLER_ACTUAL_PROOF"}
    planned = ("DYNAMIC_PINNED_CAPTURE_CHAIN", "ACTIVE_VERIFIED_TEXT_READ_EXCEPTION")
    phase = "PREPARE_FROZEN_INPUTS"
    try:
        pins = {}
        value = admission["source_pins"]
        items = ({"path": k, **v} for k, v in value.items()) if isinstance(value, dict) else value
        source_map, raw_sources = {}, {}
        for ref in items:
            raw = verified(ref, 4 * CHUNK)
            canonical = path(ref["path"])
            normalized = canonical.relative_to(ROOT).as_posix()
            pins[normalized] = identity_fields(ref)
            descriptor = {"path": normalized, **identity_fields(ref)}
            source_map[str(canonical).casefold()] = descriptor
            raw_sources[normalized] = raw
        need(all((SOURCE / n).relative_to(ROOT).as_posix() in pins for n in NAMES),
             "FROZEN_NINE_INCOMPLETE")
        need(all(path(r["path"]) == path(__file__) or stamp(r["path"])["sha256"] == r["sha256"]
                 for r in admission.get("dependency_inputs", [])), "DEPENDENCY_INPUT_CHANGED")
        dependency = parse(verified(admission["dependencies_ref"]))
        for ref in dependency["old_source_files"]:
            verified(ref, 4 * CHUNK)
            canonical = path(ref["path"])
            source_map[str(canonical).casefold()] = {
                "path": canonical.relative_to(ROOT).as_posix(), **identity_fields(ref)}
        helper_name = (SOURCE / "selftest.py").relative_to(ROOT).as_posix()
        helper = types.ModuleType("_r02_frozen_capture_evidence_helper")
        helper.__file__, helper.__package__ = str(SOURCE / "selftest.py"), ""
        exec(compile(raw_sources[helper_name], helper.__file__, "exec", dont_inherit=True), helper.__dict__)
        fixture = helper.get_fixture(admission)
        envelope = helper.verified_document(fixture["envelope_ref"])
        expected = helper.verified_document(fixture["expected_ref"])
        request = helper.verified_document(envelope["request"])
        need(expected["row_count"] == 7 and fixture["synthetic"] is True, "ONLY_FROZEN_SMALL_SYNTHETIC")
        write(output / "INPUT_IDENTITIES.json", {
            "sources": list(source_map.values()), "fixture": fixture,
            "expected": fixture["expected_ref"], "source_freeze_verified": True})
        harness = helper.CaptureHarness(pins, admission["dependencies_ref"])
        trace_path = output / "CASE01_CALL_TRACE.jsonl"
        phase = planned[0]
        with OrderedTrace(trace_path, source_map, started + 116) as trace:
            value = harness.process(envelope, output / "CASE01_ACTUAL")
        actual = helper.assert_capture_expected(value, expected, harness)
        chain = trace.assert_chain()
        result_ref = write(output / "CASE01_ACTUAL_RESULT.json", value)
        result["cases"].append({"case": "DYNAMIC_PINNED_CAPTURE_CHAIN", "status": "PASS",
                                "actual": actual, "ordered_dynamic_chain": chain,
                                "full_trace": stamp(trace_path), "actual_result": result_ref})
        need(time.monotonic() - started < 116, "DELTA_WALL_BUDGET")
        phase = planned[1]
        fault = active_text_case(helper, pins, admission["dependencies_ref"], envelope,
                                 request, output / "CASE02_ACTUAL")
        fault_ref = write(output / "CASE02_ACTIVE_TEXT_EXCEPTION.json", fault)
        result["cases"].append({"case": "ACTIVE_VERIFIED_TEXT_READ_EXCEPTION", "status": "PASS",
                                "evidence": fault_ref})
        for descriptor in source_map.values():
            verified(descriptor, 4 * CHUNK)
        need(len(result["cases"]) == 2 and time.monotonic() - started <= 120, "DELTA_COUNT_OR_CAP")
        result.update(status="PASS", exit_code=0)
    except BaseException as error:
        result.update(status="FAIL", exit_code=1, failed_phase=phase,
                      error=type(error).__name__, reason=str(error))
        import traceback
        result["traceback"] = traceback.format_exc()
    recorded = {case["case"] for case in result["cases"]}
    for name in planned:
        if name not in recorded:
            result["cases"].append({"case": name,
                                    "status": "FAIL" if name == phase else "NOT_STARTED"})
    result["cases"].sort(key=lambda item: planned.index(item["case"]))
    if (output / "CASE01_CALL_TRACE.jsonl").exists():
        result["full_trace"] = stamp(output / "CASE01_CALL_TRACE.jsonl")
    result.update(elapsed_seconds=time.monotonic() - started,
                  ended_utc=datetime.now(timezone.utc).isoformat())
    write(output / "GROUP_RESULT.json", result)
    print(json.dumps({"status": result["status"], "exit_code": result["exit_code"],
                      "result": stamp(output / "GROUP_RESULT.json")}))
    return result["exit_code"]


def identity_fields(ref):
    return {key: ref[key] for key in ("bytes", "sha256")}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        return run(args)
    except BaseException as error:
        print(json.dumps({"status": "PRELAUNCH_FAIL", "error": type(error).__name__,
                          "reason": str(error)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
