"""One located preflight repair; preserve failed slot and charge all new work."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import types

R = Path.cwd().resolve()
Q = R / "code/output/m3_frontend_close_r12_20261018/RECOVERY_R02_20261018"
N = "m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018"
S, D = R / "code/software" / N, R / "code/docs/test" / N


def read(p):
    return json.loads(p.read_text("utf-8"))


def save(p, obj):
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    tmp.replace(p)


def stamp(p):
    digest, count = hashlib.sha256(), 0
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            count += len(block)
            digest.update(block)
    return {"path": p.relative_to(R).as_posix(), "bytes": count, "sha256": digest.hexdigest()}


def verify(admission):
    for name, ref in admission["source_pins"].items():
        actual = stamp(R / name)
        assert actual["bytes"] == ref["bytes"] and actual["sha256"] == ref["sha256"]


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("init", "contract", "run"))
parser.add_argument("slot", nargs="?")
parser.add_argument("--admission-sha256")
args = parser.parse_args()
ledger = read(Q / "CONSUMPTION.json")
if args.mode == "init":
    failed = ledger["slots"]["GATE_ENV_R02"]
    assert failed["state"] == "FAILED_STOP" and failed["actual_result"]["exit_code"] == 97
    assert (Q / "RUNS/GATE_ENV_R02/stdout.bin").read_bytes() == b""
    assert b"Get-FileHash" in (Q / "RUNS/GATE_ENV_R02/stderr.bin").read_bytes()
    assert not (Q / "RUNS/GATE_ENV_R02/ENVIRONMENT_PROOF.json").exists()
    assert read(Q / "R01_CONSUMPTION_AT_RESUME.json")["groups"]["SOFTWARE_FIX_DIAG"]["charged_seconds"] == 60
    for name, cap in (("SOFTWARE_FIX_DIAG_02", 60), ("GATE_ENV_R02_ACTUAL", 900)):
        assert name not in ledger["slots"]
        ledger["slots"][name] = {"state": "NOT_STARTED", "attempts": 0, "charged_seconds": 0, "cap_seconds": cap}
    failed["actual_standard_gate_started"] = False
    failed["prelaunch_failure_preserved_no_refund"] = True
    save(Q / "CONSUMPTION.json", ledger)
    admission = read(Q / "ADMISSION_DELTA.json")
    admission["repair_authority"] = stamp(Q / "PRELAUNCH_REPAIR_FIX01.json")
    for name in ("preflight_fix01.py", "GATE_CHILD_R02_FIX01.ps1"):
        ref = stamp(Q / name)
        admission["source_pins"][ref["path"]] = {"bytes": ref["bytes"], "sha256": ref["sha256"]}
    assert not (Q / "ADMISSION_FIX01.json").exists()
    save(Q / "ADMISSION_FIX01.json", admission)
    print(json.dumps(stamp(Q / "ADMISSION_FIX01.json")))
elif args.mode == "contract":
    assert args.slot in ("SOFTWARE_FIX_DIAG_02", "GATE_ENV_R02_ACTUAL", "GATE_02")
    contract = read(Q / "CONTRACT_GATE_ENV_R02.json")
    contract.update(output=str(Q / "RUNS" / args.slot),
                    not_before=datetime.now(timezone.utc).isoformat(),
                    slot="GATE_02" if args.slot == "GATE_02" else "GATE_ENV_R02",
                    preflight_only=args.slot == "SOFTWARE_FIX_DIAG_02",
                    actual_slot=args.slot, repair_authority=stamp(Q / "PRELAUNCH_REPAIR_FIX01.json"),
                    worker=stamp(Q / "GATE_CHILD_R02_FIX01.ps1"))
    contract["files"] = [stamp(R / ref["path"]) for ref in contract["files"]]
    target = Q / ("CONTRACT_" + args.slot + ".json")
    assert not target.exists()
    save(target, contract)
    print(json.dumps(stamp(target)))
else:
    assert args.slot in ("SOFTWARE_FIX_DIAG_02", "GATE_ENV_R02_ACTUAL", "GATE_02")
    slot = ledger["slots"][args.slot]
    assert slot["state"] == "NOT_STARTED" and slot["attempts"] == 0
    if args.slot == "GATE_ENV_R02_ACTUAL":
        assert ledger["slots"]["SOFTWARE_FIX_DIAG_02"]["state"] == "PASS"
    if args.slot == "GATE_02":
        assert ledger["slots"]["GATE_ENV_R02_ACTUAL"]["state"] == "PASS"
        assert ledger["slots"]["S1_R02"]["state"] == "PASS"
    raw = (Q / "ADMISSION_FIX01.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == args.admission_sha256
    admission = json.loads(raw)
    verify(admission)
    contract_path = Q / ("CONTRACT_" + args.slot + ".json")
    contract = read(contract_path)
    for ref in contract["files"]:
        assert stamp(R / ref["path"]) == ref
    assert (datetime.fromisoformat(contract["deadline"]) - datetime.now(timezone.utc)).total_seconds() >= 901
    cap = slot["cap_seconds"]
    slot.update(state="CONSUMED_BEFORE_LAUNCH", attempts=1, charged_seconds=cap,
                started_utc=datetime.now(timezone.utc).isoformat(), admission=stamp(Q / "ADMISSION_FIX01.json"))
    save(Q / "CONSUMPTION.json", ledger)
    source = S / "selftest.py"
    module = types.ModuleType("_r12_fix01_existing_owned_supervisor")
    module.__file__ = str(source)
    exec(compile(source.read_bytes(), str(source), "exec", dont_inherit=True), module.__dict__)
    argv = [contract["shell"]["path"], "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
            str(Q / "GATE_CHILD_R02_FIX01.ps1"), "-ContractPath", str(contract_path),
            "-ContractSha256", stamp(contract_path)["sha256"]]
    if args.slot == "SOFTWARE_FIX_DIAG_02":
        argv.append("-PreflightOnly")
    run = Q / "RUNS" / args.slot
    result = module.owned_call(argv, R, run, cap)
    good = result["exit_code"] == 0 and result["within_cap"] and result["job_zero_observed_before_job_close"] and result["job_handle_closed"] and result["root_process_handle_closed"]
    verify(admission)
    for ref in contract["files"]:
        assert stamp(R / ref["path"]) == ref
    output = (run / "stdout.bin").read_text("utf-8", errors="replace")
    if args.slot == "SOFTWARE_FIX_DIAG_02":
        good = good and "R12_PREFLIGHT_ONLY_NO_GATE_LAUNCH" in output
    else:
        checks = re.findall(r"^\s*\[(PASS|FAIL)\] (.+)$", output, re.M)
        good = good and len(checks) == 9 and all(x[0] == "PASS" for x in checks) and "All repository checks passed." in output
        save(run / "NINE_CHECKS.json", {"checks": checks, "all_pass": good, "contract": stamp(contract_path)})
    slot.update(state="PASS" if good else "FAILED_STOP", ended_utc=datetime.now(timezone.utc).isoformat(), actual_result=result)
    save(Q / "CONSUMPTION.json", ledger)
    print(json.dumps({"slot": args.slot, "state": slot["state"], "exit": result["exit_code"], "elapsed_seconds": result["elapsed_seconds"]}))
    raise SystemExit(0 if good else result["exit_code"] or 3)
