"""Ignored final receipt for successful publication and outer-seal actuals."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

R = Path.cwd().resolve()
O = R / "code/output/m3_frontend_close_r12_20261018"
Q = O / "RECOVERY_R02_20261018"
GIT = "C:/Program Files/Git/cmd/git.exe"


def read(p):
    return json.loads(p.read_text("utf-8"))


def stamp(p):
    sha, count = hashlib.sha256(), 0
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            sha.update(block)
            count += len(block)
    return {"path": p.relative_to(R).as_posix(), "bytes": count, "sha256": sha.hexdigest()}


def query(*args):
    p = subprocess.run([GIT, *args], cwd=R, stdin=subprocess.DEVNULL,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    assert p.returncode == 0, p.stderr.decode("utf-8", "replace")
    return p.stdout


ledger = read(Q / "CONSUMPTION.json")
assert all(ledger["slots"][name]["state"] == "PASS" for name in
           ("CAPTURE_EVIDENCE_DELTA", "SOFTWARE_FIX_DIAG_02", "GATE_ENV_R02_ACTUAL", "S1_R02", "GATE_02", "S2_R02"))
assert ledger["slots"]["GATE_ENV_R02"]["state"] == "FAILED_STOP"
actual = read(Q / "PUBLICATION_ACTUAL.json")
assert actual["state"] == "REMOTE_VERIFIED" and actual["remote_containment"]
sha = actual["result_commit"]
assert len(sha) == 40 and query("rev-parse", "HEAD").decode().strip() == sha
contract = read(Q / "CONTRACT_GATE_02.json")
for ref in contract["files"]:
    assert stamp(R / ref["path"]) == ref
archive = read(Q / "FINAL_HANDOFF_MANIFEST.json")["archive"]
assert stamp(R / archive["path"]) == {k: archive[k] for k in ("path", "bytes", "sha256")}
assert archive["CRC_verified"] and archive["member_SHA_verified"]
before = read(Q / "R01_CONSUMPTION_AT_RESUME.json")
prior_groups = {**before["groups"], **before["formal_original_slots"]}
prior = sum(x["charged_seconds"] for x in prior_groups.values()) + sum(x["charged_seconds"] for x in before["network"]["operations"]) + 240
current_slots = sum(x["charged_seconds"] for x in ledger["slots"].values())
network = sum(x["charged_seconds"] for x in ledger["network"]["operations"])
record = {"schema": "M3_R12_R02_FINAL_DELIVERY_V1", "status": "M3_SOFTWARE_DELIVERABLE_COMPLETE_REMOTE_VERIFIED_AWAITING_M2_REVIEW",
    "recorded_utc": datetime.now(timezone.utc).isoformat(), "result_commit": sha, "receipt_commit": None,
    "publication": actual, "outer_archive": archive, "outer_archive_manifest": stamp(Q / "FINAL_HANDOFF_MANIFEST.json"),
    "outer_S2_result": ledger["slots"]["S2_R02"]["actual_result"],
    "outer_S2_parent_completion_is_external_to_its_own_zip": True,
    "new_software_assertions": 2, "old40_reused_without_replay": True, "total_software_assertions": 42,
    "ordered_key_function_dynamic_trace_persisted": True, "active_verified_text_exception_no_drain_proved": True,
    "corrected_candidate_gate": ledger["slots"]["GATE_ENV_R02_ACTUAL"], "final_gate": ledger["slots"]["GATE_02"],
    "source9_unchanged_from_R01": True, "all32_published_bytes_frozen_after_final_gate": True,
    "old_failure_originals_and_charges_preserved": True,
    "prelaunch_exit97": ledger["slots"]["GATE_ENV_R02"],
    "prelaunch_fix_diagnostic": ledger["slots"]["SOFTWARE_FIX_DIAG_02"],
    "validation_level": "L1_R12_SOFTWARE_PLUS_STANDARD_REPOSITORY_GATE_SMOKES",
    "scope_limits": ["C uses frozen synthetic7-row original; W uses synthetic1,398,627,657-byte frontend and private D4 boundary",
                     "Full real Pro capture/C9 and M1 numerical acceptance/timing/board not performed",
                     "T007/T019 existing RTL smokes ran only as part of the two unchanged standard gates"],
    "M2_ACCEPTED": False, "INTEGRATED": False, "board_release_allowed": False,
    "consumption": {"historical_cap_seconds_preserved": prior, "R02_slot_cap_seconds": current_slots,
                    "R02_network_cap_seconds": network, "R02_network_operations": len(ledger["network"]["operations"]),
                    "cumulative_cap_seconds": prior + current_slots + network,
                    "cap_charge_is_not_actual_elapsed": True, "token_or_currency_usage": "UNKNOWN",
                    "old_native_per_tool_counts": "UNKNOWN_NO_REFUND", "ledger": stamp(Q / "CONSUMPTION.json")},
    "user_resumed_plan": stamp(Q / "EXECUTION_PLAN.json"), "located_preflight_repair": stamp(Q / "PRELAUNCH_REPAIR_FIX01.json"),
    "recurring_monitor": "DELETED_NOT_RECREATED", "next_owner": "M2_increment_only_final_review"}
target = Q / "FINAL_DELIVERY_RECEIPT.json"
assert not target.exists()
target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
message = (
    "M2：M3 R12软件前端交付已完成实现、自审、限定验证、两段封存和普通develop发布，等待你仅复核本次增量。\n"
    "完整成果SHA：" + sha + "；收据提交SHA=null（最终门禁后未追加metadata提交，实际回执只在ignored输出）。远端包含性已核。\n"
    "源9保持原R01已测SHA；原J12/G12经唯一R/C12/W4共40项复用不重跑。新增2项实际补证PASS：真实R12→R11→R10→D4→IdentityFacade.checked/ref有序嵌套关键函数轨迹，以及活跃verified文本读1字节后第二次物理读异常，同一异常传播、无追加/关闭排空且所有文件/上下文关闭。\n"
    "候选与最终标准九门禁均9/9 PASS、自然退出0、Job0及句柄关闭齐套；使用原PowerShell/EDA/脚本。子进程Python解析和PS5原生模块来源均实核，仅进程PATH/PSModulePath修正。第一次入口预检exit97尚未调用check_repo，原900秒及日志保留，修后60秒metadata-only预检另计；未抹除旧Gate01/旧G/旧S1失败或旧消费。\n"
    "S1_R02/S2_R02各一次通过，最终32个发布文件相对最终门禁冻结字节核同。最终包：" + str(R / archive["path"]) + "\n"
    "ZIP SHA256=" + archive["sha256"] + "; bytes=" + str(archive["bytes"]) + "; 全成员SHA/CRC已核。外层S2完成证据另附FINAL_DELIVERY_RECEIPT.json。\n"
    "限定L1软件；标准门禁内原有T007/T019 RTL冒烟另有PASS，未外推真实Pro完整capture/C9、M1数学、时序、实物。W的1,398,627,657B合成raw原件、21无损分卷/全局SHA保留，峰值39,153,664B原实测复用。M2_ACCEPTED/INTEGRATED/board_release_allowed仍false。\n"
    "累计计费cap秒=" + str(prior + current_slots + network) + "（历史" + str(prior) + "，本轮组" + str(current_slots) + "，本轮网络" + str(network) + "），不是实际用时；token/金额及旧逐native次数UNKNOWN。\n"
    "用户明确解除20:09截止，本轮沿用同一主窗口和消费台账，不重开旧额度。七协作窗口均可调配，本轮夜间3/5准备、总控集成及唯一执行/发布；审核员制度和定时GitHub监测均未启用。\n"
    "请限定复核该成果SHA及可达原件，决定ACCEPTED/INTEGRATED并由M2更新状态/看板；不全面重审R11旧3c5101f19daa85b85d43082d9cadaca37fcbea13和ec833d1955fdf5e9cdd2224fbcbc342ba5c1e07f。真人消息待用户转发，尚未声称已通知真人。\n")
(Q / "FORWARD_TO_M2.txt").write_text(message, encoding="utf-8", newline="\n")
print(json.dumps({"receipt": stamp(target), "archive": archive, "result_commit": sha,
                  "consumption": record["consumption"]}, ensure_ascii=False))
