import hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_HOUR_REPLAY_09'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
proposal=D/'CLOSING_SUPPLEMENT_PROPOSAL.json';assert hashlib.sha256(proposal.read_bytes()).hexdigest()=='fafc4d2dc584aeeeac3502036f066d0a34dce7578bd8c612148d38afa60253d9'
auth={'schema':'M3_R13_W_HOUR_CLOSING_APPROVAL_V1','approved':True,'approved_proposal_sha256':'fafc4d2dc584aeeeac3502036f066d0a34dce7578bd8c612148d38afa60253d9','authority':'Direct user answer: 批准补充计划','recorded_utc':datetime.now(timezone.utc).isoformat(),'deadline':'2026-10-19T12:00:00+08:00','new_transport_only':{'operations_max':3,'charged_cap_seconds_max':390},'W_once_cap_seconds':3600,'no_old_consumption_reset':True}
save(D/'AUTHORIZATION_CLOSING.json',auth)
save(D/'CLOSING_CONSUMPTION.json',{'schema':'M3_R13_W_HOUR_INCREMENTAL_TRANSPORT_V1','deadline':auth['deadline'],'network':{'operations':[],'operations_max':3,'charged_cap_seconds_max':390},'authority_sha256':hashlib.sha256((D/'AUTHORIZATION_CLOSING.json').read_bytes()).hexdigest(),'old_R13_network_18_ops_900_seconds_not_reopened':True,'purpose':'Only current full-W upload300/download60/notify30; source push/fetch remains in original ledger'})
l=read(O/'CONSUMPTION_LIVE.json');shutil.copyfile(O/'CONSUMPTION_LIVE.json',D/'CONSUMPTION_BEFORE_HOUR_REPLAY.json');assert 'W_HOUR_09' not in l['recovery_attempts'];l['deadline_before_hour_replay']=l['deadline'];l['deadline']=auth['deadline'];l['hour_replay_authorization']={'path':(D/'AUTHORIZATION_CLOSING.json').relative_to(R).as_posix(),'sha256':hashlib.sha256((D/'AUTHORIZATION_CLOSING.json').read_bytes()).hexdigest()};l['recovery_attempts']['W_HOUR_09']={'state':'NOT_STARTED','attempts':0,'charged_seconds':0,'cap_seconds':3600,'cases_max':1,'authority':l['hour_replay_authorization']};save(O/'CONSUMPTION_LIVE.json',l)
save(O/'scheduler_state/W_HOUR_REPLAY_AUTHORITY.json',{'latest_user_supersedes_no_full_replay_for_one_run':True,'new_slot':'W_HOUR_09','cap_seconds':3600,'deadline':auth['deadline'],'old_no_replay_terminal_is_historical':True,'one_publisher':'01a14050-cd98-7c41-8004-5d3e25765167','all_old_failures_and_consumption_preserved':True})
print(json.dumps({'closing_authorization_sha256':hashlib.sha256((D/'AUTHORIZATION_CLOSING.json').read_bytes()).hexdigest(),'deadline':l['deadline'],'W_slot':'W_HOUR_09'}))
