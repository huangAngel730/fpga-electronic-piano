# R13 全局预写预算 R03：一份静态候选与集成清单

状态：`STATIC_CANDIDATE_L0_NOT_RUN`，不代签 GO，不改旧源或正式 C13，不改 R02/旧交付。
唯一候选 `global_budget_r03.py`：24918 B，SHA256
`936cba30e9c96f4710ace4998eaa85f455035b9977e356fd470266b436c351ed`。
用途仅限 root/main3 选择性合入 R13 resources 及私有接缝；不是新 runner。

## 按原任务澄清容量边界

W 前需证明产物峰值受限且可测，不要求预先证明压缩一定成功。
固定配额可以真实拒收不可压缩输入；该拒收是本次 W 的失败原件，首失败不重试，不签 PASS。
不能在 W 消费后增加配额、删产物、减少比较或重新启动来换取成功。

复算为整数 bytes，非十进制 GB：

| 全局分区 | bytes |
|---|---:|
| 全部 direct-gzip payload | 8,589,934,592 |
| DELIVERY 额外副本总载荷（若复制 plain raw 也占此分区） | 8,589,934,592 |
| 保留的 plain raw 输入总量 | 4,631,191,552 |
| baseline 分区 | 536,870,912 |
| plain/source/extract/snapshot/temp 合计 | 2,684,354,560 |
| manifest/failure/log/index ZIP 及其 tmp 合计 | 536,870,912 |
| 分配尾块、目录/文件元数据及文件系统余量 | 200,646,656 |
| **总计** | **25,769,803,776（24 GiB）** |

前两区＋raw 扣除后恰剩 3,958,743,040 B。再细分 512 MiB＋2.5 GiB＋512 MiB 后，
尚余 200,646,656 B。候选把元数据区拆成 control 480 MiB、failure/父层日志 32 MiB；
普通写者不能花 failure 区，但其日志 escrow 和实际错误报告仍需预先分配，不能重复承诺。

baseline 指所有已有文件的初始盘面，收据同时记录其实际字节及文件数；默认计入 baseline 分区。
若 W plain raw 已存在，须用冻结 `initial_roles={准确相对路径:'plain_raw'}` 将它计入 raw 分区，
不能既漏计又声称 baseline≤512 MiB。已有 gzip 等也须精确归类或保守留在 baseline，不能两次退款。

## 有限文件数与 allocation 尾块

候选上限是累计花掉的创建/重建/原子替换目标槽，不因文件删除而返还：

- 全部 payload gzip part ≤2048；单 part 的 32 MiB 物理上限必须由 open 的 file_limit 预写执行。
- DELIVERY payload/copy 文件槽 ≤2048；复制的普通控制对象仍走 control/failure ordinary 槽。
- ordinary 文件槽 ≤4096，内含 failure 预留≤128，正常 ordinary 最多3968。
- 总文件槽≤8192，目录≤4096；目录删除后不得复用同一目录名，临时目录使用预冻结有界新名。
- payload 的 decoded part 仍沿既有 31 MiB 切分，part 数超限可真实拒收，不能为通过改切窗。

root 提供实际 allocation unit A、逐文件额外元数据上界 F、逐目录上界 D 及证据；候选检查：

```text
8192*(A-1+F) + 4096*D <= 200646656
```

仅算术示例 A=F=D=4096 时，上界为 83,877,888 B，还余 116,768,768 B；
**不是本窗口已测得 NTFS 单位或元数据上界**。A=64KiB 时此组最大文件数一般放不进当前余量，
应预检拒绝或在 W 前冻结更紧的合法文件几何，不得 W 中途改限额。
证据必须涵盖命名/目录索引/MFT/临时文件等实际分配影响；只给 st_size、只猜 A=4096 不够。
整个 fs_allowance 在构造时永久占用，文件数与尾块不再混入每份 store 各自的 24 GiB。

## 候选接口及不变量

```python
budget = R13GlobalBudget(
    O,  # 必须是整个 m3_backend_stream_r13_20261018，而非某份 store 子目录
    allocation_unit_bytes=frozen_A,
    file_metadata_bound_bytes=frozen_F,
    directory_bound_bytes=frozen_D,
    filesystem_bound_evidence=frozen_evidence,
    initial_roles=exact_existing_roles,
    external_log_escrows=parent_frozen_finite_logs,
)
budget.mkdir(path, parents=True, exist_ok=True)
with budget.open(path, 'gzip_payload', 'xb', kind='payload_part',
                 file_limit=32*1024*1024) as physical_sink:
    # gzip.GzipFile(fileobj=physical_sink, ...) 的所有输出均经本 raw sink
    ...
with budget.open_text(control, 'control', 'x') as stream:
    ...  # 保留原 JSON 序列化选项；不能改 schema/finish/字段
budget.replace(temporary, final)
receipt = budget.receipt()
```

真实每次 FileIO.write 请求≤1 MiB，原逻辑 write 可更大但被分块；无缓冲物理写前先扣完整请求。
实际短写停止且不补写；IO 异常原对象通过 bare raise 传播，无法知道部分写字节时保留 unknown 上界，
不记为 0。覆盖/seek 回写 ZIP header 仍重复扣费，不退款；seek 只允许当前 extent 内，不扩洞。
显式 truncate 禁止；wb 的截断不会返还 baseline 或历史已扣额度。metadata/atomic tmp 同样走此 API。
close/context 中的二次错误被分列，不能覆盖原始业务或配额异常；旧外层 finally 也必须保持该性质。

每个 worker 中**所有 VolumeStore、普通 writer、生成/复制 writer 共用同一个对象**。
禁止分别 new 多个预算，禁止 fork/跨进程复制本对象；PID guard 只检查归属，不提供跨进程锁。
容量账与 actual IO、文件真实大小是不同指标：失败或覆盖会使 reserved 明显大于最终盘面，允许保守拒收。
receipt 返回 ACCOUNTING_ONLY_NOT_A_GO_DECISION，不把这些计数自动升级成资源 PASS。

父层旧 owner 不必为这项改写：root 在启动前冻结 stdout/stderr/RESULT/summary 各自有限 byte cap、
最大物理 write 及精确冻结输出语句依据，预留在 failure 32 MiB 中。
将同一 escrow 传入 worker 构造；日志即使已打开/已有少量字节，仍按**完整 cap**占用，不再扣一份 baseline。
所有父层输出必须落在这几份已资助 envelope 内，父层不能再持一套完整 24 GiB 配额写其它对象。
worker 结束后的 parent log 实际尺寸/封口由 root 另封父层收据，不伪造子进程中的共享可变账。
`settle_external_log` 只用于同一对象还存活且该日志真实关闭后的核账；实际超 cap 是 bound 破坏/失败。
父层 escrow 仅支持四个明确角色，不是任意外部工具的额度接口。

冻结输出上界必须计入实际 UTF-8 编码、换行和 traceback/argv/样本/manifest 数量；“有个 cap 数字”
本身不是外部写入受限证明。普通与异常输出都要有依据，不能只数成功 print。

## 全部已识别漏口：仅在 R13 私有命名空间适配

以下是必须接入的清单，不能只改 `_PartSink` 就宣布全写集闭合。未逐一闭合留显式缺口。

| 入口/当前绕过点 | 私有集成方法及归属 |
|---|---|
| root fixture 的 W plain raw、end/stdout/window plan、输入 JSON | raw 用同一预算 plain_raw；辅助文本/控制走 control 或 plain_aux，按冻结角色表分类。原 raw 保留，无 hidden raw 复制或压缩前同盘副本漏计 |
| 所有 VolumeStore 构造，包括 binding、finalize.audit 和读回时新建 store | 构造函数显式传 budget；只读 store 也不可偷偷创建新配额。移除每 store 独立 `_Quota(24GiB)`；不能仍保留一个默认 budget=None 自动新建的写路径 |
| `_PartSink.__init__/write/close` | current 改为上述 budget.open；删除旧 `quota.reserve(take)`，防双计/两套账；gzip header/data/footer 全经 current，单 part 上限在物理 write 前检查 |
| VolumeWriter 的 folder/part、`volume_io._atomic_json`、MANIFEST.json/tmp | mkdir 走 budget，manifest 走 control，tmp 与最终共存/原子 rename 计文件槽；writer close 失败不得继续发布 manifest |
| `binding._volume_policy.LogicalIO.open` 非流式 fallback | 写分支不能继续 super().open 原生落盘；二进制/plain 和 text 统一落 budget。只读分支保持原身份/EOF规则；不得将普通 JSON 误压成新业务格式 |
| ArtifactPath.mkdir/touch/write_bytes/write_text/rename/replace 与 `_PathFactory` | 私有 path/policy 绑定中的全部写入口转发预算；touch 也花文件槽。raw Path/fspath/builtins.open 一旦绕过代理，需要单独适配；不得修改全局 pathlib 或共享 sys.modules |
| `capture_identity.IdentityFacade.save` | 原 save 使用 `ji.safe_path` 后直接 `path.open('x')`，不经 LogicalIO。派生私有 Facade，save→budget.open_text、parent→budget.mkdir；**同时设置 write_json=save**，否则基类别名仍指旧 save；DependencyContext.facade 必须实际产生该私有类 |
| `json_identity.frozen_archive` | 原 ji 自己的 Path/tempfile 不经 ArtifactIO。私有替换此 contextmanager：有界私有目录、snapshot→plain_aux budget.open；保留同一字节流复制+hash、总长/SHA/EOF及原路径别名检查；正常临时清理不退款，失败原件按交接条件保留 |
| DependencyContext.snapshots/snapshot_stack、ArchiveFacade/SnapshotPath | 确认使用上项私有 frozen_archive，不回到原 ji 的无预算 writer；在私有 context 初始化前安装，不能在已缓存快照消费后补装 |
| 可达 `build_admission_bundle/c9_completion_r01/assembler.py` 的 `build_application` | payload 提取的 destination.open('xb') 与 SOURCE_APPLICATION_C9.zip 原包复制均计 plain_aux；source zip 自身与提取件、snapshot 可共存，合计不得超过2.5 GiB；所有 helper.write_json 走私有 Facade |
| assembler 的 ZipFile 读/seek、read_archive(raw member≤16MiB/总≤64MiB) | 此处是输入读，不能因只改输出预算便签全部物理 read≤1MiB。SnapshotPath 的底层读仍需受限 read facade/逐块 ZipExtFile 读，保留原成员内容/拒收规则及返回形状；当前旧 read(entry) 不能直接当物理请求已受限 |
| SOURCE/index ZIP 输出、提取、COPY/DELIVERY | ZipFile 应接 budget.open 的可 seek 无洞 raw fileobj，所有 seek header 覆盖再扣费；不能让 ZipFile(path) 自己原生开输出文件。提取/复制每文件/目录都注册；DELIVERY载荷全部占其8GiB，控制索引和ZIP/tmp占control，copy不能 hardlink |
| `finalize.atomic_json`、最终 COMPLETE、audit/resource/failure 收据 | tmp→control/failure budget.open，写后flush/fsync，再budget.replace；不得“写完再扣”；最终 marker 自身成本也计。audit 的 VolumeStore 沿用同一budget，最终全目录 census 含它们 |
| `entry.run` 目录创建及 except R13_FAILURE | 创建经 budget；失败原异常保留，失败 JSON 花预留 failure；即使 failure写入再失败，也记录secondary并原样传播首异常，不把quota拒收换成另一个错误；COMPLETE不出现/不撤销既成事实 |
| selftest `_save`、worker CONSUMPTION_RUNNING/WORKER_COMPLETE/WORKER_FAILURE、assembler失败finalization | 不能成为旁路；均按control/failure进同一账，所有输入fixture生成、tmp和失败文件纳入文件槽及共享总量 |
| root/job owner stdout/stderr/RESULT/父层摘要及其原子tmp | 只能使用上文冻结有限输出 escrow；保留旧 owner；root 原始尾收据/文件关闭后核实际大小和有限声明。额外未列日志须 W 前入预算，不得消费后扩新日志配额 |
| 任何 fd 暴露、shutil/tempfile/native/日志后端 | fileno 只给冻结的 fsync/fstat；os.write/ftruncate/mmap/duplicate fd 可绕过 wrapper。可达闭包中若存在须私有明确适配或列NO_GO，不以末尾扫描代替实际闭合 |

上述没有修改算法/模型/schema/finish。最小集成应在 C13 内进行私有注入；旧源码不改，受控闭包和新增
writer 映射由 root 冻结。未确认可达的 `serial/handoff.py` 不能因搜索命中就当本次执行过或强行纳入代码重构。

## root 的最终判据

1. W 前核定全局 bucket/分配单位和元数据上界、最大 part/普通文件数、所有 store 的共享对象身份、
   私有写闭包与 parent escrow。输出压缩结果本身可以未知，达到配额真实拒收。
2. W 的生成、实际 D4、gzip/复制、所有 hash/EOF/终检和清理都在原900s内；本候选不新增执行入口/组。
3. 后段失败时保留已写文件和原异常；不创建 COMPLETE、不重试 W，不把限额拒收签软件容量 PASS。
4. 成功还须实际内存/树归属/监督器、全读写 chunk、磁盘余量、原件通道等原门槛；此候选没有取消它们。
   before-write free 采样不是连续外部卷活动证明；其他卷写者仍需 root 的受控环境或保守下界证据。
5. receipt 的 baseline/reserved/known actual/unknown upper/文件槽/拒收数与最后真实全 O census 对照；
   known_live_file_lengths 不是已测物理盘面。父层封口完成后再最终签资源结果，不能只看 child COMPLETE。

## 本窗口实际执行边界

仅做文本读取、整数预算复算、字节/SHA/LF检查。候选未 import、AST、compile、测试、启动进程/Job，
未执行 Git 或网络。首次一次纯搜索命令使用了 PowerShell 不支持的 brace 列表语法，退出1；随后改为明确
路径读取成功，不是 W/P0/测试尝试。无目标额度消费。
本候选逐段静态审查了覆盖/短写/IO失败/close错误、文件重建/rename计槽、共享store、escrow归属及异常保留；
语法/API/ZipFile/io.TextIOWrapper/Windows文件系统实际兼容性与900s性能均未验证，须唯一执行入口按既有许可核。
交接后停止本辅助写集，等待总控新分派；旧R02及旧三候选保持原字节。
