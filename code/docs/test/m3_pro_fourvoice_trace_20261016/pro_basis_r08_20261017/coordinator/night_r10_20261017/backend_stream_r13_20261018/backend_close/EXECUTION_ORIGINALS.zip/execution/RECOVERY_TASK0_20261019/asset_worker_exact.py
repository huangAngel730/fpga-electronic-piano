"""Exact private draft-release payload transport; no target code execution."""
import argparse,hashlib,json,os,subprocess,sys,time,urllib.request,urllib.error
from pathlib import Path
from urllib.parse import urlparse,quote
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';D=O/'RECOVERY_TASK0_20261019'
p=argparse.ArgumentParser();p.add_argument('contract');p.add_argument('--sha256',required=True);a=p.parse_args()
c=Path(a.contract).resolve();raw=c.read_bytes();assert hashlib.sha256(raw).hexdigest()==a.sha256
v=json.loads(raw);assert v['method'] in ('upload','download','notify')
assert v['repository']=='huangAngel730/fpga-electronic-piano' and v['release_id']==416620891
deadline=time.monotonic()+v['cap_seconds']-3
def check():assert time.monotonic()<deadline,'TRANSPORT_CAP'
def digest(path):
 h=hashlib.sha256();n=0
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):check();n+=len(b);h.update(b)
 return {'bytes':n,'sha256':h.hexdigest()}
env=dict(os.environ);env.update(GCM_INTERACTIVE='never',GIT_TERMINAL_PROMPT='0')
git='C:/Program Files/Git/cmd/git.exe'
assert hashlib.sha256(Path(git).read_bytes()).hexdigest()=='851535ccc041bed536a23b17200cd51e7b06e266a527f4eaf8338b5c256c6466'
cred=subprocess.run([git,'-c','credential.interactive=false','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=8,env=env)
assert cred.returncode==0,'EXISTING_CREDENTIAL_UNAVAILABLE'
fields=dict(x.split(b'=',1) for x in cred.stdout.splitlines() if b'=' in x);token=fields.get(b'password',b'').decode();assert token
headers={'Authorization':'Bearer '+token,'User-Agent':'M3-exact-task-handoff','Accept':'application/vnd.github+json'}
repo=v['repository'];base='https://api.github.com/repos/'+repo
class SafeRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,hs,url):
  assert urlparse(url).hostname in ('api.github.com','uploads.github.com','release-assets.githubusercontent.com')
  r=super().redirect_request(req,fp,code,msg,hs,url)
  if r is not None:r.remove_header('Authorization')
  return r
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),SafeRedirect())
result={'schema':'M3_PRIVATE_ASSET_TRANSPORT_V1','operation_id':v['operation_id'],'method':v['method'],'request_headers_not_logged':True}
destination=D/(v['operation_id']+'_RESULT.json');assert not destination.exists()
if v['method']=='upload':
 f=(R/v['file']['path']).resolve();assert f.is_relative_to(O) and f.is_file()
 actual=digest(f);assert actual=={k:v['file'][k] for k in ('bytes','sha256')}
 assert actual['bytes']<=2*1024**3
 headers.update({'Content-Type':'application/zip','Content-Length':str(actual['bytes'])})
 url='https://uploads.github.com/repos/'+repo+'/releases/416620891/assets?name='+quote(v['asset_name'],safe='')
 class Chunks:
  def __iter__(self):
   with f.open('rb') as source:
    while True:
     check();b=source.read(1048576)
     if not b:break
     yield b
 req=urllib.request.Request(url,data=Chunks(),headers=headers,method='POST')
 with opener.open(req,timeout=min(30,max(1,deadline-time.monotonic()))) as response:
  b=response.read(1048576+1);assert len(b)<=1048576;value=json.loads(b);status=response.status
 assert status==201 and value['size']==actual['bytes']
 result.update(status='PASS',HTTP_status=status,asset_id=value['id'],asset_name=value['name'],file=v['file'],asset_api_url=value['url'],browser_download_url=value['browser_download_url'],github_digest=value.get('digest'))
elif v['method']=='download':
 assert isinstance(v['asset_id'],int)
 headers['Accept']='application/octet-stream'
 req=urllib.request.Request(base+'/releases/assets/'+str(v['asset_id']),headers=headers,method='GET')
 h=hashlib.sha256();n=0
 with opener.open(req,timeout=min(30,max(1,deadline-time.monotonic()))) as response:
  assert response.status==200
  while True:
   check();b=response.read(1048576)
   if not b:break
   n+=len(b);assert n<=v['file']['bytes'];h.update(b)
 assert n==v['file']['bytes'] and h.hexdigest()==v['file']['sha256']
 result.update(status='PASS',asset_id=v['asset_id'],download_back={'bytes':n,'sha256':h.hexdigest()},M2_RECEIVED=False,M2_ACCEPTED=False)
else:
 body=json.dumps({'body':v['body']},ensure_ascii=False).encode();assert len(body)<=16384
 headers['Content-Type']='application/json'
 req=urllib.request.Request(base+'/issues/1/comments',data=body,headers=headers,method='POST')
 with opener.open(req,timeout=20) as response:
  b=response.read(1048576+1);assert len(b)<=1048576;value=json.loads(b);assert response.status==201
 result.update(status='PASS',comment_url=value['html_url'],M2_AI_received=False)
check();destination.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ('operation_id','method','status','asset_id','comment_url') if k in result}))

