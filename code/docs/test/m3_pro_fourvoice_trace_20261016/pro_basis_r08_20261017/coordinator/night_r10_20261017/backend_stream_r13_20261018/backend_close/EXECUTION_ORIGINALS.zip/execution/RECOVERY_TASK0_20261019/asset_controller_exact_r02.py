"""One prospective exact asset operation under the frozen owned supervisor."""
import argparse,hashlib,json,types
from pathlib import Path
from datetime import datetime,timedelta,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019'
P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
OWNER=R/'code/software'/P/'frontend_close_r12_20261018/selftest.py'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=argparse.ArgumentParser();p.add_argument('contract');a=p.parse_args();cp=Path(a.contract).resolve();assert cp.is_relative_to(T)
v=read(cp);op=v['operation_id'];assert op.replace('_','').isalnum();cap=v['cap_seconds'];assert cap in (30,60,300)
ledgerpath=O/'CONSUMPTION_LIVE.json' if v['charge_scope']=='R13' else T/'STATIC_PUBLICATION_LEDGER.json'
if ledgerpath.exists():l=read(ledgerpath)
else:l={'scope':'Direct user request to upload completed R14 and task3 static units; no target execution allowance','network':{'operations':[],'operations_max':4,'charged_cap_seconds_max':120},'local_git':{'operations':[],'charged_cap_seconds_max':40},'deadline':read(T/'W_CODEC_PERFORMANCE_REPAIR_08/AUTHORIZATION_R01.json')['deadline']}
net=l['network'];assert len(net['operations'])<net['operations_max']
assert not any(x['operation_id']==op or x['state']=='RUNNING' for x in net['operations'])
assert sum(x['charged_seconds'] for x in net['operations'])+cap<=net['charged_cap_seconds_max']
if v['charge_scope']=='R13':assert sum(x['charged_seconds'] for x in net['operations'])+cap+360<=net['charged_cap_seconds_max'],'RESERVE_ORDINARY_PUSH_AND_FETCH'
assert datetime.now(timezone.utc)+timedelta(seconds=cap+60)<=datetime.fromisoformat(l['deadline'])
local=l['local_git'];assert sum(x.get('charged_seconds',0) for x in local['operations'])+10<=local['charged_cap_seconds_max']
row={'operation_id':op,'state':'RUNNING','action':'EXACT_PRIVATE_DRAFT_ASSET_'+v['method'],'charged_seconds':cap,'contract_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),'source_authority':'Latest direct user upload/Task0 instruction; no new service or credential'}
net['operations'].append(row);local['operations'].append({'operation_id':op+'_credential','charged_seconds':10,'state':'PRECHARGED','scope':'Existing Git helper credential in memory only'})
save(ledgerpath,l)
raw=OWNER.read_bytes();assert hashlib.sha256(raw).hexdigest()=='5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c'
m=types.ModuleType('_exact_asset_owner');m.__file__=str(OWNER);exec(compile(raw,str(OWNER),'exec',dont_inherit=True),m.__dict__);m.OUTPUT=O
argv=['C:/Users/songdongkuan/miniconda3/python.exe','-X','utf8','-B',str(T/'asset_worker_exact.py'),str(cp),'--sha256',row['contract_sha256']]
result=m.owned_call(argv,R,O/'NETWORK'/op,cap)
row.update(state='PASS' if result['exit_code']==0 else 'UNKNOWN_OR_FAILED',actual_result=result);local['operations'][-1]['state']='COMPLETED_OR_UNAVAILABLE_SECRET_NOT_LOGGED';save(ledgerpath,l)
print(json.dumps({'operation_id':op,'state':row['state'],'exit_code':result['exit_code'],'elapsed_seconds':result['elapsed_seconds']}))
raise SystemExit(0 if row['state']=='PASS' else 1)



