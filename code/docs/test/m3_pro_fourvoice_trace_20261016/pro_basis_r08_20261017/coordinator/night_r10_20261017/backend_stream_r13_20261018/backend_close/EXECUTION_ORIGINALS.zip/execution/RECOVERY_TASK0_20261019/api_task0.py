"""R13 root-only bounded Git transport using the frozen successful R12 owner."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import types

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
NAME = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
CLOSE = ROOT / 'code/docs/test' / NAME / 'backend_stream_r13_20261018/backend_close'
OWNER = ROOT / 'code/software' / NAME / 'frontend_close_r12_20261018/selftest.py'
GIT = Path('C:/Program Files/Git/cmd/git.exe')


def read(path):
    return json.loads(path.read_text('utf-8'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


parser=argparse.ArgumentParser();parser.add_argument('request_file');args=parser.parse_args()
request=Path(args.request_file).resolve();assert request.is_relative_to(OUT/'RECOVERY_TASK0_20261019')
value=read(request);op=value['request_id'];ledger=read(OUT/'CONSUMPTION_LIVE.json');net=ledger['network'];assert len(net['operations'])<net['operations_max']
assert not any(x['operation_id']==op or x['state']=='RUNNING' for x in net['operations'])
assert sum(x['charged_seconds'] for x in net['operations'])+30+360<=net['charged_cap_seconds_max']
assert datetime.now(timezone.utc)+timedelta(seconds=90)<=datetime.fromisoformat(ledger['deadline'])
raw=OWNER.read_bytes();assert hashlib.sha256(raw).hexdigest()=='5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c'
module=types.ModuleType('_task0_owner');module.__file__=str(OWNER);exec(compile(raw,str(OWNER),'exec',dont_inherit=True),module.__dict__);module.OUTPUT=OUT
row={'operation_id':op,'action':'TASK0_GITHUB_API','charged_seconds':30,'state':'RUNNING','method':value['method'],'endpoint':value['endpoint'],'authority':'RECOVERY_TASK0_20261019/USER_AUTHORITY_AND_QUEUE.json','route':'DIRECT_HTTPS'};net['operations'].append(row)
ledger['local_git']['operations'].append({'operation_id':op+'_credential_fill','state':'PRECHARGED','charged_seconds':10,'scope':'Git credential fill, secret output in worker memory only; no Git source write'})
save(OUT/'CONSUMPTION_LIVE.json',ledger)
destination=OUT/'NETWORK'/op
argv=['C:/Users/songdongkuan/miniconda3/python.exe','-X','utf8','-B',str(OUT/'RECOVERY_TASK0_20261019/github_worker.py'),str(request)]
result=module.owned_call(argv,ROOT,destination,30)
row.update(state='PASS' if result['exit_code']==0 else 'UNKNOWN_OR_FAILED',actual_result=result)
ledger['local_git']['operations'][-1]['state']='COMPLETED_OR_UNAVAILABLE_SECRET_NOT_LOGGED'
save(OUT/'CONSUMPTION_LIVE.json',ledger)
print(json.dumps({'operation_id':op,'state':row['state'],'exit_code':result['exit_code'],'elapsed_seconds':result['elapsed_seconds'],'worker_stdout':(destination/'stdout.bin').read_text('utf-8',errors='replace')[:2000]}));raise SystemExit(0 if row['state']=='PASS' else 1)
