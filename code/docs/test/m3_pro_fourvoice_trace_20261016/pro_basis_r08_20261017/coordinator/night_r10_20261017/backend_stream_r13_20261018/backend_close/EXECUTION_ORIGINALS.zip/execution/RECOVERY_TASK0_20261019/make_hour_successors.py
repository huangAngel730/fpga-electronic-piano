from pathlib import Path
R=Path.cwd().resolve();T=R/'code/output/m3_backend_stream_r13_20261018/RECOVERY_TASK0_20261019'
def save(name,text):
 p=T/name;assert not p.exists();p.write_text(text,encoding='utf-8',newline='\n')
w=(T/'w_codec_08_worker.py').read_text('utf-8');assert "W_CODEC_08" in w;save('w_hour_09_worker.py',w.replace('W_CODEC_08','W_HOUR_09'))
b=(T/'codec_08_bridge.py').read_text('utf-8');assert "'W':1800" in b;b=b.replace("'W':1800","'W':3600").replace("'w_codec_08_worker.py'","'w_hour_09_worker.py'");save('hour_09_bridge.py',b)
c=(T/'root_run_files_r01.py').read_text('utf-8');c=c.replace("'GATE_01':('W_CODEC_08',)","'GATE_01':('W_HOUR_09',)")
c=c.replace("'W_CODEC_08':'W'}","'W_CODEC_08':'W','W_HOUR_09':'W'}")
c=c.replace("('P1_FILES_R01','B_FILES_R01','W_CODEC_08')","('P1_FILES_R01','B_FILES_R01','W_CODEC_08','W_HOUR_09')")
c=c.replace("deadline = datetime.fromisoformat(ledger['deadline'])","extra=read(OUT/'RECOVERY_TASK0_20261019/W_HOUR_REPLAY_09/CLOSING_CONSUMPTION.json')\nremaining += extra['network']['charged_cap_seconds_max']-sum(x['charged_seconds'] for x in extra['network']['operations'])+120\ndeadline = datetime.fromisoformat(ledger['deadline'])")
c=c.replace("'GATE_CHILD_CODEC_08.ps1'","'GATE_CHILD_HOUR_09.ps1'").replace("'codec_08_bridge.py'","'hour_09_bridge.py'")
marker="raw = args.contract.read_bytes()";assert marker in c
c=c.replace(marker,"hour_auth=OUT/'RECOVERY_TASK0_20261019/W_HOUR_REPLAY_09/AUTHORIZATION_CLOSING.json'\nassert stamp(hour_auth)['sha256']=='138582298f07c5e3103005a05eb574be3c71af397d9b99bc1ae3483035e4ae79'\nassert read(hour_auth)['approved'] is True\n"+marker)
save('root_run_hour_09.py',c)
g=(T/'GATE_CHILD_CODEC_08.ps1').read_text('utf-8');g=g.replace('44f657f5ba91fe70734a540334ed40ef3546665fde316d598189eda4f0f68c46','138582298f07c5e3103005a05eb574be3c71af397d9b99bc1ae3483035e4ae79').replace('2026-10-19T10:00:00+08:00','2026-10-19T12:00:00+08:00');save('GATE_CHILD_HOUR_09.ps1',g)
print('Prepared four cap/path/authority successors; no candidate or test launched.')
