"""Current full-window admission metadata; never imports or generates target data."""
import hashlib
import json
import shutil
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
HERE = OUT / 'RECOVERY_TASK0_20261019'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'

def read(path):
    return json.loads(path.read_text('utf-8'))

def save(path, value):
    assert not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def ref(path):
    path = path.resolve()
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}

ledger = read(OUT / 'CONSUMPTION_LIVE.json')
assert ledger['groups']['W']['state'] == 'NOT_STARTED'
assert ledger['recovery_attempts']['B04_RECOVERY_05']['state'] == 'PASS'
assert ledger['recovery_attempts']['P1_B04_01']['state'] == 'PASS'
assert read(OUT / 'WRITE_LEASES_CLOSED.json')['all_target_writers_closed']
channel = HERE / 'DELIVERY_CHANNEL_R02_GITHUB.json'
assert read(channel)['state'] == 'PRIVATE_REPO_DRAFT_ASSET_UPLOADED_DOWNLOADED_BYTE_IDENTICAL'
remaining = sum(row['cap_seconds'] for row in ledger['groups'].values() if row['state'] == 'NOT_STARTED')
remaining += ledger['network']['charged_cap_seconds_max'] - sum(row['charged_seconds'] for row in ledger['network']['operations'])
remaining += ledger['local_git']['charged_cap_seconds_max'] - sum(row.get('charged_seconds', 0) for row in ledger['local_git']['operations'])
assert datetime.now(timezone.utc) + timedelta(seconds=remaining + 60) <= datetime.fromisoformat(ledger['deadline'])
free = shutil.disk_usage(OUT).free
assert free >= 32 * 1073741824
freeze_path = HERE / 'B04_SEAL_REPAIR/FREEZE.json'
freeze = read(freeze_path)
for item in freeze['frozen_files']:
    assert ref(Path(item['path'])) == item
controller = HERE / 'root_run_b04_repair.py'
go = {'schema': 'M3_R13_W_ADMISSION_V1', 'GO': True,
      'all_resource_and_source_requirements_met': True,
      'source_freeze': ref(freeze_path), 'actual_pins_P1': ref(OUT / 'RUNS/P1_B04_01/inner/GROUP_COMPLETE.json'),
      'actual_B_reconciliation': ref(OUT / 'RUNS/B04_RECOVERY_05/inner/GROUP_COMPLETE.json'),
      'K_V_old_actual_pass_preserved': True, 'free_before_launch_bytes': free,
      'remaining_all_caps_plus_margin_seconds': remaining + 60, 'deadline': ledger['deadline'],
      'memory': 'Actual whole owned Job member final lifetime PeakWorkingSet sum <=512MiB required; not extrapolated from P0 or B',
      'workspace': 'Same shared prewrite quotas, finite member/file limits and actual4096B allocation; all artifacts/temp/copies <=24GiB, reserve8GiB each physical write. Quota rejection fails W; no capacity success predeclared.',
      'input': '1130662 synthetic rows, all72 raw ports, fixed recipe/frame geometry, corrected pre-NBA mechanical zero PCM pins; no real HDL execution',
      'delivery_channel': ref(channel), 'future_W_remote_delivery_verified': False,
      'delivery_after_actual_export': 'Use same private repository draft asset channel; freeze actual full export size/hash/manifest first. Bounded task-specific compression/asset transfer must keep original bytes and consumption; if unavailable retain PARTIAL, never mark delivered.',
      'old_failures_and_consumption_preserved': True, 'recorded_utc': datetime.now(timezone.utc).isoformat()}
save(OUT / 'W_ADMISSION.json', go)
base = OUT / 'ADMISSIONS/W'
ap = base / 'ADMISSION.json'
owner = OUT / 'RUNS/W/inner'
python = str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
admission = read(OUT / 'ADMISSIONS/P1_B04_01/ADMISSION.json')
admission.update(group='W', absolute_cap_seconds=900, root_accounting_slot='W',
                 source_freeze=ref(freeze_path), prepared_utc=datetime.now(timezone.utc).isoformat(),
                 root_deadline_monotonic=time.monotonic() + 900, resource_profile='PASS')
admission['accounting_profile']['enforce_start_free'] = True
admission['external_log_escrows'] = {key.replace('RUNS/P1_B04_01/', 'RUNS/W/'): val for key, val in admission['external_log_escrows'].items() if '/inner/B03/' not in key and '/inner/B04/' not in key}
admission['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller'] = ref(controller)
admission['argv'] = [python, '-X', 'utf8', '-B', str(SOURCE / 'selftest.py'), '--worker', '--group', 'W',
                     '--admission', str(ap), '--admission-sha256', '@ADMISSION_SHA256@', '--output', str(owner / 'worker')]
wf = {'schema': 'M3_R13_W_INPUT_BINDER_FREEZE_V1', 'run_id': 'W01', 'nonce': uuid.uuid4().hex,
      'templates': admission['fixture_templates'],
      'physical_budgets': {'all_stores': 8589934592, 'delivery': 8589934592,
                           'raw_plain': 4631191552, 'all_other': 3958743040}}
wp = base / 'W_INPUT_FREEZE.json'
save(wp, wf)
admission['w_input_freeze_ref'] = ref(wp)
save(ap, admission)
contract = {'root_approved': True, 'slot': 'W', 'wire_group': 'W', 'plan_sha256': admission['plan_sha256'],
      'cap_seconds': 900, 'all_target_writers_closed': True,
      'frozen_files': [*freeze['frozen_files'], ref(freeze_path), ref(wp), ref(ap), ref(controller), ref(OUT / 'W_ADMISSION.json')],
      'target_script': str(SOURCE / 'job_bridge.py'),
      'argv': [python, '-X', 'utf8', '-B', str(SOURCE / 'job_bridge.py'), '--execute-one', '--admission', str(ap),
               '--admission-sha256', ref(ap)['sha256'], '--owner-output', str(owner)],
      'worker_result_relative_path': 'inner/worker/WORKER_COMPLETE.json',
      'bridge_result_relative_path': 'inner/GROUP_COMPLETE.json', 'expected_case_ids': ['W01']}
cp = base / 'ROOT_CONTRACT.json'
save(cp, contract)
print(json.dumps(ref(cp)))
