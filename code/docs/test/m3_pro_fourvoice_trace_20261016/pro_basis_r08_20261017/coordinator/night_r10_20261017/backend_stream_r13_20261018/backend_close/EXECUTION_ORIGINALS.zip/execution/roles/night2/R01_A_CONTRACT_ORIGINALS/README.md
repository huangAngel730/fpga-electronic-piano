# R13 A 合同总成候选

本目录九件同属 `M3_R13_CONTRACT_20261019_R01`，只组装已有源码/可达原件的机械合同及真实差额，不修改原schema、算法、公共出口或finish行为。交付等级为 **L0 静态候选**；测试、全窗生成、准入、消费、门禁、发布由夜间任务1唯一执行，后续实际结果在 `../backend_close/`，本目录不预写PASS。

从 `CONTRACT_INDEX.json` 进入。它为其他八件保存路径/字节/SHA；其他对象通过同一 bundle_id 与文件名回指索引，避免自含SHA循环。先核索引和上游权威，再读路由与profile、plan/epoch/finish，最后看一页决定表。所有来源ref均指实际文件，来源可信、执行许可和机械SHA相等分别判断。

- A1：`FIELD_ROUTE_TABLE.json` 逐项说明74字段的源公开位、宽度/符号、变换、时基、消费者及null/X/Z理由。72个raw信号和67个DUT公开观察口不是74字段的同一集合。
- A2：`PROFILE_AND_CAPACITY.json` 覆盖D4 raw43/public/CSV往返、intake、serial、math行索引/三类历史、metadata、ZIP快照/重建/分卷，不以raw尺寸代表全产物容量。静态估算不等于W实测；需冻结geometry、存储实现、资源和跨电脑通道再准入。
- A3：`PLAN_IDENTITY_MAP.json` 从原始独立plan复制63字节/23事件和各事件ID/到达窗，实际accept/apply保持null；`EPOCH_RESET_FINISH_CONTRACT.json` 保留D/D+1差额、PRE_NBA、真实reset边、全局行号、唯一finish/END/MONITOR_END与终末身份复查。
- A4：`SOURCE_PROVENANCE.json` 绑定原源码/ROM/include、拟议工具/argv/cwd及可公开环境摘要，显式区分真实原件缺失、合成声明receipt和已执行软件证据；`OPEN_DECISIONS.json` 与 `M2_DECISION_SHEET.md` 只列真实待决。

数学机械对象按实际D4为六件：`MATH_ROW_INDEX.jsonl`、`FX_HISTORY.jsonl`、`ADVANCE_HISTORY.jsonl`、`INPUT_AND_APPLY_HISTORY.jsonl`、`MATH_INPUT_BUNDLE.json`、`RECEIPT.json`。四流没有各自新造顶层schema；bundle/receipt沿用 `M3_D4_C9_MATH_INPUT_BUNDLE_V1`。17个 REQUIRED_ROLES 是原件依赖集合。第七件准确名称和可执行消费者合同为 `PENDING_M1_NAMING_AND_CONSUMER_CONTRACT`，未拿FRAME/public_rows凑件；B包提供原件入口和缺件恢复。本包不以六件存在冒称M1已接收。

W仅可使用明确合成的独立数据，≥1130662行且raw≥1398627657B，实际走完整D4后段，无私有D4替身。大对象实际读≤1MiB；单worker/有后代时并发树峰值≤512MiB；全workspace≤24GiB，启动free≥32GiB并保留≥8GiB。仓库路径 `EXECUTION_ORIGINALS.zip`须≤32MiB且能恢复所有逻辑原件；另一既有用户转发通道必须先明确位置与M2可取方法。压缩比未知或只在ignored本机，不构成通道通过。

当前通道更新：用户已在 `code/output/m3_backend_stream_r13_20261018/DELIVERY_CHANNEL_CONFIRMED.json` 确认人工转发 `DELIVERY/` 全目录，包含所有无损卷及清单。独立“缺可取通道选择”项已关闭；GitZIP≤32MiB只放索引/小原件，大卷不要求塞入该ZIP。M2_RECEIVED/M2_ACCEPTED仍false；实际卷名、字节和SHA由生产后原件封存，未预造。24GiB物理几何和其他W前置未因此通过。

真实Pro/HDL/C9、M1数学、时序和板卡仍PENDING，`board_release_allowed=false`。与合成软件容量的前置分层，不自动扩大阻断；整包R13_SW_COMPLETE由总控按原完成条件判定。NoteOn旧勘误已接受，不重提；R12旧42不重跑。七个窗口的协作、直接回传和本写集已经授权，不把静态自审升级成审核员制度。
