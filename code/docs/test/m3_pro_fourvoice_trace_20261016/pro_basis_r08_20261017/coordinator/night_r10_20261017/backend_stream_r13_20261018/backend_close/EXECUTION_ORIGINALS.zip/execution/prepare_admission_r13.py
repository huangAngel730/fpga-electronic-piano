"""Root-only frozen JSON construction, never imports/launches candidates."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
STEM = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
SOURCE = ROOT / 'code/software' / STEM / 'backend_stream_r13_20261018'
PYTHON = 'C:/Users/songdongkuan/miniconda3/python.exe'
PLAN = '729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3'
COUNTS = {'P0': ['P001'], 'K': [f'K{i:02d}' for i in range(1, 9)],
          'V': [f'V{i:02d}' for i in range(1, 13)],
          'B': [f'B{i:02d}' for i in range(1, 13)], 'W': ['W01']}


def read(path):
    return json.loads(path.read_text('utf-8'))


def save(path, value):
    assert not path.exists(), 'NEVER_OVERWRITE_FROZEN_ADMISSION'
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n',
                    encoding='utf-8', newline='\n')


def identity(path):
    count, digest = 0, hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            count += len(block)
            digest.update(block)
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT)
            else str(path), 'bytes': count, 'sha256': digest.hexdigest()}


parser = argparse.ArgumentParser()
parser.add_argument('slot', choices=(*COUNTS, 'P1', 'R'))
parser.add_argument('--extra', required=True, type=Path)
args = parser.parse_args()
ledger = read(OUT / 'CONSUMPTION_LIVE.json')
slot = ledger['groups'][args.slot]
assert slot['state'] == 'NOT_STARTED' and slot['attempts'] == 0
assert read(OUT / 'WRITE_LEASES_CLOSED.json')['all_target_writers_closed'] is True
repair = read(OUT / 'LOCATED_REPAIR.json') if args.slot in ('P1', 'R') else None
freeze_path = OUT / ('REPAIR_FREEZE.json' if repair else 'FREEZE_BEFORE_P0.json')
freeze = read(freeze_path)
assert freeze['state'] == ('REPAIR_FROZEN_BY_ROOT' if repair else 'FROZEN_BY_ROOT')
if repair:
    assert repair['failed_group'] in ('K', 'V', 'B')
    assert ledger['groups'][repair['failed_group']]['state'] == 'FAILED_STOP'
    assert repair['software_only_changed_sources_frozen'] is True
    assert freeze['located_repair_sha256'] == identity(OUT / 'LOCATED_REPAIR.json')['sha256']
for item in freeze['frozen_files']:
    path = Path(item['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = identity(path)
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], item['path']
extra_path = args.extra.resolve()
assert extra_path.is_relative_to(OUT)
extra = read(extra_path)
directory = OUT / 'ADMISSIONS' / args.slot
directory.mkdir(parents=True, exist_ok=False)
admission_path = directory / 'ADMISSION.json'
owner_output = OUT / 'RUNS' / args.slot / 'inner'
worker_output = owner_output / 'B02/worker' if args.slot == 'B' else owner_output / 'worker'
argv_template = [str(Path(PYTHON).resolve()), '-X', 'utf8', '-B',
                 str((SOURCE / 'selftest.py').resolve()), '--worker', '--group', args.slot,
                 '--admission', str(admission_path.resolve()), '--admission-sha256',
                 '@ADMISSION_SHA256@', '--output', str(worker_output.resolve())]
admission = {
    'plan_sha256': PLAN, 'group': args.slot, 'state': 'CONSUMED_RUNNING',
    'absolute_cap_seconds': slot['cap_seconds'], 'argv': argv_template,
    'control_declaration_only_not_consumption_evidence': True,
    'root_deadline_monotonic': time.monotonic() + slot['cap_seconds'],
    'prepared_utc': datetime.now(timezone.utc).isoformat(),
    'deadline': ledger['deadline'], 'actual_START': ledger['actual_START'],
    'source_freeze': identity(freeze_path),
}
assert not (set(extra) & set(admission)), 'EXTRA_CANNOT_OVERRIDE_ROOT_AUTHORITY'
admission.update(extra)
save(admission_path, admission)
admission_ref = identity(admission_path)
worker_name = ('WORKER_LOCAL_RESULT.json' if (args.slot in ('P0', 'P1', 'B') or (args.slot == 'R' and repair['failed_group'] == 'B'))
               else 'WORKER_COMPLETE.json')
contract = {
    'schema': 'M3_R13_ROOT_RUN_CONTRACT_V1', 'root_approved': True,
    'slot': args.slot, 'plan_sha256': PLAN, 'cap_seconds': slot['cap_seconds'],
    'all_target_writers_closed': True,
    'frozen_files': [*freeze['frozen_files'], identity(freeze_path),
                     admission_ref, identity(extra_path),
                     identity(OUT / 'root_run_r13.py')],
    'target_script': str((SOURCE / 'job_bridge.py').resolve()),
    'argv': [str(Path(PYTHON).resolve()), '-X', 'utf8', '-B',
             str((SOURCE / 'job_bridge.py').resolve()), '--execute-one',
             '--admission', str(admission_path.resolve()), '--admission-sha256',
             admission_ref['sha256'], '--owner-output', str(owner_output.resolve())],
    'worker_result_relative_path': (worker_output / worker_name).relative_to(
        OUT / 'RUNS' / args.slot).as_posix(),
    'bridge_result_relative_path': 'inner/GROUP_COMPLETE.json',
    'expected_case_ids': (['P001'] if args.slot == 'P1' else
                          repair['affected_case_ids'] if args.slot == 'R' else COUNTS[args.slot]),
    'repair_group': repair['failed_group'] if repair else None,
}
contract_path = directory / 'ROOT_CONTRACT.json'
save(contract_path, contract)
print(json.dumps({'admission': admission_ref, 'root_contract': identity(contract_path),
                  'not_launched': True, 'consumption_unchanged': True}))
