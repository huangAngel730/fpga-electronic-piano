"""Production entry for one R13 backend streaming candidate run."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import traceback
import uuid

import binding
import finalize
import resources
from stream_bridge import (Reject, identity, read_control,
                           read_descriptor_json, require, strict_child)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
OUTPUT_ROOT = ROOT / "code/output/m3_backend_stream_r13_20261018"
CONTROL_FIELDS = {"schema", "run_id", "run_kind", "envelope_ref",
                  "dependencies_ref", "quota_bytes", "volume_policy",
                  "authority"}


def validate_control(value: dict) -> None:
    require(type(value) is dict and set(value) == CONTROL_FIELDS,
            "R13_CONTROL_FIELDS")
    require(value["schema"] == "M3_R13_BACKEND_CONTROL_V1",
            "R13_CONTROL_SCHEMA")
    require(value["run_kind"] in ("SYNTHETIC_SOFTWARE", "FORMAL_REAL"),
            "R13_RUN_KIND")
    require(value["volume_policy"] == "GZIP_32M_PARTS_IO_1M",
            "R13_VOLUME_POLICY")
    require(value["authority"] == {
        "execution_allowed": False, "real_verified": False,
        "math_verified": False, "board_release_allowed": False},
        "R13_FALSE_AUTHORITY")
    require(type(value["quota_bytes"]) is int and
            0 < value["quota_bytes"] <= resources.WORKSPACE_LIMIT,
            "R13_QUOTA")
    if value["run_kind"] == "FORMAL_REAL":
        # D4 has six mathematical outputs.  Its seven-input M1 consumer still
        # needs the signed streaming-index/reset projection adapter; do not
        # silently promote the software successor to a formal REAL run.
        raise Reject("R13_FORMAL_REAL_CONSUMER_ADAPTER_PENDING")


def run(control_path: Path, control_sha256: str, final_dir: Path) -> dict:
    require(sys.dont_write_bytecode and not sys.flags.optimize,
            "R13_REQUIRES_B_ASSERTIONS_ON")
    control_path = Path(control_path).resolve()
    initial = read_control(control_path, control_sha256)
    validate_control(initial["value"])
    control = initial["value"]
    final_dir = strict_child(OUTPUT_ROOT, final_dir)
    require(not final_dir.exists(), "R13_FINAL_EXISTS")
    partial = final_dir.with_name("." + final_dir.name +
                                  ".partial." + uuid.uuid4().hex)
    require(not partial.exists(), "R13_PARTIAL_EXISTS")
    partial.mkdir(parents=True)
    chain_dir = partial / "chain"
    started = datetime.now(timezone.utc).isoformat()
    try:
        before = resources.preflight(partial,
                                     full_window=control["run_id"] == "W01")
        require(before["decision"] == "GO", "R13_RESOURCE_PREFLIGHT")
        envelope_record = read_descriptor_json(control["envelope_ref"], ROOT)
        dependency_record = read_descriptor_json(control["dependencies_ref"], ROOT)
        envelope = envelope_record["value"]
        result = binding.run_frozen_chain(
            envelope, control["dependencies_ref"], chain_dir,
            control["quota_bytes"])
        # Freeze decisions came from initial.raw only; this second identity is
        # a terminal mutation guard, never a second parse/decision source.
        require(identity(control_path) == initial["stamp"],
                "R13_CONTROL_CHANGED_DURING_RUN")
        require(read_descriptor_json(control["envelope_ref"], ROOT)["stamp"] ==
                envelope_record["stamp"], "R13_ENVELOPE_CHANGED_DURING_RUN")
        require(read_descriptor_json(control["dependencies_ref"], ROOT)["stamp"] ==
                dependency_record["stamp"], "R13_DEPENDENCIES_CHANGED_DURING_RUN")
        audit = finalize.audit(result, ROOT, partial)
        after = resources.disk_snapshot(partial)
        require(after["tree_bytes"] <= resources.WORKSPACE_LIMIT and
                after["disk_free"] >= resources.END_RESERVE,
                "R13_FINAL_DISK_RESOURCE_LIMIT")
        completion = {"schema": "M3_R13_ATOMIC_COMPLETION_V1",
                      "status": "COMPLETE_SOFTWARE_ONLY",
                      "run_id": control["run_id"],
                      "started_utc": started,
                      "ended_utc": datetime.now(timezone.utc).isoformat(),
                      "control": {"path": str(control_path), **initial["stamp"]},
                      "envelope": envelope_record["stamp"],
                      "dependencies": dependency_record["stamp"],
                      "audit": audit,
                      "workspace_resources": after,
                      "volume_store": result["R13_volume_store"],
                      "instantaneous_ABA_not_observable": True,
                      **{flag: False for flag in finalize.AUTHORITY_FLAGS}}
        finalize.atomic_json(partial / "COMPLETE.json", completion)
        os.replace(partial, final_dir)
        return completion
    except BaseException as error:
        failure = {"schema": "M3_R13_FAILURE_V1",
                   "status": "PARTIAL_FAILURE_OR_REJECT",
                   "started_utc": started,
                   "ended_utc": datetime.now(timezone.utc).isoformat(),
                   "error": type(error).__name__ + ":" + str(error),
                   "traceback": traceback.format_exc(),
                   "completion_written": False,
                   **{flag: False for flag in finalize.AUTHORITY_FLAGS}}
        try:
            finalize.atomic_json(partial / "R13_FAILURE.json", failure)
        except BaseException as secondary:
            failure["secondary_failure"] = type(secondary).__name__ + ":" + str(secondary)
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--control", required=True, type=Path)
    parser.add_argument("--control-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = run(args.control, args.control_sha256, args.output)
    print(json.dumps({"status": result["status"],
                      "real_verified": False,
                      "board_release_allowed": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
