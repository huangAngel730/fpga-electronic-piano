"""Exact user-approved codec08 group caps, same frozen owned mechanism."""
import argparse, hashlib, json, sys, time
from pathlib import Path
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019'
S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
p=argparse.ArgumentParser();p.add_argument('--admission',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
raw=a.admission.read_bytes();assert hashlib.sha256(raw).hexdigest()==a.sha256;v=json.loads(raw)
sys.path.insert(0,str(S));import job_bridge
group=v['group'];caps={'P1':60,'C':120,'B':240,'W':3600};assert v['absolute_cap_seconds']==caps[group]
if group in ('P1','B'):
    # Private disposable process only. Frozen execute/assess/owned bodies stay unchanged.
    job_bridge.CAPS=dict(job_bridge.CAPS, B=240)
    job_bridge.B_ACTUAL_CAP=216
    result=job_bridge.execute(a.admission,a.sha256,a.output)
else:
    owner=a.output.resolve();expected=O/'RUNS'/v['root_accounting_slot']/'inner';assert owner==expected
    worker=T/('codec_08_tests.py' if group=='C' else 'w_hour_10_worker.py')
    call,events=job_bridge.frozen_owned_call(v['root_deadline_monotonic'])
    cap=min(caps[group]-10,v['root_deadline_monotonic']-time.monotonic()-10);assert cap>5
    argv=[str(Path(sys.executable).resolve()),'-X','utf8','-B',str(worker),'--admission',str(a.admission.resolve()),'--sha256',a.sha256,'--output',str(owner/'worker')]
    owned=call(argv,R,owner,cap);assessment=job_bridge.assess(owned,cap,events)
    result={'schema':'M3_R13_OWNED_GROUP_RESULT_V1','group':group,'owned':owned,'assessment':assessment,'status':assessment['status']}
    if result['status']=='PASS':job_bridge.atomic_json(owner/'GROUP_COMPLETE.json',result)
print(json.dumps(result));raise SystemExit(0 if result['status']=='PASS' else 2)
