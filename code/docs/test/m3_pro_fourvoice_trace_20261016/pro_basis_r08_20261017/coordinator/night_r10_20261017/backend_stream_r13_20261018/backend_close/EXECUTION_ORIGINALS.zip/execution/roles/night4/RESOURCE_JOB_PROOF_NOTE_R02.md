# R13 私有原生关闭观测与父层场景建议 R02

状态：L0 静态建议，未导入、AST 解析、编译或执行本说明中的代码。
仅新增本说明及对应机读清单；不修改已交 night4 原件或正式 13 文件。

## 结论与适用边界

可以在 R13 私有加载命名空间添加原生 CloseHandle 结果观测，保持冻结 owner 原文及原有
创建→挂接→恢复→等待→Job0→关闭顺序。推荐两个不同接缝：

1. 仅在私有嵌套 owner 加载后，对该私有 `WindowsJob` 派生一个观测类；实例的私有
   kernel32.CloseHandle 包装器转调同一个原生函数一次，记录真实 BOOL，再原样返回。
2. 仅在私有 subprocess facade 的 Popen 返回后，对该单个 root handle 实例的 Close 方法
   注入回调。当前本机 `Handle.Close(self, CloseHandle=_winapi.CloseHandle)` 明确支持此参数。
   回调直接调用同一 Windows CloseHandle API 一次，记录 BOOL；失败抛 WinError，以保留
   原 `_winapi.CloseHandle` 的错误传播语义。不要先调用原 Close 再第二次 CloseHandle。

这不是零行为变化：root 的原生调用绑定由 `_winapi` 换到显式 ctypes ABI，增加了少量观测开销。
因此必须由 root/main3 采纳、冻结新适配源码与工具身份，并在既有 P0 单次槽内实证；
静态代码不能把现有 PENDING 改成实测 PASS。任一适配装配失败，只保留缺证并沿原生命周期
清理，不能在 Popen 已创建而尚未归属 Job 时抛出一个适配错误、遗留悬停进程。

## 精确静态集成片段

以下作为说明中的代码片段供唯一 C 写者采纳，不能由支持窗口运行。
它只创建观测绑定；自身不调用 Popen、不创建 Job。实际构造 WinDLL 发生在 root 将来调用时。

```python
def make_native_close_observation():
    import builtins
    import ctypes
    from ctypes import wintypes
    import subprocess as real_subprocess
    import time
    import types

    events = []
    root_kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    root_close_api = root_kernel.CloseHandle
    root_close_api.argtypes = [wintypes.HANDLE]
    root_close_api.restype = wintypes.BOOL

    def hvalue(value):
        return int(value.value if hasattr(value, "value") else value)

    def native_once(role, value, api):
        handle = hvalue(value)
        ctypes.set_last_error(0)
        try:
            result = api(wintypes.HANDLE(handle))
        except BaseException as error:
            events.append({"kind": "NATIVE_CLOSE", "role": role,
                           "handle": handle, "bool_return": None,
                           "error": type(error).__name__ + ":" + str(error),
                           "at": time.monotonic()})
            raise
        error = ctypes.get_last_error() if not result else 0
        events.append({"kind": "NATIVE_CLOSE", "role": role,
                       "handle": handle, "bool_return": int(result),
                       "winerror": int(error), "at": time.monotonic()})
        return result, error

    def private_owner_exec(code, namespace):
        # Called only by the selected frozen owned_call's nested owner load.
        # WINDOWS_JOB is the exact pinned absolute Path in formal job_bridge.
        if (namespace.get("__name__") != "_r12_unchanged_job_owner"
                or not isinstance(code, types.CodeType)
                or code.co_filename != str(WINDOWS_JOB)):
            raise RuntimeError("ONLY_PINNED_PRIVATE_JOB_OWNER_EXEC")
        builtins.exec(code, namespace)
        OriginalJob = namespace["WindowsJob"]

        class ObservedJob(OriginalJob):
            def __init__(self):
                super().__init__()
                # Do not raise an observation-install error after native Job
                # creation: old constructor has no new cleanup owner here.
                try:
                    original_api = self.kernel.CloseHandle
                    original_api.restype = wintypes.BOOL
                    observed_handle = hvalue(self.handle)

                    def observed_job_close(value):
                        result, error = native_once("job", value, original_api)
                        return result  # old close() still owns all flow

                    self.kernel.CloseHandle = observed_job_close
                    events.append({"kind": "HOOK_INSTALLED", "role": "job",
                                   "handle": observed_handle})
                except BaseException as error:
                    events.append({"kind": "HOOK_INSTALL_FAILED", "role": "job",
                                   "error": type(error).__name__ + ":" + str(error)})

        namespace["WindowsJob"] = ObservedJob

    def private_popen(*args, **kwargs):
        process = real_subprocess.Popen(*args, **kwargs)
        # Always return the created process to the original owner. It must
        # assign/resume/clean it even when observation installation fails.
        try:
            handle = process._handle
            original_close = handle.Close
            observed_handle = int(handle)

            def root_native_callback(value):
                result, error = native_once("root", value, root_close_api)
                if not result:
                    raise ctypes.WinError(error)
                return None  # match the native _winapi wrapper on success

            def observed_root_close():
                return original_close(CloseHandle=root_native_callback)

            handle.Close = observed_root_close  # this instance only
            events.append({"kind": "HOOK_INSTALLED", "role": "root",
                           "handle": observed_handle, "pid": process.pid})
        except BaseException as error:
            events.append({"kind": "HOOK_INSTALL_FAILED", "role": "root",
                           "error": type(error).__name__ + ":" + str(error)})
        return process

    private_builtins = dict(vars(builtins))
    private_builtins["exec"] = private_owner_exec
    private_subprocess = types.SimpleNamespace(
        Popen=private_popen, DEVNULL=real_subprocess.DEVNULL,
        TimeoutExpired=real_subprocess.TimeoutExpired)
    return {"__builtins__": private_builtins,
            "subprocess": private_subprocess}, events
```

在正式 `frozen_owned_call()` 已有 `module.__dict__.update({...})` 之后、执行四定义之前：

```python
observation_bindings, close_events = make_native_close_observation()
module.__dict__.update(observation_bindings)
# Original four-definition compile/exec remains at its existing root-only site.
# Return (module.owned_call, close_events) to execute(), not owned_call alone.
```

调用完原 owned_call 后，由当前外层 execute 把 `close_events` 随原 owned 收据一起封存；
不改旧 RESULT 内容，也不把新事件硬填回历史文件。`private_owner_exec` 只接管嵌套
WindowsJob 模块的 exec；不能替换全局 builtins、sys.modules、subprocess.Popen 或 Handle 类。

判据应核本次 run_id/nonce、pid/句柄数值与安装事件一致；每个角色只有一次实际关闭事件，
BOOL 为非零、无 hook 失败/原生异常、原 owned 收据相应关闭路径已执行。
这里的“一次”以一次 owned_call 为单位；每个父层子场景需独立 bindings/events，并在封存时
绑定 group/case_id/run_id，不能把三个场景的关闭事件混合后仅按角色取最后一条。
实际 BOOL=0 或原生关闭异常应判 FAIL；缺装配/缺事件判 PENDING，二者不混为通过。
Job0 必须在 Job native close 事件之前，并有独立累计进程数/退出/超时证据。
重复关闭不能作为重试，缺事件不能按 `handle=None` 或 `closed=True` 补成功。
Handle.__del__ 在本机实现仍为原类 Close；显式 Close 先置 closed=True 后，它不会再次关闭。
不能依赖析构器来补本说明的显式关闭证据。

本机 `subprocess.py` 文本支持上述参数注入，但私有实例属性覆盖、ctypes ABI、异常路径和
与实际被冻结 Python/_winapi 的一致性仍必须 P0 实证。非本机此版本不得照抄默认参数假设。
事件留在内存后一次封存；它的写入、封存失败、桥接退出都计入原槽，不能新增槽或返还时间。

## GetHandleInformation 路线的证据边界

关闭前对同一进程的同一句柄 GetHandleInformation 成功、关闭后立即查询失败且错误 6
（ERROR_INVALID_HANDLE），可作为“该数值此刻已无效”的辅助证据。它不是原 CloseHandle BOOL：

- 另一线程关闭或句柄数值被回收/重用，均会干扰归因。
- 查询失败但不是错误 6、没有可靠关闭前有效证明、或查询到不同进程中的同值句柄，都不成立。
- Job 活跃数为 0 与 Job 句柄本身关闭是两个不同事实。
- 如果验收要求真实返回码，不能用该路线静默替换；它适合补充诊断或由责任人明确接受的较弱声明。

本说明未联网查阅 SDK 文档、未执行任何 API；上述 Win32 语义只作静态方案边界，实际工具/ABI
及错误码处理由 root 对其已冻结环境核实。不推荐增加一次故意重复 CloseHandle 来制造错误 6。

## P0 与 B02–04 的父层观察入口

| 项 | 必须真实发生 | 父层入口与完成证据 |
|---|---|---|
| P0，原 60s 槽 | 本轮来源/工具冻结＋至少本槽自己的受控进程自然完成 | 私有 owner exec/Job 构造、挂接前悬停、挂接/恢复返回、实际 owned 收据、Job0、两类 native close 事件；冻结实际 Python、stdlib Handle 实现与 _winapi 归属；不能用“STATIC_PINS_BOUND”字样代替 |
| B02，自然退出 | B 组实际受控 worker 自然退出 0 | 原 Popen/wait 的 NATURAL、exit0、Job0前后样本、两类 close 事件及绝对墙钟；可复用 B 组本次实际自然收据，但不借旧 R12 |
| B03，后代观察 | 冻结的测试 worker 确实产生一个受控后代 | worker/child PID 与双向 ready/有界退出标记、父层 Job 累计 total 与活跃变化；必要时 IsProcessInJob 核目标 child 归属；完成后 Job0。声明“parent observation=true”或累计 total=1 都不证明这个正向后代场景已发生 |
| B04，超时清理 | 冻结的测试 worker（可带后代）在有界 natural_wait 到点仍存活 | 原 owned_call 使用既有 natural_wait 参数触发 TimeoutExpired→TerminateJobObject→有界 wait→Job0→close；父层独立记录自然等待期限、实际终止、清理耗时及原始 124/非零退出。它是预期负场景，不能套“所有案例 NATURAL/exit0”判据 |

B03/B04 当前业务 selftest 没有真正实现这些 fixture；`DEFERRED_TO_PARENT_JOB_RECEIPT` 只是待接缝。
要由唯一 C 写者在其既有 13 文件内加入冻结测试 fixture/父层路由，并由 root 在一次 B 组内
按原 12 案计数执行；不得另外把每个子场景当新 120s 组或把 B04 改成取消整个 B 组。
P0 是独立先行槽，不在 B 内重开；如果尚未执行 P0，应在冻结前完成适配，已消费则不重开。

具体调度建议：B 的 disposable 父层拥有整个 120s 绝对期限，在其内部先留原 9 个业务案和
B02/B03/B04 所需小段的完整上限及清理余量。每次原 owned_call 的子上限只能取尚余 B 时间
内的预冻结值；B04 的 natural_wait 要明显小于其子上限，使强制终止/Job0/关闭能在同一段内结束。
原灾难 watchdog 的 os._exit 仍会终止该 disposable 父层，若发生不得追加重试或伪造尾收据。
root 的外层整个 B 组最终自然 0，只表示预期正/负案例均被判对；须保留 B04 内层非零原码。
B04 预期的是 OWNED_TERMINATED_TIMEOUT、归一化 124 和完整清理证据；125 异常、缺尾收据或
仅看到 worker 已消失，均不能冒充该场景通过。

内存证明仍分开：B03 是故意存在后代的清理正例，不能从单 root PeakWorkingSet64 签树 512MiB；
W 仍须自己的无后代终生证明，或严格并发树内存测量。观察成功不解决全目录写入覆盖、物理
chunk、连续磁盘 reserve、原件通道或完整实际 D4 链的其他门槛。

## 当前精确静态发现与身份

- 正式 job_bridge.assess 无条件追加 `NATIVE_CLOSE_BOOL_NOT_RECORDED_BY_FROZEN_OWNER`，
  因而实际执行即使自然 0 也只能 PENDING；应只由本次完整观测证据解除这一条。
- `B02_B03_B04_parent_observation=true` 是常量，当前没有对应实际子场景调度，不能当证据。
- 正式 selftest 定义了 `_p0_case()`，但 `worker(group=='P0')` 当前只返回 STATIC_PINS_BOUND，
  未调用该函数；它甚至没有运行已写的 pins/D4 源身份核验，不能称 P0 完整完成。

本轮只读快照（采纳前 root 需重核，后续并发修订不由本说明覆盖）：

| 文件 | bytes | SHA256 |
|---|---:|---|
| 本机 `C:/Users/songdongkuan/miniconda3/Lib/subprocess.py`，Handle.Close 在 218–221 行 | 88725 | `baa9f9138d8d20df6284f67e7d2e790f847f65e2c5370de322d54cccd737f2d9` |
| 冻结 `windows_job.py` | 3481 | `5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b` |
| 正式 R13 `job_bridge.py` | 5370 | `cd6baa39ddb9b60245aaf1a62ae01aeb4479db52d1e856b0997af0d404b10e5c` |
| 正式 R13 `selftest.py` | 20180 | `16a71dc9d9ff8611d4d13f9df056b8c74ce02d6be4b002df8c9435117dcfd6ed` |
| 正式 R13 `CASE_MATRIX.json` | 1441 | `f4249e3e4a21ad188bfcfeb7d4513642a10a0eeaf4117b1da6b8787f791d4907` |

全部新建议仅为 L0，原生关闭、父层场景、P0、B 组尚未由本窗口运行。
