"""Root-owned one-shot Windows Job launcher for R13 workers.

The frozen R12 owner is extracted by AST and executes in this disposable
supervisor process.  The long-lived coordinator must launch this file as a
separate process because the inherited disaster watchdog uses os._exit(124).
"""
from __future__ import annotations

import argparse
import ast
import builtins
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import types

from finalize import atomic_json
from stream_bridge import CHUNK, read_control, require, strict_child

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
OUTPUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
R12_SELFTEST = HERE.parent / "frontend_close_r12_20261018/selftest.py"
R12_SELFTEST_SHA = "5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c"
WINDOWS_JOB = ROOT / "code/software/t052_runner_acceptance_candidate_20261012/windows_job.py"
WINDOWS_JOB_SHA = "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b"
CAPS = {"P0": 60, "K": 120, "V": 120, "B": 120, "W": 900, "R": 120}
B_ACTUAL_CAP = 100
B_DESCENDANT_CAP = 5
B_TIMEOUT_CAP = 5


def _frozen(path, sha):
    raw = path.read_bytes()
    require(len(raw) <= CHUNK and hashlib.sha256(raw).hexdigest() == sha,
            "FROZEN_OWNER_SOURCE")
    return raw


def _small_bytes(path):
    with Path(path).open("rb", buffering=0) as stream:
        raw = stream.read(CHUNK)
        require(not stream.read(1), "FIXTURE_STDOUT_TOO_LARGE")
    return raw


def make_native_close_observation():
    events = []
    root_kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    root_close_api = root_kernel.CloseHandle
    root_close_api.argtypes = [wintypes.HANDLE]
    root_close_api.restype = wintypes.BOOL

    def hvalue(value):
        return int(value.value if hasattr(value, "value") else value)

    def native_once(role, value, api):
        handle = hvalue(value)
        ctypes.set_last_error(0)
        try:
            result = api(wintypes.HANDLE(handle))
        except BaseException as error:
            events.append({"kind": "NATIVE_CLOSE", "role": role,
                           "handle": handle, "bool_return": None,
                           "error": type(error).__name__ + ":" + str(error),
                           "at": time.monotonic()})
            raise
        winerror = ctypes.get_last_error() if not result else 0
        events.append({"kind": "NATIVE_CLOSE", "role": role,
                       "handle": handle, "bool_return": int(result),
                       "winerror": int(winerror), "at": time.monotonic()})
        return result, winerror

    def private_owner_exec(code, namespace):
        if (namespace.get("__name__") != "_r12_unchanged_job_owner" or
                not isinstance(code, types.CodeType) or
                code.co_filename != str(WINDOWS_JOB)):
            raise RuntimeError("ONLY_PINNED_PRIVATE_JOB_OWNER_EXEC")
        builtins.exec(code, namespace)
        original_job = namespace["WindowsJob"]

        class ObservedJob(original_job):
            def __init__(self):
                super().__init__()
                try:
                    original_api = self.kernel.CloseHandle
                    original_api.restype = wintypes.BOOL
                    observed_handle = hvalue(self.handle)

                    def observed_job_close(value):
                        result, _ = native_once("job", value, original_api)
                        return result

                    self.kernel.CloseHandle = observed_job_close
                    events.append({"kind": "HOOK_INSTALLED", "role": "job",
                                   "handle": observed_handle})
                except BaseException as error:
                    events.append({"kind": "HOOK_INSTALL_FAILED", "role": "job",
                                   "error": type(error).__name__ + ":" +
                                            str(error)})

        namespace["WindowsJob"] = ObservedJob

    def private_popen(*args, **kwargs):
        process = subprocess.Popen(*args, **kwargs)
        try:
            handle = process._handle
            original_close = handle.Close
            observed_handle = int(handle)

            def root_native_callback(value):
                result, winerror = native_once("root", value, root_close_api)
                if not result:
                    raise ctypes.WinError(winerror)
                return None

            def observed_root_close():
                return original_close(CloseHandle=root_native_callback)

            handle.Close = observed_root_close
            events.append({"kind": "HOOK_INSTALLED", "role": "root",
                           "handle": observed_handle, "pid": process.pid})
        except BaseException as error:
            events.append({"kind": "HOOK_INSTALL_FAILED", "role": "root",
                           "error": type(error).__name__ + ":" + str(error)})
        return process

    private_builtins = dict(vars(builtins))
    private_builtins["exec"] = private_owner_exec
    private_subprocess = types.SimpleNamespace(
        Popen=private_popen, DEVNULL=subprocess.DEVNULL,
        TimeoutExpired=subprocess.TimeoutExpired)
    return {"__builtins__": private_builtins,
            "subprocess": private_subprocess}, events


def frozen_owned_call():
    raw = _frozen(R12_SELFTEST, R12_SELFTEST_SHA)
    _frozen(WINDOWS_JOB, WINDOWS_JOB_SHA)
    tree = ast.parse(raw, filename=str(R12_SELFTEST))
    wanted = {"JobAccounting", "job_accounting", "peak_working_set", "owned_call"}
    nodes = [node for node in tree.body if isinstance(
        node, (ast.ClassDef, ast.FunctionDef)) and node.name in wanted]
    require({node.name for node in nodes} == wanted, "FROZEN_OWNER_DEFINITIONS")
    module = types.ModuleType("_r13_frozen_owned_call")
    module.__dict__.update({
        "ctypes": ctypes, "wintypes": wintypes, "datetime": datetime,
        "timezone": timezone, "hashlib": hashlib, "json": json, "os": os,
        "Path": Path, "subprocess": subprocess, "threading": threading,
        "time": time, "types": types, "ROOT": ROOT, "OUTPUT": OUTPUT})
    observation_bindings, close_events = make_native_close_observation()
    module.__dict__.update(observation_bindings)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(R12_SELFTEST),
                 "exec", dont_inherit=True), module.__dict__)
    return module.owned_call, close_events


def assess(record, cap, close_events, *, expected_exit="NATURAL",
           expected_code=0, require_descendant=False):
    issues, pending = [], []
    for field in ("job_handle_closed", "root_process_handle_closed",
                  "job_zero_observed_before_job_close", "within_cap"):
        if record.get(field) is not True:
            issues.append(field)
    if (record.get("exit_class") != expected_exit or
            record.get("exit_code") != expected_code):
        issues.append("EXPECTED_EXIT:" + expected_exit + ":" +
                      str(expected_code))
    samples = record.get("samples", [])
    if not samples or samples[-1].get("active") != 0:
        issues.append("JOB_ZERO_SAMPLE")
    observations = [record.get("before_root_handle_close", {})] + samples
    totals = {item.get("total") for item in observations
              if isinstance(item, dict) and
              isinstance(item.get("total"), int)}
    if not observations or any(not isinstance(item, dict) or
                               not isinstance(item.get("total"), int)
                               for item in observations):
        issues.append("JOB_TOTAL_OBSERVATION_MALFORMED")
    if require_descendant:
        if not any(isinstance(total, int) and total >= 2 for total in totals):
            issues.append("DESCENDANT_NOT_OBSERVED:" + str(sorted(totals)))
    elif totals != {1}:
        pending.append("NO_DESCENDANT_AND_TREE_PEAK_NOT_PROVED:" + str(sorted(totals)))
    peak = record.get("peak_working_set", {})
    if peak.get("bytes", 512 * 1024 * 1024 + 1) > 512 * 1024 * 1024:
        issues.append("WORKER_PEAK_512MIB")
    for role in ("root", "job"):
        hooks = [item for item in close_events
                 if item.get("kind") == "HOOK_INSTALLED" and
                 item.get("role") == role]
        closes = [item for item in close_events
                  if item.get("kind") == "NATIVE_CLOSE" and
                  item.get("role") == role]
        if (len(hooks) != 1 or len(closes) != 1 or
                hooks[0].get("handle") != closes[0].get("handle") or
                closes[0].get("bool_return") != 1 or
                closes[0].get("winerror") != 0):
            issues.append("NATIVE_CLOSE_PROOF:" + role)
    if any(item.get("kind") == "HOOK_INSTALL_FAILED"
           for item in close_events):
        issues.append("NATIVE_CLOSE_HOOK_FAILED")
    job_close = [item for item in close_events
                 if item.get("kind") == "NATIVE_CLOSE" and
                 item.get("role") == "job"]
    if (job_close and samples and
            job_close[0].get("at", 0) < samples[-1].get("monotonic", 1)):
        issues.append("JOB_CLOSED_BEFORE_JOB_ZERO")
    return {"status": "FAIL" if issues else "PENDING" if pending else "PASS",
            "issues": issues, "pending": pending,
            "native_close_events": close_events,
            "this_owned_call_parent_observation": True}


def execute(admission_path, admission_sha, owner_output):
    record = read_control(admission_path, admission_sha)["value"]
    group = record.get("group")
    require(group in CAPS and record.get("state") == "CONSUMED_RUNNING" and
            record.get("absolute_cap_seconds") == CAPS[group],
            "CONSUMED_ADMISSION")
    owner_output = strict_child(OUTPUT, owner_output)
    actual_owner = owner_output / "B02" if group == "B" else owner_output
    worker_output = actual_owner / "worker"
    require(not owner_output.exists(), "FRESH_OWNER_OUTPUT")
    argv = record.get("argv")
    expected = [str(Path(sys.executable).resolve()), "-X", "utf8", "-B",
                str((HERE / "selftest.py").resolve()), "--worker", "--group",
                group, "--admission", str(Path(admission_path).resolve()),
                "--admission-sha256", admission_sha, "--output",
                str(worker_output.resolve())]
    require(argv == expected and worker_output != owner_output,
            "FROZEN_WORKER_ARGV")
    started = time.monotonic()
    owned_call, close_events = frozen_owned_call()
    actual_cap = B_ACTUAL_CAP if group == "B" else CAPS[group]
    result = owned_call(argv, ROOT, actual_owner, actual_cap)
    actual_assessment = assess(result, actual_cap, close_events)
    parent_cases = {"B02": {"owned": result,
                             "assessment": actual_assessment}}
    if group == "B" and actual_assessment["status"] == "PASS":
        fixture_base = [str(Path(sys.executable).resolve()), "-X", "utf8", "-B",
                        str(Path(__file__).resolve()), "--fixture"]
        for case_id, fixture, cap, natural_wait, exit_class, exit_code in (
                ("B03", "descendant", B_DESCENDANT_CAP, None, "NATURAL", 0),
                ("B04", "timeout", B_TIMEOUT_CAP, 0.5,
                 "OWNED_TERMINATED_TIMEOUT", 124)):
            require(time.monotonic() - started + cap + 5 < CAPS["B"],
                    "B_PARENT_ABSOLUTE_BUDGET")
            call, events = frozen_owned_call()
            case_result = call(fixture_base + [fixture], ROOT,
                               owner_output / case_id, cap,
                               natural_wait=natural_wait)
            case_assessment = assess(
                case_result, cap, events, expected_exit=exit_class,
                expected_code=exit_code, require_descendant=True)
            stdout = _small_bytes(owner_output / case_id / "stdout.bin")
            require(b"R13_PARENT_READY child_pid=" in stdout and
                    b"R13_CHILD_READY" in stdout,
                    "FIXTURE_READY_EVIDENCE:" + case_id)
            if case_id == "B03":
                require(b"R13_PARENT_DONE" in stdout and
                        b"R13_CHILD_DONE" in stdout,
                        "FIXTURE_NATURAL_EVIDENCE")
            else:
                require(b"R13_PARENT_DONE" not in stdout and
                        b"R13_CHILD_DONE" not in stdout,
                        "FIXTURE_TIMEOUT_EVIDENCE")
            parent_cases[case_id] = {"owned": case_result,
                                     "assessment": case_assessment}
            if case_assessment["status"] != "PASS":
                break
    assessments = [item["assessment"] for item in parent_cases.values()]
    overall = ("PASS" if len(parent_cases) == 3 and
               all(item["status"] == "PASS" for item in assessments)
               else "FAIL" if any(item["status"] == "FAIL"
                                  for item in assessments) else "PENDING")
    receipt = {"schema": "M3_R13_OWNED_GROUP_RESULT_V1",
               "group": group, "owned": result,
               "assessment": actual_assessment,
               "parent_cases": parent_cases if group == "B" else {},
               "status": overall if group == "B" else
                         actual_assessment["status"],
               "B02_B03_B04_parent_observation":
                   (group == "B" and len(parent_cases) == 3 and
                    all(item["assessment"]["status"] == "PASS"
                        for item in parent_cases.values())),
               "elapsed_seconds": time.monotonic() - started}
    if group == "B" and receipt["elapsed_seconds"] > CAPS["B"]:
        receipt["status"] = "FAIL"
        receipt["budget_error"] = "B_PARENT_ABSOLUTE_CAP_EXCEEDED"
    if receipt["status"] == "PASS":
        atomic_json(owner_output / "GROUP_COMPLETE.json", receipt)
    return receipt


def fixture(kind):
    require(kind in {"descendant", "timeout"}, "FIXTURE_KIND")
    child_code = ("import time; print('R13_CHILD_READY', flush=True); "
                  "time.sleep(" + ("0.2" if kind == "descendant" else "60") +
                  "); print('R13_CHILD_DONE', flush=True)")
    child = subprocess.Popen([str(Path(sys.executable).resolve()), "-X", "utf8",
                              "-B", "-c", child_code])
    print("R13_PARENT_READY child_pid=" + str(child.pid), flush=True)
    if kind == "descendant":
        require(child.wait(timeout=2) == 0, "FIXTURE_CHILD_EXIT")
        print("R13_PARENT_DONE", flush=True)
        return 0
    time.sleep(60)
    return 99


def main():
    parser = argparse.ArgumentParser()
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument("--execute-one", action="store_true")
    actions.add_argument("--fixture", choices=("descendant", "timeout"))
    parser.add_argument("--admission", type=Path)
    parser.add_argument("--admission-sha256")
    parser.add_argument("--owner-output", type=Path)
    args = parser.parse_args()
    if args.fixture:
        return fixture(args.fixture)
    require(args.admission is not None and args.admission_sha256 and
            args.owner_output is not None, "EXECUTE_ARGUMENTS")
    result = execute(args.admission, args.admission_sha256, args.owner_output)
    print(json.dumps(result, ensure_ascii=False))
    if result["status"] == "PASS":
        return 0
    return 3 if result["status"] == "PENDING" else 2


if __name__ == "__main__":
    raise SystemExit(main())
