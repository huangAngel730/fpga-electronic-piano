"""Single root R13 execution authority; candidates cannot consume slots."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time
import types

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
STEM = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
SOURCE = ROOT / 'code/software' / STEM / 'backend_stream_r13_20261018'
CLOSE = ROOT / 'code/docs/test' / STEM / 'backend_stream_r13_20261018/backend_close'
LEGACY = ROOT / 'code/software' / STEM / 'frontend_close_r12_20261018/selftest.py'
PLAN_SHA = '729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3'
AUTH_SHA = 'f6db0a87ca66d6dd30a21203ac2210db6260c91aea875d2fac4534ac53bf98e5'


def read(path):
    return json.loads(path.read_text('utf-8'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def stamp(path):
    digest, total = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            total += len(block)
            digest.update(block)
    return {'path': str(path), 'bytes': total, 'sha256': digest.hexdigest()}


def verify(ref):
    path = Path(ref['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = stamp(path)
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256'], ref['path']


def authority():
    assert stamp(CLOSE / 'PLAN.json')['sha256'] == PLAN_SHA
    assert stamp(CLOSE / 'AUTHORIZATION.json')['sha256'] == AUTH_SHA
    auth = read(CLOSE / 'AUTHORIZATION.json')
    assert auth['approved'] is True and auth['approved_plan_sha256'] == PLAN_SHA


def owner():
    raw = LEGACY.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c'
    module = types.ModuleType('_r13_private_unchanged_r12_owner')
    module.__file__ = str(LEGACY)
    exec(compile(raw, str(LEGACY), 'exec', dont_inherit=True), module.__dict__)
    module.OUTPUT = OUT
    return module


def dependencies(slot, ledger):
    groups = ledger['groups']
    if slot == 'P0':
        assert read(OUT / 'WRITE_LEASES_CLOSED.json')['all_target_writers_closed'] is True
        return
    if slot in ('P1', 'R'):
        fix = read(OUT / 'LOCATED_REPAIR.json')
        assert fix['failed_group'] in ('K', 'V', 'B') and fix['unchanged_retry'] is False
        assert fix['new_sources_frozen'] and fix['all_affected_cases_count'] <= 16
        assert groups[fix['failed_group']]['state'] == 'FAILED_STOP'
        if slot == 'R':
            assert groups['P1']['state'] == 'PASS'
        return
    parents = {
        'K': ('P0',), 'V': ('P0', 'K'), 'B': ('P0', 'K', 'V'),
        'W': ('P0', 'K', 'V', 'B'), 'GATE_01': ('P0', 'K', 'V', 'B', 'W'),
        'S1': ('GATE_01',), 'GATE_02': ('GATE_01', 'S1'), 'S2': ('GATE_02',),
    }[slot]
    for parent in parents:
        if groups[parent]['state'] == 'PASS':
            continue
        if parent == 'P0':
            recovery = ledger.get('recovery_attempts', {}).get('P0_RECOVERY_03', {})
            assert recovery.get('state') == 'PASS', 'RECOVERY_P0_NOT_PASS'
            continue
        fix = read(OUT / 'LOCATED_REPAIR.json')
        assert parent == fix['failed_group'] and groups['R']['state'] == 'PASS'
        assert read(OUT / 'REPAIR_ACCEPTED.json')['status'] == 'PASS'
    if slot == 'W':
        assert read(OUT / 'DELIVERY_CHANNEL_CONFIRMED.json')['state'] == 'USER_FORWARD_ALL_LOSSLESS_VOLUMES_CONFIRMED'
        admission = read(OUT / 'W_ADMISSION.json')
        assert admission['GO'] is True and admission['all_resource_and_source_requirements_met'] is True
    if slot == 'S2':
        assert read(OUT / 'PUBLICATION_ACTUAL.json')['remote_containment'] is True


parser = argparse.ArgumentParser()
parser.add_argument('slot', choices=('P0', 'K', 'V', 'B', 'W', 'P1', 'R', 'GATE_01', 'S1', 'GATE_02', 'S2'))
parser.add_argument('--contract', type=Path, required=True)
parser.add_argument('--sha256', required=True)
args = parser.parse_args()
started = time.monotonic()
authority()
raw = args.contract.read_bytes()
assert hashlib.sha256(raw).hexdigest() == args.sha256
contract = json.loads(raw)
assert contract['root_approved'] is True and contract['slot'] == args.slot
assert contract['plan_sha256'] == PLAN_SHA
ledger_path = OUT / 'CONSUMPTION_LIVE.json'
ledger = read(ledger_path)
attempt_id = contract.get('attempt_id')
slot = ledger['recovery_attempts'][attempt_id] if attempt_id else ledger['groups'][args.slot]
if attempt_id:
    assert args.slot == 'P0' and attempt_id == 'P0_RECOVERY_03'
    assert ledger['groups']['P0']['state'] == 'FAILED_STOP'
    verify(contract['new_user_authority'])
    auth_delta = read(OUT / 'RECOVERY_TASK0_20261019/RECOVERY_EXECUTION_ADDENDUM_R03.json')
    assert auth_delta['new_attempt_id'] == attempt_id and auth_delta['new_attempt_cap_seconds'] == 60
assert slot['state'] == 'NOT_STARTED' and slot['attempts'] == 0, 'CONSUMED_SLOT'
assert contract['cap_seconds'] == slot['cap_seconds']
dependencies(args.slot, ledger)
remaining = sum(v['cap_seconds'] for v in ledger['groups'].values() if v['state'] == 'NOT_STARTED')
if attempt_id:
    remaining += slot['cap_seconds']
remaining += ledger['network']['charged_cap_seconds_max'] - sum(v['charged_seconds'] for v in ledger['network']['operations'])
remaining += ledger['local_git']['charged_cap_seconds_max'] - sum(v.get('charged_seconds', 0) for v in ledger['local_git']['operations'])
deadline = datetime.fromisoformat(ledger['deadline'])
assert datetime.now(timezone.utc) + timedelta(seconds=remaining + 60) <= deadline, 'FULL_REMAINING_CAPS_AND_MARGIN_NOT_AVAILABLE'
assert contract['all_target_writers_closed'] is True
argv = contract['argv']
assert argv and Path(argv[0]).is_absolute()
target = Path(contract['target_script']).resolve()
if args.slot.startswith('GATE_'):
    assert target == OUT / 'GATE_CHILD_R13.ps1'
else:
    assert target in (SOURCE / 'selftest.py', SOURCE / 'job_bridge.py',
                      OUT / 'seal_r13.py')
assert str(target) in argv, 'ONLY_FROZEN_R13_TARGET_ENTRY_ALLOWED'
slot.update(state='CONSUMED_BEFORE_LAUNCH', attempts=1, charged_seconds=slot['cap_seconds'],
            contract_sha256=args.sha256, started_utc=datetime.now(timezone.utc).isoformat())
save(ledger_path, ledger)
# The root deadline covers source hashing and postchecks too. If it fires,
# the consumed receipt remains; OS closes this process's kill-on-close Job.
# It never authorizes replay of an incomplete/unknown run.
outer_remaining = slot['cap_seconds'] - (time.monotonic() - started) - 0.1
assert outer_remaining > 5
outer_timer = threading.Timer(outer_remaining, lambda: os._exit(124))
outer_timer.daemon = True
outer_timer.start()
for ref in contract['frozen_files']:
    verify(ref)
before_elapsed = time.monotonic() - started
child_cap = slot['cap_seconds'] - before_elapsed - 3
assert child_cap >= 5
run = OUT / 'RUNS' / (attempt_id or args.slot)
private_temp = OUT / 'RUNTIME_TEMP'
private_temp.mkdir(parents=True, exist_ok=True)
# Process-local inherited temporary paths keep child intermediates in the
# same owned artifact scope. No user/system environment setting is changed.
os.environ['TEMP'] = str(private_temp)
os.environ['TMP'] = str(private_temp)
result = owner().owned_call(argv, ROOT, run, child_cap)
good = result['exit_code'] == 0 and result['exit_class'] == 'NATURAL'
good = good and all(result[key] for key in ('within_cap', 'job_handle_closed', 'root_process_handle_closed', 'job_zero_observed_before_job_close'))
evidence = {}
try:
    for ref in contract['frozen_files']:
        verify(ref)
    bridge = None
    if good and contract.get('bridge_result_relative_path'):
        bridge = read(run / contract['bridge_result_relative_path'])
        assert bridge['status'] == 'PASS' and bridge['group'] == contract.get('wire_group', args.slot)
        assert bridge['assessment']['status'] == 'PASS'
        evidence['bridge'] = bridge
    if good and args.slot in ('P0', 'P1', 'K', 'V', 'B', 'W', 'R'):
        worker = read(run / contract['worker_result_relative_path'])
        pending_parent = worker['status'] == 'PASS_LOCAL_PENDING_PARENT'
        assert worker['status'] == 'PASS' or (pending_parent and bridge is not None
                                             and (args.slot in ('P0', 'P1', 'B') or
                                                  (args.slot == 'R' and contract.get('repair_group') == 'B')))
        cases = []
        for original in worker['cases']:
            case = dict(original)
            if args.slot in ('P0', 'P1') and case['id'] == 'P001':
                assert bridge is not None
                assert case['status'] in ('PASS', 'PASS_LOCAL_PINS', 'PASS_LOCAL_PENDING_PARENT')
                case['local_status'] = case['status']
                case['status'] = 'PASS'
                case['parent_proof'] = contract['bridge_result_relative_path']
            if (args.slot == 'B' or (args.slot == 'R' and contract.get('repair_group') == 'B')) and case['id'] in ('B02', 'B03', 'B04'):
                assert bridge is not None
                parent = bridge['parent_cases'][case['id']]
                assert parent['assessment']['status'] == 'PASS'
                case['worker_status'] = case['status']
                case['status'] = 'PASS'
                case['parent_proof'] = parent
            cases.append(case)
        if args.slot == 'B' or (args.slot == 'R' and contract.get('repair_group') == 'B'):
            assert bridge is not None and bridge['B02_B03_B04_parent_observation'] is True
            for case_id in ('B02', 'B03', 'B04'):
                if case_id not in {case['id'] for case in cases}:
                    parent = bridge['parent_cases'][case_id]
                    assert parent['assessment']['status'] == 'PASS'
                    cases.append({'id': case_id, 'status': 'PASS', 'parent_proof': parent})
        observed = {case['id'] for case in cases}
        good = observed == set(contract['expected_case_ids']) and all(case['status'] == 'PASS' for case in cases)
        good = good and len(cases) == len(observed) <= slot.get('cases_max', 1)
        evidence.update(worker=worker, cases=cases, status='PASS' if good else 'FAIL')
    if good and args.slot.startswith('GATE_'):
        import re
        text = (run / 'stdout.bin').read_text('utf-8', errors='replace')
        checks = re.findall(r'^\s*\[(PASS|FAIL)\] (.+)$', text, re.M)
        good = len(checks) == 9 and all(state == 'PASS' for state, _ in checks) and 'All repository checks passed.' in text
        evidence = {'nine_checks': checks, 'all_pass': good}
    if good and args.slot in ('S1', 'S2'):
        sealed = read(OUT / 'SEAL' / args.slot / 'SEAL_RESULT.json')
        assert sealed['status'] == 'PASS' and sealed['phase'] == args.slot
        for archive in sealed['archives']:
            verify(archive['file'])
            assert archive['all_payload_sizes_SHAs_and_ZIP_CRC_verified'] is True
        evidence = {'seal_result': sealed}
except BaseException as error:
    good = False
    evidence = {'parent_postcheck_failure': type(error).__name__ + ':' + str(error),
                'worker_actual_result_preserved': True}
actual_elapsed = time.monotonic() - started
good = good and actual_elapsed <= slot['cap_seconds']
slot.update(state='PASS' if good else 'FAILED_STOP', actual_result=result,
            controller_elapsed_seconds=actual_elapsed, postcheck_evidence=evidence,
            ended_utc=datetime.now(timezone.utc).isoformat())
save(ledger_path, ledger)
outer_timer.cancel()
print(json.dumps({'slot': args.slot, 'state': slot['state'], 'exit_code': result['exit_code'], 'controller_elapsed_seconds': actual_elapsed}))
raise SystemExit(0 if good else 1)
