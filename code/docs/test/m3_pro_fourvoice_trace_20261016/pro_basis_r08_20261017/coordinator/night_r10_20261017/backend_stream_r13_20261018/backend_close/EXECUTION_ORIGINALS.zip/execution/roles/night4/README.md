# R13 night4 静态候选交接

状态：`STATIC_CANDIDATE_READY_L0`，不是 R13 软件整包完成或执行准入通过。
本目录三份 Python 仅供 main3 选择性采纳到其 13 文件写集；本窗口没有修改正式 C 源码。
主协调窗口 night1 独占实际执行、消费账、backend_close、门禁和 Git 发布。

本轮计划 SHA：`729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3`。
协调记录 START 为 `2026-10-19T00:00:26+08:00`、最早截止为 `2026-10-19T05:00:26+08:00`；
候选要求调用方每次提供真实最新时窗，不用本说明中的历史时间自动启动。

| 文件 | 可采纳接口 | 边界 |
|---|---|---|
| `job_bridge.py` | `load_frozen_owned_call`、`evaluate_owned_result`、`run_backend_group` | 仅复用已有 Job 生命周期；不新建通用 runner，不修改历史源 |
| `resources.py` | `Limits`、`census`、`preflight`、`WorkspaceBudget`、`check_measured_receipt` | 明确区分目录观察值、预留上界和仍待实测的证据 |
| `run_plan.py` | `assess_start(group, snapshot, prerequisites, now_iso)` | 纯计算；不写共享消费，不执行或重试任何命令 |

## Job 接缝

`load_frozen_owned_call(root, output_root)` 先核原始字节，再从固定 R12 `selftest.py`
仅提取 `JobAccounting/job_accounting/peak_working_set/owned_call` 四个定义，保留原定义主体。
不会执行 R12 main、fixture 或旧组；原 `windows_job.py` 仍由原函数按固定 SHA 载入。
这是待 root 验证的静态接法，不声称 AST 提取接缝已经运行成功。

- R12 selftest raw SHA：`5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c`。
- 原 windows_job raw SHA：`5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b`。
- 源码若因 checkout 换行或其他变化而异，拒绝运行；不得静默换 pin。

`run_backend_group` 只接受固定 R13 `selftest.py` worker。Python 选项允许现有的
`-X utf8 -B` 或 `-B -X utf8`；其余 CLI 由 main3 实现并由 root 原样冻结。
本候选没有替 main3 发明 worker 业务参数。

root 提供独立冻结 admission 文件及其 SHA，字段包括：

```text
plan_sha256, executor_thread, state=CONSUMED_RUNNING, slot_nonce,
group=K|V|B|W|R, absolute_cap_seconds, preflight_status=PASS,
source_frozen=true, deadline_reservation_pass=true,
outer_full_lifetime_owner_ready=true, deadline,
argv, python_sha256, selftest_sha256,
inherited_environment_sha256={TEMP:sha256(UTF8(value)),TMP:...,...}, output
W additionally: all_writer_resource_coverage=true
```

这些字段必须来自 root 的真实授权、冻结及消费记录，候选校验不产生权限，也不防止调用方伪造事实。
不更改进程环境；TEMP/TMP 必须已由主窗口限定到 R13 workspace 并冻结。
返回 owned 原收据和单独 assessment，assessment 缺证为 PENDING。
总体准入须同时核计划、Job、资源和业务完成屏障，不能只挑某一个子判定的 PASS。

已有 owner 内部 watchdog 从 Job 创建后起算。桥接先计入自身身份校验开销，并缩减内部剩余时间；
身份读取、哈希阻塞及桥接本身仍需 root 已有的外层全生命周期 owner 限时。
候选没有自证这项外层约束，不能仅靠内部 timer 签完整槽的绝对墙钟。

`evaluate_owned_result` 要求自然 0、cap、Job0 在关闭前、根句柄和 Job 句柄状态。
单 worker 峰值只能在累计 Job total=1、完整归属、禁止 breakaway 时使用。
旧 `WindowsJob.close()` 未记录 CloseHandle BOOL；如需严格原生关闭证据，调用方另交
`native_cleanup_evidence={job_close_succeeded:true,root_process_close_succeeded:true,evidence_path:...}`。
原布尔不自动升级成该证据；bridge 自身返回仍可为 PENDING。

## 资源接缝

硬限：worker 512 MiB、物理 chunk 1 MiB、自有全目录 24 GiB、启动 free 32 GiB、保留 free 8 GiB。
`preflight(root, projected_peak_bytes)` 的参数是整个 workspace 的总峰值上界，包含已存在文件。
必须先由 A2 计入 raw/public/CSV/索引/历史/临时文件/日志/失败原件/分卷/压缩前后共存。

写入方共享同一个 `WorkspaceBudget`，每个新建或 append 的物理写调用前先
`before_write(path,n,mode='exclusive'|'append')`，实际写后 flush，再在 finally 中
`after_write(reservation,actual_bytes,failed=...)`。失败文件不删除、不漏计；不支持覆盖、
稀疏 seek、删除抵扣、多个未结预留或未注册写入方。所有读写 chunk 的实测与写预留额分开。

`receipt(exclusive_writer=True,all_writes_reserved=True,max_physical_chunk_bytes=...)` 的
两个覆盖字段必须来自真实逐写接入证据。默认不会声称连续磁盘 free 下界已证。
仅靠采样 high-water、最后目录总量、或 `before_write` 的 n，分别不能证明严格峰值、
短命临时文件覆盖或实际全部读写 chunk。

`check_measured_receipt(metrics, authorized_cap_seconds=冻结槽上限)` 读取：

```text
worker_memory: metric, scope, bytes, strict_peak
process_evidence: total_processes, descendants_ever, job_total_processes,
                  complete_lifetime, attached_before_resume, breakaway_disallowed
supervisor_memory: bytes, metric
workspace: budget receipt + 独立的 physical chunk、连续可用余量证据
job: active_processes_final, job_zero_before_close,
     root_process_handle_closed, job_handle_closed
timing: elapsed_seconds, absolute_cap_seconds, complete_lifetime,
        absolute_watchdog_enforced
```

单 worker 用 `metric=PeakWorkingSet64,scope=single_worker`。
否则必须提供严格的并发树 working set 聚合证据（`STRICT_CONCURRENT_TREE_WORKING_SET`、
`aggregate_evidence_complete=true`），不能加各进程各自生命周期峰值冒充同时峰值，
也不能用 Job private commit 替代 working set。监督器另记。
workspace 连续余量需另附 `volume_reserve_bound_complete=true` 和非空
`volume_reserve_bound_evidence`；观察采样本身不提供这项证明。

## 已确认的真实缺口

1. 已只读核旧 W 收据 `RESUME_R01_20261018/RUNS/W/RESULT.json`：Job total=2，
   根 PeakWorkingSet64=39,153,664B。CD 收据 `RECOVERY_R02_20261018/RUNS/CD/RESULT.json`：
   total=2，根峰=79,355,904B。两者在 R12 ignored 输出根下；原件路径和 SHA 见 READY。
   这是旧范围的清理/根内存记录，不能签 R13 无子进程或完整树内存通过。
2. 原 owner 直接把 stdout/stderr 写文件，finally 直接写 RESULT；这些写入尚未接资源预算。
   原 D4、native writer、临时目录、原生缓冲、压缩器也必须逐一纳入；未齐则 W NO_GO。
3. 新 worker 的无子进程或严格树峰值、监督器实测、完整读写 chunk、连续磁盘余量、
   整槽 watchdog、原生 CloseHandle 成功返回，目前都没有由本候选产生的新执行证据。
4. A2 全产物几何和可达原件通道仍须由相应写者/root 核实。
   ≤32MiB Git 原件包或已批准且确认 M2 可取的通道未冻结时阻 W。
5. main3 必须选择性采纳和适配，冻结当前正式依赖和 CLI；root 才能在原预算内做 P0/K/V/B/W。
   不因候选齐全而重复旧 42 项、C9、RTL、EDA 或硬件动作。

## 计划接缝与静态自审

`run_plan` 保留 P0→K→V→B→W→Gate01→S1→Gate02→发布→S2，初始矩阵 8/12/12/1。
P1/R 只接受一个已定位 K/V/B 软件缺陷、差异/新 SHA、P1 后 R 的条件式后继；
W/P0/原生/封存/门禁失败不恢复。所有槽按完整 cap 计费，不按实际快结束返还。
候选保守预留全部未执行普通组、剩余网络/Git整段预算和 60 秒余量；
发布前另至少留 fetch60+push300+包含query30 及三个操作位。
这是比最低预留更保守的估算，不是 root 当前消费账的替代品。

已逐段静态核对来源、写集、常量、失败传播和缺证分支；未 import、compile、运行候选、
运行测试、启动 worker/native/HDL/EDA/设备、执行 Git 写或网络操作。
本目录仅完成 L0；实际语法、API、Windows 生命周期和容量验证都待 root 许可范围内验证。
没有后台定时器或 GitHub 自动监控。本轮候选交接后停止写入，等待新的明确分派。
