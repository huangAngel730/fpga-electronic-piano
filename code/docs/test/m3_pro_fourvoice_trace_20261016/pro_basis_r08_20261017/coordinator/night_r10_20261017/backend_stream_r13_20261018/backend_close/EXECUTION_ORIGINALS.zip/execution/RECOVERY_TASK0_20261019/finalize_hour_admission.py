import json,hashlib,time,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';D=O/'RECOVERY_TASK0_20261019/W_HOUR_REPLAY_09';A=O/'ADMISSIONS/W_HOUR_09/ADMISSION.json';C=O/'ADMISSIONS/W_HOUR_09/ROOT_CONTRACT.json'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
l=json.loads((O/'CONSUMPTION_LIVE.json').read_text('utf-8'));assert l['recovery_attempts']['W_HOUR_09']['state']=='NOT_STARTED'
assert not (O/'RUNS/W_HOUR_09').exists()
shutil.copyfile(A,D/'ADMISSION_BEFORE_LAUNCH_CLOCK.json');shutil.copyfile(C,D/'ROOT_CONTRACT_BEFORE_LAUNCH_CLOCK.json')
v=json.loads(A.read_text('utf-8'));v['root_deadline_monotonic']=time.monotonic()+3600;v['prepared_utc']=datetime.now(timezone.utc).isoformat();save(A,v);a=ref(A)
c=json.loads(C.read_text('utf-8'));c['frozen_files']=[a if Path(x['path']).resolve()==A.resolve() else x for x in c['frozen_files']];i=c['argv'].index('--sha256');c['argv'][i+1]=a['sha256'];save(C,c)
save(D/'FINAL_ADMISSION_STATIC_CHECK.json',{'scope':'Only prelaunch monotonic clock refreshed after static review; no target had started, no consumed slot rebased','old_ROOT_contract':ref(D/'ROOT_CONTRACT_BEFORE_LAUNCH_CLOCK.json'),'new_ROOT_contract':ref(C),'other_fields_unchanged':True,'review':'Root plus read-only auxiliary static check found cap/path/log bindings consistent'})
print(json.dumps(ref(C)))
