# Task0 Job成员／Lifetime Peak修法静态交回

状态 L0，未执行；仅正式 C/job_bridge.py 修改。C 为批准的 backend_stream_r13_20261018 软件根。
本轮 user authority 与恢复队列取 O/RECOVERY_TASK0_20261019/USER_AUTHORITY_AND_QUEUE.json；
原失败 P0、415s新账及6540s继承账保留，未把任何槽退款或自行运行恢复试次。

新版 job_bridge.py：39684 B，SHA256
`111179f3aa3c5f38c371aaaeae2457a861c8b5e1e207de11c72bcad7adedfed7`。
修改前原字节存 roles/night4/TASK0_BEFORE_job_bridge.py，SHA
`95666e09586ad8ef4ee13372b97b60ab037629be92d6d40c15b36c3e06da1dbe`。
其他正式文件、旧源及停止P0原件未改。原 ROOT_STATIC_C_SNAPSHOT_03 未覆盖。

## 最小功能增量

1. 在已有私有 Popen facade 中，root 仍为 CREATE_SUSPENDED 时 DuplicateHandle 出独立查询句柄，
   绑定 GetProcessId＋GetProcessTimes.creation。原 root Popen._handle 仍由原 owner 独立关闭，
   不借用它长期持有、不替它 close。
2. 在私有 ObservedJob.attach_and_resume 中，启动同监督器进程的一个 daemon **线程**，随后调用
   原 assign-and-resume；原 owner 流程及冻结原文字节不改，无新增子进程、全局patch或runner。
3. 只查自己 Job 的 BasicAccounting 和 BasicProcessIdList。PID仅来自该Job或自己的原root。
   子成员 OpenProcess 查询句柄先核 IsProcessInJob，再取 PID/creation；同 PID 不同 creation 分列。
   PID复用到 Job 外、快退/OpenProcess拒绝、Query失败均粘性 PENDING，关闭失败 FAIL，不擦掉故障。
4. 对持有的每个成员查询 WaitForSingleObject。活跃时记录 OS lifetime peak观察；已退出后取最终
   GetProcessTimes.exit 与 PeakWorkingSet64，记录后立即 CloseHandle 查询句柄，真实 BOOL/错误码/时间留证。
   不把任何采样 WorkingSet 或最后一次活跃 peak当最终peak。最终peak不可取时不签证明。
5. 原 root 关闭回调先同步 reaping，尽量在原 Job0 drain 前释放已退出成员的查询引用；后台线程同时
   及时回收退出后代。Job close 前停止/join观察线程、做最后一轮自己Job查询；Job close后不再查该Job。
   原 root/job 两项 Native CloseHandle BOOL1 证明完整保留，不重复关闭原句柄。
6. close_events 增加一份 TREE_PEAK_PROOF。assessment 对照**原 actual owned_call最后Job0样本的累计total**：
   捕获身份数、成员数、独立身份数、观察者最后total须全部相等，root PID与Job句柄也必须绑定同次owner。
   每成员须有本Job归属、退出、最终Peak、成功且晚于取Peak的查询句柄关闭；PASS时查询句柄还须在Job原生关闭前释放。
7. 完整覆盖时，把各成员最终 lifetime Peak 求和，明确命名为并发树Peak的**保守上界**；
   校验和重新求和一致、root项不低于原owner根Peak、最终Peak不低于活跃时已观测Peak。
   仅上界≤536870912B且其他原门槛齐才PASS。Total=2本身不再无条件PENDING，也不被伪装为无后代。
8. B03/B04原真实后代/timeout政策、原码与ready/done证据保留；同样要求完整树证明。
   调用 frozen_owned_call 现在显式传原 root_deadline_monotonic，三类owner均不新增/延长时钟或cap。

## 证据字段与明确边界

TREE_PEAK_PROOF 包含每成员 pid、creation/exit FILETIME、查询handle、alive_peak、final_peak、
opened/exit_observed/final_peak/close时间、close BOOL/error；另含累计total、成员数、查询次数、
未闭合monitor handles、失败/缺证及sum_final_peaks_upper_bound_bytes。
监督器自身Peak另列 supervisor_peak_separate，不加入worker树和；其scope明确截至proof seal。
如果需要监督器**进程完全退出后**的最终Lifetime Peak，由外层已持有监督器句柄的root另取，
不能拿本进程写JSON之前的值冒充写完退出后的峰值。

Polling不保证捕获任意短命进程。这里不降低门槛：漏了PID，累计total仍增加，精确对账会留PENDING。
最多256成员和2048次OpenProcess尝试是有界保护，触顶不签PASS。查询拒绝不换权限或遍历全机进程。
若平台对已退出进程不能返回最终GetProcessMemoryInfo，方法即在该平台不闭合，保持PENDING；
不借近退出采样值补齐。查询句柄关闭本身失败不重关，保留FAIL；未退出成员不提前关其monitor句柄，
终止失败链仍依原Job/灾难watchdog和disposable进程清理，不能声称Job0/完整内存已通过。

**主集成需知**：本租约不能改 resources.py。该文件旧 finalize_resources 的“必须无后代”帮助逻辑
仍可能保留；root最终消费应使用新的 job_bridge assessment.tree_peak_proof 的保守上界口径，
或由获授权写者在下一次冻结中同步消费者。不要用旧根31,924,224B或旧无后代布尔代替这份证明。
原停止P0不是成功记录；新静态SHA不构成恢复测试已获通过，恢复次数和消费仅由root登记。

## 自审与交回

仅静态读原C/job_bridge、恢复授权，逐段审原流程接缝、成员/PID复用、最终峰值、查询句柄释放、
原root/job关闭、原Job总数对账及B条件；LF/末尾换行/尾空白与SHA用PowerShell文件读核。
未 import、AST、compile、执行任何目标/fixture/Job、Git或网络；没有使用八次恢复中的任何一次。
实际API/ABI、Job PIDList语义、退出后GetProcessMemoryInfo可取性、时序/性能以及下一次P0均未验证。
源码及辅助写集交回后释放，不自行继续修改或运行。
