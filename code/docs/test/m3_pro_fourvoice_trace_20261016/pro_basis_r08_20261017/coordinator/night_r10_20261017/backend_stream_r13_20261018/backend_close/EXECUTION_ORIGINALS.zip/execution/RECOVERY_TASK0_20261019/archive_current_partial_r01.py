"""Current R13 PARTIAL original transfer, never a replacement for S1/S2 or a gate pass."""
import hashlib,json,time,zipfile
from pathlib import Path
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'PARTIAL_TRANSFER_CURRENT';D.mkdir(exist_ok=False)
P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
S=R/'code/software'/P/'backend_stream_r13_20261018';E=R/'code/docs/test'/P/'backend_stream_r13_20261018'
deadline=time.monotonic()+117
def check():assert time.monotonic()<deadline,'PARTIAL_TRANSFER120_CAP'
files=list(sorted(S.rglob('*')))+list(sorted(E.rglob('*')))
for f in O.rglob('*'):
 if not f.is_file() or f.is_relative_to(D) or '/STATIC_DELIVERY_' in f.as_posix():continue
 # Existing partial raw bytes, complete frozen full input and all actual receipts.
 if f.suffix in ('.json','.jsonl','.gz','.bin','.md','.diff','.py','.ps1','.txt') and not ('_RESPONSE.bin' in f.name and f.stat().st_size>2*1048576):files.append(f)
files=sorted(set(f for f in files if f.is_file()))
assert len(files)<=8192 and sum(f.stat().st_size for f in files)<=8*1024**3
path=D/'M3_R13_CURRENT_PARTIAL_ORIGINALS_20261019.zip';refs=[]
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
 for f in files:
  check();name=f.relative_to(R).as_posix();n=0;h=hashlib.sha256()
  with f.open('rb') as source,z.open(name,'w',force_zip64=f.stat().st_size>2*1024**3) as sink:
   for b in iter(lambda:source.read(1048576),b''):check();n+=len(b);h.update(b);assert sink.write(b)==len(b)
  refs.append({'member':name,'bytes':n,'sha256':h.hexdigest()})
 z.writestr('TRANSFER_MANIFEST.json',json.dumps({'schema':'M3_R13_PARTIAL_TRANSFER_MANIFEST_V2','payloads':refs,'NOT_A_SUCCESSFUL_W_OR_S1_S2':True,'new_source_result_commit':None,'M2_RECEIVED':False,'M2_ACCEPTED':False},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(path) as z:
 assert len(z.infolist())==len(refs)+1
 for ref in refs:
  n=0;h=hashlib.sha256()
  with z.open(ref['member']) as f:
   for b in iter(lambda:f.read(1048576),b''):check();n+=len(b);h.update(b)
  assert n==ref['bytes'] and h.hexdigest()==ref['sha256']
h=hashlib.sha256();n=0
with path.open('rb') as f:
 for b in iter(lambda:f.read(1048576),b''):check();n+=len(b);h.update(b)
result={'purpose':'User task0 private original delivery, current R13 PARTIAL; not S1/S2/gate/source-commit publication','file':{'path':path.relative_to(R).as_posix(),'bytes':n,'sha256':h.hexdigest()},'payloads':len(refs),'decoded_total_bytes':sum(x['bytes'] for x in refs),'all_sizes_SHA_CRC_verified':True,'elapsed_seconds':117-(deadline-time.monotonic())}
(D/'TRANSFER_RECEIPT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result))

