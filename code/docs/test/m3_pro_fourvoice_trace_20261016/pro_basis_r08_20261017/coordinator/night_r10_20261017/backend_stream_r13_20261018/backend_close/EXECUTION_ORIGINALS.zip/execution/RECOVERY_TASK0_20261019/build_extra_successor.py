"""Root frozen metadata only; no candidate import or fixture creation."""
import argparse
from datetime import datetime,timezone
import hashlib,json,uuid
from pathlib import Path
ROOT=Path.cwd().resolve()
OUT=ROOT/'code/output/m3_backend_stream_r13_20261018'
STEM='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
SOURCE=ROOT/'code/software'/STEM/'backend_stream_r13_20261018'
DOCS=ROOT/'code/docs/test'/STEM/'backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,x):
 assert not p.exists(),'NO_EXTRA_OVERWRITE'
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 p=Path(p).resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):n+=len(b);h.update(b)
 return {'path':p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else str(p),'bytes':n,'sha256':h.hexdigest()}
parser=argparse.ArgumentParser();parser.add_argument('slot',choices=('P0','K','V','B','W'));a=parser.parse_args()
ledger=read(OUT/'CONSUMPTION_LIVE.json');assert ledger['groups'][a.slot]['state']=='NOT_STARTED'
unit=None;p0_ref=None
if a.slot!='P0':
 assert ledger['recovery_attempts']['P0_RECOVERY_03']['state']=='PASS'
 p0=ledger['recovery_attempts']['P0_RECOVERY_03']['postcheck_evidence']['worker']
 unit=p0['cases'][0]['observed']['disk']['allocation_unit_bytes'];assert type(unit)is int and unit>0
 p0_ref={'receipt':ref(OUT/'RUNS/P0_RECOVERY_03/inner/worker/WORKER_LOCAL_RESULT.json'),'allocation_unit_bytes':unit}
# Small, finite parent envelopes are funded by the same failure bucket in the worker.
# Frozen owner samples at most 2s/25ms + endpoints; no per-input-row stdout exists.
base=f'RUNS/{a.slot}';parents=[base,base+'/inner'] if a.slot!='B' else [base]+[base+'/inner/'+x for x in ('B02','B03','B04')]
evidence={'kind':'FROZEN_SOURCE_FINITE_PARENT_RECORD_BOUND','per_file_bound_bytes':1048576,'owner_source_sha256':'5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c','bridge':ref(SOURCE/'job_bridge.py'),'basis':'Owner RESULT argv fixed; <=82 Job samples; fixture stdout fixed 4 lines; bridge prints only up to3 such owner receipts, never worker rows. CPython failure traceback finite frozen source, no per-row prints; 1MiB conservative per stream/result; verify actual sizes at terminal.'}
logs={}
for parent in parents:
 for name,role in [('stdout.bin','owner_stdout'),('stderr.bin','owner_stderr'),('RESULT.json','owner_result')]:
  logs[parent+'/'+name]={'role':role,'byte_cap':1048576,'evidence':evidence,'max_physical_write':1048576}
logs[base+'/inner/GROUP_COMPLETE.json']={'role':'parent_summary','byte_cap':1048576,'evidence':evidence,'max_physical_write':1048576}
logs['CONSUMPTION_LIVE.json']={'role':'parent_summary','byte_cap':1048576,'evidence':evidence,'max_physical_write':1048576}
extra={'accounting_profile':{'schema':'M3_R13_ACCOUNTING_PROFILE_V1','whole_output_root':str(OUT),'allocation_unit_bytes':unit,'file_metadata_bound_bytes':0,'directory_bound_bytes':0,'filesystem_bound_evidence':{'scope':'OWN_REGULAR_ARTIFACT_ALLOCATION_AND_TAIL_ROUNDING_NOT_GLOBAL_MFT','P0':p0_ref,'P0_discovery_allowed':a.slot=='P0','full_volume_metadata':'Not attributed as workspace; included by actual volume free observations','external_disk_activity':'No guarantee of continuous free reserve against unrelated writers'},'initial_roles':{},'enforce_start_free':a.slot=='W'},'external_log_escrows':logs,'delivery_channel_confirmed':True,'delivery':{'location':'https://github.com/huangAngel730/fpga-electronic-piano/releases/tag/untagged-20cfd8909421dcc18a6c','retrieval_method':'M2 repository owner/collaborator retrieves draft assets; existing PARTIAL asset download-back verified; future W complete manifest/upload separately verified','all_logical_originals_recoverable':True,'M2_received':False}}
if a.slot=='K':extra['contract_index_ref']=ref(DOCS/'contract_bundle/CONTRACT_INDEX.json')
if a.slot in ('B','W'):
 templates=read(OUT/'roles/night5/W_BINDER_R03_IDENTITY.json')['templates'];extra['fixture_templates']=templates
 if a.slot=='W':
  freeze={'schema':'M3_R13_W_INPUT_BINDER_FREEZE_V1','run_id':'W01','nonce':uuid.uuid4().hex,'templates':templates,'physical_budgets':{'all_stores':8589934592,'delivery':8589934592,'raw_plain':4631191552,'all_other':3958743040}}
  path=OUT/'ADMISSION_EXTRAS/W_INPUT_FREEZE.json';save(path,freeze);extra.update(w_input_freeze_ref=ref(path),resource_profile='PASS')
path=OUT/'ADMISSION_EXTRAS'/(a.slot+'_EXTRA.json');save(path,extra)
print(json.dumps({'extra':ref(path),'target_runs':0,'fixture_creation':0}))
