import hashlib,json,time,shutil
from pathlib import Path
from datetime import datetime,timezone,timedelta
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_HOUR_CATEGORY_10';S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v,new=True):
 assert not new or not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 p=p.resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
proposal=D/'EXECUTION_PROPOSAL.json';assert ref(proposal)['sha256']=='ecea603fabd1038ad2cc64dd83c33b1ee692b2c124b32bf783a3ada9859f98c5'
auth=D/'AUTHORIZATION.json';save(auth,{'schema':'M3_R13_HOUR10_CATEGORY_APPROVAL_V1','approved':True,'approved_proposal_sha256':'ecea603fabd1038ad2cc64dd83c33b1ee692b2c124b32bf783a3ada9859f98c5','authority':'Direct user answer: 批准修正并重跑一小时','recorded_utc':datetime.now(timezone.utc).isoformat(),'new_slot':'W_HOUR_10','cap_seconds':3600,'deadline':'2026-10-19T12:00:00+08:00','no_consumption_reset':True,'no_resource_limit_change':True})
# Baseline is generic retained state. Keep the most recent failed run there;
# older known compressed payloads and delivery aggregates use their real roles.
old=read(D/'CAPACITY_AND_CLASSIFICATION.json');roles={k:v for k,v in old['initial_roles'].items() if not ('RUNS/W_CODEC_08/' in k and v=='all_stores')}
totals={'plain_raw':0,'gzip_payload':0,'delivery_copy':0,'baseline':0};aliases={'raw_plain':'plain_raw','all_stores':'gzip_payload','delivery':'delivery_copy'};files=[];dirs=[]
for p in O.rglob('*'):
 if p.is_dir():dirs.append(p)
 if not p.is_file():continue
 files.append(p);rel=p.relative_to(O).as_posix();category=aliases.get(roles.get(rel),roles.get(rel,'baseline'));totals[category]+=p.stat().st_size
payloads=sum(x=='all_stores' for x in roles.values());delivery=sum(x=='delivery' for x in roles.values())
assert totals['baseline']<512*1048576 and totals['gzip_payload']<8*1024**3 and totals['delivery_copy']<8*1024**3
assert payloads+1024<=2048 and delivery+1536<=2048 and len(files)+1024+1536+512<=16384 and len(dirs)+512<=8192
cap=D/'CLASSIFICATION_EXECUTION_R02.json';save(cap,{'schema':'M3_R13_INITIAL_ROLES_EXECUTION_REFINEMENT_V2','initial_roles':roles,'predicted_initial_bytes':totals,'earlier_payload_parts':payloads,'payload_part_upper_including_new_run':payloads+1024,'delivery_part_upper_including_new_run':delivery+1536,'actual_files':len(files),'actual_dirs':len(dirs),'whole_file_upper':len(files)+1024+1536+512,'baseline_definition':'Generic pre-existing state, including latest failedW08 retained gzip. Earlier payload gzip declared explicitly. All bytes/counts still included; no file moves/deletes or byte/count limit changes.','prior_all-gzip_mapping_is_static_alternative':ref(D/'CAPACITY_AND_CLASSIFICATION.json'),'implementation_only_within_approved_category_fix':True})
for a,b in [('w_hour_09_worker.py','w_hour_10_worker.py'),('hour_09_bridge.py','hour_10_bridge.py'),('root_run_hour_09.py','root_run_hour_10.py')]:
 text=(T/a).read_text('utf-8').replace('W_HOUR_09','W_HOUR_10').replace('w_hour_09_worker.py','w_hour_10_worker.py').replace('hour_09_bridge.py','hour_10_bridge.py')
 if b=='root_run_hour_10.py':
  marker='raw = args.contract.read_bytes()';text=text.replace(marker,"cat_auth=OUT/'RECOVERY_TASK0_20261019/W_HOUR_CATEGORY_10/AUTHORIZATION.json'\nassert read(cat_auth)['approved'] is True and read(cat_auth)['approved_proposal_sha256']=='ecea603fabd1038ad2cc64dd83c33b1ee692b2c124b32bf783a3ada9859f98c5'\n"+marker)
 assert not (T/b).exists();(T/b).write_text(text,encoding='utf-8',newline='\n')
l=read(O/'CONSUMPTION_LIVE.json');assert l['recovery_attempts']['W_HOUR_09']['state']=='FAILED_STOP';assert 'W_HOUR_10' not in l['recovery_attempts'];shutil.copyfile(O/'CONSUMPTION_LIVE.json',D/'CONSUMPTION_BEFORE_CATEGORY_FIX.json');l['recovery_attempts']['W_HOUR_10']={'state':'NOT_STARTED','attempts':0,'charged_seconds':0,'cap_seconds':3600,'cases_max':1,'authority':ref(auth)};save(O/'CONSUMPTION_LIVE.json',l,new=False)
items={}
for x in read(T/'W_FILECOUNT_RECOVERY_R01/FREEZE.json')['frozen_files']:
 a=ref(Path(x['path']));assert a==x;items[a['path'].casefold()]=a
for p in [auth,proposal,cap,T/'root_run_hour_10.py',T/'hour_10_bridge.py',T/'w_hour_10_worker.py',T/'W_HOUR_REPLAY_09/AUTHORIZATION_CLOSING.json']:
 a=ref(p);items[a['path'].casefold()]=a
fp=D/'FREEZE.json';save(fp,{'state':'W_HOUR_10_RUNTIME_SOURCE_UNCHANGED','frozen_files':list(items.values()),'category_policy':ref(cap),'old_failure_states_preserved':True})
base=O/'ADMISSIONS/W_HOUR_10';ap=base/'ADMISSION.json';owner=O/'RUNS/W_HOUR_10/inner';controller=T/'root_run_hour_10.py';bridge=T/'hour_10_bridge.py';adm=read(O/'ADMISSIONS/W_HOUR_09/ADMISSION.json');adm.update(root_accounting_slot='W_HOUR_10',root_deadline_monotonic=time.monotonic()+3600,source_freeze=ref(fp),hour_category_authorization=ref(auth),prepared_utc=datetime.now(timezone.utc).isoformat());adm['accounting_profile']['initial_roles']=roles;adm['external_log_escrows']={k.replace('RUNS/W_HOUR_09/','RUNS/W_HOUR_10/'):v for k,v in adm['external_log_escrows'].items()};adm['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller']=ref(controller);adm['external_log_escrows']['RUNS/W_HOUR_10/inner/GROUP_COMPLETE.json']['evidence']['bridge']=ref(bridge)
py=str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve());adm['argv']=[py,'-X','utf8','-B',str(T/'w_hour_10_worker.py'),'--admission',str(ap),'--sha256','@ADMISSION_SHA256@','--output',str(owner/'worker')];save(ap,adm)
argv=[py,'-X','utf8','-B',str(bridge),'--admission',str(ap),'--sha256',ref(ap)['sha256'],'--output',str(owner)];cp=base/'ROOT_CONTRACT.json';save(cp,{'root_approved':True,'slot':'W','attempt_id':'W_HOUR_10','wire_group':'W','plan_sha256':adm['plan_sha256'],'cap_seconds':3600,'all_target_writers_closed':True,'new_user_authority':ref(auth),'frozen_files':[*items.values(),ref(fp),ref(ap)],'target_script':str(bridge),'argv':argv,'worker_result_relative_path':'inner/worker/WORKER_COMPLETE.json','bridge_result_relative_path':'inner/GROUP_COMPLETE.json','expected_case_ids':['W01']})
save(O/'scheduler_state/W_HOUR10_AUTHORITY.json',{'newest_user_approved_once':True,'slot':'W_HOUR_10','cap_seconds':3600,'old_no_replay_and_W09_stops_historical':True,'authority':ref(auth),'deadline':l['deadline']})
print(json.dumps({'root_contract':ref(cp),'classification':totals,'payloads':payloads,'delivery':delivery}))
