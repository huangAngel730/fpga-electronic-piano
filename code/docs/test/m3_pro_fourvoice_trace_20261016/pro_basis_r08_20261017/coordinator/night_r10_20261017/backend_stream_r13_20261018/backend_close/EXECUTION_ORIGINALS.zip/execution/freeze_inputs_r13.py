"""Root source/data identity freeze; metadata only, no target import/test."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
STEM = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
SOURCE = ROOT / 'code/software' / STEM / 'backend_stream_r13_20261018'
DOCS = ROOT / 'code/docs/test' / STEM / 'backend_stream_r13_20261018'


def read(path):
    return json.loads(path.read_text('utf-8'))


def stamp(path):
    path = path.resolve()
    digest, count = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            count += len(block)
            digest.update(block)
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT)
            else str(path), 'bytes': count, 'sha256': digest.hexdigest()}


def descriptors(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= set(value):
            if isinstance(value['path'], str) and type(value['bytes']) is int:
                yield {key: value[key] for key in ('path', 'bytes', 'sha256')}
        for item in value.values():
            yield from descriptors(item)
    elif isinstance(value, list):
        for item in value:
            yield from descriptors(item)


assert read(OUT / 'WRITE_LEASES_CLOSED.json')['all_target_writers_closed'] is True
assert all(item['state'] == 'NOT_STARTED' for item in
           read(OUT / 'CONSUMPTION_LIVE.json')['groups'].values())
allow = read(DOCS / 'backend_close/PUBLISH_ALLOWLIST.json')
paths = [ROOT / name for name in allow['source_files']]
assert len(paths) == 13 and len(set(paths)) == 13
paths += sorted((DOCS / 'contract_bundle').iterdir())
paths += sorted((DOCS / 'capture_originals').iterdir())
paths += [DOCS / 'backend_close' / name for name in (
    'PLAN.json', 'AUTHORIZATION.json', 'TASK_ORIGINAL.md',
    'START_AND_DEADLINE.json', 'BASELINE.json', 'PUBLISH_ALLOWLIST.json')]
paths += [OUT / name for name in ('root_run_r13.py', 'prepare_admission_r13.py',
                                 'DELIVERY_CHANNEL_CONFIRMED.json')]
deps_path = SOURCE.parent / 'frontend_close_r12_20261018/DEPENDENCIES.json'
template_path = OUT / 'roles/night5/W_BINDER_R03_IDENTITY.json'
paths += [deps_path, template_path]
refs = list(descriptors(read(deps_path)))
refs += list(descriptors(read(template_path)['templates']))
refs += list(descriptors(read(SOURCE / 'DEPENDENCIES.json')))
for ref in refs:
    path = Path(ref['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = stamp(path)
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256'], ref['path']
    paths.append(path)
actual = {}
for path in paths:
    assert path.is_file(), str(path)
    item = stamp(path)
    actual[str(path.resolve()).casefold()] = item
document = {'schema': 'M3_R13_SOURCE_AND_INPUT_FREEZE_V1',
            'state': 'FROZEN_BY_ROOT',
            'recorded_utc': datetime.now(timezone.utc).isoformat(),
            'frozen_files': sorted(actual.values(), key=lambda item: item['path']),
            'formal_C_source_files': 13, 'A_contract_files': 9, 'B_index_files': 7,
            'dependency_descriptors_verified': len(refs),
            'no_target_import_compile_or_execution': True,
            'runtime_originals_constructed_only_in_their_approved_groups': True,
            'runtime_future_outputs_not_predeclared_as_pass': True}
target = OUT / 'FREEZE_BEFORE_P0.json'
assert not target.exists(), 'NO_SILENT_REFREEZE'
target.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n',
                  encoding='utf-8', newline='\n')
print(json.dumps({'files_frozen': len(actual), 'target_runs': 0,
                  'freeze': stamp(target)}))
