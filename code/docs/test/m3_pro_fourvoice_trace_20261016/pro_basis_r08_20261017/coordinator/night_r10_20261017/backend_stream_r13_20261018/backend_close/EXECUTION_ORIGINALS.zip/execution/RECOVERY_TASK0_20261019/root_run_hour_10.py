"""Single root R13 execution authority; candidates cannot consume slots."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time
import types

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
STEM = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
SOURCE = ROOT / 'code/software' / STEM / 'backend_stream_r13_20261018'
CLOSE = ROOT / 'code/docs/test' / STEM / 'backend_stream_r13_20261018/backend_close'
LEGACY = ROOT / 'code/software' / STEM / 'frontend_close_r12_20261018/selftest.py'
PLAN_SHA = '729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3'
AUTH_SHA = 'f6db0a87ca66d6dd30a21203ac2210db6260c91aea875d2fac4534ac53bf98e5'


def read(path):
    return json.loads(path.read_text('utf-8'))


def save(path, value):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    assert len(raw.encode('utf-8')) <= 4 * 1048576, 'ROOT_LEDGER_FINITE_4MIB_BOUND'
    path.write_text(raw, encoding='utf-8', newline='\n')


def stamp(path):
    digest, total = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            total += len(block)
            digest.update(block)
    return {'path': str(path), 'bytes': total, 'sha256': digest.hexdigest()}


def verify(ref):
    path = Path(ref['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = stamp(path)
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256'], ref['path']


def authority():
    assert stamp(CLOSE / 'PLAN.json')['sha256'] == PLAN_SHA
    assert stamp(CLOSE / 'AUTHORIZATION.json')['sha256'] == AUTH_SHA
    auth = read(CLOSE / 'AUTHORIZATION.json')
    assert auth['approved'] is True and auth['approved_plan_sha256'] == PLAN_SHA


def owner():
    raw = LEGACY.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c'
    module = types.ModuleType('_r13_private_unchanged_r12_owner')
    module.__file__ = str(LEGACY)
    exec(compile(raw, str(LEGACY), 'exec', dont_inherit=True), module.__dict__)
    module.OUTPUT = OUT
    return module


def dependencies(slot, ledger):
    r=ledger['recovery_attempts']
    required={'P1':(), 'C':('P1_FILES_R01',), 'B':('P1_FILES_R01','C_CODEC_08'), 'W':('P1_FILES_R01','C_CODEC_08','B_FILES_R01'), 'GATE_01':('W_HOUR_10',), 'S1':(), 'GATE_02':(), 'S2':()}[slot]
    for parent in required:assert r[parent]['state']=='PASS',parent
    for parent in {'S1':('GATE_01',),'GATE_02':('GATE_01','S1'),'S2':('GATE_02',)}.get(slot,()):assert ledger['groups'][parent]['state']=='PASS',parent
    assert ledger['groups']['K']['state']=='PASS' and ledger['groups']['V']['state']=='PASS'
    if slot=='P1':assert read(OUT/'WRITE_LEASES_CLOSED.json')['all_target_writers_closed']
    if slot=='W':assert read(OUT/'RECOVERY_TASK0_20261019/DELIVERY_CHANNEL_R02_GITHUB.json')['download_back_verified']
    if slot=='S2':assert read(OUT/'PUBLICATION_ACTUAL.json')['remote_containment']


parser = argparse.ArgumentParser()
parser.add_argument('slot', choices=('C','B','W','P1','GATE_01','S1','GATE_02','S2'))
parser.add_argument('--contract', type=Path, required=True)
parser.add_argument('--sha256', required=True)
args = parser.parse_args()
started = time.monotonic()
authority()
new_auth=read(OUT/'RECOVERY_TASK0_20261019/W_FILECOUNT_RECOVERY_R01/AUTHORIZATION_R01.json')
assert new_auth['approved'] is True and new_auth['approved_proposal_sha256']=='33ffbecbb9aa956f4308f8fc77ad43ab003678687b8c415d7672bb5cfcbd877c'
hour_auth=OUT/'RECOVERY_TASK0_20261019/W_HOUR_REPLAY_09/AUTHORIZATION_CLOSING.json'
assert stamp(hour_auth)['sha256']=='138582298f07c5e3103005a05eb574be3c71af397d9b99bc1ae3483035e4ae79'
assert read(hour_auth)['approved'] is True
cat_auth=OUT/'RECOVERY_TASK0_20261019/W_HOUR_CATEGORY_10/AUTHORIZATION.json'
assert read(cat_auth)['approved'] is True and read(cat_auth)['approved_proposal_sha256']=='ecea603fabd1038ad2cc64dd83c33b1ee692b2c124b32bf783a3ada9859f98c5'
raw = args.contract.read_bytes()
assert hashlib.sha256(raw).hexdigest() == args.sha256
contract = json.loads(raw)
assert contract['root_approved'] is True and contract['slot'] == args.slot
assert contract['plan_sha256'] == PLAN_SHA
ledger_path = OUT / 'CONSUMPTION_LIVE.json'
ledger = read(ledger_path)
attempt_id = contract.get('attempt_id')
slot = ledger['recovery_attempts'][attempt_id] if attempt_id else ledger['groups'][args.slot]
if attempt_id:
    mapping={'P1_FILES_R01':'P1','C_CODEC_08':'C','B_FILES_R01':'B','W_CODEC_08':'W','W_HOUR_10':'W'}
    assert attempt_id in mapping and args.slot==mapping[attempt_id]
    verify(contract['new_user_authority'])
assert slot['state'] == 'NOT_STARTED' and slot['attempts'] == 0, 'CONSUMED_SLOT'
assert contract['cap_seconds'] == slot['cap_seconds']
dependencies(args.slot, ledger)
remaining = sum(v['cap_seconds'] for v in ledger['groups'].values() if v['state'] == 'NOT_STARTED')
remaining += sum(v['cap_seconds'] for k,v in ledger['recovery_attempts'].items() if k in ('P1_FILES_R01','B_FILES_R01','W_CODEC_08','W_HOUR_10') and v['state']=='NOT_STARTED')
remaining += ledger['network']['charged_cap_seconds_max'] - sum(v['charged_seconds'] for v in ledger['network']['operations'])
remaining += ledger['local_git']['charged_cap_seconds_max'] - sum(v.get('charged_seconds', 0) for v in ledger['local_git']['operations'])
extra=read(OUT/'RECOVERY_TASK0_20261019/W_HOUR_REPLAY_09/CLOSING_CONSUMPTION.json')
remaining += extra['network']['charged_cap_seconds_max']-sum(x['charged_seconds'] for x in extra['network']['operations'])+120
deadline = datetime.fromisoformat(ledger['deadline'])
assert datetime.now(timezone.utc) + timedelta(seconds=remaining + 60) <= deadline, 'FULL_REMAINING_CAPS_AND_MARGIN_NOT_AVAILABLE'
assert contract['all_target_writers_closed'] is True
argv = contract['argv']
assert argv and Path(argv[0]).is_absolute()
target = Path(contract['target_script']).resolve()
if args.slot.startswith('GATE_'):
    assert target == OUT / 'RECOVERY_TASK0_20261019/GATE_CHILD_HOUR_09.ps1'
else:
    assert target in (OUT/'RECOVERY_TASK0_20261019/hour_10_bridge.py',OUT/'seal_r13.py')
assert str(target) in argv, 'ONLY_FROZEN_R13_TARGET_ENTRY_ALLOWED'
slot.update(state='CONSUMED_BEFORE_LAUNCH', attempts=1, charged_seconds=slot['cap_seconds'],
            contract_sha256=args.sha256, started_utc=datetime.now(timezone.utc).isoformat())
save(ledger_path, ledger)
# The root deadline covers source hashing and postchecks too. If it fires,
# the consumed receipt remains; OS closes this process's kill-on-close Job.
# It never authorizes replay of an incomplete/unknown run.
outer_remaining = slot['cap_seconds'] - (time.monotonic() - started) - 0.1
assert outer_remaining > 5
outer_timer = threading.Timer(outer_remaining, lambda: os._exit(124))
outer_timer.daemon = True
outer_timer.start()
for ref in contract['frozen_files']:
    verify(ref)
before_elapsed = time.monotonic() - started
child_cap = slot['cap_seconds'] - before_elapsed - 3
assert child_cap >= 5
run = OUT / 'RUNS' / (attempt_id or args.slot)
private_temp = OUT / 'RUNTIME_TEMP'
private_temp.mkdir(parents=True, exist_ok=True)
# Process-local inherited temporary paths keep child intermediates in the
# same owned artifact scope. No user/system environment setting is changed.
os.environ['TEMP'] = str(private_temp)
os.environ['TMP'] = str(private_temp)
result = owner().owned_call(argv, ROOT, run, child_cap)
good = result['exit_code'] == 0 and result['exit_class'] == 'NATURAL'
good = good and all(result[key] for key in ('within_cap', 'job_handle_closed', 'root_process_handle_closed', 'job_zero_observed_before_job_close'))
evidence = {}
try:
    for ref in contract['frozen_files']:
        verify(ref)
    bridge = None
    if good and contract.get('bridge_result_relative_path'):
        bridge = read(run / contract['bridge_result_relative_path'])
        assert bridge['status'] == 'PASS' and bridge['group'] == contract.get('wire_group', args.slot)
        assert bridge['assessment']['status'] == 'PASS'
        evidence['bridge'] = bridge
    if good and args.slot in ('P0', 'P1', 'K', 'V', 'B', 'W', 'R', 'C'):
        worker = read(run / contract['worker_result_relative_path'])
        pending_parent = worker['status'] == 'PASS_LOCAL_PENDING_PARENT'
        assert worker['status'] == 'PASS' or (pending_parent and bridge is not None
                                             and (args.slot in ('P0', 'P1', 'B') or
                                                  (args.slot == 'R' and contract.get('repair_group') == 'B')))
        cases = []
        for original in worker['cases']:
            case = dict(original)
            if args.slot in ('P0', 'P1') and case['id'] == 'P001':
                assert bridge is not None
                assert case['status'] in ('PASS', 'PASS_LOCAL_PINS', 'PASS_LOCAL_PENDING_PARENT')
                case['local_status'] = case['status']
                case['status'] = 'PASS'
                case['parent_proof'] = contract['bridge_result_relative_path']
            if (args.slot == 'B' or (args.slot == 'R' and contract.get('repair_group') == 'B')) and case['id'] in ('B02', 'B03', 'B04'):
                assert bridge is not None
                parent = bridge['parent_cases'][case['id']]
                assert parent['assessment']['status'] == 'PASS'
                case['worker_status'] = case['status']
                case['status'] = 'PASS'
                case['parent_proof'] = parent
            cases.append(case)
        if args.slot == 'B' or (args.slot == 'R' and contract.get('repair_group') == 'B'):
            assert bridge is not None and bridge['B02_B03_B04_parent_observation'] is True
            for case_id in ('B02', 'B03', 'B04'):
                if case_id not in {case['id'] for case in cases}:
                    parent = bridge['parent_cases'][case_id]
                    assert parent['assessment']['status'] == 'PASS'
                    cases.append({'id': case_id, 'status': 'PASS', 'parent_proof': parent})
        observed = {case['id'] for case in cases}
        good = observed == set(contract['expected_case_ids']) and all(case['status'] == 'PASS' for case in cases)
        good = good and len(cases) == len(observed) <= slot.get('cases_max', 1)
        evidence.update(worker=worker, cases=cases, status='PASS' if good else 'FAIL')
    if good and args.slot.startswith('GATE_'):
        import re
        text = (run / 'stdout.bin').read_text('utf-8', errors='replace')
        checks = re.findall(r'^\s*\[(PASS|FAIL)\] (.+)$', text, re.M)
        good = len(checks) == 9 and all(state == 'PASS' for state, _ in checks) and 'All repository checks passed.' in text
        evidence = {'nine_checks': checks, 'all_pass': good}
    if good and args.slot in ('S1', 'S2'):
        sealed = read(OUT / 'SEAL' / args.slot / 'SEAL_RESULT.json')
        assert sealed['status'] == 'PASS' and sealed['phase'] == args.slot
        for archive in sealed['archives']:
            verify(archive['file'])
            assert archive['all_payload_sizes_SHAs_and_ZIP_CRC_verified'] is True
        evidence = {'seal_result': sealed}
except BaseException as error:
    good = False
    evidence = {'parent_postcheck_failure': type(error).__name__ + ':' + str(error),
                'worker_actual_result_preserved': True}
if good and evidence.get('worker'):
    # Canonical raw files retain all evidence; avoid recursive ledger duplication.
    evidence = {'status': 'PASS', 'worker_result_ref': stamp(run / contract['worker_result_relative_path']),
                'bridge_result_ref': stamp(run / contract['bridge_result_relative_path']),
                'cases': [{'id': x['id'], 'status': x['status']} for x in evidence['cases']],
                'normalization_rule': 'P0/P1 and B parent statuses promoted only after verified actual parent proof; raw originals referenced'}
actual_elapsed = time.monotonic() - started
good = good and actual_elapsed <= slot['cap_seconds']
slot.update(state='PASS' if good else 'FAILED_STOP', actual_result=result,
            controller_elapsed_seconds=actual_elapsed, postcheck_evidence=evidence,
            ended_utc=datetime.now(timezone.utc).isoformat())
save(ledger_path, ledger)
outer_timer.cancel()
print(json.dumps({'slot': args.slot, 'state': slot['state'], 'exit_code': result['exit_code'], 'controller_elapsed_seconds': actual_elapsed}))
raise SystemExit(0 if good else 1)
