"""R13-only static candidate: reuse the frozen R12 owner without rewriting it.

No module import starts a process. Only the root coordinator may call
run_backend_group after independently consuming the approved slot. Admission
fields are an integration guard, not a new grant or a shared consumption ledger.
"""

import ast
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import threading
import time
import types


PLAN_SHA256 = "729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3"
ROOT_EXECUTOR = "01a14050-cd98-7c41-8004-5d3e25765167"
BUSINESS_ROOT = (
    "code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/"
    "coordinator/night_r10_20261017/backend_stream_r13_20261018"
)
OWNED_OUTPUT = "code/output/m3_backend_stream_r13_20261018"
LEGACY_SOURCE = (
    "code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/"
    "coordinator/night_r10_20261017/frontend_close_r12_20261018/selftest.py"
)
LEGACY_SHA256 = "5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c"
OWNER_SOURCE = "code/software/t052_runner_acceptance_candidate_20261012/windows_job.py"
OWNER_SHA256 = "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b"
CAPS = {"K": 120, "V": 120, "B": 120, "W": 900, "R": 120}


def _plain_path(value):
    """Reject existing reparse components before any path normalization."""
    path = Path(os.path.abspath(value))
    for part in (path, *path.parents):
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or (
            getattr(info, "st_file_attributes", 0) & 0x400
        ):
            raise ValueError("REPARSE_PATH_REJECTED")
    return path


def _within(path, root):
    if path == root or not path.is_relative_to(root):
        raise ValueError("STRICT_WORKSPACE_CHILD_REQUIRED")


def _frozen_bytes(path, expected_sha, max_bytes):
    blocks, total = [], 0
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while True:
            block = source.read(min(1024 * 1024, max_bytes - total + 1))
            if not block:
                break
            total += len(block)
            if total > max_bytes:
                raise ValueError("CONTROL_SOURCE_TOO_LARGE:" + path.name)
            digest.update(block)
            blocks.append(block)
    if digest.hexdigest() != expected_sha:
        raise ValueError("FROZEN_SOURCE_OR_ADMISSION_CHANGED:" + path.name)
    return b"".join(blocks)


def _frozen_binary_identity(path, expected_sha):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while True:
            block = source.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    if digest.hexdigest() != expected_sha:
        raise ValueError("FROZEN_PYTHON_BINARY_CHANGED")


def load_frozen_owned_call(root, output_root):
    """Extract four original definitions; no copied/reimplemented Job lifecycle.

    This executes the selected original definitions only when root calls it.
    The R12 whole source and native-owner source must both match their raw pins.
    R12 main/fixtures/import-time workflow are never executed.
    """
    root, output_root = _plain_path(root), _plain_path(output_root)
    if output_root != root / OWNED_OUTPUT:
        raise ValueError("R13_OUTPUT_ROOT_REQUIRED")
    source_path = _plain_path(root / LEGACY_SOURCE)
    raw = _frozen_bytes(source_path, LEGACY_SHA256, 1024 * 1024)
    _frozen_bytes(_plain_path(root / OWNER_SOURCE), OWNER_SHA256, 1024 * 1024)
    wanted = {"JobAccounting", "job_accounting", "peak_working_set", "owned_call"}
    parsed = ast.parse(raw, filename=str(source_path))
    selected = [node for node in parsed.body if isinstance(
        node, (ast.ClassDef, ast.FunctionDef)
    ) and node.name in wanted]
    if len(selected) != 4 or {node.name for node in selected} != wanted:
        raise ValueError("FROZEN_OWNER_DEFINITIONS_MISSING")
    module = types.ModuleType("_r13_reused_r12_owned_call")
    module.__dict__.update({
        "ctypes": ctypes, "wintypes": wintypes, "datetime": datetime,
        "timezone": timezone, "hashlib": hashlib, "json": json, "os": os,
        "Path": Path, "subprocess": subprocess, "threading": threading,
        "time": time, "types": types, "ROOT": root, "OUTPUT": output_root,
    })
    body = ast.Module(body=selected, type_ignores=[])
    exec(compile(body, str(source_path), "exec", dont_inherit=True), module.__dict__)
    return module.owned_call


def evaluate_owned_result(record, cap_seconds, *, native_cleanup_evidence=None):
    """Fail closed on missing receipt, non-natural exit, cleanup, or descendants.

    Cumulative Job total==1 is necessary for the single-worker memory claim:
    root is assigned while suspended, and the pinned owner allows no breakaway.
    If descendants exist, this candidate supplies no concurrent tree peak.
    It never substitutes a sum of separate process lifetime peaks.
    """
    issues, pending = [], []
    if not isinstance(record, dict):
        return {"status": "FAIL", "issues": ["OWNED_RESULT_MISSING"]}
    for key in ("job_handle_closed", "root_process_handle_closed",
                "job_zero_observed_before_job_close", "within_cap"):
        if record.get(key) is not True:
            issues.append(key)
    if record.get("exit_class") != "NATURAL" or record.get("exit_code") != 0:
        issues.append("NATURAL_ZERO_REQUIRED")
    if record.get("process_exit_code") != 0 or record.get("error"):
        issues.append("PROCESS_ERROR")
    elapsed = record.get("elapsed_seconds")
    if type(elapsed) not in (int, float) or not 0 <= elapsed <= cap_seconds:
        issues.append("ABSOLUTE_CAP_NOT_PROVED")
    samples = record.get("samples")
    before = record.get("before_root_handle_close")
    accounting = ([before] if isinstance(before, dict) else [])
    accounting += samples if isinstance(samples, list) else []
    if not isinstance(before, dict) or not samples or any(
        not isinstance(item, dict) or type(item.get("total")) is not int
        or item.get("total") != 1 or type(item.get("returned_bytes")) is not int
        or item.get("returned_bytes") != 48 for item in accounting
    ):
        pending.append("COMPLETE_LIFETIME_NO_DESCENDANT_PROOF_MISSING")
    if (not isinstance(samples, list) or not samples
            or not isinstance(samples[-1], dict) or samples[-1].get("active") != 0):
        issues.append("JOB_ZERO_SAMPLE_MISSING")
    peak = record.get("peak_working_set", {})
    if not isinstance(peak, dict):
        peak = {}
    if ("PeakWorkingSet64" not in str(peak.get("metric", ""))
            or type(peak.get("bytes")) is not int or peak["bytes"] <= 0
            or peak.get("pointer_bits") != 64):
        pending.append("64BIT_WORKER_PEAK_MISSING")
    elif peak["bytes"] > 512 * 1024 * 1024:
        issues.append("WORKER_PEAK_OVER_512MIB")
    # The old close() clears its Python handle attribute without recording
    # CloseHandle's BOOL. Preserve that historical flag, but do not promote it
    # into new native-close-success evidence.
    if (not isinstance(native_cleanup_evidence, dict)
            or native_cleanup_evidence.get("job_close_succeeded") is not True
            or native_cleanup_evidence.get("root_process_close_succeeded") is not True
            or not native_cleanup_evidence.get("evidence_path")):
        pending.append("NATIVE_CLOSE_SUCCESS_NOT_RECORDED_BY_LEGACY_OWNER")
    return {"status": "FAIL" if issues else "PENDING" if pending else "PASS",
            "issues": issues, "pending": pending,
            "scope": "owned_job_single_worker_only",
            "workspace_resource_proof": "PENDING_SEPARATE_ALL_WRITER_COVERAGE",
            "supervisor_memory": "PENDING_SEPARATE_MEASUREMENT"}


def run_backend_group(root, admission_path, admission_sha256):
    """Root-only use after freeze; business argv is frozen by root, not invented.

    Admission must bind argv to this R13 selftest.py and frozen Python binary.
    main3 must adopt/freeze the actual selftest CLI before root may use it.
    Inherited environment is checked, never changed by this adapter.
    Native stdout/stderr and RESULT writes in the old owner are NOT budget-
    instrumented: P0 must supply an external bound or W remains NO_GO.
    """
    bridge_started = time.monotonic()
    root = _plain_path(root)
    output_root = _plain_path(root / OWNED_OUTPUT)
    admission_path = _plain_path(admission_path)
    _within(admission_path, output_root)
    raw = _frozen_bytes(admission_path, admission_sha256, 1024 * 1024)
    admission = json.loads(raw.decode("utf-8"))
    if (admission.get("plan_sha256") != PLAN_SHA256
            or admission.get("executor_thread") != ROOT_EXECUTOR
            or admission.get("state") != "CONSUMED_RUNNING"
            or admission.get("preflight_status") != "PASS"
            or admission.get("source_frozen") is not True
            or admission.get("deadline_reservation_pass") is not True
            or admission.get("outer_full_lifetime_owner_ready") is not True
            or not admission.get("slot_nonce")):
        raise ValueError("ROOT_FROZEN_CONSUMED_ADMISSION_REQUIRED")
    group = admission.get("group")
    if group not in CAPS or admission.get("absolute_cap_seconds") != CAPS[group]:
        raise ValueError("R13_BUSINESS_SLOT_MISMATCH")
    if group == "W" and admission.get("all_writer_resource_coverage") is not True:
        raise ValueError("W_ALL_WRITER_RESOURCE_COVERAGE_REQUIRED")
    deadline = datetime.fromisoformat(admission["deadline"])
    if deadline.tzinfo is None or (deadline - datetime.now(timezone.utc)).total_seconds() < CAPS[group]:
        raise ValueError("ROOT_DEADLINE_NO_LONGER_FITS_GROUP")
    argv = admission.get("argv")
    if not isinstance(argv, list) or len(argv) < 6 or any(
        not isinstance(arg, str) for arg in argv
    ):
        raise ValueError("FROZEN_BUSINESS_ARGV_REQUIRED")
    python_path = _plain_path(argv[0])
    if not Path(argv[0]).is_absolute() or not Path(argv[4]).is_absolute():
        raise ValueError("ABSOLUTE_FROZEN_EXECUTABLE_AND_ENTRY_REQUIRED")
    if argv[1:4] not in (["-B", "-X", "utf8"], ["-X", "utf8", "-B"]) or _plain_path(argv[4]) != (
        root / BUSINESS_ROOT / "selftest.py"
    ):
        raise ValueError("ONLY_R13_SELFTEST_WORKER_ALLOWED")
    if "--worker" not in argv[5:]:
        raise ValueError("WORKER_MODE_REQUIRED")
    _frozen_binary_identity(python_path, admission["python_sha256"])
    _frozen_bytes(_plain_path(argv[4]), admission["selftest_sha256"], 1024 * 1024)
    environment = admission.get("inherited_environment_sha256")
    if not isinstance(environment, dict) or not {"TEMP", "TMP"} <= environment.keys():
        raise ValueError("FROZEN_ENVIRONMENT_REQUIRED")
    for key, expected in environment.items():
        value = os.environ.get(key)
        if value is None or hashlib.sha256(value.encode("utf-8")).hexdigest() != expected:
            raise ValueError("INHERITED_ENVIRONMENT_CHANGED:" + key)
    for key in ("TEMP", "TMP"):
        _within(_plain_path(os.environ[key]), output_root)
    if not Path(admission["output"]).is_absolute():
        raise ValueError("ABSOLUTE_GROUP_OUTPUT_REQUIRED")
    output = _plain_path(admission["output"])
    _within(output, output_root)
    if output.exists():
        raise FileExistsError("FRESH_GROUP_OUTPUT_REQUIRED")
    owned_call = load_frozen_owned_call(root, output_root)
    # Validation and source loading belong to the same group wall clock.
    # Only root's existing outer owner can cap a blocked pre-launch file read;
    # this adapter cannot manufacture that proof from a later timer.
    remaining = CAPS[group] - (time.monotonic() - bridge_started) - 1.0
    if remaining < 5:
        raise ValueError("FULL_LIFETIME_CAP_EXHAUSTED_BEFORE_LAUNCH")
    record = owned_call(argv, root, output, remaining)
    assessment = evaluate_owned_result(record, remaining)
    total_elapsed = time.monotonic() - bridge_started
    if total_elapsed > CAPS[group]:
        assessment["status"] = "FAIL"
        assessment["issues"].append("BRIDGE_FULL_LIFETIME_CAP_EXCEEDED")
    return {"record": record, "assessment": assessment,
            "admission_sha256": admission_sha256, "group": group,
            "bridge_elapsed_seconds": total_elapsed,
            "absolute_group_cap_seconds": CAPS[group],
            "outer_full_lifetime_watchdog_proof": "REQUIRED_FROM_ROOT_NOT_MEASURED_HERE"}
