"""Truthful terminal receipt for current W; no replay, gate, seal, or source publication."""
import hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
S=R/'code/software'/P/'backend_stream_r13_20261018';C=R/'code/docs/test'/P/'backend_stream_r13_20261018/backend_close'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def stamp(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':p.relative_to(R).as_posix(),'bytes':n,'sha256':h.hexdigest()}
l=read(O/'CONSUMPTION_LIVE.json');w=l['recovery_attempts']['W_CODEC_08'];assert w['state']=='FAILED_STOP'
D=T/'W_CODEC08_TERMINAL_NO_REPLAY';D.mkdir(exist_ok=False)
for f in C.iterdir():
 if f.is_file():shutil.copyfile(f,D/f.name)
phase=[read(p) for p in sorted((O/'RUNS/W_CODEC_08/inner/worker/PHASES').glob('*.json'))]
record={'schema':'M3_R13_W_CODEC08_TERMINAL_NO_REPLAY_V1','status':'PARTIAL_TECHNICAL_FIXED_TIMEOUT_NO_REPLAY','W_state':w['state'],'current_B12':'PASS','current_codec15':'PASS','actual_W':w,'actual_phases':phase,'original_START':l['actual_START'],'current_recorded_deadline':l['deadline'],'latest_user_authority':{'allow_continue_if_progress':True,'do_not_restart_whole_run':True,'time_extension_is_authorized_not_missing_permission':True,'new_60min_replay_proposal':'NOT_APPROVED'},'technical_constraint':'Launched root Timer, frozen owned_call wait and worker monotonic deadline are independent fixed timers with no renewal IPC. Cannot safely hot-extend them from outside. No debugger injection, clock alteration, output reuse substitute or new W replay performed.','unfinished':['Remaining actual D4 stages, final terminal audit and W export','Gate01/S1/Gate02/ordinary source commit/push/S2 remain NOT_STARTED'],'next_condition':'A demonstrably safe resumable checkpoint for the current work is needed; do not request or start a full replay contrary to user instruction. Existing prior complete phase outputs and raw identities remain preserved.','all_old_failures_and_consumption_preserved':True,'actual_level':'L1 current B/codec tests and completed W software stages only; overall full-window NOT_PASSED','real_verified':False,'math_verified':False,'board_release_allowed':False,'M2_RECEIVED':False,'M2_ACCEPTED':False,'created_utc':datetime.now(timezone.utc).isoformat()}
save(O/'W_CODEC08_TERMINAL_RECEIPT.json',record)
for name,extra in [('RESULT_RECEIPT.json',{'R13_SW_COMPLETE':False}),('INTEGRATION_HANDOFF.json',{'handoff_id':'M3-R13-CODEC08-PARTIAL-NO-REPLAY-20261019','consumer':'M2','result_commit':None})]:
 save(C/name,{'schema':'M3_R13_TERMINAL_REFERENCE_V4',**extra,'status':record['status'],'terminal_receipt':stamp(O/'W_CODEC08_TERMINAL_RECEIPT.json'),'source_state':'UNCOMMITTED_NOT_PUSHED_GATE_NOT_RUN','current_B12':'PASS','codec15':'PASS','W':'FAILED_STOP','real_verified':False,'math_verified':False,'board_release_allowed':False,'M2_RECEIVED':False,'M2_ACCEPTED':False})
save(C/'SOURCE_MANIFEST.json',{'schema':'M3_R13_CURRENT_PARTIAL_SOURCE_MANIFEST_V4','source_files':[stamp(p) for p in sorted(S.iterdir()) if p.is_file()],'runtime_freeze':stamp(T/'W_FILECOUNT_RECOVERY_R01/FREEZE.json'),'current_full_W_passed':False,'python_bytes_unchanged_after_W':True})
save(C/'CASE_RESULTS.json',{'schema':'M3_R13_CURRENT_PARTIAL_RESULTS_V4','actual_states':{k:{q:v.get(q) for q in ('state','cap_seconds','charged_seconds','controller_elapsed_seconds','postcheck_evidence')} for k,v in {**l['groups'],**l['recovery_attempts']}.items()},'current_W_phases':phase,'failed_result_not_promoted':True})
save(C/'CONSUMPTION.json',{'schema':'M3_R13_PARTIAL_CONSUMPTION_V4','ledger':l,'old_charges_not_restored':True,'AI_tokens':'UNKNOWN: Goal tool paused/stale; no invented continuation usage'})
save(C/'FAILURE_HISTORY.json',{'schema':'M3_R13_PARTIAL_FAILURE_SUCCESSOR_V4','old_record':stamp(D/'FAILURE_HISTORY.json'),'current_terminal':stamp(O/'W_CODEC08_TERMINAL_RECEIPT.json'),'all_raw_failures_preserved':True})
(C/'SELF_REVIEW.md').write_text('# 当前 R13 部分交付自审\n\n当前 15 项 codec 定向验证与 12 项完整 B 回归通过。W 实际完成的阶段和终止原因见机读原始收据；固定计时器触发后没有重跑，没有把部分链当完整 W。用户已允许延长时间且明确禁止整轮重跑，当前障碍是运行入口无法在线续时，不是等待权限。旧失败与消费保留。\n\n门禁、S1/S2、源码 Git 发布均未执行；GitHub 私有附件只用于向 M2 交付未验收原件，不能当 develop 源码发布。真实 Pro、数学、HDL/EDA、物理/板卡仍未验。\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':record['status'],'W':w['state'],'B12':'PASS','codec15':'PASS'}))

save(C/'RESOURCE_RECEIPT.json',{'schema':'M3_R13_CURRENT_PARTIAL_RESOURCE_V4','status':'FULL_W_NOT_PASSED','current_outer_run':w['actual_result'],'current_inner_original':stamp(O/'RUNS/W_CODEC_08/inner/RESULT.json'),'old_resource_receipt':stamp(D/'RESOURCE_RECEIPT.json'),'root_peak_not_whole_tree_proof':True,'complete_full_tree_peak_and_full_export':'NOT_AVAILABLE_AFTER_TIMEOUT'})

