"""Root metadata for a located private helper-factory performance repair."""
import argparse
import difflib
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
HERE = OUT / 'RECOVERY_TASK0_20261019'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'

def read(path):
    return json.loads(path.read_text('utf-8'))

def save(path, value, new=True):
    assert not new or not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def ref(path):
    path = path.resolve()
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('freeze', 'P1_FACTORY_01', 'B_RECOVERY_03'))
args = parser.parse_args()
ledger_path = OUT / 'CONSUMPTION_LIVE.json'
ledger = read(ledger_path)
authority_path = HERE / 'B_FACTORY_REPAIR/AUTHORITY_AND_LOCATOR.json'
freeze_path = HERE / 'B_FACTORY_REPAIR/FREEZE.json'
controller_path = HERE / 'root_run_factory_repair.py'
if args.mode == 'freeze':
    assert ledger['recovery_attempts']['B_RECOVERY_02']['state'] == 'FAILED_STOP'
    before = HERE / 'B_FACTORY_REPAIR/BEFORE_binding.py'
    after = SOURCE / 'binding.py'
    diff = ''.join(difflib.unified_diff(before.read_text('utf-8').splitlines(True), after.read_text('utf-8').splitlines(True), fromfile='before_binding.py', tofile='after_binding.py'))
    assert diff
    diff_path = HERE / 'B_FACTORY_REPAIR/REPAIR.diff'
    assert not diff_path.exists()
    diff_path.write_text(diff, encoding='utf-8', newline='\n')
    save(authority_path, {'schema': 'M3_USER_TASK0_LOCATED_FACTORY_REPAIR_V1',
         'authority': 'Latest direct user: resolve W and tasks0-3; up to8 evidence-based attempts',
         'problem_attempt_ordinal': 4, 'attempts_limit': 8,
         'old_B_R_and_recovery_failures_preserved': True,
         'source_before': ref(before), 'source_after': ref(after), 'diff': ref(diff_path),
         'failure_parent_original': ref(OUT / 'RUNS/B_RECOVERY_02/stdout.bin'),
         'actual_failure': 'B02 worker timeout; B01 7rows took22.436s, B08 837rows reached capture only. Exact native cleanup/Job0 observed; tree upperbound93794304B.',
         'located_cause': 'Frozen c9_stream.json_line calls support each row; R12 injected support invokes DependencyContext.load; cached load still ji.checked rehashes source. R13 caches only fixed helper factory return per private context, first load same verified hashed compiled bytes; context.close verifies every actually loaded source plus root full freeze before/after.',
         'new_attempts': {'P1_FACTORY_01': {'slot': 'P1', 'cap_seconds': 60}, 'B_RECOVERY_03': {'slot': 'B', 'cap_seconds': 120}},
         'charge_bucket': 'USER_TASK0_RECOVERY_INCREMENT', 'deadline': ledger['deadline'],
         'all_original_caps_and_consumption_unchanged': True, 'recorded_utc': datetime.now(timezone.utc).isoformat()})
    old = read(HERE / 'REPAIR_FREEZE_B01.json')
    files = []
    for item in old['frozen_files']:
        path = Path(item['path'])
        path = path if path.is_absolute() else ROOT / path
        actual = ref(path)
        if path.resolve() != after.resolve():
            assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']), str(path)
        files.append(actual)
    save(freeze_path, {'schema': 'M3_R13_ROOT_REPAIR_FREEZE_V1', 'state': 'REPAIR_FROZEN_BY_ROOT',
                      'authority': ref(authority_path), 'frozen_files': files + [ref(authority_path), ref(diff_path)],
                      'all_target_writers_closed': True})
    raw = (HERE / 'root_run_bounded_ledger.py').read_text('utf-8')
    start = raw.index('if attempt_id:\n    assert args.slot')
    end = raw.index("assert slot['state'] ==", start)
    raw = raw[:start] + '''if attempt_id:
    assert attempt_id in ('P1_FACTORY_01', 'B_RECOVERY_03')
    assert args.slot == ('P1' if attempt_id == 'P1_FACTORY_01' else 'B')
    assert ledger['recovery_attempts']['B_RECOVERY_02']['state'] == 'FAILED_STOP'
    verify(contract['new_user_authority'])
    if attempt_id == 'B_RECOVERY_03':
        assert ledger['recovery_attempts']['P1_FACTORY_01']['state'] == 'PASS'
''' + raw[end:]
    raw = raw.replace("get('B_RECOVERY_02', {}).get('state') == 'PASS'", "get('B_RECOVERY_03', {}).get('state') == 'PASS'")
    assert not controller_path.exists()
    controller_path.write_text(raw, encoding='utf-8', newline='\n')
    for key, slot, cap, count in [('P1_FACTORY_01', 'P1', 60, 1), ('B_RECOVERY_03', 'B', 120, 12)]:
        assert key not in ledger['recovery_attempts']
        ledger['recovery_attempts'][key] = {'state': 'NOT_STARTED', 'attempts': 0, 'charged_seconds': 0,
             'cap_seconds': cap, 'cases_max': count, 'wire_group': slot, 'authority': ref(authority_path)}
    save(ledger_path, ledger, new=False)
    print(json.dumps({'freeze': ref(freeze_path), 'controller': ref(controller_path)}))
else:
    attempt_id = args.mode
    wire = 'P1' if attempt_id == 'P1_FACTORY_01' else 'B'
    cap = 60 if wire == 'P1' else 120
    assert ledger['recovery_attempts'][attempt_id]['state'] == 'NOT_STARTED'
    if wire == 'B':
        assert ledger['recovery_attempts']['P1_FACTORY_01']['state'] == 'PASS'
    freeze = read(freeze_path)
    for item in freeze['frozen_files']:
        actual = ref(Path(item['path']))
        assert actual == item
    base = OUT / 'ADMISSIONS' / attempt_id
    admission_path = base / 'ADMISSION.json'
    owner = OUT / 'RUNS' / attempt_id / 'inner'
    worker = owner / ('worker' if wire == 'P1' else 'B02/worker')
    python = str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
    admission = read(OUT / 'ADMISSIONS/B_RECOVERY_02/ADMISSION.json')
    admission.update(group=wire, absolute_cap_seconds=cap,
         root_deadline_monotonic=time.monotonic() + cap, prepared_utc=datetime.now(timezone.utc).isoformat(),
         source_freeze=ref(freeze_path), root_accounting_slot=attempt_id)
    admission['argv'] = [python, '-X', 'utf8', '-B', str((SOURCE / 'selftest.py').resolve()), '--worker',
         '--group', wire, '--admission', str(admission_path.resolve()), '--admission-sha256',
         '@ADMISSION_SHA256@', '--output', str(worker.resolve())]
    admission['external_log_escrows'] = {key.replace('RUNS/B_RECOVERY_02/', 'RUNS/' + attempt_id + '/'): val
         for key, val in admission['external_log_escrows'].items()}
    admission['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller'] = ref(controller_path)
    save(admission_path, admission)
    ar = ref(admission_path)
    contract = {'schema': 'M3_R13_ROOT_RUN_CONTRACT_V1', 'root_approved': True, 'slot': wire,
         'attempt_id': attempt_id, 'wire_group': wire, 'repair_group': 'B', 'new_user_authority': ref(authority_path),
         'plan_sha256': admission['plan_sha256'], 'cap_seconds': cap, 'all_target_writers_closed': True,
         'frozen_files': [*freeze['frozen_files'], ref(freeze_path), ar, ref(controller_path)],
         'target_script': str((SOURCE / 'job_bridge.py').resolve()),
         'argv': [python, '-X', 'utf8', '-B', str((SOURCE / 'job_bridge.py').resolve()), '--execute-one',
              '--admission', str(admission_path.resolve()), '--admission-sha256', ar['sha256'],
              '--owner-output', str(owner.resolve())],
         'worker_result_relative_path': (worker / 'WORKER_LOCAL_RESULT.json').relative_to(OUT / 'RUNS' / attempt_id).as_posix(),
         'bridge_result_relative_path': 'inner/GROUP_COMPLETE.json',
         'expected_case_ids': ['P001'] if wire == 'P1' else [f'B{i:02d}' for i in range(1, 13)]}
    cp = base / 'ROOT_CONTRACT.json'
    save(cp, contract)
    print(json.dumps(ref(cp)))
