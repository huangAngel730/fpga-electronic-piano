"""Exact disposable successor observer using unchanged R13 owned Job mechanism."""
import argparse, hashlib, json, sys, time
from pathlib import Path
ROOT=Path.cwd().resolve(); OUT=ROOT/'code/output/m3_backend_stream_r13_20261018'
SOURCE=ROOT/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
p=argparse.ArgumentParser();p.add_argument('--admission',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
raw=a.admission.read_bytes();assert hashlib.sha256(raw).hexdigest()==a.sha256;adm=json.loads(raw)
sys.path.insert(0,str(SOURCE));import job_bridge
owner=a.output.resolve();assert owner==OUT/'RUNS/W_RECOVERY_07/inner'
call,events=job_bridge.frozen_owned_call(adm['root_deadline_monotonic'])
cap=min(880,adm['root_deadline_monotonic']-time.monotonic()-10);assert cap>5
argv=[str(Path(sys.executable).resolve()),'-X','utf8','-B',str(OUT/'RECOVERY_TASK0_20261019/w_recovery_worker.py'),'--admission',str(a.admission.resolve()),'--sha256',a.sha256,'--output',str(owner/'worker')]
r=call(argv,ROOT,owner,cap);assessment=job_bridge.assess(r,cap,events)
receipt={'schema':'M3_R13_OWNED_GROUP_RESULT_V1','group':'W','owned':r,'assessment':assessment,'status':assessment['status']}
if assessment['status']=='PASS':
 from finalize import atomic_json
 atomic_json(owner/'GROUP_COMPLETE.json',receipt)
print(json.dumps(receipt));raise SystemExit(0 if receipt['status']=='PASS' else 2)
