# B08 最小合成样本静态说明 R02

## 结论

现有原件里没有一份可以原样复用、同时满足“真实 D4 full backend + 非零数学 advance + 随后 cancel 后仍保留”的小样本。

- `R03/cases/009` 是实际 D4 full-backend 已通过的合成脚手架，但窗口只有 7 行，独立 FRAME 计划为空，`ADVANCE_HISTORY.jsonl` 也为空。
- `R02/cases/054` 已证明数学桥会保留非零 advance（包括 cancel 行上的 advance），但它只跑了数学桥；它把 FRAME 放在 cycle 0，且没有 request accept，不能直接当作 D4 full-backend B08。

实际 D4 的独立计划公式是：

```text
n_k = ceil(128 * k * 2^32 / 659706977)
cycle_k = release_cycle + n_k - 1
```

`release_cycle=0` 时，第一个 FRAME 必须是 cycle 833。因此最小连贯窗口应为 837 行（cycle 0..836），不能用 night5 的 7 行零-advance 全窗代替。

## 可复用原件（仅限指定用途）

1. 完整 D4 脚手架：
   `code/output/m3_c9_complete_d4_20261017/R03/cases/009/RESULT.json`
   SHA256 `a27d870d6f56e346096f5a2fdbb88a740f054e618a7b2a5659a8fd847a5447ed`
   只复用 request/application/full-backend 接线及完整 72-port idle 行包络。
2. 对应运行收据：
   `code/output/m3_c9_complete_d4_20261017/R03/RECEIPT.json`
   SHA256 `6bb8fcae7a0a5b47617d893191baeff05b616a0190d3e1b859d562feba45b58f`
3. advance 记录格式示例：
   `code/output/m3_c9_complete_d4_20261017/R02/cases/054/math/ADVANCE_HISTORY.jsonl`
   SHA256 `f2b9245b5842161853e4c0e6148d8388fd796c6f9414b8de69bbb59daf20203e`
   只复用字段语义，不能复用为 full-backend 通过原件。

## 最小 cycle 序列

所有行必须保留完整 72 个 raw ports；转换后每行必须有完整 74 个 public fields。以 `R03/cases/009/RAW.jsonl` 的完整 idle 行为模板，不要手写不完整字典。

| cycle | line | time_ps | 必要变化 | 预期角色 |
|---:|---:|---:|---|---|
| 0..832 | 1..833 | `(cycle+1)*25000` | 无；保持合格 active idle | 独立复位释放后的空闲前缀 |
| 833 | 834 | 20,850,000 | `obs_frame_tick=1` | 唯一 `FRAME_F` |
| 834 | 835 | 20,875,000 | `req_valid=1, req_ready=1, req_id=42, advance_mask=1111, advance_frame_req_id=42` | 同一窗内 `ACCEPT_A` + 一次四 lane advance |
| 835 | 836 | 20,900,000 | `cancel=1, raw_cancel_reason=00`；本行 `advance_mask=0` | 随后的真实 raw cancel，清掉 outstanding 42 |
| 836 | 837 | 20,925,000 | 顶层 `finish=1` | 计划结束；此时无未完成请求 |

各行共同坐标为 `epoch=0`、`source_line=cycle+1`、`time_ps=(cycle+1)*25000`。共同非零 raw 不变量为 `obs_core_clk=1`、`obs_polyphonic_valid=1`、`obs_rst_n=1`、`obs_pll_locked=1`。I2S 引脚和 `tx_sample_valid` 可以维持 idle 0；这会保留串行侧的待定状态，但不妨碍验证 B08 的 accept/cancel/advance 保留关系，也绝不能被称为 PCM/I2S 通过。

## FRAME、reset、plan 与 finish

- 复用 `C9_SYNTHETIC.resets.jsonl`（SHA256 `f57c3a9fe8454d12f90b8ea2ac03c4ac1b51bad2dec4bd5e7e21e659ed03b129`）：time 0 reset low，time 10000 release；首行 time 25000，因此 cycle 0..836 均为 `rst_n=1`。
- 新独立 scenario：`release_cycle=0`、`stop_cycle=836`、`expected_frames=[833]`。
- 新 FRAME input：ACTIVE epoch 0，`reset_assert_cycle=0`、`release_cycle=0`、`stop_cycle=836`，finish 固定为 `(epoch=0, cycle=836)`。
- 新 window：`row_count=837`、`finish_cycle=836`、`finish_time_ps=20925000`，`plan_stop_id=D4_B08_SYNTHETIC_STOP`。
- `END.json` 与唯一一行 `MONITOR_END` 必须使用同一 stop id、cycle、time 和 row count。不要移动、复制或从 capture 反推 finish。

## 可准确推导的 evidence

Intake/Calendar 应得到：

```text
F              = {cycle:833, source_line:834}
first_valid/A  = {cycle:834, source_line:835}
req_id         = 42
advance        = {cycle:834, source_line:835, mask:15, req_id:42}
raw cancel     = {cycle:835, source_line:836, raw_cancel_reason:0,
                  business_cancel_derived:false}
business_cancels = []
```

Serial 应在 line 836 输出 `kind=CANCEL`，其 entry 精确为 `epoch=0, id=42, F=833, V=834, A=834, request_cycle=834, accept_source_line=835`；cycle 836 finish 时 `outstanding=None, waiting=None, pending=None`。

Math `ADVANCE_HISTORY.jsonl` 应只有一条，位于 cycle 834 / line 835：`raw_mask=15`、`request_tag=42`、`req_id=42`、`commit_observed_same_row=0`、`cancel_raw=0`、`retained_even_if_unpublished_or_cancelled=true`。随后 cancel 不应被伪装成同一行；保留证据是这条 advance 与 cycle 835 的 intake raw cancel、serial CANCEL 三者在 full backend 结束后同时存在。

## 原件缺口与责任

- 当前没有已物化的 837 行 B08 raw/request/window/frame-input：由 R13 C 实现者按 JSON 规格生成。
- 当前没有该新 B08 的 full-backend 运行结果：main4 本次禁止运行 target/fixture/Job；由 C 实现者在其有效执行预算内只跑新 B08 定向 case，不必全面重跑旧组。
- 新 raw/public/plan/ledger/serial/math 的 SHA 只能在物化后计算，不能抄 7 行原件 SHA。
- 不创建 M1 黄金、不生成 expected PCM、不改变 finish；`math_verified`、`real_verified`、`board_release_allowed` 均保持 false。

机器可读的完整字段、源码 SHA、预期 evidence 和 writer 检查表见同目录 `B08_MINIMAL_FIXTURE_NOTE_R02.json`。
