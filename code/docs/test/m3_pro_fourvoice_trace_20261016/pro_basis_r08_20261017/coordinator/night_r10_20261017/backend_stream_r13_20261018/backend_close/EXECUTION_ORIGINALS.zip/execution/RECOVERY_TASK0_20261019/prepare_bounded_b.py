"""Prospective user-authorized B recovery metadata, no candidate import."""
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
HERE = OUT / 'RECOVERY_TASK0_20261019'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'

def read(path):
    return json.loads(path.read_text('utf-8'))

def ref(path):
    path = path.resolve()
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}

def save_new(path, value):
    assert not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

ledger_path = OUT / 'CONSUMPTION_LIVE.json'
ledger = read(ledger_path)
attempt = ledger['recovery_attempts']['B_RECOVERY_02']
assert attempt['state'] == 'NOT_STARTED' and not attempt['attempts']
assert ledger['groups']['P1']['state'] == 'PASS'
attempt['cases_max'] = 12
ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
freeze_path = HERE / 'REPAIR_FREEZE_B01.json'
freeze = read(freeze_path)
for item in freeze['frozen_files']:
    path = Path(item['path'])
    actual = ref(path if path.is_absolute() else ROOT / path)
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], str(path)
base = OUT / 'ADMISSIONS/B_RECOVERY_02'
assert not base.exists()
admission_path = base / 'ADMISSION.json'
owner = OUT / 'RUNS/B_RECOVERY_02/inner'
worker = owner / 'B02/worker'
python = str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
admission = read(OUT / 'ADMISSIONS/B/ADMISSION.json')
admission.update(group='B', state='CONSUMED_RUNNING', absolute_cap_seconds=120,
                 root_deadline_monotonic=time.monotonic() + 120,
                 prepared_utc=datetime.now(timezone.utc).isoformat(),
                 source_freeze=ref(freeze_path), root_accounting_slot='B_RECOVERY_02',
                 located_repair=ref(OUT / 'LOCATED_REPAIR.json'))
admission['argv'] = [python, '-X', 'utf8', '-B', str((SOURCE / 'selftest.py').resolve()),
                     '--worker', '--group', 'B', '--admission', str(admission_path.resolve()),
                     '--admission-sha256', '@ADMISSION_SHA256@', '--output', str(worker.resolve())]
admission['external_log_escrows'] = {key.replace('RUNS/B/', 'RUNS/B_RECOVERY_02/'): value
                                    for key, value in admission['external_log_escrows'].items()}
live = admission['external_log_escrows']['CONSUMPTION_LIVE.json']
live['byte_cap'] = 4 * 1048576
live['evidence'] = {'kind': 'ROOT_FINITE_SAVE_BOUND', 'per_file_bound_bytes': 4 * 1048576,
                    'controller': ref(HERE / 'root_run_bounded_ledger.py'),
                    'basis': 'Every root save checks 4MiB before write. Newly completed raw worker and bridge evidence stays in canonical immutable files; ledger stores hashes and normalized case status only. Existing historical ledger entries retained.'}
admission['accounting_profile']['allocation_unit_bytes'] = 4096
admission['accounting_profile']['enforce_start_free'] = False
save_new(admission_path, admission)
ar = ref(admission_path)
authority = ref(HERE / 'B_RECOVERY_ADDENDUM_02.json')
contract = {'schema': 'M3_R13_ROOT_RUN_CONTRACT_V1', 'root_approved': True,
            'slot': 'B', 'attempt_id': 'B_RECOVERY_02', 'wire_group': 'B', 'repair_group': 'B',
            'new_user_authority': authority, 'plan_sha256': admission['plan_sha256'],
            'cap_seconds': 120, 'all_target_writers_closed': True,
            'frozen_files': [*freeze['frozen_files'], ref(freeze_path), ar,
                             ref(HERE / 'root_run_bounded_ledger.py'), authority],
            'target_script': str((SOURCE / 'job_bridge.py').resolve()),
            'argv': [python, '-X', 'utf8', '-B', str((SOURCE / 'job_bridge.py').resolve()),
                     '--execute-one', '--admission', str(admission_path.resolve()),
                     '--admission-sha256', ar['sha256'], '--owner-output', str(owner.resolve())],
            'worker_result_relative_path': 'inner/B02/worker/WORKER_LOCAL_RESULT.json',
            'bridge_result_relative_path': 'inner/GROUP_COMPLETE.json',
            'expected_case_ids': [f'B{index:02d}' for index in range(1, 13)]}
contract_path = base / 'ROOT_CONTRACT.json'
save_new(contract_path, contract)
print(json.dumps(ref(contract_path)))
