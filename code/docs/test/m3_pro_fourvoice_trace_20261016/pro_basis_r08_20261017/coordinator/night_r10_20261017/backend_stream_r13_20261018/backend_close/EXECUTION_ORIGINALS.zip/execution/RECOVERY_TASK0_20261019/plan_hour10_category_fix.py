import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_HOUR_CATEGORY_10';D.mkdir(exist_ok=False)
def ref(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':p.relative_to(R).as_posix(),'bytes':n,'sha256':h.hexdigest()}
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
raw='RUNS/W/inner/worker/inputs/W01/RAW.jsonl';roles={raw:'raw_plain'};summaries={'plain_raw':0,'gzip_payload':0,'delivery_copy':0,'baseline':0};bound=[]
for p in sorted(O.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(O).as_posix();category='baseline'
 if rel==raw:category='plain_raw'
 elif '.r13_volumes' in p.parts and p.suffix=='.gz':roles[rel]='all_stores';category='gzip_payload'
 elif p.suffix=='.zip' and any(s in rel for s in ('PARTIAL_TRANSFER_CURRENT/','TASK0_HANDOFF/','STATIC_DELIVERY_R02/')):roles[rel]='delivery';category='delivery_copy'
 summaries[category]+=p.stat().st_size
 if category!='baseline':bound.append({'category':category,'file':ref(p)})
assert summaries['baseline']<512*1048576 and summaries['gzip_payload']<8*1024**3 and summaries['delivery_copy']<8*1024**3
capacity={'baseline_limit':512*1048576,'gzip_payload_limit':8*1024**3,'delivery_copy_limit':8*1024**3,'workspace_limit':24*1024**3,'usage':summaries,'initial_roles':roles,'bound_category_files':bound,'policy':'Existing physical gzip payloads remain gzip bucket; existing immutable aggregate transfer ZIPs remain delivery copy bucket, not claimed32MiB logical parts. Baseline gets true controls/other old files. No bucket limit changed; no file deleted/moved, failed originals stay failed.'}
save(D/'CAPACITY_AND_CLASSIFICATION.json',capacity)
proposal={'schema':'M3_R13_HOUR_CATEGORY_FIX_PROPOSAL_V1','approved':False,'reason':'W_HOUR_09 failed at configure_accounting before worker input/backend run: baseline quota512MiB exceeded by retained complete transfer ZIP and old physical gzip payloads being default baseline. Global24GiB not exceeded. Root preflight previously missed bucket-specific sums.','repair':'Only accurate category declarations in fresh admission. S13 runtime code unchanged from passedB12/C15. Existing initial_roles API unchanged.','new_slot':'W_HOUR_10','runs':1,'cap_seconds':3600,'cases_max':1,'deadline':'2026-10-19T12:00:00+08:00','W_HOUR_09_charge3600_preserved':True,'all_old_failures_and_charges_preserved':True,'resource_limits_unchanged':True,'closing_budget':'Previously approved390s transport unused; original gates/seals/push/fetch untouched','classification':ref(D/'CAPACITY_AND_CLASSIFICATION.json'),'actual_source_change':False,'created_utc':datetime.now(timezone.utc).isoformat()}
save(D/'EXECUTION_PROPOSAL.json',proposal);print(json.dumps({'usage':summaries,'proposal':ref(D/'EXECUTION_PROPOSAL.json')}))
