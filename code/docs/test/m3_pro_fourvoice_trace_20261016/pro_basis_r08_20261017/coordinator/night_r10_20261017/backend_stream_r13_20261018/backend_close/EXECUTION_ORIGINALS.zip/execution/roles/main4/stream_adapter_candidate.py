"""R13 main4 static reference candidate for the C writer.

This file was not imported or executed by main4.  It is deliberately outside
the official thirteen-file source set.  The C writer may copy the small APIs
below into ``binding.py``, ``volume_io.py`` and ``finalize.py`` after adapting
error names and the owned output root.

The candidate has three hard boundaries:

* control JSON is identity-checked and parsed from the same <= 8 MiB buffer;
* logical large files are read in requests no larger than 1 MiB, including
  across transport-volume boundaries, and are accepted only at verified EOF;
* the completion marker is created only after all required final identities
  and terminal coordinates have been checked.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import io
import json
import os
from pathlib import Path
import re
from typing import Callable, Iterable, Iterator


CHUNK = 1024 * 1024
MAX_CONTROL_JSON = 8 * CHUNK
SHA256_RE = re.compile(r"[0-9a-f]{64}")


class CandidateReject(ValueError):
    """Reference error; the official successor should use its owned type."""


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise CandidateReject(reason)


def _pairs(items):
    value = {}
    for key, item in items:
        require(key not in value, "DUPLICATE_JSON_KEY")
        value[key] = item
    return value


def read_control_same_buffer(path: Path, expected: dict) -> tuple[bytes, object]:
    """Return the exact bytes and their parsed value from one bounded buffer."""
    require(set(expected) >= {"bytes", "sha256"}, "CONTROL_DESCRIPTOR")
    require(type(expected["bytes"]) is int and 0 <= expected["bytes"] <= MAX_CONTROL_JSON,
            "CONTROL_SIZE_BOUND")
    require(type(expected["sha256"]) is str and SHA256_RE.fullmatch(expected["sha256"]),
            "CONTROL_SHA")
    blocks = []
    count = 0
    with Path(path).open("rb", buffering=0) as source:
        while True:
            block = source.read(min(CHUNK, MAX_CONTROL_JSON + 1 - count))
            if not block:
                break
            count += len(block)
            require(count <= MAX_CONTROL_JSON, "CONTROL_SIZE_BOUND")
            blocks.append(block)
    raw = b"".join(blocks)
    actual = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    require(actual == {key: expected[key] for key in actual}, "CONTROL_IDENTITY")
    value = json.loads(raw, object_pairs_hook=_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(
                           CandidateReject("NONFINITE_JSON")))
    return raw, value


@dataclass(frozen=True)
class VolumePart:
    path: Path
    offset: int
    bytes: int
    sha256: str


@dataclass(frozen=True)
class LogicalFile:
    bytes: int
    sha256: str
    parts: tuple[VolumePart, ...]


def validate_logical_file(spec: LogicalFile) -> None:
    require(type(spec.bytes) is int and spec.bytes >= 0, "LOGICAL_BYTES")
    require(SHA256_RE.fullmatch(spec.sha256) is not None, "LOGICAL_SHA")
    position = 0
    require(bool(spec.parts) or spec.bytes == 0, "LOGICAL_PARTS")
    for part in spec.parts:
        require(part.offset == position and type(part.bytes) is int and part.bytes >= 0,
                "VOLUME_ORDER_OR_OFFSET")
        require(SHA256_RE.fullmatch(part.sha256) is not None, "VOLUME_SHA")
        position += part.bytes
    require(position == spec.bytes, "LOGICAL_PART_TOTAL")


class VerifiedVolumeStream(io.RawIOBase):
    """One continuous, non-seekable logical byte stream over ordered volumes.

    A consumer must read to EOF.  Each physical request is <= 1 MiB.  Part and
    whole-stream byte counts and hashes are accepted only after the final EOF
    probe, so a correct prefix is never accepted as the logical file.
    """

    def __init__(self, spec: LogicalFile):
        super().__init__()
        validate_logical_file(spec)
        self.spec = spec
        self._part_index = 0
        self._part_stream = None
        self._part_hash = hashlib.sha256()
        self._part_count = 0
        self._whole_hash = hashlib.sha256()
        self._whole_count = 0
        self._returned_count = 0
        self._pending = bytearray()
        self._physical_verified = False

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    @property
    def verified(self) -> bool:
        return (self._physical_verified and not self._pending
                and self._returned_count == self.spec.bytes)

    @property
    def count(self) -> int:
        return self._whole_count

    def _open_part(self) -> None:
        if self._part_stream is None and self._part_index < len(self.spec.parts):
            self._part_stream = self.spec.parts[self._part_index].path.open("rb", buffering=0)
            self._part_hash = hashlib.sha256()
            self._part_count = 0

    def _finish_part(self) -> None:
        part = self.spec.parts[self._part_index]
        require(self._part_count == part.bytes, "VOLUME_LENGTH")
        require(self._part_hash.hexdigest() == part.sha256, "VOLUME_IDENTITY")
        require(self._part_stream.read(1) == b"", "VOLUME_TRAILING_BYTES")
        self._part_stream.close()
        self._part_stream = None
        self._part_index += 1

    def _finish_logical(self) -> None:
        require(self._whole_count == self.spec.bytes, "LOGICAL_LENGTH")
        require(self._whole_hash.hexdigest() == self.spec.sha256, "LOGICAL_IDENTITY")
        self._physical_verified = True

    def _pull_physical(self, size: int) -> bytes:
        if size == 0 or self._physical_verified:
            return b""
        output = bytearray()
        while len(output) < size and self._part_index < len(self.spec.parts):
            self._open_part()
            part = self.spec.parts[self._part_index]
            remaining = part.bytes - self._part_count
            if remaining == 0:
                self._finish_part()
                continue
            block = self._part_stream.read(min(size - len(output), remaining, CHUNK))
            require(bool(block), "VOLUME_TRUNCATED")
            self._part_count += len(block)
            self._whole_count += len(block)
            require(self._whole_count <= self.spec.bytes, "LOGICAL_LENGTH")
            self._part_hash.update(block)
            self._whole_hash.update(block)
            output.extend(block)
        if self._part_index == len(self.spec.parts) and self._part_stream is None:
            self._finish_logical()
        return bytes(output)

    def read(self, size: int = -1) -> bytes:
        require(type(size) is int and 0 <= size <= CHUNK, "READ_REQUEST_BOUND")
        if size == 0:
            return b""
        output = bytearray()
        if self._pending:
            take = min(size, len(self._pending))
            output += self._pending[:take]
            del self._pending[:take]
        if len(output) < size:
            output += self._pull_physical(size - len(output))
        self._returned_count += len(output)
        return bytes(output)

    def readline(self, limit: int) -> bytes:
        require(type(limit) is int and 0 < limit <= CHUNK + 1, "LINE_BOUND")
        output = bytearray()
        while len(output) < limit:
            stop = self._pending.find(b"\n", 0, limit - len(output))
            if stop >= 0:
                take = stop + 1
                output += self._pending[:take]
                del self._pending[:take]
                break
            if self._pending:
                take = min(limit - len(output), len(self._pending))
                output += self._pending[:take]
                del self._pending[:take]
                if len(output) == limit:
                    break
            block = self._pull_physical(min(CHUNK, limit - len(output)))
            if not block:
                break
            self._pending.extend(block)
        self._returned_count += len(output)
        require(len(output) < limit or output.endswith(b"\n"), "LINE_BOUND")
        return bytes(output)

    def require_verified_eof(self) -> None:
        require(self._verified, "LOGICAL_STREAM_NOT_AT_EOF")

    def close(self) -> None:
        if self._part_stream is not None:
            self._part_stream.close()
            self._part_stream = None
        super().close()


def iter_jsonl(stream: VerifiedVolumeStream) -> Iterator[dict]:
    number = 0
    while True:
        raw = stream.readline(CHUNK + 1)
        if not raw:
            break
        number += 1
        require(bool(raw.strip()), "EMPTY_JSONL_LINE:" + str(number))
        value = json.loads(raw, object_pairs_hook=_pairs,
                           parse_constant=lambda _: (_ for _ in ()).throw(
                               CandidateReject("NONFINITE_JSON")))
        require(type(value) is dict, "JSONL_OBJECT:" + str(number))
        yield value
    stream.require_verified_eof()


def identity_stream(path: Path) -> dict:
    digest = hashlib.sha256()
    count = 0
    with Path(path).open("rb", buffering=0) as source:
        while True:
            block = source.read(CHUNK)
            if not block:
                break
            count += len(block)
            digest.update(block)
    return {"bytes": count, "sha256": digest.hexdigest()}


def copy_verified_snapshot(source: Path, expected: dict, target: Path) -> dict:
    """Freeze a tool/source file without the reachable 64 MiB heap buffer."""
    digest = hashlib.sha256()
    count = 0
    with Path(source).open("rb", buffering=0) as reader, Path(target).open("xb", buffering=0) as sink:
        while True:
            block = reader.read(CHUNK)
            if not block:
                break
            count += len(block)
            digest.update(block)
            sink.write(block)
    actual = {"bytes": count, "sha256": digest.hexdigest()}
    require(actual == {key: expected[key] for key in actual}, "SNAPSHOT_SOURCE_IDENTITY")
    require(identity_stream(target) == actual, "SNAPSHOT_TARGET_IDENTITY")
    return actual


class BoundedRandomAccess:
    """Small reads from an already verified private snapshot, for PE parsing."""

    def __init__(self, path: Path, size: int):
        self.path = Path(path)
        self.size = size
        self._stream = self.path.open("rb", buffering=0)

    def read_at(self, offset: int, size: int) -> bytes:
        require(type(offset) is int and type(size) is int and 0 <= offset <= self.size,
                "READ_AT_OFFSET")
        require(0 <= size <= CHUNK and offset + size <= self.size, "READ_AT_BOUND")
        self._stream.seek(offset)
        raw = self._stream.read(size)
        require(len(raw) == size, "READ_AT_TRUNCATED")
        return raw

    def c_string(self, offset: int, limit: int = 512) -> bytes:
        require(0 < limit <= CHUNK and 0 <= offset < self.size, "C_STRING_BOUND")
        raw = self.read_at(offset, min(limit, self.size - offset))
        end = raw.find(b"\0")
        require(end >= 0, "C_STRING_TERMINATOR")
        return raw[:end]

    def close(self) -> None:
        self._stream.close()


@dataclass(frozen=True)
class TerminalObservation:
    row_count: int
    finish_cycle: int
    finish_rows: int
    monitor_end_matches: int


def validate_terminal(observed: TerminalObservation, expected_finish_cycle: int) -> None:
    require(observed.row_count == expected_finish_cycle + 1, "FINAL_ROW_COUNT")
    require(observed.finish_cycle == expected_finish_cycle, "FINAL_FINISH_CYCLE")
    require(observed.finish_rows == 1, "FINAL_FINISH_UNIQUENESS")
    require(observed.monitor_end_matches == 1, "FINAL_MONITOR_END_UNIQUENESS")


def finalize_success(
        output_dir: Path,
        completion: dict,
        required_artifacts: Iterable[tuple[Path, dict]],
        terminal: TerminalObservation,
        expected_finish_cycle: int,
        write_failure: Callable[[BaseException], None] | None = None) -> Path:
    """Atomically publish the sole R13 completion marker after final checks.

    The caller should run the frozen D4 chain in a staging descendant.  D4's
    historical HANDOFF.json remains an intermediate artifact; only the marker
    returned here means the R13 completion barrier was crossed.
    """
    marker = Path(output_dir) / "R13_COMPLETE.json"
    temporary = Path(output_dir) / ".R13_COMPLETE.json.tmp"
    require(not marker.exists() and not temporary.exists(), "COMPLETION_ALREADY_EXISTS")
    try:
        for path, expected in required_artifacts:
            require(identity_stream(path) == {key: expected[key] for key in ("bytes", "sha256")},
                    "FINAL_ARTIFACT_IDENTITY:" + str(path))
        validate_terminal(terminal, expected_finish_cycle)
        raw = (json.dumps(completion, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
        with temporary.open("xb", buffering=0) as sink:
            sink.write(raw)
            sink.flush()
            os.fsync(sink.fileno())
        os.replace(temporary, marker)
        return marker
    except BaseException as original:
        try:
            if temporary.exists():
                temporary.unlink()
            if write_failure is not None:
                write_failure(original)
        except BaseException:
            # Preserve the first failure.  The official implementation should
            # record the secondary cleanup/write error in a side-channel receipt.
            pass
        raise

