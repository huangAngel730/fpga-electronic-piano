"""Pure R13 admission arithmetic; never consumes slots or executes anything.

The root coordinator supplies a frozen snapshot and authoritative clocks. This
module returns a decision only. A decision cannot replace root authorization,
source freeze, Job proof, source semantics, or the shared consumption ledger.
"""

from datetime import datetime, timedelta
import math


PLAN_SHA256 = "729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3"
CAPS = {"P0": 60, "K": 120, "V": 120, "B": 120, "W": 900,
        "P1": 60, "R": 120, "GATE_01": 900, "S1": 60,
        "GATE_02": 900, "S2": 60}
NORMAL_ORDER = ("P0", "K", "V", "B", "W", "GATE_01", "S1", "GATE_02", "S2")
TERMINAL_FAILURES = {"P0", "P1", "R", "W", "GATE_01", "GATE_02", "S1", "S2"}
MAX_CASES = {"K": 16, "V": 16, "B": 16, "W": 1, "R": 16}
INITIAL_CASES = {"K": 8, "V": 12, "B": 12, "W": 1}


def _time(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError("TIMEZONE_REQUIRED")
    return result


def _counter(value, maximum):
    if type(value) is not int or not 0 <= value <= maximum:
        raise ValueError("INVALID_CHARGED_COUNTER")
    return value


def assess_start(group, snapshot, prerequisites, now_iso):
    """No I/O, clock reads, mutation, retry, polling, or shared-ledger writes.

    snapshot: plan_sha256, start, member_end, explicit_cutoff (ISO, null
    permitted only for explicit_cutoff), deadline, slots (all CAPS keys, each
    state NOT_STARTED/RUNNING/PASS/FAIL, charged_cap_seconds), network_operations,
    network_charged_seconds, local_git_charged_seconds, repair (null or mapping).
    prerequisites: exact current source/preflight and group-specific facts.
    Missing facts fail closed. Root must pin this snapshot before consuming.
    """
    issues = []
    if (not isinstance(group, str) or group not in CAPS
            or not isinstance(snapshot, dict) or not isinstance(prerequisites, dict)
            or snapshot.get("plan_sha256") != PLAN_SHA256):
        return {"decision": "NO_GO", "issues": ["PLAN_OR_GROUP_MISMATCH"]}
    try:
        start, now = _time(snapshot["start"]), _time(now_iso)
        deadline = _time(snapshot["deadline"])
        member_end = _time(snapshot["member_end"])
        ends = [start + timedelta(hours=5), member_end]
        if snapshot.get("explicit_cutoff") is not None:
            ends.append(_time(snapshot["explicit_cutoff"]))
        if deadline != min(ends) or now < start:
            issues.append("EARLIEST_DEADLINE_OR_START_MISMATCH")
        slots = snapshot["slots"]
        if set(slots) != set(CAPS):
            raise ValueError("EXACT_SLOT_SNAPSHOT_REQUIRED")
        charged_slots = 0
        for name, cap in CAPS.items():
            item = slots[name]
            state = item["state"]
            if state not in {"NOT_STARTED", "RUNNING", "PASS", "FAIL"}:
                raise ValueError("SLOT_STATE_UNKNOWN")
            expected = 0 if state == "NOT_STARTED" else cap
            if type(item["charged_cap_seconds"]) is not int or item["charged_cap_seconds"] != expected:
                raise ValueError("FULL_CAP_NO_REFUND_REQUIRED")
            charged_slots += expected
        net = _counter(snapshot["network_charged_seconds"], 1260)
        ops = _counter(snapshot["network_operations"], 20)
        git = _counter(snapshot["local_git_charged_seconds"], 360)
        if charged_slots + net + git + CAPS[group] > 5040:
            issues.append("PACKAGE_5040_CAP_EXHAUSTED")
        if slots[group]["state"] != "NOT_STARTED":
            issues.append("SLOT_ALREADY_CONSUMED_NO_RETRY")
        if any(item["state"] == "RUNNING" for item in slots.values()):
            issues.append("SINGLE_EXECUTOR_SAFE_CHECKPOINT_REQUIRED")
        if any(slots[name]["state"] == "FAIL" for name in TERMINAL_FAILURES):
            issues.append("TERMINAL_FAILURE_NO_RECOVERY")
        failures = [name for name in ("K", "V", "B") if slots[name]["state"] == "FAIL"]
        repair = snapshot.get("repair")
        repair_valid = (
            isinstance(repair, dict) and len(failures) == 1
            and repair.get("located_group") == failures[0]
            and repair.get("failure_kind") == "LOCATED_OWN_SOFTWARE_DEFECT"
            and all(isinstance(repair.get(key), str) and repair[key]
                    for key in ("basis_path", "diff_path", "old_source_sha256", "new_source_sha256"))
            and repair.get("old_source_sha256") != repair.get("new_source_sha256")
            and isinstance(repair.get("affected_groups"), list)
            and failures[0] in repair["affected_groups"]
            and set(repair["affected_groups"]) <= {"K", "V", "B"}
        )
        repaired = repair_valid and slots["R"]["state"] == "PASS"

        def effective_pass(name):
            return slots[name]["state"] == "PASS" or (
                repaired and name in repair["affected_groups"]
                and prerequisites.get("R_all_affected_cases_pass") is True
            )

        if group in {"P1", "R"}:
            if not repair_valid or slots["P0"]["state"] != "PASS":
                issues.append("CONDITIONAL_REPAIR_BASIS_MISSING")
            if group == "R" and slots["P1"]["state"] != "PASS":
                issues.append("P1_NEW_FREEZE_PASS_REQUIRED")
        else:
            if failures and not repaired:
                issues.append("FAILED_GROUP_BLOCKS_DEPENDENTS")
            index = NORMAL_ORDER.index(group)
            if any(not effective_pass(name) for name in NORMAL_ORDER[:index]):
                issues.append("EARLIER_MANDATORY_GROUP_NOT_PASS")
        required = {"root_authorization", "source_frozen", "tool_profile_unchanged",
                    "deadline_snapshot_current", "no_native_permission_failure"}
        if group != "P0":
            required |= {"P0_identity_and_job_proof_pass"}
        if group in MAX_CASES:
            count = prerequisites.get("case_count")
            expected = INITIAL_CASES.get(group)
            if type(count) is not int or not 1 <= count <= MAX_CASES[group]:
                issues.append("CASE_LIMIT_OR_COUNT_MISSING")
            elif expected is not None and count != expected:
                issues.append("FROZEN_INITIAL_MATRIX_MISMATCH")
        if group == "W":
            required |= {"A2_exact_all_output_geometry_pass", "delivery_channel_confirmed",
                         "all_logical_originals_recoverable", "actual_D4_no_stub",
                         "resources_strict_coverage_and_bound_pass", "fresh_free_space_pass",
                         "synthetic_geometry_frozen", "source_semantics_ready"}
        if group == "GATE_02":
            required |= {"S1_all_tracked_bytes_frozen"}
        if group == "S2":
            required |= {"normal_push_remote_inclusion_verified", "final_tree_unchanged"}
        issues += ["MISSING:" + key for key in sorted(required)
                   if prerequisites.get(key) is not True]
        # Reserve every unconsumed normal group and every unused publication
        # budget at full upper caps. Conditional P1/R are reserved together
        # once a repair is declared. Short real durations never refund charge.
        remaining = {name: CAPS[name] for name in NORMAL_ORDER
                     if slots[name]["state"] == "NOT_STARTED"}
        if group in {"P1", "R"} or repair is not None:
            remaining.update({name: CAPS[name] for name in ("P1", "R")
                              if slots[name]["state"] == "NOT_STARTED"})
        remaining[group] = CAPS[group]
        reserve = sum(remaining.values()) + (1260 - net) + (360 - git) + 60
        seconds_left = (deadline - now).total_seconds()
        if not math.isfinite(seconds_left) or seconds_left < reserve:
            issues.append("FULL_REMAINING_CAPS_PLUS_60S_DO_NOT_FIT")
        # Future fetch+push+containment need at least three available ops.
        # S2 follows completed publication and does not need new network ops.
        if group != "S2" and ops > 17:
            issues.append("PUBLICATION_OPERATION_RESERVE_MISSING")
        if group != "S2" and 1260 - net < 390:
            issues.append("FETCH_PUSH_INCLUSION_FULL_CAP_RESERVE_MISSING")
        return {"decision": "NO_GO" if issues else "GO_FOR_ROOT_CONSUMPTION_ONLY",
                "issues": issues, "group": group, "group_cap_seconds": CAPS[group],
                "remaining_group_caps": remaining,
                "reserved_seconds_including_margin": reserve,
                "seconds_to_earliest_deadline": seconds_left,
                "consumption_written": False, "execution_started": False}
    except (KeyError, TypeError, ValueError, AttributeError) as error:
        return {"decision": "NO_GO", "issues": ["INVALID_OR_INCOMPLETE_SNAPSHOT:" + str(error)],
                "consumption_written": False, "execution_started": False}
