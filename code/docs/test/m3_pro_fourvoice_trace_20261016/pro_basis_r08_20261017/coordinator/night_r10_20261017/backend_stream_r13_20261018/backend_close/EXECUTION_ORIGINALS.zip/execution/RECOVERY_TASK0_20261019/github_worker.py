"""Task0 one private-repository HTTP request, no code execution/installation."""
import base64,hashlib,json,os,subprocess,sys,urllib.request,urllib.error
from pathlib import Path
R=Path.cwd().resolve();D=R/'code/output/m3_backend_stream_r13_20261018/RECOVERY_TASK0_20261019'
a=json.loads(Path(sys.argv[1]).read_text('utf-8'));assert a['request_id'].replace('_','').isalnum()
repo='huangAngel730/fpga-electronic-piano'
endpoint=a['endpoint'];assert endpoint.startswith('/repos/'+repo+'/') or endpoint=='/repos/'+repo
assert a['method'] in ('GET','POST','PATCH')
env=dict(os.environ);env.update(GCM_INTERACTIVE='never',GIT_TERMINAL_PROMPT='0')
p=subprocess.run(['C:/Program Files/Git/cmd/git.exe','-c','credential.interactive=false','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=8,env=env)
if p.returncode:raise RuntimeError('GITHUB_STORED_CREDENTIAL_UNAVAILABLE')
fields=dict(line.split(b'=',1) for line in p.stdout.splitlines() if b'=' in line)
token=fields.get(b'password',b'').decode();assert token,'EMPTY_STORED_CREDENTIAL'
headers={'Authorization':'Bearer '+token,'User-Agent':'M3-R13-Task0-Handoff','Accept':'application/vnd.github+json'}
body=None
if 'body' in a:body=(json.dumps(a['body'],ensure_ascii=False)+'\n').encode();headers['Content-Type']='application/json'
url='https://api.github.com'+endpoint
if a.get('upload_file'):
 assert endpoint=='/repos/'+repo+'/releases/416620891/assets?name=M3_R13_PARTIAL_FOR_M2_AI_20261019.zip'
 path=(R/a['upload_file']).resolve();assert path==D/'M3_R13_PARTIAL_FOR_M2_AI_20261019.zip'
 body=path.read_bytes();assert len(body)==912923 and hashlib.sha256(body).hexdigest()=='2bb1b4294399ab3e327d9af418d05178f56e60acb4d83ac7694f35f63d54bd18'
 headers['Content-Type']='application/zip';url='https://uploads.github.com'+endpoint
if a.get('download'):
 headers['Accept']='application/octet-stream'
request=urllib.request.Request(url,data=body,headers=headers,method=a['method'])
class SafeRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  from urllib.parse import urlparse
  host=urlparse(newurl).hostname
  assert host in ('api.github.com','uploads.github.com','release-assets.githubusercontent.com'),'UNAPPROVED_REDIRECT_HOST'
  result=super().redirect_request(req,fp,code,msg,headers,newurl)
  if result is not None:result.remove_header('Authorization')
  return result
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),SafeRedirect())
try:
 with opener.open(request,timeout=18) as f:
  data=f.read(2*1048576+1);assert len(data)<=2*1048576,'API_RESPONSE_BOUND';status=f.status
 value=({'downloaded_bytes':len(data),'downloaded_sha256':hashlib.sha256(data).hexdigest()} if a.get('download') else json.loads(data))
except urllib.error.HTTPError as e:
 status=e.code;data=e.read(1048576);value={'HTTP_error_status':status,'message':'HTTP request rejected; response preserved without request headers'}
(D/(a['request_id']+'_RESPONSE.bin')).write_bytes(data)
(D/(a['request_id']+'_RESULT.json')).write_text(json.dumps({'status':status,'method':a['method'],'endpoint':endpoint,'response_sha256':hashlib.sha256(data).hexdigest(),'response_bytes':len(data),'credential_source':'Existing Git helper; token kept in memory, never logged','value':value},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'request_id':a['request_id'],'HTTP_status':status,'id':value.get('id') if isinstance(value,dict) else None,'html_url':value.get('html_url') if isinstance(value,dict) else None}))
raise SystemExit(0 if 200<=status<300 else 1)
