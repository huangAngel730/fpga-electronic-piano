# R04 night4 两文件静态交回

状态：`STATIC_IMPLEMENTATION_L0_NOT_RUN`。遵循 INTEGRATION_R04_API 与 EVENT_AND_PROFILE。
只修改正式 C/resources.py、C/volume_io.py；C 是已批准的 backend_stream_r13_20261018 软件根。
不修改其他 C 文件、冻结旧源、R02/R03原件、主账、Goal或许可。全部实际执行仍由总控。

| 文件 | bytes | SHA256 |
|---|---:|---|
| resources.py | 54042 | `e110c141349673650f6e837475026c4b738fad604b27ba6062300a48558fe344` |
| volume_io.py | 20382 | `0d651cdd68d4a20b2d51b70cdd9369479c91868ba1ea97f82f996f1ddb51da91` |

修改前原字节保存在 roles/night4/R04_BEFORE/：
resources.py 28859 B / `99f0afd0aca336c34e4016de108a6eb990bb5077a3ebb4207745ce2a12a98c20`；
volume_io.py 14364 B / `9d67ed5324cdac6ce49f48382a0a49cba67f54265c41fbcc487ae174b9334f81`。

## 已实现的接缝

- `configure_accounting(profile,external_logs,deadline_monotonic)` 一次配置，必须在首次 get_budget/worker IO 前调用。
  失败后不重配、不退款；同进程所有调用和所有 VolumeStore 使用同一个对象，不能传入不同预算。
- profile 按 R04 字段 `schema=M3_R13_ACCOUNTING_PROFILE_V1`、`whole_output_root`、
  `allocation_unit_bytes`、`enforce_start_free`、`initial_roles`、F/D（允许0）及 filesystem_bound_evidence。
  external_logs 是既有已资助 parent 四类日志的冻结 mapping。
- 配置中在原已准入槽内调用实际 GetVolumePathNameW/GetDiskFreeSpaceW。**P0 首次发现可给 A=0/None**，
  仅非 W 允许该占位，配置会查询真实 A 并保存；正数 A 必须与当前实际查询相等。
  **W 必须传 P0 冻结的正数 A**，不能通过占位发现开启 W。没有运行这些 API 的静态阶段不填实际数值。
- deadline 直接存原 `root_deadline_monotonic`，不改成 now+新时长。budget.check 在 IO/生成/卷读写入口核同一值，
  到期不恢复写入；receipt 仍可只读封存。原完整生命周期硬限仍由 root 原 owner 保证。
- 未 configure 的小单位用例可走显式 `unconfigured_unit_fallback=true`，不扫描/认领完整历史盘面，
  不猜实际 A，不据此签 W；首次借用 fallback 后不能再原地改为正式配置。W preflight 明确拒绝 fallback。
- accounting_open/mkdir/replace/save_bytes/copy_file 按共享 API；save/copy 返回 `{path,bytes,sha256}`，
  repo 内路径为相对 POSIX。只读输入允许 O 外，冻结调用方仍负责来源/权限校验；所有正式配置写入限 O。
- category aliases 按 R04；已登记文件的 all_other/默认写入继承其原 bucket，避免损坏自己 raw 副本时换账。
  startup baseline 默认只读，须 initial_roles 精确标成自己可写副本，不能改历史材料。
- 所有 payload/普通 JSON/manifest/tmp/失败文件共用预写账，≤1MiB 实际 FileIO read/write；覆盖写、短写、
  失败、删除、缩短 truncate、rename 均不退款。seek/扩长 truncate 禁止扩洞，ZIP header 回写仍重新花额度。
- 物理 writer 首次写失败后保存同一异常，后续 buffered close 不能再次向 OS 重试失败数据。
- 既有 24GiB 各 bucket、200646656B余量、payload2048/DELIVERY2048/ordinary4096/总8192及目录4096上限保留。
  F/D允许0，尾簇与可选额外F/D账不声称全卷 MFT/journal理论。已有文件实际 AllocationSize 超出单簇尾差额也计余量。
- disk_snapshot 输出 `allocation_unit_bytes`、原生 allocation_unit 明细、`allocation_size_bytes`、
  每文件 FILE_STANDARD_INFO.AllocationSize/EOF观察及完整性/错误，连同全目录逻辑 bytes/free。
  未观察到的分配量为 None，不当0。P0 case已有该函数调用，实际结果待总控原P0槽执行。
- finalize_resources 保留观察口径并加入已配置预写账、物理IO与allocation条件；`observation_pass` 和
  `pass` 分列，scope 仍要求总控已冻结写闭包，不自动变成完整 R13 或物理通过。

## 卷流的失败与 EOF

- 原每 store `_Quota(24GiB)` 已去除；可选 quota_bytes 仅作额外更紧的本 store 检查，不能发第二份全局额度。
  `self.budget`/`self.quota` 均指同一 resources.get_budget()。
- gzip header/data/footer 经共享 raw sink，单 part 32MiB 在物理 write 前拒收；31MiB decoded 分界保留。
  manifest/tmp 也计文件槽和 control 额度，原子替换通过共享预算。
- binary/text writer 记录首异常；异常 __exit__/close、编码失败、放弃对象的 GC 只 abort/释放，
  不给部分前缀生成正式 MANIFEST。只有完整正常 close 才发布 manifest 并加入 entries。
- reader 仅正常 gzip EOF 调 verify_eof，再核压缩/decoded part/whole identity；close 不读尾、不替换消费者原异常。
  OSError 原样传播，仅 BadGzipFile/EOFError 映射格式 Reject；循环跨空 part，避免递归堆栈问题。
- manifest 核确切字段、≤2048 parts、规范 part 文件名/序号/offset/范围/SHA 和全长，拒绝跨目录借其它文件。
  不更改业务 schema/finish/算法含义。

## 静态自审与仍需总控验证

已逐段静态阅读配置时序、共享对象、物理块拆分、覆盖/重建/rename计槽、短写/IO异常、构造失败释放、
二次close异常、正常 EOF 与异常不 drain、原子manifest屏障，以及 main3/night3 当前共享 API 调用形态。
两正式文件 LF、无BOM、无尾空白，SHA/字节由 PowerShell 读文件复核。
一次组合 apply_patch 因同一路径 Delete/Add 校验被拒，未执行目标；改为独立编辑后写入成功，不是工具组尝试。

**未 import、AST、compile、运行任何目标/fixture/Job/Git/网络；0目标组消费。**
实际 Python/IO/ZIP/ctypes ABI、P0原生分配观察、B05同异常和无读尾、V正负/边界、W内存/全部产物及900s性能，
仍由总控原预算和首失败门禁核验。不能把本次静态交回写成 P0/B/W 已通过。

需要总控最终合并核的边界：

1. P0 profile可用 A=0/None bootstrap，W profile用P0实际A；配置在 selftest首次IO前，当前night3代码顺序已对齐。
2. parent原owner日志由已冻结有限语句 escrow 资助，子receipt中 actual可仍None；父层关闭后另封真实尺寸，
   不声称跨进程共享了这份可变对象。读取原件与全部私有Path/ZIP/IdentityFacade写闭包仍须主集成冻结确认。
3. 当前free/AllocationSize是观测，预写界限是被受控 writer 执行的上界；不是任意外部卷写入下的连续free证明。
   保留MFT/journal在卷free观测中的影响，不能把F=D=0称作已测元数据为0。
4. 配额/文件数/压缩失败可以形成真实 W 失败原件，不保证压缩必成功，不增加或恢复 W/其他槽。
5. R04其余文件在其他独占租约中，本窗口没有替其最终内容签字；全13与总准入只由总控统一冻结。

正式两文件及本辅助写集在此次交回后释放；等待明确新分派，不再自行修改。
