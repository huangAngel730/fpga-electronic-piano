"""User-requested transfer originals only; not R13 S1/S2 or candidate execution."""
import hashlib,json,time,zipfile
from pathlib import Path
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'STATIC_DELIVERY_R02';D.mkdir(exist_ok=False)
deadline=time.monotonic()+57
def check():assert time.monotonic()<deadline
def stamp(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):check();n+=len(b);h.update(b)
 return {'path':p.relative_to(R).as_posix(),'bytes':n,'sha256':h.hexdigest()}
def archive(path,items):
 refs=[]
 assert sum(p.stat().st_size for name,p in items)<64*1048576
 with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
  for name,p in items:
   check();ref=stamp(p);refs.append({'member':name,**ref})
   with z.open(name,'w') as out,p.open('rb') as f:
    for b in iter(lambda:f.read(1048576),b''):check();assert out.write(b)==len(b)
  z.writestr('TRANSFER_MANIFEST.json',json.dumps({'members':refs,'scope':'Original static preparation; all candidate cases NOT_RUN; archive SHA is not a source Git commit'},ensure_ascii=False,indent=2)+'\n')
 with zipfile.ZipFile(path) as z:
  for ref in refs:
   n=0;h=hashlib.sha256()
   with z.open(ref['member']) as f:
    for b in iter(lambda:f.read(1048576),b''):check();n+=len(b);h.update(b)
   assert n==ref['bytes'] and h.hexdigest()==ref['sha256']
  assert z.testzip() is None
 return {'file':stamp(path),'payloads':len(refs),'CRC_SHA_size_verified':True}
a=R/'code/output/m3_business_precheck_r14_20261019';b=R/'code/output/m3_waveform_n32_nonphysical_prep_20261019'
results=[]
for folder,count,name in ((a,30,'M3_R14_STATIC_PREP_20261019.zip'),(b,13,'M3_WAVEFORM_N32_STATIC_PREP_20261019.zip')):
 manifest=json.loads((folder/'MANIFEST.json').read_text('utf-8'))
 for ref in manifest['payloads']:
  p=R/ref['path'];actual=stamp(p);assert actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256']
 files=sorted(p for p in folder.rglob('*') if p.is_file());assert len(files)==count
 results.append(archive(D/name,[(p.relative_to(folder).as_posix(),p) for p in files]))
(D/'UNITS.json').write_text(json.dumps({'units':results,'R14_candidate_execution':'NOT_RUN','E2_N32_cases':'NOT_RUN','source_result_commit':None,'M2_ACCEPTED':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
extra=[('R13_PARTIAL/'+p.name,p) for p in (O/'W_CODEC08_TERMINAL_RECEIPT.json',T/'CURRENT_PARTIAL_TRANSFER_RECEIPT.json',O/'CONSUMPTION_LIVE.json')]
extra += [('R14_HISTORY/'+p.name,p) for p in sorted((T/'R14_ROOT_RECONCILIATION_R02').iterdir()) if p.is_file()]
combined=archive(D/'M3_R14_STATIC_EXTENSION_AND_R13_PARTIAL_RECEIPTS_20261019.zip',[(p.name,p) for p in sorted(D.iterdir()) if p.is_file()]+extra)
(D/'TRANSFER_RECEIPT.json').write_text(json.dumps({'purpose':'User-requested GitHub original transfer of two completed static preparation units; not a native test, R13 seal or code publication','units':results,'combined':combined},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(combined))



