import hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_HOUR_REPLAY_09';D.mkdir(exist_ok=False)
P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017';S=R/'code/software'/P/'backend_stream_r13_20261018'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
l=json.loads((O/'CONSUMPTION_LIVE.json').read_text('utf-8'));assert l['recovery_attempts']['W_CODEC_08']['state']=='FAILED_STOP'
source=[ref(p) for p in sorted(S.iterdir()) if p.is_file()];assert len(source)==13
auth={'schema':'M3_R13_USER_ONE_HOUR_W_REPLAY_V1','approved':True,'authority':'Direct latest user: 请家加长时间继续冲重跑 预留一个小时的量','interpretation':'One fresh complete W run with 3600s cap; explicitly supersedes prior no-full-replay instruction for this run only. Retain all old failed receipts and charges.','original_START':l['actual_START'],'recorded_utc':datetime.now(timezone.utc).isoformat(),'new_W_slot':'W_HOUR_09','cap_seconds':3600,'cases_max':1,'old_slots_restored':False,'resource_limits_unchanged':True,'closing_deadline_proposed':'2026-10-19T12:00:00+08:00','only_root_test_and_publish':True,'source_files':source}
save(D/'AUTHORIZATION_W.json',auth)
files=[p for p in O.rglob('*') if p.is_file()];dirs=[p for p in O.rglob('*') if p.is_dir()]
save(D/'PRELAUNCH_HEADROOM.json',{'actual_files':len(files),'actual_directories':len(dirs),'actual_bytes':sum(p.stat().st_size for p in files),'free':shutil.disk_usage(O).free,'normal_file_limit':8064,'ordinary_upper_using_all_existing_plus512':len(files)+512+64,'global_files_upper_with2048payload2048delivery':len(files)+512+64+4096,'global_file_limit':16384,'directory_limit':8192,'no_delete_move_or_refund':True})
proposal={'schema':'M3_R13_W_HOUR_CLOSING_SUPPLEMENT_PROPOSAL_V1','approved':False,'already_authorized_W':ref(D/'AUTHORIZATION_W.json'),'retained_unconsumed_gates_seals_seconds':1920,'retained_network':'2 operations /360s for source push300 + containment fetch60 only','retained_local_git_seconds':135,'requested_incremental_transport':{'upload_current_full_W':{'runs':1,'cap_seconds':300},'download_back_verify':{'runs':1,'cap_seconds':60},'notify_M2':{'runs':1,'cap_seconds':30}},'extra_network_operations':3,'extra_network_seconds':390,'extra_local_git_seconds':0,'existing_local_git_includes_new_credential30':True,'deadline':'2026-10-19T12:00:00+08:00','W_and_all_closing_caps_seconds':3600+1920+360+135+390+120+60,'original_START':l['actual_START'],'old_consumption_not_reset':True,'no_HDL_EDA_hardware_or_N32_execution':True,'stop':'New W first failure stops dependency; no automatic extra W. Existing gate/seal slots once only.'}
save(D/'CLOSING_SUPPLEMENT_PROPOSAL.json',proposal);print(json.dumps({'W_authority':ref(D/'AUTHORIZATION_W.json'),'closing_proposal':ref(D/'CLOSING_SUPPLEMENT_PROPOSAL.json')}))
