"""R13 W-only global prewrite candidate; static, unexecuted support artifact.

Every store and plain writer in ONE worker must share the same instance.
External parent logs require a frozen finite escrow, never an unfunded second
budget. This is not a runner, process monitor, or an execution permission.
"""

import io
import os
from pathlib import Path
import shutil
import stat
import threading


MIB = 1024 * 1024
GIB = 1024 * MIB
CHUNK = MIB
LIMITS = {
    "gzip_payload": 8 * GIB,
    "delivery_copy": 8 * GIB,
    "plain_raw": 4631191552,
    "baseline": 512 * MIB,
    "plain_aux": 5 * GIB // 2,
    "control": 480 * MIB,
    "failure": 32 * MIB,
    "fs_allowance": 200646656,
}
MAX_FILES = 8192
MAX_PAYLOAD_PARTS = 2048
MAX_DELIVERY_PARTS = 2048
MAX_ORDINARY_FILES = 4096
MAX_FAILURE_FILES = 128  # included within ordinary; normal ordinary <=3968
MAX_DIRS = 4096
LOG_ROLES = {"owner_stdout", "owner_stderr", "owner_result", "parent_summary"}


class R13BudgetViolation(ValueError):
    pass


def _count(value, label):
    if type(value) is not int or value < 0:
        raise R13BudgetViolation("NONNEGATIVE_INTEGER:" + label)
    return value


class R13GlobalBudget:
    def __init__(self, root, *, allocation_unit_bytes,
                 file_metadata_bound_bytes, directory_bound_bytes,
                 filesystem_bound_evidence, initial_roles=None,
                 external_log_escrows=None):
        self.root = Path(os.path.abspath(root))
        if self.root.name != "m3_backend_stream_r13_20261018":
            raise R13BudgetViolation("WHOLE_R13_OUTPUT_ROOT_REQUIRED")
        self._owner_pid = os.getpid()
        self._lock = threading.RLock()
        self._files, self._dirs, self._external = {}, set(), {}
        self._counts = {"payload_part": 0, "delivery_part": 0,
                        "ordinary": 0, "failure": 0}
        self.reserved = {key: 0 for key in LIMITS}
        self.actual_io = {key: 0 for key in LIMITS}
        self.unknown_actual_upper = {key: 0 for key in LIMITS}
        self._errors, self._rejections = [], 0
        self._writes, self._max_write, self._short_writes = 0, 0, 0
        self._baseline_bytes, self._baseline_files = 0, 0
        self._allocation_unit = _count(allocation_unit_bytes, "allocation_unit")
        file_meta = _count(file_metadata_bound_bytes, "file_metadata")
        dir_bound = _count(directory_bound_bytes, "directory_bound")
        self._file_metadata_bound, self._directory_bound = file_meta, dir_bound
        if (self._allocation_unit <= 0 or file_meta <= 0 or dir_bound <= 0
                or self._allocation_unit & (self._allocation_unit - 1)
                or not filesystem_bound_evidence):
            raise R13BudgetViolation("FROZEN_FILESYSTEM_BOUNDS_REQUIRED")
        self.fs_bound = (MAX_FILES * (self._allocation_unit - 1 + file_meta)
                         + MAX_DIRS * dir_bound)
        if self.fs_bound > LIMITS["fs_allowance"]:
            raise R13BudgetViolation("ALLOCATION_AND_METADATA_ALLOWANCE_EXCEEDED")
        self.fs_evidence = filesystem_bound_evidence
        # Whole allowance is permanently charged up front; no deletion,
        # truncation, rename or IO failure can refund any part of it.
        self.reserved["fs_allowance"] = LIMITS["fs_allowance"]
        self._path(self.root, allow_root=True)
        if not self.root.is_dir():
            raise R13BudgetViolation("EXISTING_WORKSPACE_ROOT_REQUIRED")
        initial_roles = initial_roles or {}
        # Parent freezes these BEFORE launching the original owner. The worker
        # imports the already-funded finite envelopes, not a second permission
        # to spend the same workspace budget. Files can already exist here.
        for relative, escrow in (external_log_escrows or {}).items():
            path = self._path(self.root / relative)
            if relative in initial_roles:
                raise R13BudgetViolation("EXTERNAL_AND_BASELINE_ROLE_OVERLAP")
            self._validate_external(escrow["role"], escrow["byte_cap"],
                                    escrow["evidence"], escrow["max_physical_write"])
            key = str(path).casefold()
            if key in self._external:
                raise R13BudgetViolation("DUPLICATE_EXTERNAL_PATH")
            self._register_file(path, "failure", "ordinary")
            self._charge("failure", escrow["byte_cap"])
            self._external[key] = {
                "path": str(path), "role": escrow["role"],
                "reserved": escrow["byte_cap"], "actual": None,
                "evidence": escrow["evidence"],
                "max_physical_write": escrow["max_physical_write"]}
        visited = set()
        pending = [self.root]
        while pending:
            directory = pending.pop()
            self._register_dir(directory)
            with os.scandir(directory) as entries:
                for entry in entries:
                    path = self._path(entry.path)
                    info = entry.stat(follow_symlinks=False)
                    if stat.S_ISDIR(info.st_mode):
                        pending.append(path)
                    elif stat.S_ISREG(info.st_mode):
                        relative = path.relative_to(self.root).as_posix()
                        key = str(path).casefold()
                        category = ("failure" if key in self._external else
                                    initial_roles.get(relative, "baseline"))
                        kind = ("payload_part" if category == "gzip_payload" else
                                "delivery_part" if category == "delivery_copy" else
                                "ordinary")
                        state = self._register_file(path, category, kind, info.st_size)
                        state["extent"], state["present"] = info.st_size, True
                        if key in self._external:
                            if info.st_size > self._external[key]["reserved"]:
                                raise R13BudgetViolation("EXTERNAL_BOUND_BROKEN_AT_START")
                        else:
                            self._charge(category, info.st_size)
                        self._baseline_bytes += info.st_size
                        self._baseline_files += 1
                        visited.add(relative)
                    else:
                        raise R13BudgetViolation("SPECIAL_BASELINE_FILE")
        if set(initial_roles) - visited:
            raise R13BudgetViolation("UNMATCHED_BASELINE_ROLE")
        self.initial_free = shutil.disk_usage(self.root).free
        self.min_free_observed = self.initial_free
        if self.initial_free < 32 * GIB:
            raise R13BudgetViolation("INITIAL_FREE_BELOW_32GIB")

    def _same_owner(self):
        if os.getpid() != self._owner_pid:
            raise R13BudgetViolation("BUDGET_COPY_OR_CROSS_PROCESS_USE_FORBIDDEN")

    def _path(self, value, *, allow_root=False):
        self._same_owner()
        path = Path(os.path.abspath(value))
        if ((path == self.root and not allow_root)
                or not path.is_relative_to(self.root)):
            raise R13BudgetViolation("PATH_OUTSIDE_GLOBAL_WORKSPACE")
        reserved_names = {"CON", "PRN", "AUX", "NUL"} | {
            prefix + str(number) for prefix in ("COM", "LPT") for number in range(1, 10)}
        for part in path.relative_to(self.root).parts:
            if (":" in part or part.endswith((" ", ".")) or "\x00" in part
                    or part.split(".", 1)[0].upper() in reserved_names):
                raise R13BudgetViolation("WINDOWS_ALIAS_OR_STREAM_PATH")
        for component in (path, *path.parents):
            try:
                info = component.lstat()
            except FileNotFoundError:
                continue
            if (stat.S_ISLNK(info.st_mode)
                    or getattr(info, "st_file_attributes", 0) & 0x400):
                raise R13BudgetViolation("REPARSE_OR_SYMLINK")
            if stat.S_ISREG(info.st_mode) and getattr(info, "st_nlink", 1) > 1:
                raise R13BudgetViolation("HARD_LINK_NOT_SUPPORTED")
        return path

    def _reject(self, reason):
        self._rejections += 1
        raise R13BudgetViolation(reason)

    def _charge(self, category, count):
        _count(count, "reserve")
        if category not in LIMITS or category == "fs_allowance":
            self._reject("UNKNOWN_OR_NONWRITE_BUCKET")
        if self.reserved[category] + count > LIMITS[category]:
            self._reject("GLOBAL_QUOTA_REJECTED:" + category)
        self.reserved[category] += count

    def _register_dir(self, path):
        key = str(path).casefold()
        if key not in self._dirs:
            if len(self._dirs) >= MAX_DIRS:
                self._reject("DIRECTORY_COUNT_LIMIT")
            self._dirs.add(key)

    def _register_file(self, path, category, kind, size=0, file_limit=None):
        key = str(path).casefold()
        if key in self._files:
            item = self._files[key]
            if item["category"] != category or item["kind"] != kind:
                self._reject("PATH_CATEGORY_CHANGE_FORBIDDEN")
            return item
        if category not in LIMITS or category == "fs_allowance":
            self._reject("FILE_CATEGORY")
        if kind not in ("payload_part", "delivery_part", "ordinary"):
            self._reject("FILE_KIND")
        if ((kind == "payload_part") != (category == "gzip_payload")
                or (kind == "delivery_part") != (category == "delivery_copy")):
            self._reject("PART_BUCKET_KIND_MISMATCH")
        if sum(self._counts[key] for key in ("payload_part", "delivery_part", "ordinary")) >= MAX_FILES:
            self._reject("GLOBAL_FILE_COUNT_LIMIT")
        limit = {"payload_part": MAX_PAYLOAD_PARTS,
                 "delivery_part": MAX_DELIVERY_PARTS,
                 "ordinary": MAX_ORDINARY_FILES}[kind]
        if self._counts[kind] >= limit:
            self._reject("FILE_KIND_COUNT_LIMIT:" + kind)
        if kind == "ordinary":
            if category == "failure":
                if self._counts["failure"] >= MAX_FAILURE_FILES:
                    self._reject("FAILURE_FILE_COUNT_LIMIT")
                self._counts["failure"] += 1
            elif self._counts["ordinary"] - self._counts["failure"] >= (
                MAX_ORDINARY_FILES - MAX_FAILURE_FILES
            ):
                self._reject("NORMAL_FILES_CANNOT_SPEND_FAILURE_RESERVE")
        self._counts[kind] += 1
        item = {"path": str(path), "category": category, "kind": kind,
                "extent": size, "present": path.exists(),
                "file_limit": file_limit, "open": False}
        self._files[key] = item
        return item

    def _free_check(self, count=0):
        free = shutil.disk_usage(self.root).free
        self.min_free_observed = min(self.min_free_observed, free)
        if free - count < 8 * GIB:
            self._reject("FREE_RESERVE_BELOW_8GIB")

    def mkdir(self, path, *, parents=False, exist_ok=False):
        with self._lock:
            path = self._path(path, allow_root=True)
            wanted = [path]
            if parents:
                wanted = [*reversed(path.parents), path]
            for item in wanted:
                if not item.is_relative_to(self.root):
                    continue
                if item.exists():
                    if not item.is_dir():
                        self._reject("DIRECTORY_EXPECTED")
                    if item == path and not exist_ok:
                        raise FileExistsError(str(path))
                    self._register_dir(item)
                    continue
                if str(item).casefold() in self._dirs:
                    self._reject("DIRECTORY_RECREATION_WITHOUT_NEW_SLOT_FORBIDDEN")
                self._register_dir(item)  # failed mkdir still spends its slot
                self._free_check(self._directory_bound)
                item.mkdir()

    def open(self, path, category, mode="xb", *, kind="ordinary", file_limit=None):
        with self._lock:
            path = self._path(path)
            if mode not in ("xb", "wb", "ab", "r+b"):
                self._reject("EXPLICIT_BINARY_WRITE_MODE_REQUIRED")
            if file_limit is not None:
                _count(file_limit, "file_limit")
            key = str(path).casefold()
            existed = path.exists()
            if existed and key not in self._files:
                self._reject("UNREGISTERED_EXISTING_WRITER")
            if not path.parent.is_dir() or str(path.parent).casefold() not in self._dirs:
                self._reject("UNREGISTERED_PARENT_DIRECTORY")
            previous = self._files.get(key)
            if previous is not None and not existed:
                if (previous["open"] or key in self._external
                        or previous["category"] != category or previous["kind"] != kind):
                    self._reject("RECREATION_SCOPE_OR_WRITER_CONFLICT")
                if file_limit is None:
                    file_limit = previous["file_limit"]
                del self._files[key]  # counters/reserved bytes NEVER removed
            item = self._register_file(path, category, kind, 0, file_limit)
            if item["open"] or key in self._external:
                self._reject("CONCURRENT_OR_EXTERNAL_PATH_WRITER")
            if file_limit is not None:
                if item["file_limit"] not in (None, file_limit):
                    self._reject("FILE_LIMIT_CHANGED")
                item["file_limit"] = file_limit
            self._free_check(self._file_metadata_bound + self._allocation_unit)
            raw = path.open(mode, buffering=0)
            item["extent"] = os.fstat(raw.fileno()).st_size
            item["present"], item["open"] = True, True
            return _R13PhysicalWriter(self, raw, item)

    def open_text(self, path, category, mode="x", **kwargs):
        if mode not in ("x", "w", "a"):
            self._reject("EXPLICIT_TEXT_MODE_REQUIRED")
        raw = self.open(path, category, mode + "b", **kwargs)
        return _R13TextWriter(io.BufferedWriter(raw, buffer_size=CHUNK),
                              encoding="utf-8", errors="strict", newline="\n")

    def replace(self, source, target):
        with self._lock:
            source, target = self._path(source), self._path(target)
            if source == target or str(target.parent).casefold() not in self._dirs:
                self._reject("RENAME_SAME_PATH_OR_UNREGISTERED_PARENT")
            old = self._files.get(str(source).casefold())
            if old is None or old["open"] or not old["present"]:
                self._reject("CLOSED_REGISTERED_RENAME_SOURCE_REQUIRED")
            target_key = str(target).casefold()
            prior_target = self._files.get(target_key)
            if ((prior_target is not None and prior_target["open"])
                    or target_key in self._external):
                self._reject("RENAME_TARGET_WRITER_OPEN")
            if prior_target is not None:
                if (prior_target["category"] != old["category"]
                        or prior_target["kind"] != old["kind"]):
                    self._reject("RENAME_CATEGORY_CHANGE")
                del self._files[target_key]
            new = self._register_file(target, old["category"], old["kind"], 0,
                                      old["file_limit"])
            if prior_target is not None:
                new["extent"], new["present"] = prior_target["extent"], prior_target["present"]
            # Rename spends a target-name slot even if OS replacement fails.
            os.replace(source, target)
            new["extent"], new["present"] = old["extent"], True
            old["present"] = False

    def reserve_external_log(self, path, *, role, byte_cap, evidence,
                             max_physical_write):
        """Only finite, frozen parent stdout/stderr/RESULT/summary statements.

        This is escrow, not runtime interception. A promise alone is not the
        writer bound; evidence must identify exact frozen output statements.
        """
        with self._lock:
            path = self._path(path)
            self._validate_external(role, byte_cap, evidence, max_physical_write)
            key = str(path).casefold()
            if path.exists() or key in self._external or key in self._files:
                self._reject("FRESH_EXTERNAL_LOG_REQUIRED")
            self._register_file(path, "failure", "ordinary")
            self._charge("failure", byte_cap)
            self._free_check(byte_cap)
            self._external[key] = {"path": str(path), "role": role,
                                   "reserved": byte_cap, "actual": None,
                                   "evidence": evidence,
                                   "max_physical_write": max_physical_write}
            return key

    def _validate_external(self, role, byte_cap, evidence, max_physical_write):
        _count(byte_cap, "external_cap")
        if (role not in LOG_ROLES or not evidence
                or type(max_physical_write) is not int
                or not 0 < max_physical_write <= CHUNK):
            self._reject("FINITE_FROZEN_EXTERNAL_LOG_BOUND_REQUIRED")

    def settle_external_log(self, token):
        with self._lock:
            item = self._external[token]
            if item["actual"] is not None:
                self._reject("EXTERNAL_LOG_ALREADY_SETTLED")
            path = self._path(item["path"])
            size = path.stat().st_size
            item["actual"] = size
            self.actual_io["failure"] += size
            file_state = self._files[token]
            file_state["extent"], file_state["present"] = size, True
            if size > item["reserved"]:
                self._reject("FROZEN_EXTERNAL_LOG_BOUND_BROKEN")

    def secondary(self, error):
        if len(self._errors) < 32:
            self._errors.append(type(error).__name__ + ":" + str(error)[:512])

    def receipt(self):
        with self._lock:
            self._same_owner()
            return {"schema": "M3_R13_GLOBAL_PREWRITE_BUDGET_R03",
                    "status": "ACCOUNTING_ONLY_NOT_A_GO_DECISION",
                    "limits": dict(LIMITS), "quota_reserved": dict(self.reserved),
                    "total_reserved_upper_bytes": sum(self.reserved.values()),
                    "actual_io_bytes_known": dict(self.actual_io),
                    "actual_io_bytes_unknown_upper": dict(self.unknown_actual_upper),
                    "baseline_bytes": self._baseline_bytes,
                    "baseline_files": self._baseline_files,
                    "registered_file_slots": sum(self._counts[key] for key in
                                                 ("payload_part", "delivery_part", "ordinary")),
                    "registered_directory_slots": len(self._dirs),
                    "file_kind_slots": dict(self._counts),
                    "allocation_unit_bytes": self._allocation_unit,
                    "allocation_and_metadata_bound_bytes": self.fs_bound,
                    "filesystem_bound_evidence": self.fs_evidence,
                    "external_logs": list(self._external.values()),
                    "writes": self._writes, "max_physical_write": self._max_write,
                    "short_writes": self._short_writes, "quota_rejections": self._rejections,
                    "initial_free_bytes": self.initial_free,
                    "minimum_free_observed": self.min_free_observed,
                    "continuous_free_space_proved_here": False,
                    "secondary_errors": list(self._errors),
                    "unclosed_writers": sum(item["open"] for item in self._files.values()),
                    "known_live_file_lengths": sum(item["extent"] for item in self._files.values()
                                                   if item["present"]),
                    "final_physical_census": "REQUIRED_NOT_REPLACED_BY_KNOWN_LENGTHS",
                    "all_writer_closure_and_external_proofs": "REQUIRED_FROM_ROOT",
                    "refund_bytes": 0, "execution_allowed": False}


class _R13PhysicalWriter(io.RawIOBase):
    def __init__(self, budget, raw, item):
        self.budget, self.raw, self.item = budget, raw, item
        self.name, self.mode = raw.name, raw.mode

    def writable(self):
        return True

    def seekable(self):
        return True

    def readable(self):
        return False

    def tell(self):
        return self.raw.tell()

    def fileno(self):
        # Frozen callers may use this ONLY for fsync/fstat. An os.write,
        # ftruncate, mmap or descriptor duplicate would bypass the budget.
        return self.raw.fileno()

    def seek(self, offset, whence=0):
        with self.budget._lock:
            _count(self.item["extent"], "extent")
            base = {0: 0, 1: self.raw.tell(), 2: self.item["extent"]}.get(whence)
            if type(offset) is not int or base is None:
                self.budget._reject("SEEK_ARGUMENT")
            target = base + offset
            if not 0 <= target <= self.item["extent"]:
                self.budget._reject("SPARSE_OR_OUTSIDE_EXTENT_SEEK_FORBIDDEN")
            return self.raw.seek(target, 0)

    def truncate(self, *args):
        raise R13BudgetViolation("EXPLICIT_TRUNCATE_FORBIDDEN_NO_REFUNDS")

    def write(self, data):
        view = memoryview(data).cast("B")
        offset = 0
        while offset < len(view):
            block = view[offset:offset + CHUNK]
            count = len(block)
            with self.budget._lock:
                self.budget._same_owner()
                if self.closed or self.raw.closed:
                    raise ValueError("write to closed file")
                position = (self.item["extent"] if "a" in self.mode else self.raw.tell())
                if not 0 <= position <= self.item["extent"]:
                    self.budget._reject("WRITE_WOULD_CREATE_HOLE")
                bound = self.item["file_limit"]
                if bound is not None and position + count > bound:
                    self.budget._reject("FILE_BOUND_BEFORE_PHYSICAL_WRITE")
                self.budget._free_check(count + self.budget._allocation_unit - 1)
                category = self.item["category"]
                # Charge every attempted byte including overwrites and failed
                # IO. No subsequent status or cleanup ever refunds this.
                self.budget._charge(category, count)
                self.budget._writes += 1
                self.budget._max_write = max(self.budget._max_write, count)
                try:
                    written = self.raw.write(block)
                except BaseException:
                    self.budget.unknown_actual_upper[category] += count
                    try:
                        self.item["extent"] = os.fstat(self.raw.fileno()).st_size
                    except BaseException as secondary:
                        self.budget.secondary(secondary)
                    raise  # exact original IO exception, no retry
                if type(written) is int and 0 <= written <= count:
                    self.budget.actual_io[category] += written
                    self.item["extent"] = max(self.item["extent"], position + written)
                else:
                    self.budget.unknown_actual_upper[category] += count
                if written != count:
                    self.budget._short_writes += 1
                    raise R13BudgetViolation("PHYSICAL_SHORT_WRITE_NO_RETRY")
            offset += count
        return len(view)

    def flush(self):
        if not self.raw.closed:
            self.raw.flush()

    def close(self):
        if self.closed:
            return
        primary = None
        try:
            super().close()
        except BaseException as error:
            primary = error
        try:
            self.raw.close()
        except BaseException as secondary:
            if primary is None:
                raise
            self.budget.secondary(secondary)
        finally:
            self.item["open"] = not self.raw.closed
        if primary is not None:
            raise primary.with_traceback(primary.__traceback__)

    def __exit__(self, kind, value, traceback):
        if kind is None:
            self.close()
        else:
            try:
                self.close()
            except BaseException as secondary:
                self.budget.secondary(secondary)
        return False


class _R13TextWriter(io.TextIOWrapper):
    def __init__(self, buffer, **kwargs):
        self._budget = buffer.raw.budget
        super().__init__(buffer, **kwargs)

    def __exit__(self, kind, value, traceback):
        if kind is None:
            self.close()
        else:
            try:
                self.close()
            except BaseException as secondary:
                self._budget.secondary(secondary)
        return False
