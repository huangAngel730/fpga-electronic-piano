# R13 C writer: minimal reachable-chain adaptation guide

Status: static main4 assistance only. This guide and the adjacent Python candidate were not imported, compiled, or tested. They are not official R13 source files and do not claim a passed software group.

## 1. Keep the reachable chain; change only its private I/O seams

The required entry path is:

`R12 capture_entry.process` -> `DependencyContext.complete()` -> private R11 `process` -> injected private R10 `capture_link.entry.process` -> injected frozen D4 `chain.process`.

Do not call D4 directly and do not create a replacement processor. The R13 entry should still construct one fresh private dependency context per request and delegate to the frozen R11/R10/D4 `process` functions. Add explicit constructor dependencies for control-record loading, artifact/volume opening, PE snapshot/random reads, and finalization. Do not patch canonical modules or global `pathlib`.

## 2. Exact official-file seams recommended

- `binding.py`
  - `read_control_record(path, descriptor) -> (raw, value)`: one <=8 MiB buffer; SHA/length and parse use the identical bytes; reject duplicate keys/non-finite values.
  - Freeze request, dependency manifest, envelope, application request, window/frame/end documents and other bounded JSON before dispatch. Control JSON remains single-file and must not use transport volumes.
- `volume_io.py`
  - `LogicalFile` plus `VerifiedVolumeStream`: ordered contiguous offsets, part bytes/SHA, logical bytes/SHA, <=1 MiB physical requests, lines may cross part boundaries, success requires verified EOF.
  - A volume boundary is never a row/reset/epoch boundary. `source.line`, `cycle`, `time_ps`, digest state and parser state remain global.
  - For the reachable tool-identity PE read, stream-copy the exact checked executable/dependency to a private snapshot and parse that snapshot with <=1 MiB `read_at` calls. Preserve the old PE field checks and 1024-import/512-name limits. This removes `FrozenBufferPath.read_bytes()` without changing the tool identity or parser outcome.
- `stream_bridge.py`
  - Wire only the private R12 loader/facade path slots to the new openers. Keep frozen D4 algorithms and the actual module-binding document.
  - Preserve the actual stage order: raw projection -> public rows -> CSV encode -> CSV decode -> row-for-row equality -> intake -> calendar -> serial -> ROM manifest -> math histories -> provenance.
  - Keep math `ADVANCE_HISTORY.jsonl` selection `advance_mask != 0` and fields including `cancel_raw` plus `retained_even_if_unpublished_or_cancelled=true`.
  - Keep per-row source identity and the raw/public physical-line hash index. Never zip sparse histories positionally.
- `finalize.py`
  - Run D4 under a fresh staging descendant. Treat its `HANDOFF.json` as an intermediate, not the R13 completion marker.
  - After every writer is closed, re-hash required artifacts to EOF and validate: global row count, exactly one final row, `row_count == finish_cycle + 1`, final-row cycle, and exactly one byte-exact `MONITOR_END` line.
  - Only then write a temporary R13 completion document, flush/fsync it, and atomically replace the final marker. On any exception, preserve the original exception, retain partial artifacts/failure originals, and leave no R13 completion marker.
- `resources.py`
  - Account for every simultaneous/staged file, not only raw/public. The row index embeds the full canonical row again; CSV plus decoded JSONL, intake projection/sidecar/preserved rows, serial outputs and math histories are additional bytes.
  - W must remain NO_GO until measured/derived peak workspace is <=24 GiB, free-at-start is >=32 GiB with >=8 GiB reserve, and the worker/process-tree peak rule is satisfied.

## 3. Reachable whole-buffer decisions

1. **8 MiB, reachable and intentional for controls.** R12 `json_identity.read_stream_json` joins a maximum 8 MiB buffer and `capture_identity.IdentityFacade.read` routes old `read_json` calls through the same-byte identity+parse operation. Keep this for bounded control JSON only.
2. **64 MiB, reachable and should be removed from the heap path.** D4 application assembly calls the reused tool checker. Its `evaluate()` calls adapted `m3r08_common.checked_file()`, then `source.read_bytes()` before PE parsing. R12 returns `FrozenBufferPath(limit=64 MiB)`, so vlib/vlog/vsim PE files and any traversed dependency can be fully joined in memory. Replace only this private boundary with verified snapshot plus bounded random-access PE parsing.
3. **A separate 64 MiB decoded archive residency is reachable.** Application assembly reads two source ZIPs and retains selected decompressed members in dictionaries; each member is capped at 16 MiB and the decoded total at 64 MiB. R12 streams the ZIP snapshot but does not remove the decompressed `payload`/`members` residency. Include this in peak memory and reject a larger closure; do not silently drop members.
4. **16 MiB logical metadata buffers are also reachable.** `c9_stream.convert_files()` passes complete reset/end/stdout bytes to the frozen legacy normalizer; provenance also reads reset bytes with `16 MiB+1`. Physical reads are already <=1 MiB in R12, but the returned logical objects are whole buffers. Keep only if A2 proves the frozen roles stay bounded; otherwise add a semantics-preserving streaming parser before W.
5. **The 8 MiB ledger read is a full-window risk.** Intake externalizes only `preserved_rows`; its ledger still contains frames, transactions, TX samples and raw cancels. `chain.py` immediately reopens `INTAKE_LEDGER.json` through the R12 8 MiB control-JSON path before calendar analysis. Either prove the frozen W geometry stays below the bound, or add an explicit streaming ledger/calendar seam with equivalent ordering and rejection checks. Never raise the bound to make W pass.
6. **Do not repair dead reads.** R11 `legacy_module()` and R10 `capture_link.load()` contain `read_bytes`, but R12 replaces their factories before `process`; they are not the active loading path. `c9_oracle_bridge` also contains a whole-trace `read_bytes` conversion entry, but the D4 chain uses only its binding/helpers during `c9_stream`, not that conversion entry.

## 4. Seven M1 job roles and exact current gap

The seven names come from the signed M1 `MATH_INPUT_JOB_TEMPLATE.json`/`c9_inputs.ROLES`; they are not seven invented R13 files:

1. `mechanical_index`: current M1 expects one `M3_R7C_C9_MECHANICAL_INDEX_V1` JSON object containing a `rows` list. Frozen D4 instead emits streaming `MATH_ROW_INDEX.jsonl` plus `M3_D4_C9_MATH_INPUT_BUNDLE_V1`. M1's signed compatibility decision says the latter is the sole future adapter target, but its streaming reader is not implemented.
2. `public_rows`: `PUBLIC_ROWS_C9.jsonl`, one `M3_R7A_C9_PUBLIC_ROW_V1` per physical line, from `c9_stream.convert_files`.
3. `raw_capture`: same-run raw JSONL, one `M3_R7A_C9_RAW_CORE_ROW_V1` per line, from the capture producer; D4 does not synthesize it.
4. `independent_plan`: independent MIDI/event plan (`M3_R06_MIDI_STIMULUS_PLAN_V1` in the current frozen source), never inferred from observed trace.
5. `frame_plan`: unique frame plan (`M3_R06_UNIQUE_FRAME_PLAN_V1`) from the frozen frame generator.
6. `reset_edges`: same-run asynchronous reset JSONL, per-line `M3_R7A_RESET_SNAPSHOT_V1`. Current M1 consumer expects a separate bounded reset projection object, so this remains an explicit adapter gap rather than a silent reinterpretation.
7. `provenance`: D4 `M3_C9_CHAIN_PROVENANCE_V1`, with exact M2 admission still required for REAL mode.

The D4 math manifest additionally carries the broader 17-role identity set and four byte streams (`MATH_ROW_INDEX`, `FX_HISTORY`, `ADVANCE_HISTORY`, `INPUT_AND_APPLY_HISTORY`). Do not rename those four streams to pretend the seven-role M1 consumer is already compatible.

## 5. Static resource/failure findings the implementation must cover

- Raw is read twice by conversion and again by provenance; public rows are read by CSV encode, roundtrip comparison, intake, serial, math and provenance.
- CSV decode produces another full public JSONL. `MATH_ROW_INDEX` embeds each canonical public row. Intake emits legacy projection, complete sidecar and preserved-row JSONL. These duplications make the 24 GiB W cap a real admission check.
- Intake offloads `preserved_rows`, but still materializes frame/transaction/TX/cancel ledger lists and D4 reads the ledger as bounded JSON before calendar analysis. Reject on the existing bound; do not raise the bound or silently omit entries.
- The frozen intake algorithm repeatedly scans accumulated frames for oldest/open-frame and frame ordinal decisions; a long/high-frame-count profile can be quadratic. Preserve its exact ordering/selection if a streaming successor replaces it, and include this cost in W admission.
- Existing child `except` blocks write failure JSON and re-raise, but a failure while writing failure evidence can mask the first exception. R13 should save the first exception, attempt secondary evidence separately, and re-raise the first.
- D4 writes `HANDOFF.json` before return. R13 must add a later, unique completion barrier after close/EOF/final identity checks; otherwise a late failure can leave a misleading completion-looking file.
- `capture_entry.main()` returns 3 even after a successful limited candidate. If R13 launches that CLI, its run contract must explicitly map the pinned exit code 3 plus valid result/receipts to limited success; generic exit-code-zero logic would reject a valid candidate, while exit code 3 alone must never prove success.

