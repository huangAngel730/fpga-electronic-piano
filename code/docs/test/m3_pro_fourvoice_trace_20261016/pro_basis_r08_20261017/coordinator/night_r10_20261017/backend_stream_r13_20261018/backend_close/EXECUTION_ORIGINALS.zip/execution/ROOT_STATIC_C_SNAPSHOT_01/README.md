# M3 R13 后端流式候选（静态实现，尚未运行）

本目录是 R12 的新后继，不是 D4 替身。实际调用链为：

`entry.py → binding.py → 冻结 R12 → R11 → R10 → 真实 D4 → application/frame/stream/codec/intake/calendar/serial/math/provenance`。

当前仅完成候选源码和静态自审。M3 本窗口没有运行 P0/K/V/B/W、没有导入目标模块、没有执行 Git、HDL、EDA、设备或网络操作。所有 `real_verified`、`math_verified`、`execution_allowed`、`board_release_allowed` 都保持 `false`。

## 关键接口

生产入口：

```powershell
python.exe -X utf8 -B code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018/entry.py `
  --control <absolute CONTROL.json> `
  --control-sha256 <sha256> `
  --output <absolute fresh child under code/output/m3_backend_stream_r13_20261018>
```

`CONTROL.json` 必须严格使用 `M3_R13_BACKEND_CONTROL_V1`，字段为 `schema/run_id/run_kind/envelope_ref/dependencies_ref/quota_bytes/volume_policy/authority`。`envelope_ref` 和 `dependencies_ref` 均为 `{path,bytes,sha256}` 文件描述符。控制 JSON 只读入并解析一个缓冲；结束前仅复算身份，不以第二次解析覆盖初始决定。完全改回的瞬时 ABA 无法由前后身份证明，完成收据明确保留此限制。

纯准入入口：

```powershell
python.exe -X utf8 -B .../run_plan.py --assess-one --group K `
  --snapshot <abs> --snapshot-sha256 <sha> `
  --prerequisites <abs> --prerequisites-sha256 <sha> `
  --now <ISO8601-with-zone> --output <fresh decision.json>
```

一次性监督器必须由 root 作为独立 Python 进程启动，不能在长寿命协调器内 import 调用：

```powershell
python.exe -X utf8 -B .../job_bridge.py --execute-one `
  --admission <abs> --admission-sha256 <sha> `
  --owner-output <fresh .../RUNS/K>
```

它冻结的 worker argv 为：

```text
python.exe -X utf8 -B selftest.py --worker --group <P0|K|V|B|W|R>
  --admission <same abs> --admission-sha256 <same sha>
  --output <owner-output>/worker
```

`owner-output` 保存原始 `stdout.bin/stderr.bin/RESULT.json`；业务输出只能在其 fresh 子目录 `worker`。B02/B03/B04 的自然退出、后代和 Job0 只能由父层收据判断，worker 不会自签。

## 流式卷与完成语义

- 所有 `.jsonl/.csv` 大逻辑文件生成时直接写为 gzip 独立卷；不会先生成整份明文。
- 每次物理读写不超过 1 MiB；每卷最多 31 MiB 解码数据，压缩卷硬上限 32 MiB。
- 清单绑定卷序号、逻辑偏移、逐卷解码长度/SHA、压缩长度/SHA，以及完整逻辑流长度/SHA。
- 读取严格检查缺卷、重复/错序、错偏移、压缩或解码身份、截断和整体身份；字节透明，不规范化 UTF-8、CRLF 或 LF。
- D4 任一异常原样传播，并保留 partial 与原 D4/R13 failure；异常关闭不写成功目录。
- 只有真实 D4 全链返回、全部描述符终检和资源/身份账完成后，才 `fsync + os.replace` 写 `COMPLETE.json` 并原子发布最终目录。D4 的 `HANDOFF.json` 不是 R13 完成标志。

## 数学输入/输出边界

D4 当前真实数学**输出六件**为 `MATH_INPUT_BUNDLE.json`、`RECEIPT.json`、`MATH_ROW_INDEX.jsonl`、`FX_HISTORY.jsonl`、`ADVANCE_HISTORY.jsonl`、`INPUT_AND_APPLY_HISTORY.jsonl`。不得虚构第七输出；取消后 advance 仍由原 D4 逻辑保留。

M1 消费合同的**输入七角色**为 `mechanical_index/public_rows/raw_capture/independent_plan/frame_plan/reset_edges/provenance`。旧 `mechanical_index rows[]` 与流式 `MATH_ROW_INDEX.jsonl`、reset 投影的消费者适配仍为 PENDING。因此 `FORMAL_REAL` 被明确拒绝；当前入口只能形成软件合成候选。

远端新增的 M1 R13 bounded consumer/independent semantics 已按提交 `86cd5975f5679ad2db9da7b0d20d2892e76e76b1` 和绑定提交 `7319fe670d3524252ac299e11f00d00ae52c9953` 收件；其 36 个声明原件可取，但仍是 L0 候选，本窗口未导入或执行。`CAP01=GENERATOR_BINDING_PENDING`，54 案、容量与数学均未验，因此它不会自动解除上述 FORMAL REAL/消费者兼容缺口。

## 已知限制与 W 状态

- 旧 D4 明文几何估算约 32 GiB，超过 24 GiB；本候选用生成即分卷避免多份明文并存，但最坏情况物理压缩上界尚未由 A2/实际资源收据证明。
- W01 当前必须保持 `RESOURCE_PROFILE_PENDING`/NO_GO，直至 32 GiB 起始空闲、8 GiB 结束保留、24 GiB 全工作区峰值、512 MiB worker/进程树峰值和所有 writer 覆盖均有证据。
- 历史 frozen owner 的 Job 累计 `total=2`，不能仅以根进程峰值证明无子进程/树峰值；`job_bridge.py` 会报告 PENDING，不会放宽成 PASS。
- frozen owner 未记录 `CloseHandle` 的原生 BOOL，因此句柄字段仅为历史 Python 状态，不升级为新的原生关闭证明。
- 旧链的 8 MiB 控制 JSON（包括可能增长的 intake ledger）、16 MiB metadata 和 64 MiB PE/source payload 可达边界仍须 P0/B/W 实际证明；本候选没有擅自抬限。
- 用户确认最终大卷可从 `code/output/.../DELIVERY/` 人工转发；Git 内 `<32 MiB` 的执行原件包只放索引和小原件，不能声称包含所有大卷。

## 文件职责

- `entry.py`：一次控制、staging、真实链、终检、原子发布。
- `binding.py`：私有命名空间中按 SHA 装载并接通真实 R12→D4。
- `stream_bridge.py`：同缓冲控制、≤1 MiB 身份读取。
- `volume_io.py`：无损可逆卷。
- `finalize.py`：六个 D4 数学输出、全产物身份和唯一完成屏障。
- `resources.py`：资源阈值/观测数据结构；W 严格证明仍待协调器收据。
- `run_plan.py`：纯 GO/NO_GO 算术，不消费、不启动。
- `job_bridge.py`：冻结 R12 owned_call 与 Windows Job 生命周期。
- `selftest.py`：P0/K8/V12/B12/W1/R worker 候选；测试结果尚不存在。

验证等级：**L0 静态候选，未运行**。只有协调器按批准的组别、额度、截止和冻结 SHA 执行后，才能产生软件级结果；任何结果都不是 HDL、FPGA、数学黄金、上板或发声验收。
