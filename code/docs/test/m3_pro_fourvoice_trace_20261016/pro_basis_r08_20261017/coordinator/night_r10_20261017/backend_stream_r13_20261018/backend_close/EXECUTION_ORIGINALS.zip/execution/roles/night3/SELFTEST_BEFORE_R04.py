"""Root-admitted R13 worker CLI; importing this file performs no work.

The coordinator supplies independently frozen controls for real-chain B/W
cases.  This worker never manufactures a D4 replacement or derives expected
content from actual output.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys
import traceback

import binding
import entry
import resources
from finalize import atomic_json
from stream_bridge import (CHUNK, Reject, identity, read_control,
                           parse_json, read_descriptor_json, require,
                           strict_child)
from volume_io import VolumeStore

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
OUTPUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
PLAN_SHA256 = "729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3"
GROUPS = {"P0": ["P001"],
          "K": [f"K{i:02d}" for i in range(1, 9)],
          "V": [f"V{i:02d}" for i in range(1, 13)],
          "B": [f"B{i:02d}" for i in range(1, 13)],
          "W": ["W01"]}
PINNED = {
    **{str(binding.R12 / name): sha for name, sha in binding.PINS.items()},
    str(binding.R12 / "selftest.py"):
        "5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c",
    str(ROOT / "code/software/t052_runner_acceptance_candidate_20261012/"
        "windows_job.py"):
        "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b",
}
CONTRACT_OBJECTS = {
    "FIELD_ROUTE_TABLE.json", "PROFILE_AND_CAPACITY.json",
    "PLAN_IDENTITY_MAP.json", "EPOCH_RESET_FINISH_CONTRACT.json",
    "SOURCE_PROVENANCE.json", "OPEN_DECISIONS.json",
    "M2_DECISION_SHEET.md", "README.md",
}
B08_SPEC = {
    "path": ROOT / "code/output/m3_backend_stream_r13_20261018/roles/"
                   "main4/B08_MINIMAL_FIXTURE_NOTE_R02.json",
    "bytes": 18457,
    "sha256": "f74e26b6d7351af164863c12be32d470b30332deb7be9e885aa28e43a7b389be",
}


def _manifest(path):
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False,
                               separators=(",", ":")) + "\n",
                    encoding="utf-8", newline="\n")


def _expect_reject(call, token):
    try:
        call()
    except BaseException as error:
        require(token in str(error), "WRONG_REJECT:" + str(error))
        return
    raise Reject("EXPECTED_REJECT_NOT_OBSERVED:" + token)


def _delivery_ready(value):
    require(value.get("delivery_channel_confirmed") is True,
            "DELIVERY_CHANNEL_NOT_CONFIRMED")
    delivery = value.get("delivery")
    require(type(delivery) is dict and
            type(delivery.get("location")) is str and delivery["location"] and
            type(delivery.get("retrieval_method")) is str and
            delivery["retrieval_method"] and
            delivery.get("all_logical_originals_recoverable") is True,
            "DELIVERY_CHANNEL_INCOMPLETE")


def _volume_case(case_id, root, admission):
    case = root / case_id
    case.mkdir()
    logical = case / "logical.jsonl"
    store = VolumeStore(case)
    if case_id == "V02":
        payload = b"a" * (CHUNK - 1) + "音".encode() + b"\n"
    elif case_id == "V03":
        payload = b"one\r\ntwo\nthree\r\n"
    else:
        payload = (b'{"row":1}\n' * 8192)
    with store.open(logical, "xb") as stream:
        offset = 0
        while offset < len(payload):
            block = payload[offset:offset + CHUNK]
            stream.write(block)
            offset += len(block)
    manifest_path = store.folder_for(logical) / "MANIFEST.json"
    manifest = _manifest(manifest_path)
    expected = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
    if case_id == "V04":
        (store.folder_for(logical) /
         manifest["parts"][0]["compressed"]["path"]).unlink()
    elif case_id == "V05":
        manifest["parts"].append(copy.deepcopy(manifest["parts"][0]))
        _save(manifest_path, manifest)
    elif case_id == "V06":
        manifest["parts"][0]["sequence"] = 1
        _save(manifest_path, manifest)
    elif case_id == "V07":
        manifest["parts"][0]["logical_offset"] = 1
        _save(manifest_path, manifest)
    elif case_id == "V08":
        manifest["parts"][0]["decoded_sha256"] = "0" * 64
        _save(manifest_path, manifest)
    elif case_id == "V09":
        manifest["original"]["sha256"] = "0" * 64
        _save(manifest_path, manifest)
    elif case_id == "V10":
        part = store.folder_for(logical) / manifest["parts"][0]["compressed"]["path"]
        with part.open("r+b") as stream:
            stream.truncate(max(0, part.stat().st_size - 1))
    if case_id in {"V04", "V05", "V06", "V07", "V08", "V09", "V10"}:
        fresh = VolumeStore(case)
        _expect_reject(lambda: _drain(fresh.open(logical, "rb")), "VOLUME_")
        return {"id": case_id, "status": "EXPECTED_REJECT"}
    actual = _drain(store.open(logical, "rb"))
    require(actual == payload, "VOLUME_NOT_LOSSLESS")
    if case_id == "V11":
        control = case / "control.json"
        control.write_bytes(b'{"decision":"original"}\n')
        first = read_control(control)
        control.write_bytes(b'{"decision":"changed"}\n')
        require(first["value"]["decision"] == "original" and
                read_control(control)["stamp"] != first["stamp"],
                "SAME_BUFFER_OR_MUTATION_GUARD")
    if case_id == "V12":
        invalid = copy.deepcopy(admission)
        invalid["delivery_channel_confirmed"] = False
        invalid.pop("delivery", None)
        _expect_reject(lambda: _delivery_ready(invalid),
                       "DELIVERY_CHANNEL_NOT_CONFIRMED")
    return {"id": case_id, "status": "PASS",
            "bytes": expected["bytes"], "sha256": expected["sha256"]}


def _drain(stream):
    blocks = []
    with stream:
        while True:
            block = stream.read(CHUNK)
            if not block:
                break
            require(len(block) <= CHUNK, "READ_REQUEST_BOUND")
            blocks.append(block)
    return b"".join(blocks)


def _contract_bundle(index_path, index_sha):
    record = read_control(index_path, index_sha)
    value = record["value"]
    require(value.get("schema") == "M3_R13_CONTRACT_INDEX_V1",
            "CONTRACT_INDEX_SCHEMA")
    objects = value.get("objects")
    require(type(objects) is list and len(objects) == len(CONTRACT_OBJECTS),
            "CONTRACT_OBJECT_COUNT")
    names, loaded = set(), {}
    for descriptor in objects:
        require(type(descriptor) is dict and
                set(descriptor) == {"path", "bytes", "sha256"},
                "CONTRACT_DESCRIPTOR")
        name = Path(descriptor["path"]).name
        require(name in CONTRACT_OBJECTS and name not in names,
                "CONTRACT_OBJECT_SET")
        names.add(name)
        path = (ROOT / descriptor["path"]).resolve()
        actual = identity(path)
        require(actual == {"bytes": descriptor["bytes"],
                           "sha256": descriptor["sha256"]},
                "CONTRACT_OBJECT_IDENTITY:" + name)
        if path.suffix == ".json":
            loaded[name] = read_control(path, descriptor["sha256"])["value"]
    require(names == CONTRACT_OBJECTS, "CONTRACT_OBJECT_SET")
    return value, loaded


def _k_cases(admission, wanted=None):
    cases = admission.get("contract_cases")
    wanted = set(GROUPS["K"] if wanted is None else wanted)
    require(type(cases) is list and
            {item.get("id") for item in cases} == wanted,
            "CONTRACT_CASE_SET")
    outcomes = []
    for item in sorted(cases, key=lambda value: value["id"]):
        case_id, expected = item["id"], item.get("expected")
        try:
            index, loaded = _contract_bundle(
                Path(item["contract_index"]), item["contract_index_sha256"])
            require(index.get("routes", {}).keys() >=
                    {"A1", "A2", "A3", "A4", "B", "C", "root"},
                    "CONTRACT_ROUTE_MISSING")
            if case_id == "K07":
                finish = loaded["EPOCH_RESET_FINISH_CONTRACT.json"]
                require(finish["real_finish_candidates_preserved"]
                        ["approved_finish_cycle"] is None,
                        "FINISH_UNEXPECTEDLY_APPROVED")
                actual = "FINISH_PENDING"
            elif case_id == "K08":
                provenance = loaded["SOURCE_PROVENANCE.json"]
                require(provenance.get("acceptance_boundary", {}).get(
                        "real_verified") is False,
                        "AUTHENTICITY_UNEXPECTEDLY_REAL")
                actual = "AUTHENTICITY_PENDING"
            else:
                actual = "PASS"
        except BaseException as error:
            actual = "REJECT:" + type(error).__name__ + ":" + str(error)
        require((expected == actual) or
                (type(expected) is str and expected.startswith("REJECT:") and
                 expected[7:] in actual),
                "K_CASE:" + case_id + ":" + actual)
        outcomes.append({"id": case_id, "status": actual,
                         "contract_index_sha256":
                             item["contract_index_sha256"]})
    return outcomes


def _p0_case():
    checked = []
    for raw_path, sha in sorted(PINNED.items()):
        path = Path(raw_path).resolve()
        actual = identity(path)
        require(actual["sha256"] == sha, "P0_PIN:" + str(path))
        checked.append({"path": str(path), **actual})
    require(Path(sys.executable).resolve().is_file(), "P0_PYTHON_MISSING")
    actual_d4 = (ROOT / "code/software/m3_pro_fourvoice_trace_20261016/"
                 "pro_basis_r08_20261017/coordinator/"
                 "task_day4_completion_20261017/chain.py")
    d4 = identity(actual_d4)
    require(d4 == {"bytes": 12667,
                   "sha256": "64bfdf4787aa9dd1ddab30a30ed7cf4fb05be763b9303ec965061005430f1c44"},
            "P0_ACTUAL_D4_PIN")
    disk = resources.preflight(OUTPUT, full_window=False)
    require(disk["decision"] == "GO", "P0_DISK_PREFLIGHT")
    return {"id": "P001", "status": "PASS_LOCAL_PINS",
            "pins": checked + [{"path": str(actual_d4), **d4}],
            "disk": disk,
            "parent_job_receipt_required": True}


def _actual_cases(group, admission, output, wanted_override=None):
    controls = admission.get("business_cases")
    require(type(controls) is list, "BUSINESS_CASES_REQUIRED")
    wanted = (["W01"] if group == "W" else [
        case for case in GROUPS["B"] if case not in {"B02", "B03", "B04"}])
    if wanted_override is not None:
        wanted = list(wanted_override)
    by_id = {item.get("id"): item for item in controls}
    require(set(by_id) == set(wanted), "BUSINESS_CASE_SET")
    require(len({item.get("control_sha256") for item in controls}) == len(controls),
            "BUSINESS_CONTROL_SHA_NOT_UNIQUE")
    require(len({str(Path(item.get("control", "")).resolve())
                 for item in controls}) == len(controls),
            "BUSINESS_CONTROL_PATH_NOT_UNIQUE")
    outcomes = []
    for case_id in wanted:
        item = by_id[case_id]
        case_out = output / "cases" / case_id
        expected = item["expected"]
        try:
            entry.run(Path(item["control"]), item["control_sha256"], case_out)
            actual = "PASS"
        except BaseException as error:
            actual = "REJECT:" + type(error).__name__ + ":" + str(error)
        require((expected == "PASS" and actual == "PASS") or
                (expected.startswith("REJECT:") and expected[7:] in actual),
                "BUSINESS_EXPECTATION:" + case_id + ":" + actual)
        post = item.get("postcondition")
        require(type(post) is dict, "BUSINESS_POSTCONDITION:" + case_id)
        complete_path = case_out / "COMPLETE.json"
        failure_path = case_out / "R13_FAILURE.json"
        if expected == "PASS":
            require(complete_path.is_file() and not failure_path.exists(),
                    "BUSINESS_COMPLETE_MARKER:" + case_id)
            complete = read_control(complete_path)["value"]
            require(complete.get("status") == "COMPLETE_SOFTWARE_ONLY" and
                    complete.get("audit", {}).get("status") ==
                    "SOFTWARE_CHAIN_COMPLETE_PENDING_AUTHORITY",
                    "BUSINESS_COMPLETE_CONTENT:" + case_id)
            _check_success_postcondition(case_id, case_out, complete, post)
        else:
            require(not complete_path.exists() and failure_path.is_file() and
                    not (case_out / "COMPLETE.pending.json").exists(),
                    "BUSINESS_FAILURE_BARRIER:" + case_id)
            failure = read_control(failure_path)["value"]
            require(failure.get("completion_written") is False and
                    expected[7:] in failure.get("error", ""),
                    "BUSINESS_FAILURE_RECEIPT:" + case_id)
        outcomes.append({"id": case_id, "status": "PASS",
                         "observed": actual,
                         "control_sha256": item["control_sha256"]})
    if group == "B" and wanted_override is None:
        outcomes += [{"id": case, "status": "DEFERRED_TO_PARENT_JOB_RECEIPT"}
                     for case in ("B02", "B03", "B04")]
    return sorted(outcomes, key=lambda item: item["id"])


def _artifact(complete, role):
    artifacts = complete["audit"]["artifacts"]
    require(role in artifacts, "POST_ARTIFACT_ROLE:" + role)
    return artifacts[role]


def _artifact_stream(case_out, artifact):
    path = case_out / artifact["path"]
    store = VolumeStore(case_out)
    return (store.open(path, "rb", {"bytes": artifact["bytes"],
                                    "sha256": artifact["sha256"]})
            if artifact["storage"] == "VOLUME" else
            path.open("rb", buffering=0))


def _logical_records(case_out, artifact):
    records = []
    stream = _artifact_stream(case_out, artifact)
    with stream:
        while True:
            line = stream.readline(CHUNK)
            if not line:
                break
            require(line.endswith(b"\n"), "POST_JSONL_TRUNCATED")
            records.append(parse_json(line))
    return records


def _contains_subset(value, expected):
    if isinstance(expected, dict):
        return (isinstance(value, dict) and
                all(key in value and _contains_subset(value[key], item)
                    for key, item in expected.items()))
    if isinstance(expected, list):
        return value == expected
    return value == expected


def _somewhere(value, expected):
    if _contains_subset(value, expected):
        return True
    if isinstance(value, dict):
        return any(_somewhere(item, expected) for item in value.values())
    if isinstance(value, list):
        return any(_somewhere(item, expected) for item in value)
    return False


def _artifact_values(case_out, artifact):
    if artifact["path"].endswith(".jsonl"):
        return _logical_records(case_out, artifact)
    require(artifact["path"].endswith(".json") and
            artifact["storage"] == "PLAIN",
            "POST_EXPECTED_JSON_ARTIFACT")
    path = case_out / artifact["path"]
    return read_control(path, artifact["sha256"])["value"]


def _check_success_postcondition(case_id, case_out, complete, post):
    terminal = complete["audit"]["terminal"]
    minimum_rows = post.get("minimum_rows")
    require(type(minimum_rows) is int and terminal["rows"] >= minimum_rows,
            "POST_MINIMUM_ROWS:" + case_id)
    if case_id == "B07":
        expected = post.get("artifact_identities")
        require(type(expected) is dict and
                set(expected) == {"public_rows", "public_csv", "csv_roundtrip"},
                "B07_EXPECTED_IDENTITIES")
        for role, stamp in expected.items():
            actual = _artifact(complete, role)
            require({key: actual[key] for key in ("bytes", "sha256")} == stamp,
                    "B07_IDENTITY:" + role)
    elif case_id == "B08":
        require(identity(B08_SPEC["path"]) == {
                    "bytes": B08_SPEC["bytes"],
                    "sha256": B08_SPEC["sha256"]},
                "B08_STATIC_SPEC_IDENTITY")
        require(post.get("fixture_spec") == {
                    "path": str(B08_SPEC["path"]),
                    "bytes": B08_SPEC["bytes"],
                    "sha256": B08_SPEC["sha256"]},
                "B08_ADMISSION_SPEC_BINDING")
        require(terminal == {"rows": 837, "finish_count": 1,
                             "last_cycle": 836,
                             "monitor_end_count": 1},
                "B08_TERMINAL_837")
        public_role = post.get("public_role")
        public = _artifact(complete, public_role)
        require({key: public[key] for key in ("bytes", "sha256")} ==
                post.get("public_identity"), "B08_PUBLIC_IDENTITY")
        public_rows = _logical_records(case_out, public)
        require(len(public_rows) == 837 and
                all(isinstance(row.get("fields"), dict) and
                    len(row["fields"]) == 74 and
                    isinstance(row.get("raw_ports"), dict) and
                    len(row["raw_ports"]) == 72
                    for row in public_rows),
                "B08_PUBLIC_837_74_72")
        require(sum(row["fields"].get("frame_tick") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("req_valid") == 1 and
                    row["fields"].get("req_ready") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("cancel") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("finish") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("advance_mask", 0) != 0
                    for row in public_rows) == 1,
                "B08_PUBLIC_EVENT_COUNTS")
        require(_contains_subset(public_rows[833]["fields"], {
                    "cycle": 833, "frame_tick": 1, "finish": 0}) and
                _contains_subset(public_rows[834]["fields"], {
                    "cycle": 834, "req_valid": 1, "req_ready": 1,
                    "req_id": 42, "advance_mask": 15,
                    "advance_frame_req_id": 42, "cancel": 0,
                    "finish": 0}) and
                _contains_subset(public_rows[835]["fields"], {
                    "cycle": 835, "cancel": 1,
                    "cancel_reason": 0, "advance_mask": 0,
                    "finish": 0}) and
                _contains_subset(public_rows[836]["fields"], {
                    "cycle": 836, "finish": 1}),
                "B08_PUBLIC_CYCLE_SEQUENCE")
        role = post.get("advance_role")
        advance = _artifact(complete, role)
        require({key: advance[key] for key in ("bytes", "sha256")} ==
                post.get("advance_identity"), "B08_ADVANCE_IDENTITY")
        advance_rows = _logical_records(case_out, advance)
        require(len(advance_rows) == 1 and _contains_subset(
            advance_rows[0], {
                "source": {"line": 835, "cycle": 834, "epoch": 0,
                           "time_ps": 20875000,
                           "sampling_phase": "POSEDGE_PRE_NBA"},
                "advance": {"raw_mask": 15, "all_four_lanes": True,
                            "status": "ALL_FOUR_LANES"},
                "request_tag": 42, "req_id": 42,
                "commit_observed_same_row": 0, "cancel_raw": 0,
                "retained_even_if_unpublished_or_cancelled": True}),
                "B08_EXACT_ADVANCE_HISTORY")
        cancel_role = post.get("cancel_evidence_role")
        cancel = _artifact(complete, cancel_role)
        require({key: cancel[key] for key in ("bytes", "sha256")} ==
                post.get("cancel_evidence_identity"),
                "B08_CANCEL_EVIDENCE_IDENTITY")
        cancel_values = _artifact_values(case_out, cancel)
        require(_somewhere(cancel_values, {
                    "cycle": 835, "source_line": 836,
                    "raw_cancel_reason": 0,
                    "business_cancel_derived": False}) and
                _somewhere(cancel_values, {"business_cancels": []}),
                "B08_INTAKE_CANCEL_RETENTION")
        serial_role = post.get("serial_role")
        serial = _artifact(complete, serial_role)
        require({key: serial[key] for key in ("bytes", "sha256")} ==
                post.get("serial_identity"), "B08_SERIAL_IDENTITY")
        serial_values = _artifact_values(case_out, serial)
        require(_somewhere(serial_values, {
                    "source_line": 836, "cycle": 835, "epoch": 0,
                    "time_ps": 20900000, "kind": "CANCEL",
                    "raw_reason": 0,
                    "entry": {"epoch": 0, "id": 42, "F": 833,
                              "V": 834, "A": 834,
                              "request_cycle": 834,
                              "accept_source_line": 835}}),
                "B08_SERIAL_CANCEL")
        require(_somewhere(serial_values, {
                    "counts": {"rows": 837, "FRAME_F": 1,
                               "accepted": 1, "result": 0,
                               "commit": 0}}),
                "B08_SERIAL_COUNTS")
        frame_role = post.get("frame_plan_role")
        frame = _artifact(complete, frame_role)
        require({key: frame[key] for key in ("bytes", "sha256")} ==
                post.get("frame_plan_identity"), "B08_FRAME_PLAN_IDENTITY")
        require(_somewhere(_artifact_values(case_out, frame), {
                    "epoch": 0, "cycles": [833],
                    "release_cycle": 0, "stop_cycle": 836,
                    "window_kind": "ACTIVE"}) and
                _somewhere(_artifact_values(case_out, frame),
                           {"finish": {"epoch": 0, "cycle": 836}}),
                "B08_FRAME_PLAN")
    elif case_id == "B10":
        require(terminal == post.get("terminal"), "B10_TERMINAL_SOURCE")
    elif case_id == "B11":
        inventory = complete["audit"]["workspace_inventory"]
        for key in ("physical_bytes", "logical_bytes"):
            minimum = post.get("minimum_" + key)
            require(type(minimum) is int and inventory[key] >= minimum,
                    "B11_RESOURCE_ACCOUNT:" + key)
        require(post.get("parent_process_tree_receipt_required") is True,
                "B11_PARENT_RESOURCE_RECEIPT")
    elif case_id == "W01":
        require(terminal["rows"] >= 1130662,
                "W01_FULL_WINDOW_ROWS")
        raw_role = post.get("raw_role")
        require(_artifact(complete, raw_role)["bytes"] >= 1398627657,
                "W01_FULL_WINDOW_RAW_BYTES")



# Root-adopted W binder. All generated input work remains inside W.
"""R03 static candidate: root-owned W input binding, never a launcher.

No module import has been performed for validation. Merge the selected helpers
into the existing C selftest only after root self-audit. All actual file IO is
injected; no timer, tool, subprocess, Git or target algorithm runs here.
"""

import copy
from datetime import datetime
import hashlib
import io as binary_io
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

CHUNK = 1 << 20
MAX_CONTROL = 8 * CHUNK
MIN_ROWS = 1_130_662
MIN_RAW_BYTES = 1_398_627_657
RAW_MAX = 4_631_191_552
PHASE_STEP = 659_706_977
RAW_SCHEMA = "M3_R7A_C9_RAW_CORE_ROW_V1"
PORT_MAP_SHA = "65a4fcca8b83ab72eaed3aaf5bf7cd48db18ad0691027aaaf57d1e9e4ced0807"
EXPECTED_BUDGETS = {"all_stores": 8 << 30, "delivery": 8 << 30,
                    "raw_plain": RAW_MAX, "all_other": 3_958_743_040}
PIN_SHA = {
    "recipe": "2e880fc06e4a34d1c62d7f409193d909f3999257464e62c362e21acf601961d4",
    "seed": "2188b80bbe4561c44a1728fabc50dbb0bd9b6101582700799d537f0443631882",
    "port_map": PORT_MAP_SHA,
    "application": "d49c15e629a700b929c67f8ec0de2e18eb323cfba1866175e3d82eb016107f08",
    "request": "977f31e7157aa2141da9e6402142a78ed886dfeadeb40949043335e12c276b77",
    "graph": "3f293f01cb31bdb82f64526e7b5d295a1fb87ed86225ca4824b4a21392c8b959",
    "r12_dependencies": "73525eaa939c0b9627e42d9e763d93e206028102d8e7fed07350a493a8aac731",
    "module_bindings": "dc66002f2a14017ae7abb439ea683b9b2dc1dfca18a35c6b07b43e6a37d661f8",
    "midi_plan": "35a723e210a2cce83bdb5b346855beb0fca3fe3a5c806c247cdd8ffc8bc0a59a",
}


class BinderPending(ValueError):
    pass


def need(ok, reason):
    if not ok:
        raise BinderPending("W_INPUT_BINDER_PENDING:" + reason)


def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def document(raw):
    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                      parse_constant=lambda _: need(False, "NONFINITE_JSON"))


class BinderIO:
    """Hooks must enforce global writer limits and no aliases, including ZIP.

    open_file(path,mode,*,budget,category) -> seekable binary context manager.
    save_bytes(path,body,*,budget,category,exclusive) -> descriptor.
    copy_file(source,target,*,budget,category,exclusive) -> descriptor.
    mkdir(path,*,budget,exclusive) -> None.
    Categories raw_plain/all_other debit the root's existing shared allocation.
    Hook checks happen on every physical operation; wrappers add <=1MiB calls.
    """
    def __init__(self, root, output, budget, open_file, save_bytes, copy_file, mkdir):
        self.root, self.output = Path(root).resolve(), Path(output).resolve()
        self.budget, self.open_file = budget, open_file
        self.save_bytes, self.copy_file, self.mkdir_hook = save_bytes, copy_file, mkdir
        scope = self.root / "code/output/m3_backend_stream_r13_20261018"
        need(self.output != scope and self.output.is_relative_to(scope), "OUTPUT_SCOPE")
        need(all(callable(x) for x in (open_file, save_bytes, copy_file, mkdir)),
             "ALL_IO_HOOKS_REQUIRED")

    def path(self, descriptor):
        need(type(descriptor) is dict and set(descriptor) == {"path", "bytes", "sha256"},
             "DESCRIPTOR_FIELDS")
        need(type(descriptor["bytes"]) is int and descriptor["bytes"] >= 0
             and isinstance(descriptor["sha256"], str)
             and re.fullmatch("[0-9a-f]{64}", descriptor["sha256"]), "DESCRIPTOR_IDENTITY")
        path = Path(descriptor["path"])
        return (path if path.is_absolute() else self.root / path).resolve()

    def ref(self, path, count, digest):
        path = Path(path).resolve()
        return {"path": path.relative_to(self.root).as_posix()
                if path.is_relative_to(self.root) else str(path),
                "bytes": count, "sha256": digest}

    def identify(self, path, limit):
        digest, count = hashlib.sha256(), 0
        self.budget.check()
        with self.open_file(Path(path), "rb", budget=self.budget,
                            category="all_other") as stream:
            while True:
                self.budget.check()
                block = stream.read(CHUNK)
                if not block:
                    break
                count += len(block)
                need(len(block) <= CHUNK and count <= limit, "IDENTITY_BYTE_BOUND")
                digest.update(block)
        self.budget.check()
        return self.ref(path, count, digest.hexdigest())

    def verified(self, ref):
        actual = self.identify(self.path(ref), ref["bytes"])
        need(actual["bytes"] == ref["bytes"] and actual["sha256"] == ref["sha256"],
             "FROZEN_FILE_CHANGED:" + ref["path"])
        return actual

    def read_reference(self, ref):
        self.path(ref)
        need(ref["bytes"] <= MAX_CONTROL, "CONTROL_BOUND")
        digest, body = hashlib.sha256(), bytearray()
        with self.open_file(self.path(ref), "rb", budget=self.budget,
                            category="all_other") as stream:
            while True:
                self.budget.check()
                block = stream.read(CHUNK)
                if not block:
                    break
                body.extend(block)
                need(len(block) <= CHUNK and len(body) <= ref["bytes"], "CONTROL_BOUND")
                digest.update(block)
        need(len(body) == ref["bytes"] and digest.hexdigest() == ref["sha256"],
             "CONTROL_IDENTITY")
        self.budget.check()
        return bytes(body)

    def save(self, name, body):
        path = (self.output / name).resolve()
        need(path != self.output and path.is_relative_to(self.output), "SAVE_SCOPE")
        need(isinstance(body, bytes) and len(body) <= MAX_CONTROL, "SAVE_CONTROL_BOUND")
        self.budget.check()
        result = self.save_bytes(path, body, budget=self.budget,
                                 category="all_other", exclusive=True)
        need(result == self.ref(path, len(body), hashlib.sha256(body).hexdigest()),
             "SAVE_HOOK_DESCRIPTOR")
        self.verified(result)
        return result

    def save_json(self, name, value):
        return self.save(name, encoded(value))

    def copy(self, ref, name):
        source = self.path(ref)
        self.verified(ref)
        target = (self.output / name).resolve()
        need(target != self.output and target.is_relative_to(self.output), "COPY_SCOPE")
        result = self.copy_file(source, target, budget=self.budget,
                                category="all_other", exclusive=True)
        need(result == self.ref(target, ref["bytes"], ref["sha256"]), "COPY_HOOK_DESCRIPTOR")
        self.verified(result)
        return result


class _ZipIO:
    """Only bounded ZIP archive IO, never a target/facade monkeypatch."""
    def __init__(self, stream, budget):
        self.stream, self.budget = stream, budget

    def read(self, size=-1):
        if size is None or size < 0:
            here = self.tell()
            end = self.seek(0, 2)
            self.seek(here)
            size = end - here
        need(type(size) is int and 0 <= size <= 64 * CHUNK, "ZIP_READ_BOUND")
        parts, remaining = [], size
        while remaining:
            self.budget.check()
            block = self.stream.read(min(CHUNK, remaining))
            need(len(block) <= min(CHUNK, remaining), "ZIP_READ_CHUNK")
            if not block:
                break
            parts.append(block)
            remaining -= len(block)
        self.budget.check()
        return b"".join(parts)

    def write(self, body):
        view, offset = memoryview(body).cast("B"), 0
        while offset < len(view):
            self.budget.check()
            chunk = view[offset:offset + CHUNK]
            need(self.stream.write(chunk) == len(chunk), "ZIP_SHORT_WRITE")
            offset += len(chunk)
        self.budget.check()
        return len(view)

    def seek(self, offset, whence=0):
        self.budget.check()
        result = self.stream.seek(offset, whence)
        self.budget.check()
        return result

    def tell(self):
        self.budget.check()
        return self.stream.tell()

    def flush(self):
        self.stream.flush()
        self.budget.check()

    def seekable(self):
        return True


class _PlainRawSink:
    def __init__(self, io):
        self.io, self.path = io, io.output / "RAW.jsonl"
        self.manager = io.open_file(self.path, "xb", budget=io.budget, category="raw_plain")
        self.stream = self.manager.__enter__()
        self.digest, self.count, self.closed = hashlib.sha256(), 0, False

    def write(self, line):
        need(not self.closed and isinstance(line, bytes) and 0 < len(line) <= 4096
             and line.endswith(b"\n"), "RAW_LINE_BOUND")
        need(self.count + len(line) <= RAW_MAX, "RAW_TOTAL_BOUND")
        self.io.budget.check()
        need(self.stream.write(line) == len(line), "RAW_SHORT_WRITE")
        self.digest.update(line)
        self.count += len(line)
        self.io.budget.check()
        return len(line)

    def finish(self):
        need(not self.closed, "RAW_CLOSED")
        self.manager.__exit__(None, None, None)
        self.closed = True
        expected = self.io.ref(self.path, self.count, self.digest.hexdigest())
        self.io.verified(expected)
        self.io.budget.check()
        return expected

    def abort(self):
        if not self.closed:
            self.closed = True
            self.manager.__exit__(None, None, None)
        # No delete, drain or finish marker. Preserve all partial bytes.


def frame_cycle(k):
    # Input synthesis uses the frozen independent formula. It does not write
    # UNIQUE_FRAME_PLAN, FRAME_PLAN or TX_FRAME_PLAN. Real producer stays D4's.
    return (128 * k * (1 << 32) + PHASE_STEP - 1) // PHASE_STEP - 1


def produce_inputs(recipe_ref, seed_ref, port_map_ref, *,
                   sink_factory, put_control, budget, read_reference):
    """Storage-only hooks: sink_factory(role) and put_control(name, raw_bytes).

    Returned logical raw must be resolved byte-for-byte by the C IO adapter.
    Every generated byte, compression, hash and subsequent D4 work uses the SAME
    caller-owned 900-second Budget. This function never starts a fresh timer.
    """
    budget.check()
    recipe = json.loads(read_reference(recipe_ref).decode("utf-8"),
                        object_pairs_hook=pairs)
    need(recipe["schema"] == "M3_R13_SYNTHETIC_WINDOW_RECIPE_V1", "RECIPE_SCHEMA")
    need(recipe["origin"] == "SYNTHETIC_SCHEMA_FIXTURE", "SYNTHETIC_ONLY")
    rows = recipe["rows"]
    need(type(rows) is int and MIN_ROWS <= rows <= MIN_ROWS, "EXACT_ADMITTED_ROWS")
    need(recipe["first_core_ps"] == 25000
         and recipe["core_period_ps"] == 25000, "FROZEN_TIMEBASE")
    capture_id, stop_id = recipe["capture_id"], recipe["plan_stop_id"]
    for value in (capture_id, stop_id):
        need(isinstance(value, str) and re.fullmatch("[A-Za-z0-9_-]{1,32}", value),
             "SAFE_BOUNDED_ID")
    need(recipe["profile"] == "ACTIVE_FRAME_SPARSE_DIAGNOSTICS_NO_REAL_CLAIM",
         "EXPLICIT_SYNTHETIC_PROFILE")
    seed_lines = read_reference(seed_ref).splitlines()
    need(len(seed_lines) == 7, "ARCHIVED_SEVEN_ROW_SEED_REQUIRED")
    seed = json.loads(seed_lines[0].decode("utf-8"), object_pairs_hook=pairs)
    need(seed["schema"] == RAW_SCHEMA, "SEED_RAW_SCHEMA")
    need(port_map_ref["sha256"] == PORT_MAP_SHA, "PINNED_PUBLIC_PORT_MAP_REQUIRED")
    port_map = json.loads(read_reference(port_map_ref).decode("utf-8"),
                          object_pairs_hook=pairs)
    declarations = port_map["raw_ports"]
    need(len(declarations) == 72 and set(seed["ports"]) == set(declarations),
         "PRESERVE_ALL_72_RAW_PORTS")
    ports = dict(seed["ports"])
    for name, declaration in declarations.items():
        width = declaration["width"]
        need(type(width) is int and len(ports[name]) == width
             and re.fullmatch("[01]+", ports[name]), "KNOWN_SEED_WIDTH:" + name)
    # Known nonzero, explicitly synthetic values. No observed PCM is a golden.
    # Idle ready/UART and held payload are retained as raw values, not accepts.
    ports.update(obs_event_ready="1", obs_req_ready="1", uart_tx="1")
    ports["obs_apply_data"] = format(0x0011223344556677, "064b")
    ports["obs_advance_frame_req_id"] = format(42, "032b")

    def variant(frame, phase):
        values = dict(ports)
        values["obs_frame_tick"] = str(int(frame))
        values["obs_cancel"] = str(int(frame))
        values["obs_raw_cancel_reason"] = "01" if frame else "00"
        if phase == 1:
            values.update(obs_effect_input_valid="1", obs_effect_input_ready="1",
                          obs_effect_input_left=format(2048, "024b"),
                          obs_effect_input_right=format((1 << 24) - 1024, "024b"),
                          obs_effect_input_clip_mask="01",
                          obs_upstream_clip_mask="01", obs_effect_clip_mask="10",
                          obs_feedback_clip_mask="00")
        elif phase == 2:
            # Autonomous release observation: invalid cause, not a MIDI event.
            values.update(obs_apply_valid="1", obs_apply_kind="0011",
                          obs_apply_mask="0001", obs_apply_data="0" * 64,
                          obs_router_apply_seq="0" * 32,
                          obs_router_apply_seq_valid="0")
        elif phase == 3:
            payload = (1 << 61) | (31 << 45) | (16384 << 30) | (8192 << 15) | 4096
            values.update(obs_config_take="1", obs_config_valid="1",
                          obs_config_ready="1",
                          obs_config_payload=format(payload, "062b"))
        return json.dumps(values, separators=(",", ":"), sort_keys=True).encode("ascii")

    variants = {(False, 0): variant(False, 0),
                (True, 0): variant(True, 0)}
    for phase in (1, 2, 3):
        variants[(False, phase)] = variant(False, phase)
    # Freeze scenario/window inputs BEFORE emitting the observation stream.
    scenario = {"schema": "M3_R13_INDEPENDENT_SYNTHETIC_SCENARIO_V1",
                "recipe": recipe_ref, "seed": seed_ref, "port_map": port_map_ref,
                "row_count": rows, "finish_cycle": rows - 1,
                "frame_formula": "ceil(128*k*2**32/659706977)-1; k>=1",
                "source": "declared deterministic software input, never HDL",
                "sparse_phases_after_each_F": {"1": "FX_OBSERVATION",
                                             "2": "INVALID_CAUSE_RELEASE",
                                             "3": "CONFIG_TAKE"},
                "coverage_debt": ["no request/result/commit/TX transaction",
                                  "serial pins remain idle, serial is PARTIAL",
                                  "no valid independent apply mapping or golden"],
                "real_verified": False, "math_verified": False}
    scenario_ref = put_control("INDEPENDENT_SCENARIO.json", encoded(scenario))
    finish_time = rows * 25000
    frame_input = {"schema": "M3_R06_FRAME_PLAN_GENERATOR_INPUT_V1",
                   "status": "FROZEN_INDEPENDENT_INPUT",
                   "independent_of_observed_trace": True,
                   "source_identities": [
                       {"path": scenario_ref["path"], "sha256": scenario_ref["sha256"]},
                       {"path": recipe["base_source"]["path"],
                        "sha256": recipe["base_source"]["sha256"]}],
                   "epochs": [{"epoch": 0, "reset_assert_cycle": 0,
                               "release_cycle": 0, "stop_cycle": rows - 1,
                               "window_kind": "ACTIVE"}],
                   "finish": {"epoch": 0, "cycle": rows - 1}}
    controls = {
        "frame_input": ("FRAME_INPUT.json", encoded(frame_input)),
        "window_plan": ("WINDOW.json", encoded({
            "schema": "M3_R7D_INDEPENDENT_WINDOW_V1", "capture_id": capture_id,
            "plan_stop_id": stop_id, "input_plan_sha256": recipe["midi_plan"]["sha256"],
            "first_core_ps": 25000, "core_period_ps": 25000,
            "row_count": rows, "finish_cycle": rows - 1,
            "finish_time_ps": finish_time,
            "window_parameters": {"CAPTURE_ID": capture_id, "PLAN_STOP_ID": stop_id,
                "STOP_DRIVER_CYCLE": rows - 2,
                "EXPECTED_FINISH_CORE_CYCLE": rows - 1,
                "MAX_CORE_SAMPLES": rows + 16,
                "MAX_SIM_TIME_PS": finish_time + 1_000_000}})),
        "end": ("END.json", encoded({
            "schema": "M3_R7A_END_V1", "capture_id": capture_id,
            "plan_stop_id": stop_id, "finish_cycle": rows - 1,
            "time_ps": finish_time, "row_count": rows, "reason": "PLANNED_WINDOW_END",
            "ledger_status": "NOT_CHECKED_R6_5_REQUIRED",
            "serial_tail_status": "UNKNOWN_R6_6_REQUIRED"})),
        "stdout": ("STDOUT.txt", (
            f"MONITOR_END capture_id={capture_id} cycle={rows - 1} "
            f"time_ps={finish_time} rows={rows} reason=PLANNED_WINDOW_END\n").encode()),
        "resets": ("RESET_EDGES.jsonl", b"".join(encoded({
            "schema": "M3_R7A_RESET_SNAPSHOT_V1", "capture_id": capture_id,
            "kind": kind, "time_ps": at, "edge_seq": seq,
            "values": {"obs_pll_locked": bit, "sys_rst_n": bit, "obs_rst_n": bit}})
            for seq, kind, at, bit in ((1, "INITIAL", 0, "0"),
                                      (2, "CHANGE", 10000, "1"))))}
    refs = {role: put_control(name, raw) for role, (name, raw) in controls.items()}
    raw_sink = sink_factory("raw_capture")
    k, upcoming, previous_frame = 1, frame_cycle(1), -100
    decoded_bytes = 0
    try:
        for cycle in range(rows):
            budget.check()
            is_frame = cycle == upcoming
            if is_frame:
                previous_frame = cycle
                k += 1
                upcoming = frame_cycle(k)
            phase = cycle - previous_frame
            phase = phase if phase in (1, 2, 3) else 0
            port_bytes = variants[(is_frame, phase)]
            prefix = (f'{{"schema":"{RAW_SCHEMA}","capture_id":"{capture_id}",'
                      f'"source_line":{cycle + 1},"cycle":{cycle},'
                      f'"time_ps":{(cycle + 1) * 25000},"epoch":null,'
                      '"epoch_reason":"BIND_FROM_INDEPENDENT_RESET_EDGES",'
                      f'"finish":{int(cycle == rows - 1)},"ports":').encode("ascii")
            line = prefix + port_bytes + b"}\n"
            need(len(line) <= 4096, "ADMITTED_RAW_LINE_GEOMETRY")
            need(raw_sink.write(line) == len(line), "RAW_SHORT_WRITE")
            decoded_bytes += len(line)
        need(decoded_bytes >= MIN_RAW_BYTES, "RAW_MINIMUM_NOT_REACHED")
        refs["raw_logical"] = raw_sink.finish()
    except BaseException as primary:
        # Preserve the active error even if closing a partial writer also fails.
        try:
            raw_sink.abort()
        except BaseException as cleanup:
            primary.add_note("RAW_ABORT_FAILED:" + type(cleanup).__name__ + ":" + str(cleanup))
        raise
    budget.check()
    return {"schema": "M3_R13_INPUT_CANDIDATE_V1",
            "status": "SYNTHETIC_INPUTS_ONLY_D4_NOT_CALLED",
            "refs": refs, "scenario": scenario_ref, "rows": rows,
            "raw_decoded_bytes": decoded_bytes,
            "requires_actual_D4": True,
            "W_admission": "NOT_GRANTED_BY_INPUT_BINDER",
            "integration_gaps": [
                "C storage Path/identity facade must read raw logical volume exactly",
                "bind new application_request window_parameters to WINDOW",
                "bind real source/ROM/tool closure plus midi plan and frame rules",
                "do not reuse seven-row execution receipt, row hashes or EXPECTED",
                "new synthetic receipt must remain declared, never trusted HDL",
                "B must validate actual D4 profile and record expected PARTIAL semantics",
                "all D4 outputs and comparisons must execute; no D4 replacement"],
            "real_verified": False, "math_verified": False,
            "board_release_allowed": False}



def _archive_member(archive, info, budget):
    need(info.file_size <= 16 * CHUNK, "ZIP_MEMBER_BOUND")
    body = bytearray()
    with archive.open(info, "r") as stream:
        while True:
            budget.check()
            block = stream.read(CHUNK)
            if not block:
                break
            body.extend(block)
            need(len(block) <= CHUNK and len(body) <= info.file_size, "ZIP_MEMBER_BOUND")
    need(len(body) == info.file_size, "ZIP_MEMBER_SIZE")
    return bytes(body)


def _replace_four_stimuli(io, application, graph, bodies):
    old_zip_ref = application["source"]["application"]
    original_bytes = io.read_reference(old_zip_ref)
    nodes = {item["path"]: item for item in graph["nodes"]}
    roms = {item["path"]: item for item in graph["ROM_payloads"]}
    need(len(graph["units"]) == len(set(graph["units"])) == 75
         and len(nodes) == 77 and set(graph["units"]) <= nodes.keys()
         and len(roms) == 9, "FROZEN_75_SOURCE_9_ROM_GRAPH")
    replacements = {"inputs/" + name: body for name, body in bodies.items()}
    new_path = io.output / "SOURCE_APPLICATION_SYNTHETIC_W_R03.zip"
    unchanged, replaced, rom_copies = [], [], []
    seen, node_seen, rom_seen = set(), set(), set()
    with zipfile.ZipFile(_ZipIO(binary_io.BytesIO(original_bytes), io.budget)) as original:
        members = original.infolist()
        need(len(members) <= 256 and sum(x.file_size for x in members) <= 64 * CHUNK,
             "SOURCE_ARCHIVE_BOUND")
        with io.open_file(new_path, "xb", budget=io.budget, category="all_other") as raw:
            with zipfile.ZipFile(_ZipIO(raw, io.budget), "w", compression=zipfile.ZIP_DEFLATED) as successor:
                for info in members:
                    io.budget.check()
                    name, posix = info.filename, PurePosixPath(info.filename)
                    need(not posix.is_absolute() and ".." not in posix.parts
                         and "\\" not in name and ":" not in name
                         and len(name.encode("utf-8")) <= 512
                         and all(p.rstrip(" .") == p for p in posix.parts)
                         and (posix.as_posix() == name or info.is_dir()), "ZIP_PATH")
                    need(name.casefold() not in seen
                         and (info.external_attr >> 16) & 0o170000 != 0o120000,
                         "ZIP_DUPLICATE_OR_ALIAS")
                    seen.add(name.casefold())
                    body = _archive_member(original, info, io.budget)
                    if name in replacements:
                        body = replacements[name]
                        replaced.append(name)
                    else:
                        unchanged.append({"member": name, "bytes": len(body),
                                          "sha256": hashlib.sha256(body).hexdigest()})
                    if name.startswith("inputs/"):
                        relative = name[7:]
                        expected = nodes.get(relative, roms.get(relative))
                        if expected is not None:
                            need(len(body) == expected["bytes"] and
                                 hashlib.sha256(body).hexdigest() == expected["sha256"],
                                 "FROZEN_SOURCE_OR_ROM_CHANGED:" + relative)
                        if relative in nodes:
                            node_seen.add(relative)
                        if relative in roms:
                            rom_seen.add(relative)
                            rom_copies.append(io.save("rom_originals/" + relative, body))
                    successor.writestr(copy.copy(info), body)
                    io.budget.check()
    need(set(replaced) == set(replacements) and len(replaced) == 4
         and node_seen == set(nodes) and rom_seen == set(roms), "ZIP_EXACT_REPLACEMENT_OR_GRAPH")
    # Changed archive identity is measured after its writer closes. Original
    # untouched member bytes are preserved; compression bytes need not match.
    new_ref = io.identify(new_path, 64 * CHUNK)
    io.verified(old_zip_ref)
    return new_ref, rom_copies, unchanged, sorted(replaced)


def _declared_roles(request, application):
    inputs = request["inputs"]
    result = {key: inputs[key] for key in ("source_manifest", "rom_manifest", "tool_manifest")}
    for name, role in (("input_plan", "midi_plan"), ("window_plan", "window_plan"),
                       ("raw_stdout", "stdout"), ("raw_stderr", "stderr"),
                       ("raw_trace", "raw"), ("reset_edges", "resets"),
                       ("finish_receipt", "end")):
        result[name] = inputs[role]
    result["driver"] = application["source"]["capture_sources"]["DRIVER"]
    result["observer"] = application["source"]["capture_sources"]["OBSERVER"]
    return result


def _context(value):
    need(type(value) is dict and set(value) == {"pid", "utc"}
         and type(value["pid"]) is int and value["pid"] > 0, "ACTUAL_BUILDER_CONTEXT")
    moment = datetime.fromisoformat(value["utc"])
    need(moment.utcoffset() is not None, "ACTUAL_BUILDER_TIMEZONE")
    return moment


def bind_w_inputs(freeze_ref, *, root, output, budget, open_file,
                  save_bytes, copy_file, mkdir, builder_context):
    """Create inputs only, within root's existing admitted W clock and writers.

    freeze_ref is an explicit same-buffer descriptor (see R03 notes). There
    are no guessed defaults for the native identities, source graph, nonce or
    global writer allocation. Hooks must create parent directories safely.
    Missing frozen parameters raise BinderPending, with partials preserved.
    No COMPLETE marker, D4 call, process launch, timer or EXPECTED is emitted.
    """
    try:
        return _bind_w_inputs(freeze_ref, root=root, output=output, budget=budget,
                              open_file=open_file, save_bytes=save_bytes,
                              copy_file=copy_file, mkdir=mkdir,
                              builder_context=builder_context)
    except FileNotFoundError as error:
        raise BinderPending("W_INPUT_BINDER_PENDING:MISSING_ORIGINAL:" + str(error)) from error
    except KeyError as error:
        raise BinderPending("W_INPUT_BINDER_PENDING:MISSING_FROZEN_PARAMETER:" +
                            str(error)) from error


def _bind_w_inputs(freeze_ref, *, root, output, budget, open_file,
                   save_bytes, copy_file, mkdir, builder_context):
    io = BinderIO(root, output, budget, open_file, save_bytes, copy_file, mkdir)
    budget.check()
    freeze = document(io.read_reference(freeze_ref))
    need(set(freeze) == {"schema", "templates", "physical_budgets", "nonce", "run_id"}
         and freeze["schema"] == "M3_R13_W_INPUT_BINDER_FREEZE_V1"
         and freeze["run_id"] == "W01", "FROZEN_BINDER_PARAMETERS")
    need(freeze["physical_budgets"] == EXPECTED_BUDGETS
         and sum(EXPECTED_BUDGETS.values()) == 24 << 30, "ROOT_WRITER_PROFILE_PENDING")
    need(isinstance(freeze["nonce"], str)
         and re.fullmatch("[0-9a-f]{32,64}", freeze["nonce"]), "NEW_NONCE_REQUIRED")
    templates = freeze["templates"]
    need(set(templates) == set(PIN_SHA), "EXACT_FROZEN_TEMPLATE_SET")
    for role, ref in templates.items():
        need(ref["sha256"] == PIN_SHA[role], "TEMPLATE_PIN:" + role)
    # All decisions use the same buffers which passed their identity checks.
    master_recipe = document(io.read_reference(templates["recipe"]))
    application = document(io.read_reference(templates["application"]))
    request_template = document(io.read_reference(templates["request"]))
    graph = document(io.read_reference(templates["graph"]))
    dependency_raw = io.read_reference(templates["r12_dependencies"])
    dependency_doc = document(dependency_raw)
    need(dependency_doc["schema"] == "M3_R12_PINNED_DEPENDENCIES_V1", "R12_DEPENDENCY_SCHEMA")
    io.read_reference(templates["module_bindings"])
    plan = document(io.read_reference(templates["midi_plan"]))
    need(master_recipe["rows"] == MIN_ROWS and plan["events"] == []
         and application["approved"] is False
         and request_template["origin"] == "SYNTHETIC_SCHEMA_FIXTURE"
         and freeze["nonce"] != application["execution_spec"]["nonce"], "SYNTHETIC_TEMPLATE_OR_NONCE")
    need(callable(builder_context), "ACTUAL_BUILDER_CONTEXT_HOOK_REQUIRED")
    begin = builder_context("START")
    begin_time = _context(begin)
    io.mkdir_hook(io.output, budget=budget, exclusive=True)
    budget.check()
    # Source dependency document retains its exact original bytes and sources.
    dependency_ref = io.copy(templates["r12_dependencies"], "FROZEN_R12_DEPENDENCIES.json")
    plan["total_cycles"] = MIN_ROWS - 2
    bodies = {"plan.json": encoded(plan), "bytes.drv": b"",
              "reset.drv": b"0 1\n", "ready.drv": b"0 1\n"}
    stimulus_refs = {name: io.save("stimulus/" + name, body) for name, body in bodies.items()}
    recipe = copy.deepcopy(master_recipe)
    recipe["midi_plan"] = stimulus_refs["plan.json"]
    bound_recipe_ref = io.save_json("BOUND_FULL_WINDOW_RECIPE_R03.json", recipe)
    sinks = []
    def raw_factory(role):
        need(role == "raw_capture" and not sinks, "EXACT_ONE_PLAIN_RAW_SINK")
        sink = _PlainRawSink(io)
        sinks.append(sink)
        return sink
    generated = produce_inputs(bound_recipe_ref, templates["seed"], templates["port_map"],
                               sink_factory=raw_factory, put_control=io.save,
                               budget=budget, read_reference=io.read_reference)
    refs = generated["refs"]
    window = document(io.read_reference(refs["window_plan"]))
    need(window["input_plan_sha256"] == stimulus_refs["plan.json"]["sha256"]
         and window["capture_id"] == recipe["capture_id"]
         and window["row_count"] == MIN_ROWS, "GENERATED_WINDOW_BINDING")
    new_zip, rom_copies, unchanged, replaced = _replace_four_stimuli(io, application, graph, bodies)
    source = application["source"]
    source["application"], source["stimulus_inputs"] = new_zip, stimulus_refs
    application["window_reference"] = refs["window_plan"]
    spec = application["execution_spec"]
    spec["window_parameters"], spec["nonce"] = window["window_parameters"], freeze["nonce"]
    need([step["tool"] for step in spec["steps"]] == ["vlib", "vlog", "vsim"]
         and spec["top"] == "tb_r7a_c9_public_capture" and spec["cwd"] == "inputs",
         "PROPOSED_TOOL_STEPS")
    order = ("CAPTURE_ID", "PLAN_STOP_ID", "STOP_DRIVER_CYCLE",
             "EXPECTED_FINISH_CORE_CYCLE", "MAX_CORE_SAMPLES", "MAX_SIM_TIME_PS")
    step = spec["steps"][2]
    step["argv"] = [application["tools"]["vsim"]["tool"]["file"]["path"], "-c"] + [
        "-g" + key + "=" + str(spec["window_parameters"][key]) for key in order] + [
        "work.tb_r7a_c9_public_capture", "-do", "run -all; quit -f"]
    application["proposed_plan"] = {
        "schema": "M3_C9_BOUND_APPLICATION_PLAN_V1", "source": copy.deepcopy(source),
        "tools": copy.deepcopy(application["tools"]),
        "external_inputs": copy.deepcopy(application["external_inputs"]),
        "window_reference": refs["window_plan"], "execution": copy.deepcopy(spec),
        "permission": "NOT_GRANTED", "process_route": "ABSENT"}
    app_ref = io.save_json("APPLICATION_REQUEST.json", application)
    source_members = [source["base"], source["decision"], source["application"],
                      *source["capture_sources"].values()]
    for ref in [*source_members, *source["contracts"].values(), application["external_inputs"],
                request_template["inputs"]["frame_rules"], *request_template["source_contract_refs"]]:
        io.verified(ref)
    source_ref = io.save_json("SOURCE_CLOSURE.json", {"schema": "M3_R7D_FILE_CLOSURE_V1",
                                                     "files": source_members})
    rom_ref = io.save_json("ROM_CLOSURE.json", {"schema": "M3_R7D_FILE_CLOSURE_V1",
                                               "files": [new_zip, *rom_copies]})
    native = {}
    for tool in application["tools"].values():
        for item in [tool["tool"], *tool.get("dependencies", [])]:
            ref = item["file"]
            key = str(io.path(ref)).casefold()
            need(key not in native or native[key] == ref, "NATIVE_IDENTITY_CONFLICT")
            native[key] = ref
    for ref in native.values():
        io.verified(ref)  # file identity only; never invoke PE/native tools.
    tool_ref = io.save_json("TOOL_CLOSURE.json", {"schema": "M3_R7D_FILE_CLOSURE_V1",
        "files": list(native.values()), "argv": step["argv"], "cwd": spec["cwd"],
        "version": "SYNTHETIC_DECLARATION_ONLY_NOT_EXECUTED; frozen native file identities"})
    inputs = {"raw": refs["raw_logical"], "resets": refs["resets"], "end": refs["end"],
              "stdout": refs["stdout"], "frame_input": refs["frame_input"],
              "stderr": io.save("CAPTURE_STDERR_SYNTHETIC_EMPTY.bin", b""),
              "application_request": app_ref, "frame_rules": request_template["inputs"]["frame_rules"],
              "window_plan": refs["window_plan"], "midi_plan": stimulus_refs["plan.json"],
              "source_manifest": source_ref, "rom_manifest": rom_ref, "tool_manifest": tool_ref}
    request = {key: copy.deepcopy(value) for key, value in request_template.items()
               if key not in {"synthetic_application_example", "inputs", "math_inputs"}}
    request.update(capture_id=recipe["capture_id"], origin="SYNTHETIC_SCHEMA_FIXTURE",
                   inputs=inputs, module_bindings=templates["module_bindings"])
    roles = _declared_roles(request, application)
    end = builder_context("DECLARATION")
    end_time = _context(end)
    need(end["pid"] == begin["pid"] and end_time >= begin_time, "BUILDER_CONTEXT_CHANGED")
    # Existing R11 requires these structural clean values. Their declared-only
    # meaning is explicit in ORIGIN, not a claim that vsim/tool execution ran.
    receipt = {"schema": "M3_R7D_DECLARED_EXECUTION_V1", "capture_id": recipe["capture_id"],
        "argv": step["argv"], "cwd": spec["cwd"],
        "bindings": {key: ref["sha256"] for key, ref in roles.items()},
        "exit_code": 0, "timeout": False, "cleanup_complete": True,
        "consumption": {"pid": begin["pid"], "group_id": "R13_W_SYNTHETIC_BUILDER_NOT_NATIVE",
                        "started_utc": begin["utc"], "ended_utc": end["utc"]}}
    receipt_ref = io.save_json("DECLARED_SYNTHETIC_RECEIPT.json", receipt)
    request["math_inputs"] = {"execution_receipt": receipt_ref}
    request_ref = io.save_json("CAPTURE_REQUEST.json", request)
    envelope_ref = io.save_json("ENVELOPE.json", {"schema": "N10_M3_UNIFIED_PIPELINE_REQUEST_V1",
        "mode": "PROCESS_CAPTURE", "request": request_ref})
    authority = {"execution_allowed": False, "real_verified": False,
                 "math_verified": False, "board_release_allowed": False}
    control_ref = io.save_json("CONTROL.json", {"schema": "M3_R13_BACKEND_CONTROL_V1",
        "run_id": "W01", "run_kind": "SYNTHETIC_SOFTWARE", "envelope_ref": envelope_ref,
        "dependencies_ref": dependency_ref, "quota_bytes": freeze["physical_budgets"]["all_stores"],
        "volume_policy": "GZIP_32M_PARTS_IO_1M", "authority": authority})
    origin_ref = io.save_json("W_INPUT_ORIGIN_R03.json", {
        "schema": "M3_R13_W_INPUT_ORIGIN_V1", "origin": "SYNTHETIC_SCHEMA_FIXTURE",
        "template_freeze": freeze_ref, "independent_scenario": generated["scenario"],
        "master_recipe": templates["recipe"], "bound_recipe": bound_recipe_ref,
        "new_application_zip": new_zip, "original_application_zip":
            document(io.read_reference(templates["application"]))["source"]["application"],
        "replaced_members": replaced, "unchanged_members": unchanged,
        "frozen_graph": templates["graph"], "source_units": 75, "roms": 9,
        "raw_frame_end_inherited": False, "old_EXPECTED_or_receipt_reused": False,
        "receipt_semantics": {"argv": "PROPOSED_NOT_EXECUTED", "pid_times": "ACTUAL_BUILDER_ONLY",
            "exit_cleanup": "STRUCTURAL_DECLARATION_NOT_VSIM_OBSERVATION"},
        "native_tool_calls": 0, "W_GO": False, **authority})
    for ref in [request_ref, envelope_ref, control_ref, receipt_ref, dependency_ref,
                app_ref, origin_ref, *inputs.values(), *templates.values()]:
        io.verified(ref)
    budget.check()
    return {"schema": "M3_R13_W_INPUT_BINDING_CANDIDATE_RESULT_V1",
        "status": "INPUTS_BOUND_ACTUAL_D4_NOT_CALLED", "control_ref": control_ref,
        "envelope_ref": envelope_ref, "dependency_ref": dependency_ref,
        "request_ref": request_ref, "inputs": inputs, "origin_ref": origin_ref,
        "required_W_postcondition": {"minimum_rows": MIN_ROWS,
            "raw_input_role": "raw", "raw_descriptor": inputs["raw"],
            "minimum_raw_bytes": MIN_RAW_BYTES},
        "postcondition_integration": "Current C W raw_role artifact lookup must explicitly bind final input raw; do not guess an absent artifact role.",
        "all_stores_quota_requires_shared_root_account": True,
        "W_GO": False, "actual_D4_required": True, **authority}


if __name__ == "__main__":
    raise SystemExit("ROOT_W_CLOCK_ONLY_NO_STANDALONE_FIXTURE_GENERATION")


def worker(group, admission_path, admission_sha, output):
    record = read_control(admission_path, admission_sha)
    admission = record["value"]
    require(admission.get("plan_sha256") == PLAN_SHA256 and
            admission.get("group") == group and
            admission.get("state") == "CONSUMED_RUNNING",
            "WORKER_ADMISSION")
    output = strict_child(OUTPUT, output)
    require(not output.exists(), "FRESH_WORKER_OUTPUT")
    output.mkdir(parents=True)
    atomic_json(output / "CONSUMPTION_RUNNING.json", {
        "schema": "M3_R13_WORKER_CONSUMPTION_V1", "group": group,
        "admission": {"path": str(Path(admission_path).resolve()),
                      **record["stamp"]}, "complete": False})
    try:
        if group == "P0":
            outcomes = [_p0_case()]
        elif group == "K":
            outcomes = _k_cases(admission)
        elif group == "V":
            cases = output / "cases"
            cases.mkdir()
            outcomes = [_volume_case(case, cases, admission)
                        for case in GROUPS["V"]]
        elif group in ("B", "W"):
            if group == "W":
                require(admission.get("resource_profile") == "PASS" and
                        admission.get("delivery_channel_confirmed") is True,
                        "W_RESOURCE_PROFILE_PENDING")
                _delivery_ready(admission)
            outcomes = _actual_cases(group, admission, output)
        elif group == "R":
            affected = admission.get("affected_case_ids")
            require(type(affected) is list and 0 < len(affected) <= 16,
                    "R_AFFECTED_CASES")
            repair_group = admission.get("repair_group")
            require(repair_group in {"K", "V", "B"} and
                    set(affected) <= set(GROUPS[repair_group]),
                    "R_SINGLE_GROUP_SCOPE")
            if repair_group == "K":
                outcomes = _k_cases(admission, affected)
            elif repair_group == "V":
                cases = output / "cases"
                cases.mkdir()
                outcomes = [_volume_case(case, cases, admission)
                            for case in affected]
            else:
                require(not ({"B02", "B03", "B04"} & set(affected)),
                        "R_PARENT_JOB_CASES_REQUIRE_PARENT_DISPATCH")
                outcomes = _actual_cases("B", admission, output, affected)
        else:
            raise Reject("WORKER_GROUP")
        parent_required = (group in {"P0", "B"} or
                           (group == "R" and
                            admission.get("repair_group") == "B"))
        result = {"schema": ("M3_R13_WORKER_LOCAL_RESULT_V1" if
                              parent_required else
                              "M3_R13_WORKER_COMPLETE_V1"),
                  "status": ("PASS_LOCAL_PENDING_PARENT" if parent_required
                             else "PASS"), "group": group,
                  "cases": outcomes,
                  "parent_receipt_required": parent_required,
                  "real_verified": False, "math_verified": False,
                  "execution_allowed": False, "board_release_allowed": False}
        atomic_json(output / ("WORKER_LOCAL_RESULT.json" if parent_required
                              else "WORKER_COMPLETE.json"), result)
        return result
    except BaseException as error:
        failure = {"schema": "M3_R13_WORKER_FAILURE_V1", "group": group,
                   "error": type(error).__name__ + ":" + str(error),
                   "traceback": traceback.format_exc(), "complete": False}
        try:
            atomic_json(output / "WORKER_FAILURE.json", failure)
        except BaseException as secondary:
            failure["secondary_failure"] = (type(secondary).__name__ + ":" +
                                              str(secondary))
        raise error.with_traceback(error.__traceback__)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", action="store_true", required=True)
    parser.add_argument("--group", required=True, choices=(*GROUPS, "R"))
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    worker(args.group, args.admission, args.admission_sha256, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
