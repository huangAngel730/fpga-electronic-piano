"""Root-admitted R13 worker CLI; importing this file performs no work.

The coordinator supplies independently frozen controls for real-chain B/W
cases.  This worker never manufactures a D4 replacement or derives expected
content from actual output.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import traceback

import entry
from finalize import atomic_json
from stream_bridge import CHUNK, Reject, read_control, require, strict_child
from volume_io import VolumeStore

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
OUTPUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
PLAN_SHA256 = "729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3"
GROUPS = {"P0": ["P001"],
          "K": [f"K{i:02d}" for i in range(1, 9)],
          "V": [f"V{i:02d}" for i in range(1, 13)],
          "B": [f"B{i:02d}" for i in range(1, 13)],
          "W": ["W01"]}


def _manifest(path):
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False,
                               separators=(",", ":")) + "\n",
                    encoding="utf-8", newline="\n")


def _expect_reject(call, token):
    try:
        call()
    except BaseException as error:
        require(token in str(error), "WRONG_REJECT:" + str(error))
        return
    raise Reject("EXPECTED_REJECT_NOT_OBSERVED:" + token)


def _volume_case(case_id, root):
    case = root / case_id
    case.mkdir()
    logical = case / "logical.jsonl"
    store = VolumeStore(case)
    if case_id == "V02":
        payload = b"a" * (CHUNK - 1) + "音".encode() + b"\n"
    elif case_id == "V03":
        payload = b"one\r\ntwo\nthree\r\n"
    else:
        payload = (b'{"row":1}\n' * 8192)
    with store.open(logical, "xb") as stream:
        offset = 0
        while offset < len(payload):
            block = payload[offset:offset + CHUNK]
            stream.write(block)
            offset += len(block)
    manifest_path = store.folder_for(logical) / "MANIFEST.json"
    manifest = _manifest(manifest_path)
    expected = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
    if case_id == "V04":
        (store.folder_for(logical) /
         manifest["parts"][0]["compressed"]["path"]).unlink()
    elif case_id == "V05":
        manifest["parts"].append(copy.deepcopy(manifest["parts"][0]))
        _save(manifest_path, manifest)
    elif case_id == "V06":
        manifest["parts"][0]["sequence"] = 1
        _save(manifest_path, manifest)
    elif case_id == "V07":
        manifest["parts"][0]["logical_offset"] = 1
        _save(manifest_path, manifest)
    elif case_id == "V08":
        manifest["parts"][0]["decoded_sha256"] = "0" * 64
        _save(manifest_path, manifest)
    elif case_id == "V09":
        manifest["original"]["sha256"] = "0" * 64
        _save(manifest_path, manifest)
    elif case_id == "V10":
        part = store.folder_for(logical) / manifest["parts"][0]["compressed"]["path"]
        with part.open("r+b") as stream:
            stream.truncate(max(0, part.stat().st_size - 1))
    if case_id in {"V04", "V05", "V06", "V07", "V08", "V09", "V10"}:
        fresh = VolumeStore(case)
        _expect_reject(lambda: _drain(fresh.open(logical, "rb")), "VOLUME_")
        return {"id": case_id, "status": "EXPECTED_REJECT"}
    actual = _drain(store.open(logical, "rb"))
    require(actual == payload, "VOLUME_NOT_LOSSLESS")
    if case_id == "V11":
        control = case / "control.json"
        control.write_bytes(b'{"decision":"original"}\n')
        first = read_control(control)
        control.write_bytes(b'{"decision":"changed"}\n')
        require(first["value"]["decision"] == "original" and
                read_control(control)["stamp"] != first["stamp"],
                "SAME_BUFFER_OR_MUTATION_GUARD")
    return {"id": case_id,
            "status": "PENDING_EXTERNAL_DELIVERY" if case_id == "V12" else "PASS",
            "bytes": expected["bytes"], "sha256": expected["sha256"]}


def _drain(stream):
    blocks = []
    with stream:
        while True:
            block = stream.read(CHUNK)
            if not block:
                break
            require(len(block) <= CHUNK, "READ_REQUEST_BOUND")
            blocks.append(block)
    return b"".join(blocks)


def _k_cases():
    base = {"sources": {"plan": "independent", "reset": "edges"},
            "profile": {"width": 24}, "finish": "PENDING_D_OR_D1",
            "authenticity": "UNKNOWN", "derived_plan": False}
    outcomes = []
    for case_id in GROUPS["K"]:
        value = copy.deepcopy(base)
        expected = "PASS"
        if case_id == "K02":
            del value["sources"]["plan"]
            expected = "MISSING_SOURCE"
        elif case_id == "K03":
            value["profile"]["width"] = 16
            expected = "PROFILE_CONFLICT"
        elif case_id == "K04":
            value["sources"]["plan"] = "actual_trace"
            expected = "PLAN_NOT_INDEPENDENT"
        elif case_id == "K05":
            value["derived_plan"] = True
            expected = "PLAN_DERIVED_FROM_TRACE"
        elif case_id == "K06":
            value["sources"]["reset"] = "row_inferred"
            expected = "RESET_NOT_INDEPENDENT"
        elif case_id == "K07":
            expected = "FINISH_PENDING"
        elif case_id == "K08":
            expected = "AUTHENTICITY_PENDING"
        actual = "PASS"
        if "plan" not in value["sources"]:
            actual = "MISSING_SOURCE"
        elif value["profile"]["width"] != 24:
            actual = "PROFILE_CONFLICT"
        elif value["sources"]["plan"] != "independent":
            actual = "PLAN_NOT_INDEPENDENT"
        elif value["derived_plan"]:
            actual = "PLAN_DERIVED_FROM_TRACE"
        elif value["sources"]["reset"] != "edges":
            actual = "RESET_NOT_INDEPENDENT"
        elif case_id == "K07" and value["finish"].startswith("PENDING"):
            actual = "FINISH_PENDING"
        elif case_id == "K08" and value["authenticity"] == "UNKNOWN":
            actual = "AUTHENTICITY_PENDING"
        require(actual == expected, "K_CASE:" + case_id)
        outcomes.append({"id": case_id, "status": actual})
    return outcomes


def _actual_cases(group, admission, output):
    controls = admission.get("business_cases")
    require(type(controls) is list, "BUSINESS_CASES_REQUIRED")
    wanted = ["W01"] if group == "W" else [
        case for case in GROUPS["B"] if case not in {"B02", "B03", "B04"}]
    by_id = {item.get("id"): item for item in controls}
    require(set(by_id) == set(wanted), "BUSINESS_CASE_SET")
    outcomes = []
    for case_id in wanted:
        item = by_id[case_id]
        case_out = output / "cases" / case_id
        expected = item["expected"]
        try:
            entry.run(Path(item["control"]), item["control_sha256"], case_out)
            actual = "PASS"
        except BaseException as error:
            actual = "REJECT:" + type(error).__name__ + ":" + str(error)
        require((expected == "PASS" and actual == "PASS") or
                (expected.startswith("REJECT:") and expected[7:] in actual),
                "BUSINESS_EXPECTATION:" + case_id + ":" + actual)
        outcomes.append({"id": case_id, "status": actual})
    if group == "B":
        outcomes += [{"id": case, "status": "DEFERRED_TO_PARENT_JOB_RECEIPT"}
                     for case in ("B02", "B03", "B04")]
    return sorted(outcomes, key=lambda item: item["id"])


def worker(group, admission_path, admission_sha, output):
    record = read_control(admission_path, admission_sha)
    admission = record["value"]
    require(admission.get("plan_sha256") == PLAN_SHA256 and
            admission.get("group") == group and
            admission.get("state") == "CONSUMED_RUNNING",
            "WORKER_ADMISSION")
    output = strict_child(OUTPUT, output)
    require(not output.exists(), "FRESH_WORKER_OUTPUT")
    output.mkdir(parents=True)
    atomic_json(output / "CONSUMPTION_RUNNING.json", {
        "schema": "M3_R13_WORKER_CONSUMPTION_V1", "group": group,
        "admission": {"path": str(Path(admission_path).resolve()),
                      **record["stamp"]}, "complete": False})
    try:
        if group == "P0":
            outcomes = [{"id": "P001", "status": "STATIC_PINS_BOUND"}]
        elif group == "K":
            outcomes = _k_cases()
        elif group == "V":
            cases = output / "cases"
            cases.mkdir()
            outcomes = [_volume_case(case, cases) for case in GROUPS["V"]]
        elif group in ("B", "W"):
            if group == "W":
                require(admission.get("resource_profile") == "PASS",
                        "W_RESOURCE_PROFILE_PENDING")
            outcomes = _actual_cases(group, admission, output)
        elif group == "R":
            affected = admission.get("affected_case_ids")
            require(type(affected) is list and 0 < len(affected) <= 16,
                    "R_AFFECTED_CASES")
            raise Reject("R_REQUIRES_FROZEN_REPAIR_DISPATCH")
        else:
            raise Reject("WORKER_GROUP")
        result = {"schema": "M3_R13_WORKER_COMPLETE_V1", "group": group,
                  "outcomes": outcomes,
                  "parent_receipt_required": group == "B",
                  "real_verified": False, "math_verified": False,
                  "execution_allowed": False, "board_release_allowed": False}
        atomic_json(output / "WORKER_COMPLETE.json", result)
        return result
    except BaseException as error:
        failure = {"schema": "M3_R13_WORKER_FAILURE_V1", "group": group,
                   "error": type(error).__name__ + ":" + str(error),
                   "traceback": traceback.format_exc(), "complete": False}
        try:
            atomic_json(output / "WORKER_FAILURE.json", failure)
        except BaseException as secondary:
            failure["secondary_failure"] = (type(secondary).__name__ + ":" +
                                              str(secondary))
        raise error.with_traceback(error.__traceback__)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", action="store_true", required=True)
    parser.add_argument("--group", required=True, choices=(*GROUPS, "R"))
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    worker(args.group, args.admission, args.admission_sha256, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
