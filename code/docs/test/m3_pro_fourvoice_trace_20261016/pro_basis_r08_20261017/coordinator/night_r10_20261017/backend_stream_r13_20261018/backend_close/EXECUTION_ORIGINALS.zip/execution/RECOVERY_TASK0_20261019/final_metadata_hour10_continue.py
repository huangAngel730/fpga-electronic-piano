"""Complete only the metadata bindings left after the preserved first-run order failure."""
import hashlib
import json
from pathlib import Path

R = Path.cwd().resolve()
O = R / "code/output/m3_backend_stream_r13_20261018"
T = O / "RECOVERY_TASK0_20261019"
P = "m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017"
D = R / "code/docs/test" / P / "backend_stream_r13_20261018"
C = D / "backend_close"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, value):
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def stamp(path):
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            size += len(block)
            digest.update(block)
    return {
        "path": path.relative_to(R).as_posix(),
        "bytes": size,
        "sha256": digest.hexdigest(),
    }


ledger = read(O / "CONSUMPTION_LIVE.json")
worker_path = O / "RUNS/W_HOUR_10/inner/worker/WORKER_COMPLETE.json"
worker = read(worker_path)
observed = worker["cases"][0]["observed"]
assert worker["status"] == "PASS"
assert observed["terminal"]["rows"] == 1130662

handoff = read(C / "INTEGRATION_HANDOFF.json")
handoff["formation_snapshots_are_historical"] = {
    "A_capacity_decision": [
        "PROFILE_AND_CAPACITY.json#/W_admission",
        "OPEN_DECISIONS.json#/items/5",
        "CONTRACT_INDEX.json#/delivery_channel/physical_24GiB_geometry",
        "M2_DECISION_SHEET.md R13-D06",
    ],
    "superseded_only_for": (
        "Current synthetic W resource/software admissibility; actual authorization "
        "and runtime proof referenced below. Real capture/math/board decisions remain pending."
    ),
    "B_old_cohort": (
        "Original 7-row synthetic cohort is retained unchanged; never relabelled as current W."
    ),
}
handoff["current_full_window"] = {
    "cohort": "W_HOUR_10/W01",
    "row_count": 1130662,
    "raw_input": observed["raw_input"],
    "complete_marker": stamp(
        O / "RUNS/W_HOUR_10/inner/worker/cases/W01/COMPLETE.json"
    ),
    "frozen_inputs": stamp(T / "W_SCALAR_RECOVERY/FROZEN_INPUTS.json"),
    "source_freeze": stamp(T / "W_HOUR_CATEGORY_10/FREEZE.json"),
    "export_manifest": stamp(O / "DELIVERY/W01/MANIFEST.json"),
    "transport": read(T / "W_TRANSFER_RECEIPT.json"),
    "actual_level": "L1 synthetic software full-window only",
    "logical_volume_restore": (
        "Restore every original by export manifest part order/offset; preserve internal "
        "gzip files and each manifest; their logical decoded bytes/SHA and total row order "
        "remain authoritative."
    ),
}
originals_index = read(D / "capture_originals/ORIGINALS_INDEX.json")
required = {}
for name, obj in originals_index["objects"].items():
    if obj.get("locator", {}).get("kind") not in (
        "local_original_pending_transfer",
        "user_forwarded_package_file",
        "local_control_file",
    ):
        continue
    original_path = Path(obj["path"])
    required[name] = {
        "original": {key: obj[key] for key in ("path", "bytes", "sha256")},
        "planned_transport_member": (
            "required_originals/" + name + "/" + original_path.name
        ),
    }
assert len(required) == 17
handoff["required_17_cross_PC_originals"] = required
handoff["runtime_and_failure_binding"] = {
    "cases": stamp(C / "CASE_RESULTS.json"),
    "resources": stamp(C / "RESOURCE_RECEIPT.json"),
    "consumption": stamp(C / "CONSUMPTION.json"),
    "failed_history": stamp(C / "FAILURE_HISTORY.json"),
}
handoff["latest_hour_execution_authority"] = [
    stamp(T / "W_HOUR_REPLAY_09/AUTHORIZATION_W.json"),
    stamp(T / "W_HOUR_REPLAY_09/AUTHORIZATION_CLOSING.json"),
    stamp(T / "W_HOUR_CATEGORY_10/AUTHORIZATION.json"),
]
handoff["classification_refinement"] = stamp(
    T / "W_HOUR_CATEGORY_10/CLASSIFICATION_EXECUTION_R02.json"
)
handoff["prior_no_replay_instruction_superseded"] = (
    "Latest direct user approved fresh once-hour W after retaining old fixed-timeout "
    "failures, plus metadata classification repair once-hour successor. No old slot reset."
)
handoff["metadata_generation_recovery"] = {
    "first_attempt": stamp(T / "FINAL_METADATA_FIRST_ATTEMPT_FAILURE.json"),
    "repair": (
        "The tracked candidate tree already existed. This continuation only binds the "
        "17 originals from the frozen ORIGINALS_INDEX and records the final asset as "
        "pending until after S2; it does not append README or rerun W."
    ),
}
save(C / "INTEGRATION_HANDOFF.json", handoff)

start_deadline = read(C / "START_AND_DEADLINE.json")
start_deadline["formation_intake_fields_are_historical"] = True
start_deadline["original_earliest_deadline"] = start_deadline["earliest_deadline"]
start_deadline["current_effective_deadline"] = (
    "NO_TIME_LIMIT_DIRECT_USER_CONTINUATION_2026-10-19"
)
start_deadline["runtime_slots_finished_before_prior_12_00_cutoff"] = True
start_deadline["current_Goal_tool_status"] = (
    "PAUSED_STALE_TOOL_NO_RESUME_API_USER_DIRECT_CONTINUATION_EFFECTIVE"
)
start_deadline["current_authorizations"] = handoff["latest_hour_execution_authority"]
start_deadline["original_START_unchanged"] = True
start_deadline["no_old_consumption_refunded"] = True
start_deadline["time_limit_change_scope"] = (
    "Closure only; no test slot, network operation, resource limit, or old consumption reset."
)
save(C / "START_AND_DEADLINE.json", start_deadline)

print(
    json.dumps(
        {
            "status": "CONTINUATION_COMPLETE",
            "required_originals": len(required),
            "rows": observed["terminal"]["rows"],
        },
        ensure_ascii=False,
    )
)
