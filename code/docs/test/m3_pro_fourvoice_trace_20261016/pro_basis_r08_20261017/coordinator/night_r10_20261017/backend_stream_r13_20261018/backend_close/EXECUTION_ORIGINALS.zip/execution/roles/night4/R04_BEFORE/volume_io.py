"""Transparent, reversible gzip volumes for large logical D4 artifacts.

Logical files keep their original names and byte identities in descriptors.
Their bytes are written directly to bounded physical parts; no plaintext
whole-file intermediate is created.  Readers concatenate and decompress the
parts, and verify compressed, per-part decoded and whole-stream identities.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import sys

from stream_bridge import CHUNK, Reject, parse_json, require

PART_LIMIT = 32 * 1024 * 1024
# A gzip member for at most 31 MiB of arbitrary input remains below the 32 MiB
# transfer-part ceiling even with DEFLATE stored-block and container overhead.
DECODED_PART_LIMIT = 31 * 1024 * 1024
DEFAULT_QUOTA = 24 * 1024 * 1024 * 1024
STREAM_SUFFIXES = frozenset({".jsonl", ".csv"})


def _atomic_json(path: Path, value: dict) -> None:
    raw = (json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False) + "\n").encode()
    require(len(raw) <= CHUNK, "VOLUME_MANIFEST_TOO_LARGE")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("xb", buffering=0) as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


class _PartSink(io.RawIOBase):
    def __init__(self, path: Path, quota):
        self.path, self.quota = path, quota
        self.current = path.open("xb", buffering=0)
        self.size, self.digest = 0, hashlib.sha256()

    def writable(self):
        return True

    def write(self, data):
        view = memoryview(data).cast("B")
        offset = 0
        while offset < len(view):
            take = min(CHUNK, len(view) - offset)
            block = view[offset:offset + take]
            self.quota.reserve(take)
            written = self.current.write(block)
            require(written == take, "VOLUME_SHORT_WRITE")
            self.digest.update(block)
            self.size += take
            require(self.size <= PART_LIMIT, "VOLUME_COMPRESSED_PART_LIMIT")
            offset += take
        return len(view)

    def close(self):
        if not self.closed:
            self.current.flush()
            os.fsync(self.current.fileno())
            self.current.close()
        super().close()


class _Quota:
    def __init__(self, limit=DEFAULT_QUOTA):
        require(type(limit) is int and limit > 0, "VOLUME_QUOTA")
        self.limit, self.used = limit, 0

    def reserve(self, count):
        require(self.used + count <= self.limit, "WORKSPACE_QUOTA_EXCEEDED")
        self.used += count


class VolumeWriter(io.RawIOBase):
    def __init__(self, store, logical: Path, exclusive: bool):
        self.store, self.logical = store, logical
        self.folder = store.folder_for(logical)
        require(not self.folder.exists() if exclusive else True,
                "VOLUME_LOGICAL_EXISTS")
        self.folder.mkdir(parents=True, exist_ok=False)
        self.digest, self.count = hashlib.sha256(), 0
        self.parts, self.sequence = [], 0
        self.sink = self.gzip = self.part_digest = None
        self.part_count = 0
        self._open_part()

    def writable(self):
        return True

    def _open_part(self):
        path = self.folder / f"part-{self.sequence:06d}.gz"
        self.sink = _PartSink(path, self.store.quota)
        self.gzip = gzip.GzipFile(filename="", mode="wb", fileobj=self.sink,
                                  compresslevel=6, mtime=0)
        self.part_digest, self.part_count = hashlib.sha256(), 0

    def _close_part(self):
        self.gzip.close()
        self.sink.close()
        self.parts.append({
            "sequence": self.sequence,
            "logical_offset": self.count - self.part_count,
            "decoded_bytes": self.part_count,
            "decoded_sha256": self.part_digest.hexdigest(),
            "compressed": {"path": f"part-{self.sequence:06d}.gz",
                           "bytes": self.sink.size,
                           "sha256": self.sink.digest.hexdigest()}})
        self.sequence += 1
        self.gzip = self.sink = None

    def write(self, data):
        view = memoryview(data).cast("B")
        offset = 0
        while offset < len(view):
            if self.part_count == DECODED_PART_LIMIT:
                self._close_part()
                self._open_part()
            take = min(CHUNK, DECODED_PART_LIMIT - self.part_count,
                       len(view) - offset)
            block = view[offset:offset + take]
            self.gzip.write(block)
            self.digest.update(block)
            self.part_digest.update(block)
            self.count += take
            self.part_count += take
            offset += take
        return len(view)

    def close(self):
        if self.closed:
            return
        self._close_part()
        manifest = {"schema": "M3_R13_LOGICAL_VOLUME_V1",
                    "logical_path": self.logical.relative_to(
                        self.store.workspace).as_posix(),
                    "format": "gzip_stream_split_binary",
                    "physical_part_limit": PART_LIMIT,
                    "decoded_part_limit": DECODED_PART_LIMIT,
                    "io_request_limit": CHUNK,
                    "original": {"bytes": self.count,
                                 "sha256": self.digest.hexdigest()},
                    "parts": self.parts}
        _atomic_json(self.folder / "MANIFEST.json", manifest)
        self.store.entries[str(self.logical).casefold()] = manifest
        super().close()


class _PartSource(io.RawIOBase):
    def __init__(self, path, expected):
        self.current = path.open("rb", buffering=0)
        self.expected = expected
        self.digest, self.count, self.eof = hashlib.sha256(), 0, False

    def readable(self):
        return True

    def readinto(self, buffer):
        view = memoryview(buffer).cast("B")
        require(len(view) <= CHUNK, "VOLUME_READ_BOUND")
        data = self.current.read(min(CHUNK, len(view)))
        if data:
            view[:len(data)] = data
            self.digest.update(data)
            self.count += len(data)
            require(self.count <= self.expected["bytes"],
                    "VOLUME_COMPRESSED_SIZE")
        elif not self.eof:
            self.eof = True
            require({"bytes": self.count, "sha256": self.digest.hexdigest()} ==
                    self.expected, "VOLUME_COMPRESSED_IDENTITY")
        return len(data)

    def verify_eof(self):
        """Explicit normal-EOF verification, never exception cleanup."""
        scratch = bytearray(CHUNK)
        while self.readinto(scratch):
            pass

    def close(self):
        # Closing an active reader must not consume its unread tail or replace
        # an exception from the actual downstream consumer.
        self.current.close()
        super().close()


class VolumeReader(io.RawIOBase):
    def __init__(self, store, logical, expected=None):
        self.manifest = store.manifest(logical)
        self.folder, self.parts = store.folder_for(logical), self.manifest["parts"]
        self.index, self.logical_offset = 0, 0
        self.source = self.gzip = None
        self.expected = expected or self.manifest["original"]
        self.digest, self.count, self.done = hashlib.sha256(), 0, False
        self.name, self.mode = str(logical), "rb"

    def _open_part(self):
        if self.index >= len(self.parts):
            return False
        part = self.parts[self.index]
        require(part["sequence"] == self.index and
                part["logical_offset"] == self.logical_offset,
                "VOLUME_SEQUENCE_OR_OFFSET")
        compressed = part["compressed"]
        path = self.folder / compressed["path"]
        require(path.is_file(), "VOLUME_PART_MISSING")
        self.source = _PartSource(path, {"bytes": compressed["bytes"],
                                         "sha256": compressed["sha256"]})
        self.gzip = gzip.GzipFile(mode="rb", fileobj=self.source)
        self.part_digest, self.part_count = hashlib.sha256(), 0
        return True

    def _finish_part(self):
        part = self.parts[self.index]
        # Decoder reached normal logical EOF; verify remaining physical bytes
        # here explicitly. close() itself is deliberately non-draining.
        self.source.verify_eof()
        self.source.close()
        require(self.part_count == part["decoded_bytes"] and
                self.part_digest.hexdigest() == part["decoded_sha256"],
                "VOLUME_DECODED_PART_IDENTITY")
        self.logical_offset += self.part_count
        self.gzip.close()
        self.source = self.gzip = None
        self.index += 1

    def readable(self):
        return True

    def readinto(self, buffer):
        view = memoryview(buffer).cast("B")
        require(len(view) <= CHUNK, "VOLUME_READ_BOUND")
        if self.gzip is None and not self._open_part():
            data = b""
        else:
            try:
                data = self.gzip.read(len(view))
            except (gzip.BadGzipFile, EOFError) as error:
                raise Reject("VOLUME_GZIP_DECODE:" + str(error)) from error
            if not data:
                self._finish_part()
                return self.readinto(buffer)
        view[:len(data)] = data
        self.digest.update(data)
        self.part_digest.update(data)
        self.count += len(data)
        self.part_count += len(data)
        if not data and not self.done:
            self.done = True
            require({"bytes": self.count, "sha256": self.digest.hexdigest()} ==
                    {"bytes": self.expected["bytes"],
                     "sha256": self.expected["sha256"]},
                    "VOLUME_DECODED_IDENTITY")
            require(self.index == len(self.parts),
                    "VOLUME_TRAILING_OR_UNREAD_PART")
        return len(data)

    def close(self):
        if not self.closed:
            primary = sys.exc_info()[1]
            failures = []
            for stream in (self.gzip, self.source):
                if stream is not None:
                    try:
                        stream.close()
                    except BaseException as error:
                        failures.append(error)
            self.secondary_close_errors = [type(error).__name__ + ':' + str(error)
                                           for error in failures]
            super().close()
            if failures and primary is None:
                raise failures[0]


class VolumeStore:
    def __init__(self, workspace: Path, quota_bytes=DEFAULT_QUOTA):
        self.workspace = Path(workspace).resolve()
        self.root = self.workspace / ".r13_volumes"
        self.root.mkdir(parents=True, exist_ok=True)
        self.quota, self.entries = _Quota(quota_bytes), {}

    def folder_for(self, logical: Path) -> Path:
        logical = Path(logical).resolve()
        require(logical.is_relative_to(self.workspace), "VOLUME_LOGICAL_SCOPE")
        relative = logical.relative_to(self.workspace).as_posix()
        key = hashlib.sha256(relative.casefold().encode("utf-8")).hexdigest()
        return self.root / key

    def is_volume(self, logical: Path) -> bool:
        return self.folder_for(logical).joinpath("MANIFEST.json").is_file()

    def manifest(self, logical: Path) -> dict:
        key = str(Path(logical).resolve()).casefold()
        if key in self.entries:
            return self.entries[key]
        path = self.folder_for(logical) / "MANIFEST.json"
        require(path.is_file() and path.stat().st_size <= CHUNK,
                "VOLUME_MANIFEST_MISSING_OR_LARGE")
        with path.open("rb", buffering=0) as stream:
            raw = stream.read(CHUNK)
            require(not stream.read(1), "VOLUME_MANIFEST_TOO_LARGE")
        value = parse_json(raw)
        require(value.get("schema") == "M3_R13_LOGICAL_VOLUME_V1" and
                set(value) == {"schema", "logical_path", "format",
                               "physical_part_limit", "decoded_part_limit",
                               "io_request_limit", "original", "parts"} and
                value.get("format") == "gzip_stream_split_binary" and
                value.get("physical_part_limit") == PART_LIMIT and
                value.get("decoded_part_limit") == DECODED_PART_LIMIT and
                value.get("io_request_limit") == CHUNK and
                set(value.get("original", {})) == {"bytes", "sha256"} and
                type(value.get("parts")) is list and value["parts"] and
                value.get("logical_path") == Path(logical).resolve().relative_to(
                    self.workspace).as_posix(),
                "VOLUME_MANIFEST_BINDING")
        for part in value["parts"]:
            require(type(part) is dict and set(part) == {
                "sequence", "logical_offset", "decoded_bytes",
                "decoded_sha256", "compressed"} and
                type(part["compressed"]) is dict and
                set(part["compressed"]) == {"path", "bytes", "sha256"},
                "VOLUME_PART_DESCRIPTOR")
        self.entries[key] = value
        return value

    def open(self, logical: Path, mode="rb", expected=None):
        logical = Path(logical).resolve()
        if mode in ("xb", "x", "xt", "wb", "w", "wt"):
            require(logical.suffix.casefold() in STREAM_SUFFIXES,
                    "VOLUME_ROLE_NOT_STREAM")
            raw = VolumeWriter(self, logical, "x" in mode)
            return raw if "b" in mode else io.TextIOWrapper(
                raw, encoding="utf-8", errors="strict", newline="\n")
        require(mode in ("rb", "r", "rt"), "VOLUME_OPEN_MODE")
        raw = VolumeReader(self, logical, expected)
        buffered = io.BufferedReader(raw, buffer_size=CHUNK)
        return buffered if "b" in mode else io.TextIOWrapper(
            buffered, encoding="utf-8", errors="strict", newline=None)

    def descriptor(self, logical: Path) -> dict:
        value = self.manifest(logical)["original"]
        return {"bytes": value["bytes"], "sha256": value["sha256"]}

    def physical_bytes(self) -> int:
        return sum(path.stat().st_size for path in self.root.rglob("*")
                   if path.is_file())
