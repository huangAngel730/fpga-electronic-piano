"""Prospective root freeze/admission for located synthetic pin-stream repair."""
import argparse
import difflib
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
HERE = OUT / 'RECOVERY_TASK0_20261019'
WORK = HERE / 'B_PINS_REPAIR'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'

def read(path):
    return json.loads(path.read_text('utf-8'))

def save(path, value, new=True):
    assert not new or not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def ref(path):
    path = path.resolve()
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('freeze', 'P1_PINS_01', 'B_RECOVERY_04', 'W'))
parser.add_argument('--before', type=Path)
args = parser.parse_args()
ledger_path = OUT / 'CONSUMPTION_LIVE.json'
ledger = read(ledger_path)
authority_path = WORK / 'AUTHORITY_AND_LOCATOR.json'
freeze_path = WORK / 'FREEZE.json'
controller_path = HERE / 'root_run_pins_repair.py'
if args.mode == 'freeze':
    assert args.before and args.before.is_file()
    assert ledger['recovery_attempts']['B_RECOVERY_03']['state'] == 'FAILED_STOP'
    assert read(OUT / 'WRITE_LEASES_CLOSED.json')['all_target_writers_closed']
    after = SOURCE / 'selftest.py'
    diff = ''.join(difflib.unified_diff(args.before.read_text('utf-8').splitlines(True), after.read_text('utf-8').splitlines(True), fromfile='before_selftest.py', tofile='after_selftest.py'))
    assert diff
    WORK.mkdir(parents=True, exist_ok=False)
    (WORK / 'REPAIR.diff').write_text(diff, encoding='utf-8', newline='\n')
    save(authority_path, {'schema': 'M3_USER_TASK0_LOCATED_PINS_REPAIR_V1',
         'authority': 'Latest direct user: resolve W and tasks0-3; up to8 evidence-based attempts',
         'problem_attempt_ordinal': 5, 'attempts_limit': 8,
         'original_failures_and_charges_preserved': True,
         'source_before': ref(args.before), 'source_after': ref(after), 'diff': ref(WORK / 'REPAIR.diff'),
         'failure_original': ref(OUT / 'RUNS/B_RECOVERY_03/inner/B02/worker/WORKER_FAILURE.json'),
         'located_issue': '837-row B08 and full W synthetic pins remained idle; real frozen serial PinDecoder rejects BCLK stalled after7 active cycles. Repair deterministic synthetic pins from frozen RTL; keep checker and B08 business coordinates. Same current-run B01 actual output reused only for separately executed B07/B10/B11 postchecks; no old-run reuse.',
         'new_attempts': {'P1_PINS_01': {'slot': 'P1', 'cap_seconds': 60}, 'B_RECOVERY_04': {'slot': 'B', 'cap_seconds': 120}},
         'charge_bucket': 'USER_TASK0_RECOVERY_INCREMENT', 'deadline': ledger['deadline'],
         'old_W_cap_900_not_increased': True, 'recorded_utc': datetime.now(timezone.utc).isoformat()})
    old = read(HERE / 'B_FACTORY_REPAIR/FREEZE.json')
    files = []
    for item in old['frozen_files']:
        actual = ref(Path(item['path']))
        if Path(item['path']).resolve() != after.resolve():
            assert actual == item, item['path']
        files.append(actual)
    save(freeze_path, {'schema': 'M3_R13_ROOT_REPAIR_FREEZE_V1', 'state': 'REPAIR_FROZEN_BY_ROOT',
                      'authority': ref(authority_path), 'frozen_files': files + [ref(authority_path), ref(WORK / 'REPAIR.diff')],
                      'all_target_writers_closed': True})
    raw = (HERE / 'root_run_factory_repair.py').read_text('utf-8')
    raw = raw.replace("get('B_RECOVERY_03', {}).get('state') == 'PASS'", "get('B_RECOVERY_04', {}).get('state') == 'PASS'")
    raw = raw.replace("('P1_FACTORY_01', 'B_RECOVERY_03')", "('P1_PINS_01', 'B_RECOVERY_04')")
    raw = raw.replace("attempt_id == 'P1_FACTORY_01'", "attempt_id == 'P1_PINS_01'")
    raw = raw.replace("attempt_id == 'B_RECOVERY_03'", "attempt_id == 'B_RECOVERY_04'")
    raw = raw.replace("['B_RECOVERY_02']['state'] == 'FAILED_STOP'", "['B_RECOVERY_03']['state'] == 'FAILED_STOP'")
    raw = raw.replace("['P1_FACTORY_01']['state'] == 'PASS'", "['P1_PINS_01']['state'] == 'PASS'")
    assert not controller_path.exists()
    controller_path.write_text(raw, encoding='utf-8', newline='\n')
    for key, wire, cap, count in [('P1_PINS_01', 'P1', 60, 1), ('B_RECOVERY_04', 'B', 120, 12)]:
        assert key not in ledger['recovery_attempts']
        ledger['recovery_attempts'][key] = {'state': 'NOT_STARTED', 'attempts': 0, 'charged_seconds': 0,
             'cap_seconds': cap, 'cases_max': count, 'wire_group': wire, 'authority': ref(authority_path)}
    save(ledger_path, ledger, new=False)
    print(json.dumps({'freeze': ref(freeze_path), 'controller': ref(controller_path)}))
else:
    attempt_id = args.mode
    wire = 'P1' if attempt_id == 'P1_PINS_01' else ('W' if attempt_id == 'W' else 'B')
    cap = {'P1': 60, 'B': 120, 'W': 900}[wire]
    assert (ledger['groups']['W'] if wire == 'W' else ledger['recovery_attempts'][attempt_id])['state'] == 'NOT_STARTED'
    if wire == 'B':
        assert ledger['recovery_attempts']['P1_PINS_01']['state'] == 'PASS'
    if wire == 'W':
        assert ledger['recovery_attempts']['B_RECOVERY_04']['state'] == 'PASS'
        assert read(OUT / 'W_ADMISSION.json')['GO']
    freeze = read(freeze_path)
    for item in freeze['frozen_files']:
        assert ref(Path(item['path'])) == item
    base = OUT / 'ADMISSIONS' / attempt_id
    admission_path = base / 'ADMISSION.json'
    owner = OUT / 'RUNS' / attempt_id / 'inner'
    worker = owner / ('B02/worker' if wire == 'B' else 'worker')
    python = str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
    admission = read(OUT / 'ADMISSIONS/B_RECOVERY_03/ADMISSION.json')
    admission.update(group=wire, absolute_cap_seconds=cap,
         root_deadline_monotonic=time.monotonic() + cap, prepared_utc=datetime.now(timezone.utc).isoformat(),
         source_freeze=ref(freeze_path), root_accounting_slot=attempt_id)
    admission['argv'] = [python, '-X', 'utf8', '-B', str((SOURCE / 'selftest.py').resolve()), '--worker',
         '--group', wire, '--admission', str(admission_path.resolve()), '--admission-sha256',
         '@ADMISSION_SHA256@', '--output', str(worker.resolve())]
    admission['external_log_escrows'] = {key.replace('RUNS/B_RECOVERY_03/', 'RUNS/' + attempt_id + '/'): val
         for key, val in admission['external_log_escrows'].items()}
    admission['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller'] = ref(controller_path)
    if wire == 'W':
        for key in list(admission['external_log_escrows']):
            if '/inner/B03/' in key or '/inner/B04/' in key:
                del admission['external_log_escrows'][key]
            elif '/inner/B02/' in key:
                admission['external_log_escrows'][key.replace('/inner/B02/', '/inner/')] = admission['external_log_escrows'].pop(key)
        admission['accounting_profile']['enforce_start_free'] = True
        wf = {'schema': 'M3_R13_W_INPUT_BINDER_FREEZE_V1', 'run_id': 'W01',
             'nonce': __import__('uuid').uuid4().hex, 'templates': admission['fixture_templates'],
             'physical_budgets': {'all_stores': 8589934592, 'delivery': 8589934592,
                                  'raw_plain': 4631191552, 'all_other': 3958743040}}
        wp = base / 'W_INPUT_FREEZE.json'
        save(wp, wf)
        admission.update(w_input_freeze_ref=ref(wp), resource_profile='PASS')
    save(admission_path, admission)
    ar = ref(admission_path)
    contract = {'schema': 'M3_R13_ROOT_RUN_CONTRACT_V1', 'root_approved': True, 'slot': wire,
         'wire_group': wire, 'repair_group': 'B', 'new_user_authority': ref(authority_path),
         'plan_sha256': admission['plan_sha256'], 'cap_seconds': cap, 'all_target_writers_closed': True,
         'frozen_files': [*freeze['frozen_files'], ref(freeze_path), ar, ref(controller_path)],
         'target_script': str((SOURCE / 'job_bridge.py').resolve()),
         'argv': [python, '-X', 'utf8', '-B', str((SOURCE / 'job_bridge.py').resolve()), '--execute-one',
              '--admission', str(admission_path.resolve()), '--admission-sha256', ar['sha256'],
              '--owner-output', str(owner.resolve())],
         'worker_result_relative_path': (worker / ('WORKER_COMPLETE.json' if wire == 'W' else 'WORKER_LOCAL_RESULT.json')).relative_to(OUT / 'RUNS' / attempt_id).as_posix(),
         'bridge_result_relative_path': 'inner/GROUP_COMPLETE.json',
         'expected_case_ids': ['P001'] if wire == 'P1' else (['W01'] if wire == 'W' else [f'B{i:02d}' for i in range(1, 13)])}
    if wire != 'W':
        contract['attempt_id'] = attempt_id
    else:
        contract['frozen_files'].append(ref(base / 'W_INPUT_FREEZE.json'))
    cp = base / 'ROOT_CONTRACT.json'
    save(cp, contract)
    print(json.dumps(ref(cp)))
