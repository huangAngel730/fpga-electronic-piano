"""R13 root-only bounded Git transport using the frozen successful R12 owner."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import types

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
NAME = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
CLOSE = ROOT / 'code/docs/test' / NAME / 'backend_stream_r13_20261018/backend_close'
OWNER = ROOT / 'code/software' / NAME / 'frontend_close_r12_20261018/selftest.py'
GIT = Path('C:/Program Files/Git/cmd/git.exe')


def read(path):
    return json.loads(path.read_text('utf-8'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


parser = argparse.ArgumentParser()
parser.add_argument('action', choices=('query', 'query_direct', 'fetch', 'push'))
parser.add_argument('operation_id')
args = parser.parse_args()
assert args.operation_id.replace('_', '').isalnum()
ledger = read(OUT / 'CONSUMPTION_LIVE.json')
net = ledger['network']
assert len(net['operations']) < net['operations_max']
assert not any(row['operation_id'] == args.operation_id or row['state'] == 'RUNNING' for row in net['operations'])
cap = {'query': 30, 'query_direct': 30, 'fetch': 60, 'push': 300}[args.action]
charged = sum(row['charged_seconds'] for row in net['operations'])
assert charged + cap <= net['charged_cap_seconds_max']
if args.action in ('query','query_direct'):
    assert charged + cap + 360 <= net['charged_cap_seconds_max'], 'RESERVE_FINAL_PUSH_AND_FETCH'
deadline = datetime.fromisoformat(ledger['deadline'])
assert datetime.now(timezone.utc) + timedelta(seconds=cap + 60) <= deadline
assert hashlib.sha256(GIT.read_bytes()).hexdigest() == '851535ccc041bed536a23b17200cd51e7b06e266a527f4eaf8338b5c256c6466'
raw = OWNER.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c'
module = types.ModuleType('_r13_unchanged_R12_transport_owner')
module.__file__ = str(OWNER)
exec(compile(raw, str(OWNER), 'exec', dont_inherit=True), module.__dict__)
# Private business adapter: only relocate the scratch boundary to R13.
# This is not a modification of the frozen file or any shared module object.
module.OUTPUT = OUT
argv = [str(GIT), '-c', 'http.proxy=http://127.0.0.1:7892', '-c', 'http.version=HTTP/1.1', '-c', 'credential.interactive=false']
if args.action in ('query_direct','fetch','push'):
    argv = [str(GIT), '-c', 'http.proxy=', '-c', 'https.proxy=', '-c', 'http.version=HTTP/1.1', '-c', 'credential.interactive=false']
argv += {'query_direct': ['ls-remote', '--exit-code', 'origin', 'refs/heads/develop'],
         'query': ['ls-remote', '--exit-code', 'origin', 'refs/heads/develop'],
         'fetch': ['fetch', 'origin'],
         'push': ['-c', 'http.postBuffer=33554432', 'push', '--porcelain', '--quiet', 'origin', 'develop']}[args.action]
row = {'operation_id': args.operation_id, 'action': args.action, 'charged_seconds': cap,
       'started_utc': datetime.now(timezone.utc).isoformat(), 'state': 'RUNNING', 'argv': argv,
       'owner_sha256': hashlib.sha256(raw).hexdigest(), 'old_R12_charges_not_reused': True}
row['private_output_boundary_adapter'] = str(OUT)
row['new_user_authority'] = 'RECOVERY_TASK0_20261019/USER_AUTHORITY_AND_QUEUE.json'
row['route'] = 'DIRECT_HTTPS_NEW_USER_TASK0' if args.action in ('query_direct','fetch','push') else 'ORIGINAL_PROXY'
net['operations'].append(row)
save(OUT / 'CONSUMPTION_LIVE.json', ledger)
destination = OUT / 'NETWORK' / args.operation_id
destination.parent.mkdir(exist_ok=True)
assert not destination.exists()
result = module.owned_call(argv, ROOT, destination, cap)
row.update(actual_result=result, state='PASS' if result['exit_code'] == 0 else 'UNKNOWN_TIMEOUT' if result['exit_code'] == 124 else 'FAILED',
           ended_utc=datetime.now(timezone.utc).isoformat(), output=destination.relative_to(ROOT).as_posix())
save(OUT / 'CONSUMPTION_LIVE.json', ledger)
print(json.dumps({'operation_id': args.operation_id, 'state': row['state'], 'exit_code': result['exit_code'], 'elapsed_seconds': result['elapsed_seconds'],
                  'stdout': (destination / 'stdout.bin').read_text('utf-8', errors='replace')[:2000]}))
raise SystemExit(0 if row['state'] == 'PASS' else 1)
