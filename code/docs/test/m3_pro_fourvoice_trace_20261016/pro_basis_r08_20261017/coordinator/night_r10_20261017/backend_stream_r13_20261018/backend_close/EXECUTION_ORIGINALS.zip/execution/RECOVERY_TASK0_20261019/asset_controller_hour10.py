"""Approved W-hour incremental transport; original R13 network charges untouched."""
import argparse,hashlib,json,types
from pathlib import Path
from datetime import datetime,timedelta,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_HOUR_REPLAY_09'
OWNER=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/frontend_close_r12_20261018/selftest.py'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=argparse.ArgumentParser();p.add_argument('contract');a=p.parse_args();cp=Path(a.contract).resolve();assert cp.is_relative_to(T);v=read(cp);op=v['operation_id'];assert op.replace('_','').isalnum()
auth=D/'AUTHORIZATION_CLOSING.json';assert hashlib.sha256(auth.read_bytes()).hexdigest()=='138582298f07c5e3103005a05eb574be3c71af397d9b99bc1ae3483035e4ae79' and read(auth)['approved']
assert v['method'] in ('upload','download','notify');cap={'upload':300,'download':60,'notify':30}[v['method']];assert v['cap_seconds']==cap
extra=read(D/'CLOSING_CONSUMPTION.json');l=read(O/'CONSUMPTION_LIVE.json');net=extra['network'];assert len(net['operations'])<3 and not any(x['operation_id']==op or x['state']=='RUNNING' for x in net['operations'])
assert sum(x['charged_seconds'] for x in net['operations'])+cap<=390
assert datetime.now(timezone.utc)+timedelta(seconds=cap+60)<=datetime.fromisoformat(l['deadline'])
local=l['local_git'];assert sum(x.get('charged_seconds',0) for x in local['operations'])+10<=360
row={'operation_id':op,'state':'RUNNING','action':v['method'],'charged_seconds':cap,'contract_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),'separate_new_user_approved_increment':True};net['operations'].append(row);local['operations'].append({'operation_id':op+'_credential','charged_seconds':10,'state':'PRECHARGED','scope':'Existing Git helper memory-only credential'});save(D/'CLOSING_CONSUMPTION.json',extra);save(O/'CONSUMPTION_LIVE.json',l)
raw=OWNER.read_bytes();assert hashlib.sha256(raw).hexdigest()=='5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c'
m=types.ModuleType('_hour_asset_owner');m.__file__=str(OWNER);exec(compile(raw,str(OWNER),'exec',dont_inherit=True),m.__dict__);m.OUTPUT=O
argv=['C:/Users/songdongkuan/miniconda3/python.exe','-X','utf8','-B',str(T/'asset_worker_exact.py'),str(cp),'--sha256',row['contract_sha256']]
result=m.owned_call(argv,R,O/'NETWORK'/op,cap)
row.update(state='PASS' if result['exit_code']==0 else 'UNKNOWN_OR_FAILED',actual_result=result);local['operations'][-1]['state']='COMPLETED_NO_SECRET_LOGGED';save(D/'CLOSING_CONSUMPTION.json',extra);save(O/'CONSUMPTION_LIVE.json',l)
print(json.dumps({'operation_id':op,'state':row['state'],'exit_code':result['exit_code'],'elapsed_seconds':result['elapsed_seconds']}));raise SystemExit(0 if row['state']=='PASS' else 1)
