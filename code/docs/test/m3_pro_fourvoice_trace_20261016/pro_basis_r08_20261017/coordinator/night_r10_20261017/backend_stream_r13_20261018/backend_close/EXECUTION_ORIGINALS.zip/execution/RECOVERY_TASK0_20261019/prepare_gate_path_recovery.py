"""Register one user-authorized Gate01 path-contract successor without resetting old consumption."""
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
TASK = OUT / "RECOVERY_TASK0_20261019/GATE_PATH_RECOVERY_11"
LEDGER = OUT / "CONSUMPTION_LIVE.json"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def stamp(path):
    raw = path.read_bytes()
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


ledger = read(LEDGER)
old = ledger["groups"]["GATE_01"]
assert old["state"] == "FAILED_STOP"
assert old["attempts"] == 1 and old["charged_seconds"] == 900
assert old["actual_result"]["exit_code"] == 97
assert ledger["recovery_attempts"].get("GATE_01_PATH_01") is None
proposal = TASK / "EXECUTION_PROPOSAL.json"
authorization = TASK / "AUTHORIZATION.json"
assert stamp(proposal)["sha256"] == (
    "f37858aea57ac1677ed7c20a81b6c2751b235aaba8f59f1a2862951e8a9ba4fd"
)
auth = read(authorization)
assert auth["approved"] is True
assert auth["approved_proposal_sha256"] == stamp(proposal)["sha256"]
ledger["recovery_attempts"]["GATE_01_PATH_01"] = {
    "state": "NOT_STARTED",
    "attempts": 0,
    "charged_seconds": 0,
    "cap_seconds": 900,
    "runs": 1,
    "purpose": "absolute tool-path corrected Gate01 successor",
    "authority": stamp(authorization),
    "old_failed_group": "GATE_01",
    "old_charge_preserved": True,
}
ledger["closure_time_authority"] = {
    "status": "DIRECT_USER_NO_TIME_LIMIT_2026_10_19",
    "scope": "finish current R13 closure only",
    "original_START_unchanged": True,
    "old_deadline_retained_as_historical_runtime_cutoff": ledger["deadline"],
    "no_non_time_budget_reset": True,
}
LEDGER.write_text(
    json.dumps(ledger, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps(ledger["recovery_attempts"]["GATE_01_PATH_01"], ensure_ascii=False))
