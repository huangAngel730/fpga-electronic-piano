"""Private, source-pinned R12 -> R11 -> R10 -> real D4 binding.

Only private module dictionaries are adapted.  Frozen files and canonical
``sys.modules`` entries are never changed.
"""
from __future__ import annotations

import builtins
import hashlib
import os
from pathlib import Path
from types import ModuleType, SimpleNamespace
import uuid

from stream_bridge import CHUNK, Reject, require
from volume_io import STREAM_SUFFIXES, VolumeStore

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
R12 = HERE.parent / "frontend_close_r12_20261018"
PINS = {
    "json_identity.py": "d601d68bb2ee5d4ba4c4a435bdf3709dc943f05bb4858d516b854c507c9e6ae4",
    "capture_identity.py": "360731186004a9008e8a5e1cac1bb32c059b8653a380dc39ee3bb9be45b17bbb",
    "capture_link_successor.py": "369b6f5b4f692ea86013ce02c92bf411e7469175a3b8671f1ba2abcdcd551328",
    "capture_entry.py": "b993a2cfd35cb2b435cda5ce2be1533c2f8836f8448b2aa7dd5237f2c6e5699e",
}


def _source(name: str) -> bytes:
    path = R12 / name
    raw = path.read_bytes()
    require(len(raw) <= 4 * CHUNK and
            hashlib.sha256(raw).hexdigest() == PINS[name],
            "R13_FROZEN_SOURCE_CHANGED:" + name)
    return raw


def _module(name: str, imports: dict[str, ModuleType] | None = None) -> ModuleType:
    path, raw = R12 / name, _source(name)
    module = ModuleType("_r13_private_" + name.replace(".", "_") + "_" +
                        uuid.uuid4().hex)
    module.__file__, module.__package__ = str(path), ""
    original_import = builtins.__import__
    def private_import(target, globals=None, locals=None, fromlist=(), level=0):
        if level == 0 and imports and target in imports:
            return imports[target]
        return original_import(target, globals, locals, fromlist, level)
    module.__dict__["__builtins__"] = {**vars(builtins),
                                       "__import__": private_import}
    exec(compile(raw, str(path), "exec", dont_inherit=True), module.__dict__)
    return module


def _volume_policy(ci, ji, store: VolumeStore, output_root: Path):
    base_path, base_io = ci.ArtifactPath, ci.ArtifactIO

    class LogicalPath(base_path):
        def _volume(self):
            return (self.value.resolve().is_relative_to(store.workspace) and
                    store.is_volume(self.value))

        def exists(self):
            return self._volume() or self.value.exists()

        def is_file(self):
            return self._volume() or self.value.is_file()

        def stat(self, *args, **kwargs):
            if self._volume():
                return SimpleNamespace(st_size=store.descriptor(self.value)["bytes"])
            return self.value.stat(*args, **kwargs)

    class LogicalIO(base_io):
        def path(self, value, *parts):
            if isinstance(value, LogicalPath) and value.policy is self and not parts:
                return value
            return LogicalPath(self, Path(value, *parts))

        def _logical(self, value):
            path = ji.safe_path(value)
            if not path.is_relative_to(output_root):
                return False
            if path.suffix.casefold() in STREAM_SUFFIXES:
                return True
            return path.is_relative_to(store.workspace) and store.is_volume(path)

        def register(self, descriptor, root=ROOT, *, external=False,
                     declared=True, role=None):
            require(type(descriptor) is dict and
                    {"path", "bytes", "sha256"} <= descriptor.keys(),
                    "FILE_DESCRIPTOR")
            raw_path = Path(descriptor["path"])
            path = ji.safe_path(raw_path if raw_path.is_absolute() else Path(root) / raw_path)
            if not self._logical(path):
                return super().register(descriptor, root, external=external,
                                        declared=declared, role=role)
            require((external or path.is_relative_to(Path(root).resolve())) and
                    store.is_volume(path), "DESCRIPTOR_SCOPE")
            stamp = {"path": str(path), "bytes": descriptor["bytes"],
                     "sha256": descriptor["sha256"]}
            require(store.descriptor(path) == {"bytes": descriptor["bytes"],
                                               "sha256": descriptor["sha256"]},
                    "VOLUME_DESCRIPTOR_IDENTITY")
            key, prior = str(path).casefold(), self.expected(path)
            require(prior is None or
                    {k: prior["stamp"][k] for k in ("bytes", "sha256")} ==
                    {k: stamp[k] for k in ("bytes", "sha256")},
                    "CONFLICTING_PATH_IDENTITY")
            roles = set(prior.get("roles", [])) if prior else set()
            if role:
                roles.add(role)
            self.registry[key] = {"stamp": stamp, "root": Path(root).resolve(),
                                  "external": external,
                                  "declared": bool(declared or
                                                   (prior and prior["declared"])),
                                  "roles": sorted(roles)}
            return path

        def open(self, value, mode="r", buffering=-1, encoding=None,
                 errors=None, newline=None, **kwargs):
            path = ji.safe_path(value)
            writing = any(flag in mode for flag in "wax+")
            is_stored = (path.is_relative_to(store.workspace) and
                         store.is_volume(path))
            if ((writing and path.is_relative_to(store.workspace) and
                 path.suffix.casefold() in STREAM_SUFFIXES) or
                    (not writing and is_stored)):
                require(not kwargs and "+" not in mode and "a" not in mode,
                        "VOLUME_OPEN_OPTIONS")
                if writing:
                    self.write_path(path)
                entry = self.expected(path)
                expected = entry["stamp"] if entry else None
                self.metrics["opens"] += 1
                return store.open(path, mode, expected)
            return super().open(path, mode, buffering=buffering,
                                encoding=encoding, errors=errors,
                                newline=newline, **kwargs)

        def identity(self, value):
            path = ji.safe_path(value)
            if (not path.is_relative_to(store.workspace) or
                    not store.is_volume(path)):
                return super().identity(path)
            expected = store.descriptor(path)
            digest, count = hashlib.sha256(), 0
            self.metrics["opens"] += 1
            with store.open(path, "rb", expected) as stream:
                while True:
                    block = stream.read(CHUNK)
                    if not block:
                        break
                    require(len(block) <= CHUNK, "READ_REQUEST_BOUND")
                    digest.update(block)
                    count += len(block)
            actual = {"bytes": count, "sha256": digest.hexdigest()}
            require(actual == expected, "VOLUME_IDENTITY_MISMATCH")
            self.metrics["stream_verified"] += 1
            return actual

    return LogicalIO


def run_frozen_chain(envelope: dict, dependency_ref: dict, output_dir: Path,
                     quota_bytes: int) -> dict:
    """Invoke the real frozen successor once under a private volume policy."""
    output_dir = Path(output_dir).resolve()
    output_root = output_dir.parent.resolve()
    require(output_dir != output_root and output_dir.is_relative_to(output_root),
            "R13_PRIVATE_OUTPUT_SCOPE")
    # Keep the logical D4 output child fresh.  The volume store lives in its
    # already-created stable output parent and serves every descendant.
    store = VolumeStore(output_root, quota_bytes)
    ji = _module("json_identity.py")
    ji.OUTPUT = output_root
    ci = _module("capture_identity.py", {"json_identity": ji})
    ci.OUTPUT = output_root
    ci.ArtifactIO = _volume_policy(ci, ji, store, output_root)
    successor = _module("capture_link_successor.py",
                        {"json_identity": ji, "capture_identity": ci})
    successor.OUTPUT = output_root
    capture = _module("capture_entry.py", {
        "json_identity": ji, "capture_link_successor": successor})
    result = capture.process(envelope, output_dir,
                             dependency_ref=dependency_ref)
    result["R13_volume_store"] = {
        "schema": "M3_R13_VOLUME_STORE_SUMMARY_V1",
        "physical_bytes": store.physical_bytes(),
        "quota_bytes": quota_bytes,
        "logical_volumes": sorted(store.entries.values(),
                                  key=lambda item: item["logical_path"]),
        "direct_plaintext_intermediate": False,
    }
    return result
