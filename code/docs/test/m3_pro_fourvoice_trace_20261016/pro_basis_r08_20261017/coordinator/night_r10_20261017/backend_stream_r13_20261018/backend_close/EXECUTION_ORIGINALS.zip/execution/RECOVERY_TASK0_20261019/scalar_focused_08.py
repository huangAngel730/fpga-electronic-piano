"""Bounded exact-AST-body scalar equivalence unit; never substitutes for D4."""
import ast,hashlib,json,re,sys,types
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';D=O/'RECOVERY_TASK0_20261019';S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
if sys.argv[1]=='worker':
 old=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017/public_capture_tb/assemble.py'
 raw=old.read_bytes();assert hashlib.sha256(raw).hexdigest()=='c2339e73c61ba4b04231e9c08a34fd364c365e6cd67ce70007956faf5eb6c003'
 nodes=ast.parse(raw.decode('utf-8')).body;selected=[n for n in nodes if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('Reject','need','scalar')]
 env={'re':re};exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(old),'exec'),env);original=env['scalar']
 tree=ast.parse((S/'binding.py').read_text('utf-8'));candidates=[n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='scalar'];assert len(candidates)==1
 unit={'cache':{},'original_scalar':original};exec(compile(ast.fix_missing_locations(ast.Module(body=candidates,type_ignores=[])),str(S/'binding.py'),'exec'),unit);memo=unit['scalar']
 def outcome(fn,bits,spec):
  try:return ('VALUE',type(fn(bits,spec)).__name__,fn(bits,spec))
  except Exception as e:return ('ERROR',type(e).__name__,str(e))
 count=0
 portmap=read(R/'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017/public_capture_tb/c9_binding/PORT_MAP_C9.json')['raw_ports']
 raw_path=O/'RUNS/B_RECOVERY_04/inner/B02/worker/inputs/B08/RAW.jsonl'
 with raw_path.open('rb') as f:
  for line in f:
   for name,bits in json.loads(line)['ports'].items():
    spec=portmap[name];assert outcome(original,bits,spec)==outcome(memo,bits,spec);count+=1
 for width in (1,24,32,64):
  for signed in (False,True):
   spec={'width':width,'signed':signed}
   for bits in ('0'*width,'1'*width,'X'*width,'z'*width,'','2'*width,None,1):
    assert outcome(original,bits,spec)==outcome(memo,bits,spec);count+=1
 assert len(unit['cache'])<=4096
 save(D/'SCALAR_FOCUSED_08_RESULT.json',{'status':'PASS','comparisons':count,'scope':'Exact production scalar AST body with captured-global bindings compared to unchanged original scalar; this is a focused unit, not D4 runtime','real_current_D4_B01_complete':str(O/'RUNS/B_SCALAR_06/inner/B02/worker/cases/B01/COMPLETE.json'),'previous_B12_reference':'RUNS/B04_RECOVERY_05/inner/GROUP_COMPLETE.json','cache_limit':4096})
else:
 l=read(O/'CONSUMPTION_LIVE.json');assert l['recovery_attempts']['B_SCALAR_06']['state']=='FAILED_STOP';assert l['recovery_attempts']['P1_SCALAR_01']['state']=='PASS'
 assert read(O/'RUNS/B_SCALAR_06/inner/B02/worker/cases/B01/COMPLETE.json')['status']=='COMPLETE_SOFTWARE_ONLY'
 assert read(O/'RUNS/B04_RECOVERY_05/inner/GROUP_COMPLETE.json')['status']=='PASS'
 assert 'SCALAR_FOCUSED_08' not in l['recovery_attempts'];row={'state':'CONSUMED_BEFORE_LAUNCH','attempts':1,'charged_seconds':30,'cap_seconds':30,'authority':'User up to8 evidence-based repairs; original full B timeout retained; exact pure-function comparison plus actual current B01 and prior unchanged B12 reuse'};l['recovery_attempts']['SCALAR_FOCUSED_08']=row;save(O/'CONSUMPTION_LIVE.json',l)
 old=S.parent/'frontend_close_r12_20261018/selftest.py';raw=old.read_bytes();assert hashlib.sha256(raw).hexdigest()=='5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c';m=types.ModuleType('_focused_owner');m.__file__=str(old);exec(compile(raw,str(old),'exec'),m.__dict__);m.OUTPUT=O
 result=m.owned_call([str(Path(sys.executable).resolve()),'-X','utf8','-B',str(Path(__file__).resolve()),'worker'],R,O/'RUNS/SCALAR_FOCUSED_08',30)
 good=result['exit_code']==0 and result['exit_class']=='NATURAL' and all(result[k] for k in ('within_cap','job_handle_closed','root_process_handle_closed','job_zero_observed_before_job_close'))
 row.update(state='PASS' if good else 'FAILED_STOP',actual_result=result,focused_result=read(D/'SCALAR_FOCUSED_08_RESULT.json') if good else None);save(O/'CONSUMPTION_LIVE.json',l)
 assert good
 raw=(D/'root_run_scalar_recovery.py').read_text('utf-8').replace("get('B_SCALAR_06', {}).get('state') == 'PASS'","get('SCALAR_FOCUSED_08', {}).get('state') == 'PASS'").replace("['B_SCALAR_06']['state']=='PASS'","['SCALAR_FOCUSED_08']['state']=='PASS'")
 (D/'root_run_scalar_reconciled.py').write_text(raw,encoding='utf-8',newline='\n')
 print(json.dumps({'status':'PASS','comparisons':row['focused_result']['comparisons']}))
