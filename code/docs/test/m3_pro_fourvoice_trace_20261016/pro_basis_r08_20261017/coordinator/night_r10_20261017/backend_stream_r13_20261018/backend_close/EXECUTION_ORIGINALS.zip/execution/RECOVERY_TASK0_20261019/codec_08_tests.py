"""Bounded production writer/scalar-cache differential checks, not a D4 replacement."""
import argparse,hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018'
S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
p=argparse.ArgumentParser();p.add_argument('--admission',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
raw=a.admission.read_bytes();assert hashlib.sha256(raw).hexdigest()==a.sha256;v=json.loads(raw)
sys.path.insert(0,str(S));import resources,binding
from volume_io import VolumeStore,DECODED_PART_LIMIT
from finalize import atomic_json
resources.configure_accounting(v['accounting_profile'],v['external_log_escrows'],v['root_deadline_monotonic'])
out=a.output.resolve();assert out==O/'RUNS/C_CODEC_08/inner/worker' and not out.exists();resources.accounting_mkdir(out,parents=True,exist_ok=False)
store=VolumeStore(out);cases=[]
def passed(cid,observed):cases.append({'id':cid,'status':'PASS','observed':observed})
def writer_case(cid,chunks):
    path=out/(cid+'.csv');expected=b''.join(x.encode('utf-8') for x in chunks);counter=0
    with store.open(path,'x') as w:
        for text in chunks:
            w.write(text);counter+=len(text.encode('utf-8'));before=w.buffer.count
            assert w.tell()==counter and w.buffer.count==before,'TELL_FLUSHED_OR_WRONG_OFFSET'
    assert store.descriptor(path)=={'bytes':len(expected),'sha256':hashlib.sha256(expected).hexdigest()}
    h=hashlib.sha256();n=0
    with store.open(path,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
    assert n==len(expected) and h.hexdigest()==hashlib.sha256(expected).hexdigest()
    try:w.tell()
    except ValueError:pass
    else:raise AssertionError('CLOSED_TELL_ACCEPTED')
    passed(cid,{'bytes':n,'parts':len(store.manifest(path)['parts']),'closed_tell_rejected':True})
writer_case('C01',['abc','def'])
writer_case('C02',['中文','🎹','é','\u0000'])
writer_case('C03',['a\r\n','b\n','\r','c'])
writer_case('C04',['x'*8191,'🎹','y'*8193])
writer_case('C05',['',''])
writer_case('C06',['z'*1048576]*(DECODED_PART_LIMIT//1048576)+['tail🎹'])
class Sentinel(ValueError):pass
failure=Sentinel('INJECTED_WRITER_FAILURE');path=out/'C07.csv';w=store.open(path,'x')
def failing_write(data):raise failure
w.buffer.write=failing_write
try:
    with w:w.write('q'*8193)
except Sentinel as error:assert error is failure
else:raise AssertionError('WRITE_FAILURE_SWALLOWED')
assert not store.folder_for(path).joinpath('MANIFEST.json').exists()
passed('C07',{'same_primary_exception':True,'failure_has_no_manifest':True})
strict=binding._module('json_identity.py');original_support=SimpleNamespace(loads=strict.parse,marker=object())
m=SimpleNamespace(json=json,support=lambda:original_support)
binding._install_private_codec_scalar_cache(m);c=m.support();assert c.marker is original_support.marker
options={'ensure_ascii':False,'separators':(',',':'),'allow_nan':False}
values=[None,False,True,0,1,-1,2**64-1,-2**63,'','汉字','🎹','a\n"b',1.25,[0,1],{'x':[1,2]},'x'*300]
comparisons=0
for _ in range(3):
    for value in values:
        assert m.json.dumps(value,**options)==json.dumps(value,**options);comparisons+=1
assert m.json.dumps(True,**options)=='true' and m.json.dumps(1,**options)=='1'
passed('C08',{'comparisons':comparisons,'bool_int_keys_distinct':True})
for opts in ({},{'ensure_ascii':True},{'ensure_ascii':False,'sort_keys':True},{'separators':(', ',': ')}):
    for value in values:assert m.json.dumps(value,**opts)==json.dumps(value,**opts)
passed('C09',{'alternate_options_original_fallback':True})
def outcome(fn,*args,**kw):
    try:return ('VALUE',type(fn(*args,**kw)),fn(*args,**kw))
    except BaseException as error:return ('ERROR',type(error),str(error))
for value in (float('nan'),float('inf'),object(),{1,2}):assert outcome(m.json.dumps,value,**options)==outcome(json.dumps,value,**options)
passed('C10',{'invalid_dump_errors_match_original':True})
raws=['null','true','false','0','1','-1','18446744073709551615','"汉字"','"🎹"','1.25','[1,2]','{"a":1}']
for _ in range(3):
    for text in raws:assert outcome(c.loads,text)==outcome(original_support.loads,text)
passed('C11',{'strict_scalar_loads_match_original':True})
for text in ('{"x":1,"x":2}','NaN','Infinity','-Infinity','{"x":','00','[1,]','true false'):
    actual=outcome(c.loads,text);expected=outcome(original_support.loads,text);assert actual==expected and actual[0]=='ERROR'
passed('C12',{'duplicate_nonfinite_and_syntax_rejected_as_original':True})
for text in ('{"x":[1]}','[1,2]'):
    x=c.loads(text);y=c.loads(text);assert x is not y
    if isinstance(x,dict):x['x'].append(2);assert y=={'x':[1]}
    else:x.append(3);assert y==[1,2]
passed('C13',{'containers_fresh_no_cross_row_alias':True})
for i in range(5000):m.json.dumps(i,**options);c.loads(str(i))
def closure(function,name):return dict(zip(function.__code__.co_freevars,[x.cell_contents for x in function.__closure__]))[name]
assert len(closure(m.json.dumps,'dump_cache'))<=4096
assert len(closure(c.loads.__func__,'load_cache'))<=4096
passed('C14',{'cache_bounds':4096})
n=SimpleNamespace(json=json,support=lambda:original_support);binding._install_private_codec_scalar_cache(n)
assert closure(n.json.dumps,'dump_cache') is not closure(m.json.dumps,'dump_cache')
assert c.loads(b'1')==original_support.loads(b'1')
assert json.dumps(True)=='true' and m.json is not json
passed('C15',{'private_module_isolation':True,'bytes_input_original_fallback':True})
result={'schema':'M3_R13_WORKER_COMPLETE_V1','status':'PASS','group':'C','cases':cases,'actual_scope':'Production UTF8 writer and private codec scalar cache differential unit only; full actual D4 B/W remain separately required','global_budget':resources.get_budget().receipt(),'real_verified':False,'math_verified':False,'board_release_allowed':False}
atomic_json(out/'WORKER_COMPLETE.json',result);print(json.dumps({'status':'PASS','cases':len(cases)}))
