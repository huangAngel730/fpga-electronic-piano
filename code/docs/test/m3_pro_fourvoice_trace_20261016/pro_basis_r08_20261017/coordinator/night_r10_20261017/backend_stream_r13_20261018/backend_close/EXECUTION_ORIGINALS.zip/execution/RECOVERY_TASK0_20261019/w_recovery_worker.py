"""Located W successor; reuse the complete frozen input from failed W, never its partial outputs."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
p = argparse.ArgumentParser(); p.add_argument('--admission', type=Path, required=True); p.add_argument('--sha256', required=True); p.add_argument('--output', type=Path, required=True); a = p.parse_args()
raw = a.admission.read_bytes(); assert hashlib.sha256(raw).hexdigest() == a.sha256
admission = json.loads(raw)
assert admission['purpose'] == 'W_SCALAR_CACHE_FROZEN_INPUT_SUCCESSOR'
sys.path.insert(0, str(SOURCE))
import resources, entry, selftest
from stream_bridge import read_control, identity
from finalize import atomic_json
resources.configure_accounting(admission['accounting_profile'], admission['external_log_escrows'], admission['root_deadline_monotonic'])
output = a.output.resolve(); assert output == OUT / 'RUNS/W_RECOVERY_07/inner/worker' and not output.exists()
resources.accounting_mkdir(output, parents=True, exist_ok=False)
inputs = Path(admission['frozen_input_directory'])
for descriptor in admission['frozen_inputs']:
    assert identity(Path(descriptor['path'])) == {k:descriptor[k] for k in ('bytes','sha256')}
control = inputs / 'CONTROL.json'
request = read_control(inputs / 'CAPTURE_REQUEST.json')['value']
raw_ref = request['inputs']['raw']
assert raw_ref['bytes'] >= selftest.MIN_RAW_BYTES
actual_input = {}
def observe(event, payload):
    if event == 'after_backend_before_final_verify':
        actual_input.update(payload['result']['inputs']['raw'])
        assert actual_input == raw_ref
entry.install_test_hook(observe)
final_dir = output / 'cases/W01'
resources.accounting_mkdir(final_dir.parent, parents=True, exist_ok=False)
try:
    complete = entry.run(control, identity(control)['sha256'], final_dir)
finally:
    entry.install_test_hook(None)
assert complete['audit']['terminal']['rows'] == selftest.MIN_ROWS and actual_input == raw_ref
delivery = selftest._export_w_originals(admission, final_dir, inputs, actual_input)
result = {'schema':'M3_R13_WORKER_COMPLETE_V1','status':'PASS','group':'W',
 'cases':[{'id':'W01','status':'PASS','observed':{'terminal':complete['audit']['terminal'],'raw_input':raw_ref,'delivery':delivery,
 'whole_output_resources':resources.disk_snapshot(OUT),'global_budget':resources.get_budget().receipt(),
 'input_generation_origin':'First failed W generated full1130662-row input within its charged900s; this successor rehashes/reuses exact immutable input, no partial old outputs reused',
 'source_freeze':admission['source_freeze']}}], 'real_verified':False,'math_verified':False,'board_release_allowed':False}
atomic_json(output / 'WORKER_COMPLETE.json', result)
print(json.dumps({'status':'PASS','case':'W01','input_reused_from_failed_W':True}))
