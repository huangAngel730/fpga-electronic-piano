"""Task0 exact cross-PC originals transport, not R13 S1/S2 or new business execution."""
import hashlib,json,os,threading,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'FULL_W_TRANSFER_R01'
P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
B=R/'code/docs/test'/P/'backend_stream_r13_20261018/capture_originals/ORIGINALS_INDEX.json'
started=time.monotonic();deadline=started+117
timer=threading.Timer(119,lambda:os._exit(124));timer.daemon=True;timer.start()
def check():assert time.monotonic()<deadline,'TASK0_TRANSPORT_ARCHIVE_CAP_120'
def read(p):return json.loads(p.read_text('utf-8'))
def stamp(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):check();n+=len(x);h.update(x)
 return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'bytes':n,'sha256':h.hexdigest()}
class BoundedTarget:
 def __init__(self,f):self.f=f
 def write(self,b):
  v=memoryview(b);assert self.f.tell()+len(v)<=2*1024**3,'DRAFT_ASSET_2GIB_BOUND'
  for k in range(0,len(v),1048576):check();assert self.f.write(v[k:k+1048576])==len(v[k:k+1048576])
  return len(v)
 def seek(self,*a):return self.f.seek(*a)
 def tell(self):return self.f.tell()
 def flush(self):return self.f.flush()
 def seekable(self):return True
l=read(O/'CONSUMPTION_LIVE.json');assert l['recovery_attempts']['W_HOUR_10']['state']=='PASS'
manifestpath=O/'DELIVERY/W01/MANIFEST.json';manifest=read(manifestpath)
D.mkdir(exist_ok=False);archive=D/'M3_R13_CURRENT_FULL_W_AND_REQUIRED_ORIGINALS_20261019.zip'
items=[('W01/MANIFEST.json',manifestpath,stamp(manifestpath))]
final_closure_paths=[('final_closure/FINAL_HANDOFF_R13.zip',O/'FINAL_HANDOFF_R13.zip'),('final_closure/S2_SEAL_RESULT.json',O/'SEAL/S2/SEAL_RESULT.json'),('final_closure/GATE_01_RESULT.json',O/'RUNS/GATE_01/RESULT.json'),('final_closure/GATE_02_RESULT.json',O/'RUNS/GATE_02/RESULT.json'),('final_closure/PUBLICATION_ACTUAL.json',O/'PUBLICATION_ACTUAL.json'),('final_closure/CONSUMPTION_LIVE.json',O/'CONSUMPTION_LIVE.json'),('final_closure/W_TRANSFER_FREEZE_RECEIPT.json',T/'W_TRANSFER_RECEIPT.json')]
for member,p in final_closure_paths:
 assert p.is_file(),p
 items.append((member,p,stamp(p)))
shared_originals=[]
prior_asset={'asset_id':654895708,'bytes':380825742,'sha256':'e2d3ceac083c34530778367d9cf475b160749c6151321429b048314759056df5','url':'https://github.com/huangAngel730/fpga-electronic-piano/releases/download/untagged-20cfd8909421dcc18a6c/M3_R13_CURRENT_PARTIAL_ORIGINALS_20261019.zip','download_back_already_verified':True,'raw_member':'code/output/m3_backend_stream_r13_20261018/RUNS/W/inner/worker/inputs/W01/RAW.jsonl'}
for obj in manifest['originals']:
 if obj['source']['sha256']=='b8c0efe717b64c9c370b8e1116b97d59b0843ff9611ec7b4e37d451687e470fe' and obj['source']['bytes']==3062558030:
  shared_originals.append({'original':obj,'prior_asset':prior_asset,'restore':'Verify prior ZIP and exact RAW member, then reproduce each current export part by its offset/length and verify part SHA; do not alter raw bytes. Same original was actually copied/readback inside current W; transport dedup only.'})
  continue
 for part in obj['parts']:
  p=R/part['path'];items.append(('W01/'+p.name,p,{k:part[k] for k in ('path','bytes','sha256')}))
assert len(shared_originals)==1
retained_previous=[]
extras={}
for name,obj in read(B)['objects'].items():
 if obj.get('locator',{}).get('kind') not in ('local_original_pending_transfer','user_forwarded_package_file','local_control_file'):continue
 p=Path(obj['path'])
 if not p.is_absolute():p=R/p
 ref={k:obj[k] for k in ('path','bytes','sha256')};member='required_originals/'+name+'/'+p.name
 items.append((member,p,ref));extras[name]={'original':ref,'transport_member':member}
assert len(extras)==17 and len(items)<=4096 and len({x[0] for x in items})==len(items)
assert sum(x[2]['bytes'] for x in items)<=9*1024**3
# No retained file is removed; own 24GiB and reserve guard also covers the bounded transport copy.
current=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
assert current+2*1024**3+16384*4095<=24*1024**3
assert __import__('shutil').disk_usage(O).free>=8*1024**3+2*1024**3
record=[]
with archive.open('xb',buffering=0) as raw:
 with zipfile.ZipFile(BoundedTarget(raw),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=False) as z:
  for name,p,ref in items:
   count=0;h=hashlib.sha256()
   with p.open('rb',buffering=0) as src,z.open(name,'w') as sink:
    for block in iter(lambda:src.read(1048576),b''):check();count+=len(block);assert count<=ref['bytes'];h.update(block);assert sink.write(block)==len(block)
   assert count==ref['bytes'] and h.hexdigest()==ref['sha256'],name
   record.append({'member':name,'original':ref})
  transfer={'schema':'M3_R13_TASK0_FINAL_TRANSPORT_MANIFEST_V2','members':record,'required_originals_mapping':extras,'retained_previous_run_volumes':retained_previous,'prior_required_asset':prior_asset,'shared_byte_identical_raw_original':shared_originals,'W_original_manifest':stamp(manifestpath),'restore':'Verify archive SHA, extract exact W01 members, then concatenate each original parts in MANIFEST order. Restore existing internal volume manifests and gzip bytes without edits; use original logical reader to validate decoded lengths/SHA. Empty files/directories are explicitly recorded.','old_manifest_legacy_status':'EXPORT_VERIFIED_PENDING_USER_TRANSFER is creation-time state; this archive is locally verified before its one authorized private GitHub upload. The later ignored transfer receipt/comment records actual upload and download-back. It does not assert recipient receipt.','real_verified':False,'math_verified':False,'M2_RECEIVED':False}
  z.writestr('TRANSFER_MANIFEST.json',json.dumps(transfer,ensure_ascii=False,indent=2)+'\n')
 raw.flush();os.fsync(raw.fileno())
# Read back each member to EOF; ZipFile checks CRC and we verify exact byte identities.
with zipfile.ZipFile(archive) as z:
 assert z.namelist()==[x[0] for x in items]+['TRANSFER_MANIFEST.json']
 for name,p,ref in items:
  count=0;h=hashlib.sha256()
  with z.open(name) as src:
   for block in iter(lambda:src.read(1048576),b''):check();count+=len(block);h.update(block)
  assert count==ref['bytes'] and h.hexdigest()==ref['sha256']
 assert json.loads(z.read('TRANSFER_MANIFEST.json'))==transfer
receipt={'schema':'M3_R13_TASK0_FINAL_TRANSPORT_ARCHIVE_V2','status':'LOCAL_ORIGINALS_ARCHIVE_VERIFIED_NOT_YET_UPLOADED','file':stamp(archive),'W_original_manifest':stamp(manifestpath),'payload_members':len(items),'required_originals_mapping':extras,'all_payload_sizes_SHAs_CRC_verified':True,'elapsed_seconds':time.monotonic()-started,'created_utc':datetime.now(timezone.utc).isoformat(),'contains_immutable_S2_and_gate_publication_receipts':True,'this_is_not_S1_or_S2':True,'M2_RECEIVED':False}
(D/'ARCHIVE_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
check();timer.cancel();print(json.dumps({k:receipt[k] for k in ('status','file','payload_members','elapsed_seconds')}))
