"""Root-only conditional repair identity freeze. Never imports a target."""
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018'
S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def stamp(p):
 p=p.resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),'bytes':n,'sha256':h.hexdigest()}
fix=read(O/'LOCATED_REPAIR.json');ledger=read(O/'CONSUMPTION_LIVE.json')
assert fix['failed_group'] in ('K','V','B') and ledger['groups'][fix['failed_group']]['state']=='FAILED_STOP'
assert ledger['groups']['P0']['state']=='PASS' and ledger['groups']['P1']['state']=='NOT_STARTED' and ledger['groups']['R']['state']=='NOT_STARTED'
assert fix['software_only_changed_sources_frozen'] is True and 0<len(fix['affected_case_ids'])==fix['all_affected_cases_count']<=16
assert all(x.startswith(fix['failed_group']) for x in fix['affected_case_ids'])
assert read(O/'WRITE_LEASES_CLOSED.json')['all_target_writers_closed'] is True
old=read(O/'FREEZE_BEFORE_P0.json');new=[];changed=[]
for item in old['frozen_files']:
 p=Path(item['path']);p=p if p.is_absolute() else R/p;actual=stamp(p)
 if actual['sha256']!=item['sha256'] or actual['bytes']!=item['bytes']:
  assert p.is_relative_to(S),'REPAIR_ONLY_FORMAL_C_SOURCE'
  changed.append({'old':item,'new':actual})
 new.append(actual)
assert changed and {x['new']['path'] for x in changed}==set(fix['changed_source_paths'])
for ref in fix['evidence_refs']:
 p=Path(ref['path']);p=p if p.is_absolute() else R/p;actual=stamp(p);assert actual['sha256']==ref['sha256'] and actual['bytes']==ref['bytes'];new.append(actual)
target=O/'REPAIR_FREEZE.json';assert not target.exists(),'NO_REPAIR_REFREEZE'
value={'state':'REPAIR_FROZEN_BY_ROOT','schema':'M3_R13_REPAIR_FREEZE_V1','recorded_utc':datetime.now(timezone.utc).isoformat(),'located_repair_sha256':stamp(O/'LOCATED_REPAIR.json')['sha256'],'original_P0_freeze':stamp(O/'FREEZE_BEFORE_P0.json'),'changed_sources':changed,'frozen_files':new,'target_runs':0}
target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(stamp(target)))
