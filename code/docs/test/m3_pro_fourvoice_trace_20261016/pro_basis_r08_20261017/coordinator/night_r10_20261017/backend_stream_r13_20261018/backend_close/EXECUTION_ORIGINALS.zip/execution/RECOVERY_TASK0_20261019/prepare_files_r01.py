"""Freeze and prepare each exact fresh codec08 slot; no target launched here."""
import argparse,hashlib,json,time
from datetime import datetime,timedelta,timezone
from pathlib import Path
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_FILECOUNT_RECOVERY_R01'
S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
KEYS={'P1_FILES_R01':('P1',60,1),'B_FILES_R01':('B',240,12),'W_CODEC_08':('W',1800,1)}
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v,new=True):
    assert not new or not p.exists(),str(p)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
    p=p.resolve();h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
    return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
p=argparse.ArgumentParser();p.add_argument('mode',choices=['freeze',*KEYS]);a=p.parse_args();l=read(O/'CONSUMPTION_LIVE.json');fp=D/'FREEZE.json';auth=D/'AUTHORIZATION_R01.json';controller=T/'root_run_files_r01.py'
assert read(auth)['approved'] is True and ref(auth)['sha256']=='16d412ba91b7604e1fd16daa695433a0725f2dea6c2e318f4c2cd013310704ee'
if a.mode=='freeze':
    proposal=read(D/'EXECUTION_PROPOSAL.json')
    for x in proposal['source_files']:
        f=R/x['path'];assert {k:ref(f)[k] for k in ('bytes','sha256')}=={k:x[k] for k in ('bytes','sha256')}
    previous=read(T/'W_CODEC_PERFORMANCE_REPAIR_08/FREEZE.json');items={}
    for x in previous['frozen_files']:
        f=Path(x['path']).resolve();actual=ref(f)
        assert f.is_relative_to(S) or actual==x,('UNEXPECTED_NON_R13_DEPENDENCY_CHANGE',str(f))
        items[str(f).casefold()]=actual
    for f in [*sorted(S.iterdir()),auth,D/'EXECUTION_PROPOSAL.json',D/'CAPACITY_JUSTIFICATION.json',D/'resources.diff',D/'PRELAUNCH_FILE_HEADROOM.json',T/'codec_08_bridge.py',T/'codec_08_tests.py',T/'w_codec_08_worker.py',controller]:
        assert f.is_file();items[str(f.resolve()).casefold()]=ref(f)
    frozen_inputs=read(T/'W_SCALAR_RECOVERY/FROZEN_INPUTS.json')
    for x in frozen_inputs['files']:assert ref(Path(x['path']))==x
    save(fp,{'state':'CURRENT_CODEC_REPAIR_FROZEN','all_target_writers_closed':True,'new_user_authorization':ref(auth),'frozen_files':list(items.values()),'full_raw_inputs_original':ref(T/'W_SCALAR_RECOVERY/FROZEN_INPUTS.json')})
    print(json.dumps(ref(fp)));raise SystemExit(0)
key=a.mode;wire,cap,count=KEYS[key];assert l['recovery_attempts'][key]['state']=='NOT_STARTED'
remaining=sum(x['cap_seconds'] for x in l['groups'].values() if x['state']=='NOT_STARTED')+sum(l['recovery_attempts'][k]['cap_seconds'] for k in KEYS if l['recovery_attempts'][k]['state']=='NOT_STARTED')
remaining+=1260-sum(x['charged_seconds'] for x in l['network']['operations'])+360-sum(x.get('charged_seconds',0) for x in l['local_git']['operations'])+60
assert datetime.now(timezone.utc)+timedelta(seconds=remaining)<=datetime.fromisoformat(l['deadline']),'FULL_REMAINING_CAPS_NOT_AVAILABLE'
freeze=read(fp)
for x in freeze['frozen_files']:assert ref(Path(x['path']))==x
base=O/'ADMISSIONS'/key;ap=base/'ADMISSION.json';owner=O/'RUNS'/key/'inner';worker=owner/('B02/worker' if wire=='B' else 'worker')
old='B_RECOVERY_04' if wire=='B' else 'P1_B04_01';adm=read(O/'ADMISSIONS'/old/'ADMISSION.json')
adm.update(group=wire,absolute_cap_seconds=cap,root_deadline_monotonic=time.monotonic()+cap,source_freeze=ref(fp),root_accounting_slot=key,deadline=l['deadline'],prepared_utc=datetime.now(timezone.utc).isoformat(),codec_08_authorization=ref(auth))
adm['external_log_escrows']={k.replace('RUNS/'+old+'/','RUNS/'+key+'/'):v for k,v in adm['external_log_escrows'].items()}
adm['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller']=ref(controller)
summary_example=next(iter(adm['external_log_escrows'].values()))
summary=json.loads(json.dumps(summary_example));summary['role']='parent_summary';summary['byte_cap']=1048576;summary['evidence']['bridge']=ref(T/'codec_08_bridge.py')
adm['external_log_escrows']['RUNS/'+key+'/inner/GROUP_COMPLETE.json']=summary
adm['accounting_profile']['initial_roles']={'RUNS/W/inner/worker/inputs/W01/RAW.jsonl':'raw_plain'}
py=str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
adm['argv']=[py,'-X','utf8','-B',str(S/'selftest.py'),'--worker','--group',wire,'--admission',str(ap),'--admission-sha256','@ADMISSION_SHA256@','--output',str(worker)]
if wire=='W':
    inputs=read(T/'W_SCALAR_RECOVERY/FROZEN_INPUTS.json')
    adm.update(purpose='W_CODEC_PRIVATE_CSV_CACHE_SUCCESSOR',frozen_input_directory=inputs['directory'],frozen_inputs=inputs['files'])
    adm['accounting_profile']['enforce_start_free']=True
save(ap,adm);ar=ref(ap);target=T/'codec_08_bridge.py'
argv=[py,'-X','utf8','-B',str(target),'--admission',str(ap),'--sha256',ar['sha256'],'--output',str(owner)]
cp=base/'ROOT_CONTRACT.json'
save(cp,{'root_approved':True,'slot':wire,'attempt_id':key,'wire_group':wire,'repair_group':'B','plan_sha256':adm['plan_sha256'],'cap_seconds':cap,'all_target_writers_closed':True,'new_user_authority':ref(auth),'frozen_files':[*freeze['frozen_files'],ref(fp),ref(ap),ref(controller)],'target_script':str(target),'argv':argv,'worker_result_relative_path':'inner/B02/worker/WORKER_LOCAL_RESULT.json' if wire=='B' else 'inner/worker/WORKER_LOCAL_RESULT.json' if wire=='P1' else 'inner/worker/WORKER_COMPLETE.json','bridge_result_relative_path':'inner/GROUP_COMPLETE.json','expected_case_ids':[f'B{i:02d}' for i in range(1,13)] if wire=='B' else ['P001'] if wire=='P1' else [f'C{i:02d}' for i in range(1,16)] if wire=='C' else ['W01']})
print(json.dumps(ref(cp)))
