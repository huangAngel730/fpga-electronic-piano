import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
u=read(T/'r13_current_partial_upload_01_RESULT.json');d=read(T/'r13_current_partial_download_01_RESULT.json')
assert u['status']==d['status']=='PASS' and d['asset_id']==u['asset_id'] and d['download_back']=={k:u['file'][k] for k in ('bytes','sha256')}
v={'schema':'M3_R13_CURRENT_PARTIAL_TRANSFER_V1','handoff_id':'M3-R13-CODEC08-PARTIAL-NO-REPLAY-20261019','status':'REMOTE_ASSET_DOWNLOAD_BYTE_IDENTICAL_R13_STILL_PARTIAL','file':u['file'],'asset_id':u['asset_id'],'asset_api_url':u['asset_api_url'],'browser_download_url':u['browser_download_url'],'draft_release_url':'https://github.com/huangAngel730/fpga-electronic-piano/releases/tag/untagged-20cfd8909421dcc18a6c','github_digest':u['github_digest'],'local_payloads':3585,'local_CRC_SHA_size_verified':True,'download_back_verified':True,'result_commit':None,'source_publication':'NOT_COMMITTED_NOT_PUSHED_GATE_NOT_RUN','M2_AI_RECEIVED':False,'M2_ACCEPTED':False,'user_no_full_replay':True,'updated_utc':datetime.now(timezone.utc).isoformat()}
save(T/'CURRENT_PARTIAL_TRANSFER_RECEIPT.json',v)
save(O/'scheduler_state/W_NO_REPLAY_TERMINAL.json',{'W_CODEC_08':'FAILED_STOP','user_allows_more_time':True,'user_explicitly_prohibits_full_replay':True,'not_authorized':'Any fresh W complete replay or reopening consumed slots','current_technical_block':'No live duration-renewal IPC in launched timers','current_partial_transfer':v,'new_business':'Queue only; evaluate latest authorized task, write set, times and shared consumption; never restore old Goal/charges automatically'})
method=Path('E:/FPGA/GAOYUNFPGA/GitHub上传方法.md')
with method.open('a',encoding='utf-8',newline='\n') as f:
 f.write('\n\n## 2026-10-19 当前 R13 部分原件上传实测\n\n仍使用同一私有仓库的 draft release；进程级直连 HTTPS，不修改仓库代理配置。381 MB 原件包上传约 80.187 秒、下载流式核同约 46.797 秒，两次退出 0。asset_id=654895708，380825742B，SHA-256=e2d3ceac083c34530778367d9cf475b160749c6151321429b048314759056df5，GitHub 返回 digest 与本地及下载字节一致。\n\n旧 127.0.0.1:7892 代理无监听与直连可用是本次有依据的路由差异；这不证明 postBuffer 是唯一原因。附件上传成功不等于 develop 源码发布、M2 AI 收件或验收。当前 R13 仍 PARTIAL，W 被原监督器硬超时结束，用户明确不重跑；门禁/源码提交/推送/S1/S2尚未执行。附件入口：'+v['browser_download_url']+'\n')
print(json.dumps({'status':v['status'],'asset_id':v['asset_id']}))
