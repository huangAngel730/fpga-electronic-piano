"""One authorized S1 successor: reuse verified source ZIP and create only evidence ZIP."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import time
import zipfile

ROOT = Path.cwd().resolve()
OUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
CHUNK = 1048576
ARCHIVE_LIMIT = 32 * CHUNK
STEM = "m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017"
CLOSE = ROOT / "code/docs/test" / STEM / "backend_stream_r13_20261018/backend_close"


def check():
    assert time.monotonic() < deadline, "S1_RECOVERY_SLOT_EXHAUSTED"


def identity(path):
    count = 0
    digest = hashlib.sha256()
    with path.open("rb", buffering=0) as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            check()
            count += len(block)
            digest.update(block)
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": count,
        "sha256": digest.hexdigest(),
    }


def verify(descriptor):
    path = Path(descriptor["path"])
    if not path.is_absolute():
        path = ROOT / path
    actual = identity(path)
    assert actual["bytes"] == descriptor["bytes"]
    assert actual["sha256"] == descriptor["sha256"]
    return path


class ChunkedZipTarget:
    def __init__(self, stream):
        self.stream = stream

    def write(self, value):
        data = memoryview(value)
        assert self.stream.tell() + len(data) <= ARCHIVE_LIMIT, "ARCHIVE_OVER_32MIB"
        for offset in range(0, len(data), CHUNK):
            check()
            part = data[offset : offset + CHUNK]
            assert self.stream.write(part) == len(part)
        return len(data)

    def seek(self, *args):
        return self.stream.seek(*args)

    def tell(self):
        return self.stream.tell()

    def flush(self):
        return self.stream.flush()

    def seekable(self):
        return True


def verify_reused_source(old_contract):
    spec = old_contract["archives"][0]
    source_zip = CLOSE / "SOURCE_PAYLOAD.zip"
    assert source_zip.exists()
    with zipfile.ZipFile(source_zip) as bundle:
        expected_names = [item["member"] for item in spec["members"]] + ["MANIFEST.json"]
        assert bundle.namelist() == expected_names
        for item in spec["members"]:
            count = 0
            digest = hashlib.sha256()
            with bundle.open(item["member"]) as stream:
                for block in iter(lambda: stream.read(CHUNK), b""):
                    check()
                    count += len(block)
                    digest.update(block)
            assert count == item["file"]["bytes"]
            assert digest.hexdigest() == item["file"]["sha256"]
        manifest = json.loads(bundle.read("MANIFEST.json"))
        assert manifest["phase"] == "S1"
        assert manifest["members"] == [
            {"member": item["member"], "original": item["file"]}
            for item in spec["members"]
        ]
        assert manifest["external_originals"] == spec.get("external_originals", [])
    return {
        "file": identity(source_zip),
        "payload_members": len(spec["members"]),
        "payload_and_manifest_members": len(expected_names),
        "all_payload_sizes_SHAs_and_ZIP_CRC_verified": True,
        "reused_from_failed_S1_completed_first_archive": True,
    }


def create_execution(spec, work):
    destination = Path(spec["destination"]).resolve()
    assert destination == CLOSE / "EXECUTION_ORIGINALS.zip"
    assert not destination.exists(), "NEVER_OVERWRITE_EXECUTION_SEAL"
    temporary = work / (destination.name + ".part")
    inputs = spec["members"]
    assert len(inputs) <= 4096
    assert sum(item["file"]["bytes"] for item in inputs) <= 256 * CHUNK
    members = []
    seen = set()
    with temporary.open("xb", buffering=0) as raw:
        with zipfile.ZipFile(
            ChunkedZipTarget(raw),
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=1,
            allowZip64=False,
        ) as bundle:
            for item in inputs:
                check()
                descriptor = item["file"]
                name = item["member"]
                assert name and name not in seen and not name.startswith("/")
                assert "\\" not in name and ".." not in name.split("/")
                seen.add(name)
                path = verify(descriptor)
                count = 0
                digest = hashlib.sha256()
                with path.open("rb", buffering=0) as source, bundle.open(name, "w") as sink:
                    for block in iter(lambda: source.read(CHUNK), b""):
                        check()
                        count += len(block)
                        assert count <= descriptor["bytes"], "INPUT_GREW_DURING_RECOVERY_SEAL"
                        digest.update(block)
                        assert sink.write(block) == len(block)
                assert count == descriptor["bytes"]
                assert digest.hexdigest() == descriptor["sha256"]
                members.append({"member": name, "original": descriptor})
            manifest = (
                json.dumps(
                    {
                        "schema": "M3_R13_ARCHIVE_MANIFEST_V1",
                        "phase": "S1",
                        "members": members,
                        "external_originals": spec.get("external_originals", []),
                        "live_ledger_excluded_by_design": True,
                    },
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n"
            ).encode("utf-8")
            with bundle.open("MANIFEST.json", "w") as sink:
                assert sink.write(manifest) == len(manifest)
        raw.flush()
        os.fsync(raw.fileno())
    actual = identity(temporary)
    assert actual["bytes"] <= ARCHIVE_LIMIT
    with zipfile.ZipFile(temporary) as bundle:
        assert bundle.namelist() == [item["member"] for item in inputs] + ["MANIFEST.json"]
        for item in inputs:
            count = 0
            digest = hashlib.sha256()
            with bundle.open(item["member"]) as stream:
                for block in iter(lambda: stream.read(CHUNK), b""):
                    check()
                    count += len(block)
                    digest.update(block)
            assert count == item["file"]["bytes"]
            assert digest.hexdigest() == item["file"]["sha256"]
    os.replace(temporary, destination)
    return {
        "file": identity(destination),
        "payload_members": len(inputs),
        "payload_and_manifest_members": len(inputs) + 1,
        "all_payload_sizes_SHAs_and_ZIP_CRC_verified": True,
        "live_ledger_excluded_and_deferred_to_S2": True,
    }


parser = argparse.ArgumentParser()
parser.add_argument("--contract", required=True, type=Path)
parser.add_argument("--sha256", required=True)
args = parser.parse_args()
started = time.monotonic()
deadline = started + 57
raw = args.contract.read_bytes()
assert hashlib.sha256(raw).hexdigest() == args.sha256
contract = json.loads(raw)
assert contract["phase"] == "S1_LIVE_01"
assert contract["plan_sha256"] == (
    "729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3"
)
old_contract_path = verify(contract["old_S1_contract"])
old_contract = json.loads(old_contract_path.read_text(encoding="utf-8"))
assert old_contract["phase"] == "S1"
work = OUT / "SEAL/S1_LIVE_01"
work.mkdir(parents=True, exist_ok=False)
source_result = verify_reused_source(old_contract)
execution_result = create_execution(contract["execution_archive"], work)
snapshot = []
for descriptor in contract["exact_tracked_tree"]:
    actual = identity(ROOT / descriptor["path"])
    assert actual["bytes"] == descriptor["bytes"]
    assert actual["sha256"] == descriptor["sha256"]
    snapshot.append(actual)
result = {
    "schema": "M3_R13_S1_RECOVERY_SEAL_RESULT_V1",
    "phase": "S1",
    "attempt_id": "S1_LIVE_01",
    "status": "PASS",
    "archives": [source_result, execution_result],
    "exact_tracked_tree_before_two_zips": snapshot,
    "old_failed_S1_preserved": contract["old_failed_S1"],
    "elapsed_seconds": time.monotonic() - started,
    "ended_utc": datetime.now(timezone.utc).isoformat(),
    "M2_RECEIVED": False,
    "M2_ACCEPTED": False,
}
check()
(work / "SEAL_RESULT.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps({"phase": "S1", "attempt_id": "S1_LIVE_01", "status": "PASS"}))
