"""Root-owned one-shot Windows Job launcher for R13 workers.

The frozen R12 owner is extracted by AST and executes in this disposable
supervisor process.  The long-lived coordinator must launch this file as a
separate process because the inherited disaster watchdog uses os._exit(124).
"""
from __future__ import annotations

import argparse
import ast
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import types

from stream_bridge import CHUNK, read_control, require, strict_child

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
OUTPUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
R12_SELFTEST = HERE.parent / "frontend_close_r12_20261018/selftest.py"
R12_SELFTEST_SHA = "5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c"
WINDOWS_JOB = ROOT / "code/software/t052_runner_acceptance_candidate_20261012/windows_job.py"
WINDOWS_JOB_SHA = "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b"
CAPS = {"P0": 60, "K": 120, "V": 120, "B": 120, "W": 900, "R": 120}


def _frozen(path, sha):
    raw = path.read_bytes()
    require(len(raw) <= CHUNK and hashlib.sha256(raw).hexdigest() == sha,
            "FROZEN_OWNER_SOURCE")
    return raw


def frozen_owned_call():
    raw = _frozen(R12_SELFTEST, R12_SELFTEST_SHA)
    _frozen(WINDOWS_JOB, WINDOWS_JOB_SHA)
    tree = ast.parse(raw, filename=str(R12_SELFTEST))
    wanted = {"JobAccounting", "job_accounting", "peak_working_set", "owned_call"}
    nodes = [node for node in tree.body if isinstance(
        node, (ast.ClassDef, ast.FunctionDef)) and node.name in wanted]
    require({node.name for node in nodes} == wanted, "FROZEN_OWNER_DEFINITIONS")
    module = types.ModuleType("_r13_frozen_owned_call")
    module.__dict__.update({
        "ctypes": ctypes, "wintypes": wintypes, "datetime": datetime,
        "timezone": timezone, "hashlib": hashlib, "json": json, "os": os,
        "Path": Path, "subprocess": subprocess, "threading": threading,
        "time": time, "types": types, "ROOT": ROOT, "OUTPUT": OUTPUT})
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(R12_SELFTEST),
                 "exec", dont_inherit=True), module.__dict__)
    return module.owned_call


def assess(record, cap):
    issues, pending = [], []
    for field in ("job_handle_closed", "root_process_handle_closed",
                  "job_zero_observed_before_job_close", "within_cap"):
        if record.get(field) is not True:
            issues.append(field)
    if record.get("exit_class") != "NATURAL" or record.get("exit_code") != 0:
        issues.append("NATURAL_ZERO_REQUIRED")
    samples = record.get("samples", [])
    if not samples or samples[-1].get("active") != 0:
        issues.append("JOB_ZERO_SAMPLE")
    totals = {item.get("total") for item in
              ([record.get("before_root_handle_close", {})] + samples)}
    if totals != {1}:
        pending.append("NO_DESCENDANT_AND_TREE_PEAK_NOT_PROVED:" + str(sorted(totals)))
    peak = record.get("peak_working_set", {})
    if peak.get("bytes", 512 * 1024 * 1024 + 1) > 512 * 1024 * 1024:
        issues.append("WORKER_PEAK_512MIB")
    pending.append("NATIVE_CLOSE_BOOL_NOT_RECORDED_BY_FROZEN_OWNER")
    return {"status": "FAIL" if issues else "PENDING" if pending else "PASS",
            "issues": issues, "pending": pending,
            "B02_B03_B04_parent_observation": True}


def execute(admission_path, admission_sha, owner_output):
    record = read_control(admission_path, admission_sha)["value"]
    group = record.get("group")
    require(group in CAPS and record.get("state") == "CONSUMED_RUNNING" and
            record.get("absolute_cap_seconds") == CAPS[group],
            "CONSUMED_ADMISSION")
    owner_output = strict_child(OUTPUT, owner_output)
    worker_output = owner_output / "worker"
    require(not owner_output.exists(), "FRESH_OWNER_OUTPUT")
    argv = record.get("argv")
    expected = [str(Path(sys.executable).resolve()), "-X", "utf8", "-B",
                str((HERE / "selftest.py").resolve()), "--worker", "--group",
                group, "--admission", str(Path(admission_path).resolve()),
                "--admission-sha256", admission_sha, "--output",
                str(worker_output.resolve())]
    require(argv == expected and worker_output != owner_output,
            "FROZEN_WORKER_ARGV")
    result = frozen_owned_call()(argv, ROOT, owner_output, CAPS[group])
    return {"schema": "M3_R13_OWNED_GROUP_RESULT_V1",
            "group": group, "owned": result,
            "assessment": assess(result, CAPS[group])}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute-one", action="store_true", required=True)
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--owner-output", required=True, type=Path)
    args = parser.parse_args()
    result = execute(args.admission, args.admission_sha256, args.owner_output)
    print(json.dumps(result, ensure_ascii=False))
    if result["assessment"]["status"] == "PASS":
        return 0
    return 3 if result["assessment"]["status"] == "PENDING" else 2


if __name__ == "__main__":
    raise SystemExit(main())
