"""Root-admitted R13 worker CLI; importing this file performs no work.

The coordinator supplies independently frozen controls for real-chain B/W
cases.  This worker never manufactures a D4 replacement or derives expected
content from actual output.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys
import traceback

import binding
import entry
import resources
from finalize import atomic_json
from stream_bridge import (CHUNK, Reject, identity, read_control,
                           parse_json, read_descriptor_json, require,
                           strict_child)
from volume_io import VolumeStore

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
OUTPUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
PLAN_SHA256 = "729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3"
GROUPS = {"P0": ["P001"],
          "K": [f"K{i:02d}" for i in range(1, 9)],
          "V": [f"V{i:02d}" for i in range(1, 13)],
          "B": [f"B{i:02d}" for i in range(1, 13)],
          "W": ["W01"]}
PINNED = {
    **{str(binding.R12 / name): sha for name, sha in binding.PINS.items()},
    str(binding.R12 / "selftest.py"):
        "5ce7234c457e8c53cdcbe857e40cc2c1235ad171bd95d647a13a8c04a5930c1c",
    str(ROOT / "code/software/t052_runner_acceptance_candidate_20261012/"
        "windows_job.py"):
        "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b",
}
CONTRACT_OBJECTS = {
    "FIELD_ROUTE_TABLE.json", "PROFILE_AND_CAPACITY.json",
    "PLAN_IDENTITY_MAP.json", "EPOCH_RESET_FINISH_CONTRACT.json",
    "SOURCE_PROVENANCE.json", "OPEN_DECISIONS.json",
    "M2_DECISION_SHEET.md", "README.md",
}
B08_SPEC = {
    "path": ROOT / "code/output/m3_backend_stream_r13_20261018/roles/"
                   "main4/B08_MINIMAL_FIXTURE_NOTE_R02.json",
    "bytes": 18457,
    "sha256": "f74e26b6d7351af164863c12be32d470b30332deb7be9e885aa28e43a7b389be",
}


def _manifest(path):
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False,
                               separators=(",", ":")) + "\n",
                    encoding="utf-8", newline="\n")


def _expect_reject(call, token):
    try:
        call()
    except BaseException as error:
        require(token in str(error), "WRONG_REJECT:" + str(error))
        return
    raise Reject("EXPECTED_REJECT_NOT_OBSERVED:" + token)


def _delivery_ready(value):
    require(value.get("delivery_channel_confirmed") is True,
            "DELIVERY_CHANNEL_NOT_CONFIRMED")
    delivery = value.get("delivery")
    require(type(delivery) is dict and
            type(delivery.get("location")) is str and delivery["location"] and
            type(delivery.get("retrieval_method")) is str and
            delivery["retrieval_method"] and
            delivery.get("all_logical_originals_recoverable") is True,
            "DELIVERY_CHANNEL_INCOMPLETE")


def _volume_case(case_id, root, admission):
    case = root / case_id
    case.mkdir()
    logical = case / "logical.jsonl"
    store = VolumeStore(case)
    if case_id == "V02":
        payload = b"a" * (CHUNK - 1) + "音".encode() + b"\n"
    elif case_id == "V03":
        payload = b"one\r\ntwo\nthree\r\n"
    else:
        payload = (b'{"row":1}\n' * 8192)
    with store.open(logical, "xb") as stream:
        offset = 0
        while offset < len(payload):
            block = payload[offset:offset + CHUNK]
            stream.write(block)
            offset += len(block)
    manifest_path = store.folder_for(logical) / "MANIFEST.json"
    manifest = _manifest(manifest_path)
    expected = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
    if case_id == "V04":
        (store.folder_for(logical) /
         manifest["parts"][0]["compressed"]["path"]).unlink()
    elif case_id == "V05":
        manifest["parts"].append(copy.deepcopy(manifest["parts"][0]))
        _save(manifest_path, manifest)
    elif case_id == "V06":
        manifest["parts"][0]["sequence"] = 1
        _save(manifest_path, manifest)
    elif case_id == "V07":
        manifest["parts"][0]["logical_offset"] = 1
        _save(manifest_path, manifest)
    elif case_id == "V08":
        manifest["parts"][0]["decoded_sha256"] = "0" * 64
        _save(manifest_path, manifest)
    elif case_id == "V09":
        manifest["original"]["sha256"] = "0" * 64
        _save(manifest_path, manifest)
    elif case_id == "V10":
        part = store.folder_for(logical) / manifest["parts"][0]["compressed"]["path"]
        with part.open("r+b") as stream:
            stream.truncate(max(0, part.stat().st_size - 1))
    if case_id in {"V04", "V05", "V06", "V07", "V08", "V09", "V10"}:
        fresh = VolumeStore(case)
        _expect_reject(lambda: _drain(fresh.open(logical, "rb")), "VOLUME_")
        return {"id": case_id, "status": "EXPECTED_REJECT"}
    actual = _drain(store.open(logical, "rb"))
    require(actual == payload, "VOLUME_NOT_LOSSLESS")
    if case_id == "V11":
        control = case / "control.json"
        control.write_bytes(b'{"decision":"original"}\n')
        first = read_control(control)
        control.write_bytes(b'{"decision":"changed"}\n')
        require(first["value"]["decision"] == "original" and
                read_control(control)["stamp"] != first["stamp"],
                "SAME_BUFFER_OR_MUTATION_GUARD")
    if case_id == "V12":
        invalid = copy.deepcopy(admission)
        invalid["delivery_channel_confirmed"] = False
        invalid.pop("delivery", None)
        _expect_reject(lambda: _delivery_ready(invalid),
                       "DELIVERY_CHANNEL_NOT_CONFIRMED")
    return {"id": case_id, "status": "PASS",
            "bytes": expected["bytes"], "sha256": expected["sha256"]}


def _drain(stream):
    blocks = []
    with stream:
        while True:
            block = stream.read(CHUNK)
            if not block:
                break
            require(len(block) <= CHUNK, "READ_REQUEST_BOUND")
            blocks.append(block)
    return b"".join(blocks)


def _contract_bundle(index_path, index_sha):
    record = read_control(index_path, index_sha)
    value = record["value"]
    require(value.get("schema") == "M3_R13_CONTRACT_INDEX_V1",
            "CONTRACT_INDEX_SCHEMA")
    objects = value.get("objects")
    require(type(objects) is list and len(objects) == len(CONTRACT_OBJECTS),
            "CONTRACT_OBJECT_COUNT")
    names, loaded = set(), {}
    for descriptor in objects:
        require(type(descriptor) is dict and
                set(descriptor) == {"path", "bytes", "sha256"},
                "CONTRACT_DESCRIPTOR")
        name = Path(descriptor["path"]).name
        require(name in CONTRACT_OBJECTS and name not in names,
                "CONTRACT_OBJECT_SET")
        names.add(name)
        path = (ROOT / descriptor["path"]).resolve()
        actual = identity(path)
        require(actual == {"bytes": descriptor["bytes"],
                           "sha256": descriptor["sha256"]},
                "CONTRACT_OBJECT_IDENTITY:" + name)
        if path.suffix == ".json":
            loaded[name] = read_control(path, descriptor["sha256"])["value"]
    require(names == CONTRACT_OBJECTS, "CONTRACT_OBJECT_SET")
    return value, loaded


def _k_cases(admission, wanted=None):
    cases = admission.get("contract_cases")
    wanted = set(GROUPS["K"] if wanted is None else wanted)
    require(type(cases) is list and
            {item.get("id") for item in cases} == wanted,
            "CONTRACT_CASE_SET")
    outcomes = []
    for item in sorted(cases, key=lambda value: value["id"]):
        case_id, expected = item["id"], item.get("expected")
        try:
            index, loaded = _contract_bundle(
                Path(item["contract_index"]), item["contract_index_sha256"])
            require(index.get("routes", {}).keys() >=
                    {"A1", "A2", "A3", "A4", "B", "C", "root"},
                    "CONTRACT_ROUTE_MISSING")
            if case_id == "K07":
                finish = loaded["EPOCH_RESET_FINISH_CONTRACT.json"]
                require(finish["real_finish_candidates_preserved"]
                        ["approved_finish_cycle"] is None,
                        "FINISH_UNEXPECTEDLY_APPROVED")
                actual = "FINISH_PENDING"
            elif case_id == "K08":
                provenance = loaded["SOURCE_PROVENANCE.json"]
                require(provenance.get("acceptance_boundary", {}).get(
                        "real_verified") is False,
                        "AUTHENTICITY_UNEXPECTEDLY_REAL")
                actual = "AUTHENTICITY_PENDING"
            else:
                actual = "PASS"
        except BaseException as error:
            actual = "REJECT:" + type(error).__name__ + ":" + str(error)
        require((expected == actual) or
                (type(expected) is str and expected.startswith("REJECT:") and
                 expected[7:] in actual),
                "K_CASE:" + case_id + ":" + actual)
        outcomes.append({"id": case_id, "status": actual,
                         "contract_index_sha256":
                             item["contract_index_sha256"]})
    return outcomes


def _p0_case():
    checked = []
    for raw_path, sha in sorted(PINNED.items()):
        path = Path(raw_path).resolve()
        actual = identity(path)
        require(actual["sha256"] == sha, "P0_PIN:" + str(path))
        checked.append({"path": str(path), **actual})
    require(Path(sys.executable).resolve().is_file(), "P0_PYTHON_MISSING")
    actual_d4 = (ROOT / "code/software/m3_pro_fourvoice_trace_20261016/"
                 "pro_basis_r08_20261017/coordinator/"
                 "task_day4_completion_20261017/chain.py")
    d4 = identity(actual_d4)
    require(d4 == {"bytes": 12667,
                   "sha256": "64bfdf4787aa9dd1ddab30a30ed7cf4fb05be763b9303ec965061005430f1c44"},
            "P0_ACTUAL_D4_PIN")
    disk = resources.preflight(OUTPUT, full_window=False)
    require(disk["decision"] == "GO", "P0_DISK_PREFLIGHT")
    return {"id": "P001", "status": "PASS_LOCAL_PINS",
            "pins": checked + [{"path": str(actual_d4), **d4}],
            "disk": disk,
            "parent_job_receipt_required": True}


def _actual_cases(group, admission, output, wanted_override=None):
    controls = admission.get("business_cases")
    require(type(controls) is list, "BUSINESS_CASES_REQUIRED")
    wanted = (["W01"] if group == "W" else [
        case for case in GROUPS["B"] if case not in {"B02", "B03", "B04"}])
    if wanted_override is not None:
        wanted = list(wanted_override)
    by_id = {item.get("id"): item for item in controls}
    require(set(by_id) == set(wanted), "BUSINESS_CASE_SET")
    require(len({item.get("control_sha256") for item in controls}) == len(controls),
            "BUSINESS_CONTROL_SHA_NOT_UNIQUE")
    require(len({str(Path(item.get("control", "")).resolve())
                 for item in controls}) == len(controls),
            "BUSINESS_CONTROL_PATH_NOT_UNIQUE")
    outcomes = []
    for case_id in wanted:
        item = by_id[case_id]
        case_out = output / "cases" / case_id
        expected = item["expected"]
        try:
            entry.run(Path(item["control"]), item["control_sha256"], case_out)
            actual = "PASS"
        except BaseException as error:
            actual = "REJECT:" + type(error).__name__ + ":" + str(error)
        require((expected == "PASS" and actual == "PASS") or
                (expected.startswith("REJECT:") and expected[7:] in actual),
                "BUSINESS_EXPECTATION:" + case_id + ":" + actual)
        post = item.get("postcondition")
        require(type(post) is dict, "BUSINESS_POSTCONDITION:" + case_id)
        complete_path = case_out / "COMPLETE.json"
        failure_path = case_out / "R13_FAILURE.json"
        if expected == "PASS":
            require(complete_path.is_file() and not failure_path.exists(),
                    "BUSINESS_COMPLETE_MARKER:" + case_id)
            complete = read_control(complete_path)["value"]
            require(complete.get("status") == "COMPLETE_SOFTWARE_ONLY" and
                    complete.get("audit", {}).get("status") ==
                    "SOFTWARE_CHAIN_COMPLETE_PENDING_AUTHORITY",
                    "BUSINESS_COMPLETE_CONTENT:" + case_id)
            _check_success_postcondition(case_id, case_out, complete, post)
        else:
            require(not complete_path.exists() and failure_path.is_file() and
                    not (case_out / "COMPLETE.pending.json").exists(),
                    "BUSINESS_FAILURE_BARRIER:" + case_id)
            failure = read_control(failure_path)["value"]
            require(failure.get("completion_written") is False and
                    expected[7:] in failure.get("error", ""),
                    "BUSINESS_FAILURE_RECEIPT:" + case_id)
        outcomes.append({"id": case_id, "status": "PASS",
                         "observed": actual,
                         "control_sha256": item["control_sha256"]})
    if group == "B" and wanted_override is None:
        outcomes += [{"id": case, "status": "DEFERRED_TO_PARENT_JOB_RECEIPT"}
                     for case in ("B02", "B03", "B04")]
    return sorted(outcomes, key=lambda item: item["id"])


def _artifact(complete, role):
    artifacts = complete["audit"]["artifacts"]
    require(role in artifacts, "POST_ARTIFACT_ROLE:" + role)
    return artifacts[role]


def _artifact_stream(case_out, artifact):
    path = case_out / artifact["path"]
    store = VolumeStore(case_out)
    return (store.open(path, "rb", {"bytes": artifact["bytes"],
                                    "sha256": artifact["sha256"]})
            if artifact["storage"] == "VOLUME" else
            path.open("rb", buffering=0))


def _logical_records(case_out, artifact):
    records = []
    stream = _artifact_stream(case_out, artifact)
    with stream:
        while True:
            line = stream.readline(CHUNK)
            if not line:
                break
            require(line.endswith(b"\n"), "POST_JSONL_TRUNCATED")
            records.append(parse_json(line))
    return records


def _contains_subset(value, expected):
    if isinstance(expected, dict):
        return (isinstance(value, dict) and
                all(key in value and _contains_subset(value[key], item)
                    for key, item in expected.items()))
    if isinstance(expected, list):
        return value == expected
    return value == expected


def _somewhere(value, expected):
    if _contains_subset(value, expected):
        return True
    if isinstance(value, dict):
        return any(_somewhere(item, expected) for item in value.values())
    if isinstance(value, list):
        return any(_somewhere(item, expected) for item in value)
    return False


def _artifact_values(case_out, artifact):
    if artifact["path"].endswith(".jsonl"):
        return _logical_records(case_out, artifact)
    require(artifact["path"].endswith(".json") and
            artifact["storage"] == "PLAIN",
            "POST_EXPECTED_JSON_ARTIFACT")
    path = case_out / artifact["path"]
    return read_control(path, artifact["sha256"])["value"]


def _check_success_postcondition(case_id, case_out, complete, post):
    terminal = complete["audit"]["terminal"]
    minimum_rows = post.get("minimum_rows")
    require(type(minimum_rows) is int and terminal["rows"] >= minimum_rows,
            "POST_MINIMUM_ROWS:" + case_id)
    if case_id == "B07":
        expected = post.get("artifact_identities")
        require(type(expected) is dict and
                set(expected) == {"public_rows", "public_csv", "csv_roundtrip"},
                "B07_EXPECTED_IDENTITIES")
        for role, stamp in expected.items():
            actual = _artifact(complete, role)
            require({key: actual[key] for key in ("bytes", "sha256")} == stamp,
                    "B07_IDENTITY:" + role)
    elif case_id == "B08":
        require(identity(B08_SPEC["path"]) == {
                    "bytes": B08_SPEC["bytes"],
                    "sha256": B08_SPEC["sha256"]},
                "B08_STATIC_SPEC_IDENTITY")
        require(post.get("fixture_spec") == {
                    "path": str(B08_SPEC["path"]),
                    "bytes": B08_SPEC["bytes"],
                    "sha256": B08_SPEC["sha256"]},
                "B08_ADMISSION_SPEC_BINDING")
        require(terminal == {"rows": 837, "finish_count": 1,
                             "last_cycle": 836,
                             "monitor_end_count": 1},
                "B08_TERMINAL_837")
        public_role = post.get("public_role")
        public = _artifact(complete, public_role)
        require({key: public[key] for key in ("bytes", "sha256")} ==
                post.get("public_identity"), "B08_PUBLIC_IDENTITY")
        public_rows = _logical_records(case_out, public)
        require(len(public_rows) == 837 and
                all(isinstance(row.get("fields"), dict) and
                    len(row["fields"]) == 74 and
                    isinstance(row.get("raw_ports"), dict) and
                    len(row["raw_ports"]) == 72
                    for row in public_rows),
                "B08_PUBLIC_837_74_72")
        require(sum(row["fields"].get("frame_tick") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("req_valid") == 1 and
                    row["fields"].get("req_ready") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("cancel") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("finish") == 1
                    for row in public_rows) == 1 and
                sum(row["fields"].get("advance_mask", 0) != 0
                    for row in public_rows) == 1,
                "B08_PUBLIC_EVENT_COUNTS")
        require(_contains_subset(public_rows[833]["fields"], {
                    "cycle": 833, "frame_tick": 1, "finish": 0}) and
                _contains_subset(public_rows[834]["fields"], {
                    "cycle": 834, "req_valid": 1, "req_ready": 1,
                    "req_id": 42, "advance_mask": 15,
                    "advance_frame_req_id": 42, "cancel": 0,
                    "finish": 0}) and
                _contains_subset(public_rows[835]["fields"], {
                    "cycle": 835, "cancel": 1,
                    "cancel_reason": 0, "advance_mask": 0,
                    "finish": 0}) and
                _contains_subset(public_rows[836]["fields"], {
                    "cycle": 836, "finish": 1}),
                "B08_PUBLIC_CYCLE_SEQUENCE")
        role = post.get("advance_role")
        advance = _artifact(complete, role)
        require({key: advance[key] for key in ("bytes", "sha256")} ==
                post.get("advance_identity"), "B08_ADVANCE_IDENTITY")
        advance_rows = _logical_records(case_out, advance)
        require(len(advance_rows) == 1 and _contains_subset(
            advance_rows[0], {
                "source": {"line": 835, "cycle": 834, "epoch": 0,
                           "time_ps": 20875000,
                           "sampling_phase": "POSEDGE_PRE_NBA"},
                "advance": {"raw_mask": 15, "all_four_lanes": True,
                            "status": "ALL_FOUR_LANES"},
                "request_tag": 42, "req_id": 42,
                "commit_observed_same_row": 0, "cancel_raw": 0,
                "retained_even_if_unpublished_or_cancelled": True}),
                "B08_EXACT_ADVANCE_HISTORY")
        cancel_role = post.get("cancel_evidence_role")
        cancel = _artifact(complete, cancel_role)
        require({key: cancel[key] for key in ("bytes", "sha256")} ==
                post.get("cancel_evidence_identity"),
                "B08_CANCEL_EVIDENCE_IDENTITY")
        cancel_values = _artifact_values(case_out, cancel)
        require(_somewhere(cancel_values, {
                    "cycle": 835, "source_line": 836,
                    "raw_cancel_reason": 0,
                    "business_cancel_derived": False}) and
                _somewhere(cancel_values, {"business_cancels": []}),
                "B08_INTAKE_CANCEL_RETENTION")
        serial_role = post.get("serial_role")
        serial = _artifact(complete, serial_role)
        require({key: serial[key] for key in ("bytes", "sha256")} ==
                post.get("serial_identity"), "B08_SERIAL_IDENTITY")
        serial_values = _artifact_values(case_out, serial)
        require(_somewhere(serial_values, {
                    "source_line": 836, "cycle": 835, "epoch": 0,
                    "time_ps": 20900000, "kind": "CANCEL",
                    "raw_reason": 0,
                    "entry": {"epoch": 0, "id": 42, "F": 833,
                              "V": 834, "A": 834,
                              "request_cycle": 834,
                              "accept_source_line": 835}}),
                "B08_SERIAL_CANCEL")
        require(_somewhere(serial_values, {
                    "counts": {"rows": 837, "FRAME_F": 1,
                               "accepted": 1, "result": 0,
                               "commit": 0}}),
                "B08_SERIAL_COUNTS")
        frame_role = post.get("frame_plan_role")
        frame = _artifact(complete, frame_role)
        require({key: frame[key] for key in ("bytes", "sha256")} ==
                post.get("frame_plan_identity"), "B08_FRAME_PLAN_IDENTITY")
        require(_somewhere(_artifact_values(case_out, frame), {
                    "epoch": 0, "cycles": [833],
                    "release_cycle": 0, "stop_cycle": 836,
                    "window_kind": "ACTIVE"}) and
                _somewhere(_artifact_values(case_out, frame),
                           {"finish": {"epoch": 0, "cycle": 836}}),
                "B08_FRAME_PLAN")
    elif case_id == "B10":
        require(terminal == post.get("terminal"), "B10_TERMINAL_SOURCE")
    elif case_id == "B11":
        inventory = complete["audit"]["workspace_inventory"]
        for key in ("physical_bytes", "logical_bytes"):
            minimum = post.get("minimum_" + key)
            require(type(minimum) is int and inventory[key] >= minimum,
                    "B11_RESOURCE_ACCOUNT:" + key)
        require(post.get("parent_process_tree_receipt_required") is True,
                "B11_PARENT_RESOURCE_RECEIPT")
    elif case_id == "W01":
        require(terminal["rows"] >= 1130662,
                "W01_FULL_WINDOW_ROWS")
        raw_role = post.get("raw_role")
        require(_artifact(complete, raw_role)["bytes"] >= 1398627657,
                "W01_FULL_WINDOW_RAW_BYTES")


def worker(group, admission_path, admission_sha, output):
    record = read_control(admission_path, admission_sha)
    admission = record["value"]
    require(admission.get("plan_sha256") == PLAN_SHA256 and
            admission.get("group") == group and
            admission.get("state") == "CONSUMED_RUNNING",
            "WORKER_ADMISSION")
    output = strict_child(OUTPUT, output)
    require(not output.exists(), "FRESH_WORKER_OUTPUT")
    output.mkdir(parents=True)
    atomic_json(output / "CONSUMPTION_RUNNING.json", {
        "schema": "M3_R13_WORKER_CONSUMPTION_V1", "group": group,
        "admission": {"path": str(Path(admission_path).resolve()),
                      **record["stamp"]}, "complete": False})
    try:
        if group == "P0":
            outcomes = [_p0_case()]
        elif group == "K":
            outcomes = _k_cases(admission)
        elif group == "V":
            cases = output / "cases"
            cases.mkdir()
            outcomes = [_volume_case(case, cases, admission)
                        for case in GROUPS["V"]]
        elif group in ("B", "W"):
            if group == "W":
                require(admission.get("resource_profile") == "PASS" and
                        admission.get("delivery_channel_confirmed") is True,
                        "W_RESOURCE_PROFILE_PENDING")
                _delivery_ready(admission)
            outcomes = _actual_cases(group, admission, output)
        elif group == "R":
            affected = admission.get("affected_case_ids")
            require(type(affected) is list and 0 < len(affected) <= 16,
                    "R_AFFECTED_CASES")
            repair_group = admission.get("repair_group")
            require(repair_group in {"K", "V", "B"} and
                    set(affected) <= set(GROUPS[repair_group]),
                    "R_SINGLE_GROUP_SCOPE")
            if repair_group == "K":
                outcomes = _k_cases(admission, affected)
            elif repair_group == "V":
                cases = output / "cases"
                cases.mkdir()
                outcomes = [_volume_case(case, cases, admission)
                            for case in affected]
            else:
                require(not ({"B02", "B03", "B04"} & set(affected)),
                        "R_PARENT_JOB_CASES_REQUIRE_PARENT_DISPATCH")
                outcomes = _actual_cases("B", admission, output, affected)
        else:
            raise Reject("WORKER_GROUP")
        parent_required = (group in {"P0", "B"} or
                           (group == "R" and
                            admission.get("repair_group") == "B"))
        result = {"schema": ("M3_R13_WORKER_LOCAL_RESULT_V1" if
                              parent_required else
                              "M3_R13_WORKER_COMPLETE_V1"),
                  "status": ("PASS_LOCAL_PENDING_PARENT" if parent_required
                             else "PASS"), "group": group,
                  "cases": outcomes,
                  "parent_receipt_required": parent_required,
                  "real_verified": False, "math_verified": False,
                  "execution_allowed": False, "board_release_allowed": False}
        atomic_json(output / ("WORKER_LOCAL_RESULT.json" if parent_required
                              else "WORKER_COMPLETE.json"), result)
        return result
    except BaseException as error:
        failure = {"schema": "M3_R13_WORKER_FAILURE_V1", "group": group,
                   "error": type(error).__name__ + ":" + str(error),
                   "traceback": traceback.format_exc(), "complete": False}
        try:
            atomic_json(output / "WORKER_FAILURE.json", failure)
        except BaseException as secondary:
            failure["secondary_failure"] = (type(secondary).__name__ + ":" +
                                              str(secondary))
        raise error.with_traceback(error.__traceback__)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", action="store_true", required=True)
    parser.add_argument("--group", required=True, choices=(*GROUPS, "R"))
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    worker(args.group, args.admission, args.admission_sha256, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
