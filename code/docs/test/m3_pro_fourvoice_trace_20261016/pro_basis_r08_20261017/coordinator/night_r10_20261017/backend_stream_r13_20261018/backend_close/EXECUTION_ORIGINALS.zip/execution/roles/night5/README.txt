夜间任务5 / R13 静态候选交付

状态：候选已写入独立写集；仅静态阅读和标准文件/JSON元数据检查，未执行目标。
不得据此开启W。当前准入仍为RESOURCE_PROFILE_PENDING。

文件：
- bounded_volume_candidate.py：1MiB逻辑字节分卷、逐卷及整体SHA、LF/offset、显式finish、EOF验证；close不drain。
- synthetic_window_candidate.py：由冻结配方生成1130662行合成输入的候选；不运行D4、不生成实际执行回执。
- FULL_WINDOW_RECIPE.json：实际7行种子/端口表/MIDI/源码引用及调用约束。引用path为仓库相对路径，调用者须解析为绝对路径。
- D4_INPUTS_AND_ARTIFACTS.json：已读真实D4/provenance/math源码身份、输入roles和产物。
- CASE_INPUTS_33.json：K8/V12/B12/W1共33项，全部PROPOSED_NOT_RUN；具体小标本仍由root/C在执行前冻结。
- CAPACITY_AND_DELIVERY.json：7行元数据外推约32.33GiB，仅作纯文本NO_GO诊断；直接分卷候选尚无24GiB上界证明。
- HANDOFF.json：成员大小/SHA、边界和接手事项。

C的接入接口：
1. Budget必须接root原W monotonic start，cap900；check_hook接真实资源观察，不新计时。
2. PhysicalLedger传全部已占工作区字节；它只约束本store，root仍统计所有输入、输出、临时文件、archive和保留失败原件。
3. sink_factory(role)返回write(bytes)/finish()/abort()对象；put_control(name,bytes)返回同缓冲SHA绑定引用。控制写盘也算原W预算和工作区。
4. produce_inputs(recipe_ref,seed_ref,port_map_ref,callbacks,budget)仅产生新合成输入。实际R12/R11/R10/D4消费者、Path/identity适配及源/ROM闭包仍由C/root绑定。
5. LogicalReader只支持有界read/readinto；消费者必须实际读至EOF并检查eof_verified。Text/CSV接口须保持原字节和换行。

明确缺口：
- B08非零advance有效小窗未生成。当前完整窗advance_mask为0，无req/result/commit/TX；serial应保持PARTIAL，是否被真实D4接受仍待root在授权B组验证。
- 源码/ROM/tool、application新窗口、独立FRAME输入、当前声明型合成执行receipt须重绑；不得复用7行receipt/EXPECTED或旧W私有D4替身。
- gzip不保证24GiB；raw回退只保证payload不超过逻辑字节总量，不能从约32GiB逻辑量推定物理准入。
- 人工转交全部DELIVERY卷和清单渠道已确认；实际卷名/大小/SHA未生成，M2未接收/验收。Git的32MiB zip不能冒称包含大原件。
- root是唯一目标执行、预算、Job、Git/网络发布者；本目录无Git提交/推送。

正负检查：静态自审修复解压最大输出和hook/末次manifest写盘后的deadline复核。未运行Python、AST、测试、压缩校准、完整窗、仿真、EDA或硬件。
real_verified=false / math_verified=false / board_release_allowed=false。
