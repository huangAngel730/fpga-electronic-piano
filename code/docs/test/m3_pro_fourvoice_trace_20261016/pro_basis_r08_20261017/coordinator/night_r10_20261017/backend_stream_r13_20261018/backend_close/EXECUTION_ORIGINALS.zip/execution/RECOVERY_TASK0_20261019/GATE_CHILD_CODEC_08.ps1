# R13 child-only gate wrapper. Root-owned Job supervisor is mandatory.
# This artifact was prepared statically; it has not been parsed or run.
[CmdletBinding()]
param([string]$ContractPath, [string]$ContractSha256, [switch]$PreflightOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$originalModulePath = $env:PSModulePath
$env:PSModulePath = [IO.Path]::Combine($PSHOME, 'Modules') + ';' + $originalModulePath
$failureExit = 97
$logRoot = $null
$proof = [ordered]@{ schema = 'M3_R13_ENVIRONMENT_PROOF_V1'; phases = [ordered]@{} }
$repoFixed = 'E:\FPGA\GAOYUNFPGA\team\fpga-electronic-piano'
$recoveryFixed = $repoFixed + '\code\output\m3_backend_stream_r13_20261018'
$pythonFixed = 'C:\Users\songdongkuan\miniconda3\python.exe'
$pythonSha = '4e5a83fcdcd12bcb9ae4dc98c5405effe35dc5ac10d89982c6a6a3646493f88a'
$sourceStem = 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018/'
$evidenceStem = 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018/'
$sourceNames = @('entry.py', 'binding.py', 'stream_bridge.py', 'volume_io.py', 'finalize.py', 'resources.py', 'selftest.py', 'run_plan.py', 'job_bridge.py', 'DEPENDENCIES.json', 'CALL_CHAIN_BINDINGS.json', 'CASE_MATRIX.json', 'README.md')
$evidenceNames = @('contract_bundle/CONTRACT_INDEX.json', 'contract_bundle/FIELD_ROUTE_TABLE.json', 'contract_bundle/PROFILE_AND_CAPACITY.json', 'contract_bundle/PLAN_IDENTITY_MAP.json', 'contract_bundle/EPOCH_RESET_FINISH_CONTRACT.json', 'contract_bundle/SOURCE_PROVENANCE.json', 'contract_bundle/OPEN_DECISIONS.json', 'contract_bundle/M2_DECISION_SHEET.md', 'contract_bundle/README.md', 'capture_originals/ORIGINALS_INDEX.json', 'capture_originals/DEPENDENCY_DAG.json', 'capture_originals/CAPTURE_IDENTITY_BINDING.json', 'capture_originals/POSITIVE_NEGATIVE_HISTORY.json', 'capture_originals/CONSUMER_LOAD_MAP.json', 'capture_originals/MISSING_ORIGINALS.json', 'capture_originals/README_FOR_M1_M2.md', 'backend_close/PLAN.json', 'backend_close/AUTHORIZATION.json', 'backend_close/START_AND_DEADLINE.json', 'backend_close/BASELINE.json', 'backend_close/SOURCE_MANIFEST.json', 'backend_close/RESULT_RECEIPT.json', 'backend_close/CASE_RESULTS.json', 'backend_close/RESOURCE_RECEIPT.json', 'backend_close/CONSUMPTION.json', 'backend_close/FAILURE_HISTORY.json', 'backend_close/SELF_REVIEW.md', 'backend_close/GATE_01.json', 'backend_close/GATE_02.json', 'backend_close/PUBLISH_ALLOWLIST.json', 'backend_close/PUBLICATION_RECEIPT.json', 'backend_close/OUTBOX_REFERENCE.json', 'backend_close/TASK_ORIGINAL.md', 'backend_close/SOURCE_PAYLOAD.zip', 'backend_close/EXECUTION_ORIGINALS.zip', 'backend_close/INTEGRATION_HANDOFF.json')
function Need([bool]$Ok, [string]$Why) { if (-not $Ok) { throw $Why } }
function Absolute([string]$Path) {
    Need (-not [string]::IsNullOrWhiteSpace($Path)) 'PATH_REQUIRED'
    Need ([IO.Path]::IsPathRooted($Path)) 'ABSOLUTE_PATH_REQUIRED'
    return [IO.Path]::GetFullPath($Path).TrimEnd('\')
}
function Reject-Alias([string]$Path) {
    $node = Get-Item -LiteralPath $Path -Force
    while ($null -ne $node) {
        Need (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) 'REPARSE_PATH_DENIED'
        if ($node -is [IO.FileInfo]) { $node = $node.Directory } else { $node = $node.Parent }
    }
}
function Pin([object]$Item, [string]$Path) {
    Need ($Item.sha256 -cmatch '^[0-9a-f]{64}$') 'FULL_SHA_REQUIRED'
    Need (($Item.bytes -is [int] -or $Item.bytes -is [long]) -and $Item.bytes -ge 0) 'SIZE_REQUIRED'
    Reject-Alias $Path
    $file = Get-Item -LiteralPath $Path -Force
    Need (-not $file.PSIsContainer -and $file.Length -eq $Item.bytes) 'PIN_SIZE_CHANGED'
    Need ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() -ceq $Item.sha256) 'PIN_SHA_CHANGED'
}
function Relative-File([string]$Path) {
    Need (-not [IO.Path]::IsPathRooted($Path)) 'RELATIVE_PATH_REQUIRED'
    $full = [IO.Path]::GetFullPath((Join-Path $repoFixed $Path))
    Need ($full.StartsWith($repoFixed + '\', [StringComparison]::OrdinalIgnoreCase)) 'PATH_ESCAPES_ROOT'
    return $full
}
function Save([string]$Name, [object]$Value) {
    Need ($Name -cmatch '^[A-Z0-9_]+\.json$') 'BAD_LOG_NAME'
    $encoder = New-Object System.Text.UTF8Encoding($false)
    $text = ($Value | ConvertTo-Json -Depth 20) + [char]10
    $bytes = $encoder.GetBytes($text)
    $stream = [IO.File]::Open((Join-Path $logRoot $Name), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $stream.Write($bytes, 0, $bytes.Length) } finally { $stream.Dispose() }
}
function Window {
    Pin $gateContract.continuation (Relative-File $gateContract.continuation.path)
    Need ($gateContract.continuation.sha256 -ceq '44f657f5ba91fe70734a540334ed40ef3546665fde316d598189eda4f0f68c46') 'CODEC_08_AUTHORITY_CHANGED'
    $now = [DateTimeOffset]::UtcNow
    $begin = [DateTimeOffset]::Parse($gateContract.not_before)
    $end = [DateTimeOffset]::Parse($gateContract.deadline)
    $limit = [DateTimeOffset]::Parse('2026-10-19T10:00:00+08:00')
    Need ($begin -lt $end -and $end -le $limit) 'WINDOW_OUTSIDE_R13'
    Need ($now -ge $begin -and ($end - $now).TotalSeconds -ge 900) 'FULL_900_SECONDS_NOT_AVAILABLE'
}
function Profile {
    Need ((Get-FileHash -Algorithm SHA256 -LiteralPath $ContractPath).Hash.ToLowerInvariant() -ceq $ContractSha256) 'CONTRACT_CHANGED'
    Need ($gateContract.cap_seconds -eq 900) 'EXACT_CAP_REQUIRED'
    Need ($gateContract.slot -cin @('GATE_01', 'GATE_02')) 'SLOT_DENIED'
    $set = @{}
    foreach ($item in @($gateContract.files)) {
        $full = Relative-File $item.path
        Need (-not $set.ContainsKey($full)) 'DUPLICATE_PROFILE_FILE'
        $set[$full] = $item
        Pin $item $full
    }
    foreach ($name in $sourceNames) {
        $full = Relative-File ($sourceStem + $name)
        Need ($set.ContainsKey($full)) 'MISSING_FROZEN_R13_SOURCE'
    }
    foreach ($name in $evidenceNames) {
        if ($gateContract.slot -ceq 'GATE_01' -and $name.EndsWith('.zip')) { continue }
        Need ($set.ContainsKey((Relative-File ($evidenceStem + $name)))) 'MISSING_FROZEN_R13_EVIDENCE'
    }
    $minimumFiles = 49
    if ($gateContract.slot -ceq 'GATE_01') { $minimumFiles = 47 }
    Need (@($gateContract.files).Count -ge $minimumFiles) 'INCOMPLETE_R13_PROFILE'
    foreach ($name in @('python', 'gate_script', 'enter_environment', 'shell')) {
        Pin $gateContract.$name (Absolute $gateContract.$name.path)
    }
    Need ((Absolute $gateContract.python.path) -ieq $pythonFixed) 'FROZEN_PYTHON_PATH_REQUIRED'
    Need ($gateContract.python.bytes -eq 104208 -and $gateContract.python.sha256 -ceq $pythonSha) 'FROZEN_PYTHON_CHANGED'
    Need ((Absolute $gateContract.gate_script.path) -ieq ($repoFixed + '\code\scripts\check_repo.ps1')) 'GATE_PATH_CHANGED'
    Need ($gateContract.gate_script.sha256 -ceq '23c69c10bd84c968f4ee23d186205d47075bfda8359f4df4e8d4196f9891ecaa') 'GATE_BODY_CHANGED'
    Need ((Absolute $gateContract.enter_environment.path) -ieq ($repoFixed + '\code\scripts\enter_fpga_env.ps1')) 'ENV_PATH_CHANGED'
    Need ($gateContract.enter_environment.sha256 -ceq '6582e41b598b207f5fac8fc74a8690a18de7778a53a0146d270f1747f4e4d866') 'ENV_BODY_CHANGED'
    Need ((Absolute $gateContract.shell.path) -ieq ((Get-Process -Id $PID).Path)) 'ACTUAL_CHILD_SHELL_MISMATCH'
    Need ($gateContract.shell.sha256 -ceq '60c9b29843624dd8af6b6a7b26147753be6aeef65098b9a503cc50850afe410f') 'SHELL_BODY_CHANGED'
    Pin $gateContract.authority (Relative-File $gateContract.authority.path)
    Need ((Relative-File $gateContract.authority.path) -ieq ($repoFixed + '\code\docs\test\m3_pro_fourvoice_trace_20261016\pro_basis_r08_20261017\coordinator\night_r10_20261017\backend_stream_r13_20261018\backend_close\PLAN.json')) 'AUTHORITY_PLAN_REQUIRED'
    Need ($gateContract.authority.sha256 -ceq '729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3') 'AUTHORITY_PLAN_CHANGED'
    Pin $gateContract.authorization (Relative-File $gateContract.authorization.path)
    Need ($gateContract.authorization.sha256 -ceq 'f6db0a87ca66d6dd30a21203ac2210db6260c91aea875d2fac4534ac53bf98e5') 'R13_AUTHORIZATION_IDENTITY_CHANGED'
    Window
}
function Python-Resolution([string]$Stage, [bool]$Required) {
    $all = @(Get-Command -Name python -All -ErrorAction SilentlyContinue)
    $entries = @($all | ForEach-Object { [ordered]@{ name = $_.Name; type = [string]$_.CommandType; source = $_.Source; definition = $_.Definition } })
    $match = $false
    if ($all.Count -gt 0 -and $all[0].CommandType -eq [System.Management.Automation.CommandTypes]::Application) {
        $match = (Absolute $all[0].Definition) -ieq $pythonFixed
    }
    $record = [ordered]@{ utc = [DateTimeOffset]::UtcNow.ToString('o'); path = $env:PATH; commands = $entries; first_is_frozen_python = $match; match_required = $Required }
    $proof.phases[$Stage] = $record
    Save ($Stage + '.json') $record
    if ($Required) { Need $match 'BARE_PYTHON_NOT_FROZEN_EXECUTABLE'; Pin $gateContract.python $pythonFixed }
}
try {
    Need (-not [string]::IsNullOrWhiteSpace($ContractPath)) 'DEFAULT_DENY_NO_CONTRACT'
    $ContractPath = Absolute $ContractPath
    Reject-Alias $ContractPath
    Need ($ContractSha256 -cmatch '^[0-9a-f]{64}$') 'EXTERNAL_CONTRACT_SHA_REQUIRED'
    Need ((Get-FileHash -Algorithm SHA256 -LiteralPath $ContractPath).Hash.ToLowerInvariant() -ceq $ContractSha256) 'CONTRACT_SHA_MISMATCH'
    $gateContract = Get-Content -LiteralPath $ContractPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Need ($gateContract.schema -ceq 'M3_R13_GATE_CONTRACT_V1') 'WRONG_CONTRACT_SCHEMA'
    Need ($gateContract.approved -is [bool] -and $gateContract.approved) 'ROOT_APPROVED_RESUMED_CONTRACT_REQUIRED'
    Need ((Absolute $gateContract.root) -ieq $repoFixed) 'ROOT_MISMATCH'
    Profile
    $logRoot = Absolute $gateContract.output
    Need ($logRoot.StartsWith($recoveryFixed + '\', [StringComparison]::OrdinalIgnoreCase)) 'OUTPUT_OUTSIDE_R13'
    Need ((Get-Item -LiteralPath $logRoot).PSIsContainer) 'ROOT_PRECREATED_OUTPUT_REQUIRED'
    Reject-Alias $logRoot
    Need (-not (Test-Path -LiteralPath (Join-Path $logRoot 'ENVIRONMENT_PROOF.json'))) 'PROOF_ALREADY_EXISTS_NO_RETRY'
    $proof.contract_sha256 = $ContractSha256
    $proof.contract_path = $ContractPath
    $proof.contract_original = [IO.File]::ReadAllText($ContractPath)
    $proof.preflight_only_switch = [bool]$PreflightOnly
    $proof.slot = $gateContract.slot
    $proof.original_module_path = $originalModulePath
    $proof.effective_module_path = $env:PSModulePath
    $hashModule = (Get-Command Get-FileHash).Module.Path
    Need ($hashModule.StartsWith((Join-Path $PSHOME 'Modules'), [StringComparison]::OrdinalIgnoreCase)) 'HASH_CMDLET_NOT_PINNED_SHELL_MODULE'
    $proof.hash_cmdlet_module_path = $hashModule
    $hashCommand = Get-Command Get-FileHash
    $proof.hash_cmdlet = [ordered]@{ type = [string]$hashCommand.CommandType; module_name = $hashCommand.ModuleName; module_version = [string]$hashCommand.Module.Version }
    $proof.ps_version = [string]$PSVersionTable.PSVersion
    $proof.ps_edition = [string]$PSVersionTable.PSEdition
    Need ($PSVersionTable.PSEdition -ceq 'Desktop') 'PINNED_DESKTOP_SHELL_REQUIRED'
    $proof.pid = $PID
    Python-Resolution 'RESOLUTION_ORIGINAL' $false
    # This is the root-supervised child process. No user/machine environment API.
    $env:PATH = ([IO.Path]::GetDirectoryName($pythonFixed)) + ';' + $env:PATH
    Python-Resolution 'RESOLUTION_BEFORE_ENTER_ENV' $true
    Profile
    . $gateContract.enter_environment.path
    Python-Resolution 'RESOLUTION_AFTER_ENTER_ENV' $true
    Profile
    Python-Resolution 'RESOLUTION_IMMEDIATELY_BEFORE_GATE' $true
    $proof.status = 'ACTUAL_RESOLUTION_VERIFIED_BEFORE_GATE_NOT_A_GATE_PASS'
    $proof.verified_utc = [DateTimeOffset]::UtcNow.ToString('o')
    Save 'ENVIRONMENT_PROOF.json' $proof
    if ($PreflightOnly) { Write-Host 'R12_PREFLIGHT_ONLY_NO_GATE_LAUNCH'; exit 0 }
    # Full contract, source/evidence, tool hashes and 900-second margin again.
    Profile
    Push-Location -LiteralPath $repoFixed
    try {
        $global:LASTEXITCODE = 97
        & $gateContract.gate_script.path
        $actualGateExit = [int]$LASTEXITCODE
    } finally { Pop-Location }
    # Preserve gate stdout/stderr for the owned supervisor; no capture/rewrite.
    exit $actualGateExit
} catch {
    if ($null -ne $logRoot) {
        try { Save 'WRAPPER_FAILURE.json' ([ordered]@{ utc = [DateTimeOffset]::UtcNow.ToString('o'); status = 'FAIL_CLOSED'; error = $_.Exception.Message; no_retry = $true }) } catch { [Console]::Error.WriteLine('FAILURE_LOG_WRITE_FAILED') }
    }
    [Console]::Error.WriteLine('R13_GATE_CHILD_FAIL_CLOSED: ' + $_.Exception.Message)
    exit $failureExit
}
