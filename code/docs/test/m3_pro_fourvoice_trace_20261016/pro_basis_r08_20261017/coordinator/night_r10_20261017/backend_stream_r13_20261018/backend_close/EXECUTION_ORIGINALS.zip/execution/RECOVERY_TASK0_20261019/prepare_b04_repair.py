"""Root metadata only; no candidate import or execution."""
import argparse
import difflib
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
HERE = OUT / 'RECOVERY_TASK0_20261019'
WORK = HERE / 'B04_SEAL_REPAIR'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'

def read(path):
    return json.loads(path.read_text('utf-8'))

def save(path, value, new=True):
    assert not new or not path.exists(), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def ref(path):
    path = path.resolve()
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
            size += len(block)
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest()}

p = argparse.ArgumentParser()
p.add_argument('mode', choices=('freeze', 'P1_B04_01', 'B04_RECOVERY_05'))
a = p.parse_args()
ledger_path = OUT / 'CONSUMPTION_LIVE.json'
ledger = read(ledger_path)
authority = WORK / 'AUTHORITY_AND_LOCATOR.json'
freeze_path = WORK / 'FREEZE.json'
controller = HERE / 'root_run_b04_repair.py'
if a.mode == 'freeze':
    assert ledger['recovery_attempts']['B_RECOVERY_04']['state'] == 'FAILED_STOP'
    before, after = WORK / 'BEFORE_job_bridge.py', SOURCE / 'job_bridge.py'
    diff = ''.join(difflib.unified_diff(before.read_text('utf-8').splitlines(True), after.read_text('utf-8').splitlines(True), fromfile='before_job_bridge.py', tofile='after_job_bridge.py'))
    assert diff
    (WORK / 'REPAIR.diff').write_text(diff, encoding='utf-8', newline='\n')
    save(authority, {'schema': 'M3_USER_TASK0_LOCATED_B04_REPAIR_V1', 'problem_attempt_ordinal': 6,
         'attempts_limit': 8, 'authority': 'Latest user resolves W/task0-3 with up to8 evidence-based attempts',
         'located_cause': 'seal uses stop.wait after stop.set, so three retries wait0s. Actual B04 console member remained unsignaled although Job0/native original close observed. Bound real retained-handle WaitForSingleObject to500ms and original deadline; no final peak invented.',
         'source_before': ref(before), 'source_after': ref(after), 'diff': ref(WORK / 'REPAIR.diff'),
         'old_failures_and_charges_preserved': True,
         'new_attempts': {'P1_B04_01': {'cap_seconds': 60}, 'B04_RECOVERY_05': {'cap_seconds': 120}},
         'regression_scope': 'Fresh P1; execute B04 only. Reuse actual same-night B_RECOVERY_04 9 business/B02/B03 originals, source changes limited to observer late reap, unchanged selftest/binding/volume/data.',
         'charge_bucket': 'USER_TASK0_RECOVERY_INCREMENT', 'deadline': ledger['deadline'],
         'recorded_utc': datetime.now(timezone.utc).isoformat()})
    old = read(HERE / 'B_PINS_REPAIR/FREEZE.json')
    items = []
    for item in old['frozen_files']:
        actual = ref(Path(item['path']))
        if Path(item['path']).resolve() != after.resolve():
            assert actual == item
        items.append(actual)
    originals = [ref(OUT / name) for name in ('RUNS/B_RECOVERY_04/stdout.bin', 'RUNS/B_RECOVERY_04/inner/B02/worker/WORKER_LOCAL_RESULT.json')]
    save(freeze_path, {'state': 'REPAIR_FROZEN_BY_ROOT', 'frozen_files': items + originals +
         [ref(authority), ref(WORK / 'REPAIR.diff'), ref(HERE / 'b04_recovery_worker.py')], 'all_target_writers_closed': True})
    raw = (HERE / 'root_run_pins_repair.py').read_text('utf-8')
    raw = raw.replace("get('B_RECOVERY_04', {}).get('state') == 'PASS'", "get('B04_RECOVERY_05', {}).get('state') == 'PASS'")
    raw = raw.replace("('P1_PINS_01', 'B_RECOVERY_04')", "('P1_B04_01', 'B04_RECOVERY_05')")
    raw = raw.replace("attempt_id == 'P1_PINS_01'", "attempt_id == 'P1_B04_01'")
    raw = raw.replace("attempt_id == 'B_RECOVERY_04'", "attempt_id == 'B04_RECOVERY_05'")
    raw = raw.replace("['B_RECOVERY_03']['state'] == 'FAILED_STOP'", "['B_RECOVERY_04']['state'] == 'FAILED_STOP'")
    raw = raw.replace("['P1_PINS_01']['state'] == 'PASS'", "['P1_B04_01']['state'] == 'PASS'")
    raw = raw.replace("OUT / 'seal_r13.py')", "OUT / 'seal_r13.py', OUT / 'RECOVERY_TASK0_20261019/b04_recovery_worker.py')")
    assert not controller.exists()
    controller.write_text(raw, encoding='utf-8', newline='\n')
    for key, cap, count in [('P1_B04_01', 60, 1), ('B04_RECOVERY_05', 120, 12)]:
        assert key not in ledger['recovery_attempts']
        ledger['recovery_attempts'][key] = {'state': 'NOT_STARTED', 'attempts': 0, 'charged_seconds': 0,
             'cap_seconds': cap, 'cases_max': count, 'authority': ref(authority)}
    save(ledger_path, ledger, False)
    print(json.dumps({'freeze': ref(freeze_path), 'controller': ref(controller)}))
else:
    key = a.mode
    assert ledger['recovery_attempts'][key]['state'] == 'NOT_STARTED'
    wire, cap = ('P1', 60) if key == 'P1_B04_01' else ('B', 120)
    if wire == 'B':
        assert ledger['recovery_attempts']['P1_B04_01']['state'] == 'PASS'
    freeze = read(freeze_path)
    for item in freeze['frozen_files']:
        assert ref(Path(item['path'])) == item
    base = OUT / 'ADMISSIONS' / key
    ap = base / 'ADMISSION.json'
    owner = OUT / 'RUNS' / key / 'inner'
    python = str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
    adm = read(OUT / 'ADMISSIONS/P1_PINS_01/ADMISSION.json')
    adm.update(group=wire, absolute_cap_seconds=cap, root_deadline_monotonic=time.monotonic() + cap,
               root_accounting_slot=key, source_freeze=ref(freeze_path))
    adm['external_log_escrows'] = {k.replace('RUNS/P1_PINS_01/', 'RUNS/' + key + '/'): v for k, v in adm['external_log_escrows'].items()}
    adm['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller'] = ref(controller)
    if wire == 'P1':
        target = SOURCE / 'job_bridge.py'
        adm['argv'] = [python, '-X', 'utf8', '-B', str(SOURCE / 'selftest.py'), '--worker', '--group', 'P1', '--admission', str(ap), '--admission-sha256', '@ADMISSION_SHA256@', '--output', str(owner / 'worker')]
        save(ap, adm)
        argv = [python, '-X', 'utf8', '-B', str(target), '--execute-one', '--admission', str(ap), '--admission-sha256', ref(ap)['sha256'], '--owner-output', str(owner)]
        worker_path = 'inner/worker/WORKER_LOCAL_RESULT.json'
    else:
        target = HERE / 'b04_recovery_worker.py'
        adm.update(purpose='B04_LATE_MEMBER_REAP_ONLY', old_originals=[ref(OUT / name) for name in ('RUNS/B_RECOVERY_04/stdout.bin', 'RUNS/B_RECOVERY_04/inner/B02/worker/WORKER_LOCAL_RESULT.json')])
        save(ap, adm)
        argv = [python, '-X', 'utf8', '-B', str(target), '--admission', str(ap), '--sha256', ref(ap)['sha256'], '--output', str(owner)]
        worker_path = 'inner/WORKER_LOCAL_RESULT.json'
    contract = {'root_approved': True, 'slot': wire, 'attempt_id': key, 'wire_group': wire, 'repair_group': 'B',
         'plan_sha256': adm['plan_sha256'], 'cap_seconds': cap, 'new_user_authority': ref(authority),
         'all_target_writers_closed': True, 'frozen_files': [*freeze['frozen_files'], ref(freeze_path), ref(ap), ref(controller)],
         'target_script': str(target), 'argv': argv, 'worker_result_relative_path': worker_path,
         'bridge_result_relative_path': 'inner/GROUP_COMPLETE.json',
         'expected_case_ids': ['P001'] if wire == 'P1' else [f'B{i:02d}' for i in range(1, 13)]}
    cp = base / 'ROOT_CONTRACT.json'
    save(cp, contract)
    print(json.dumps(ref(cp)))
