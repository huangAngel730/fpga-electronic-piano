"""Register one user-authorized S1 live-ledger successor without resetting old consumption."""
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / "code/output/m3_backend_stream_r13_20261018"
TASK = OUT / "RECOVERY_TASK0_20261019/S1_LIVE_RECOVERY_12"
LEDGER = OUT / "CONSUMPTION_LIVE.json"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def stamp(path):
    raw = path.read_bytes()
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


ledger = read(LEDGER)
old = ledger["groups"]["S1"]
assert old["state"] == "FAILED_STOP"
assert old["attempts"] == 1 and old["charged_seconds"] == 60
assert old["actual_result"]["exit_code"] == 1
assert ledger["recovery_attempts"].get("S1_LIVE_01") is None
proposal = TASK / "EXECUTION_PROPOSAL.json"
authorization = TASK / "AUTHORIZATION.json"
assert stamp(proposal)["sha256"] == (
    "39b2f8143f73431b968a126faa7bb5594f7868e599d096f5ab740e6ef6ae8197"
)
auth = read(authorization)
assert auth["approved"] is True
assert auth["approved_proposal_sha256"] == stamp(proposal)["sha256"]
ledger["recovery_attempts"]["S1_LIVE_01"] = {
    "state": "NOT_STARTED",
    "attempts": 0,
    "charged_seconds": 0,
    "cap_seconds": 60,
    "runs": 1,
    "purpose": "exclude mutable live ledger and reuse verified source archive",
    "authority": stamp(authorization),
    "old_failed_group": "S1",
    "old_charge_preserved": True,
    "source_archive_rewrite": False,
}
LEDGER.write_text(
    json.dumps(ledger, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps(ledger["recovery_attempts"]["S1_LIVE_01"], ensure_ascii=False))
