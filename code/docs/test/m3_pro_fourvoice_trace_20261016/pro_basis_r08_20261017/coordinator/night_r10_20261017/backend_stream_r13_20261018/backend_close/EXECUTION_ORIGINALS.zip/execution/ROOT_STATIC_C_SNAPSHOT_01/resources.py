"""Resource admission and post-run accounting for R13 workers."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
from pathlib import Path
import shutil

from stream_bridge import require

MIB = 1024 * 1024
GIB = 1024 * MIB
WORKER_LIMIT = 512 * MIB
WORKSPACE_LIMIT = 24 * GIB
START_FREE = 32 * GIB
END_RESERVE = 8 * GIB


def disk_snapshot(path: Path) -> dict:
    path = Path(path).resolve()
    usage = shutil.disk_usage(path if path.exists() else path.parent)
    files, total = 0, 0
    if path.exists():
        for item in path.rglob("*"):
            if item.is_file():
                files += 1
                total += item.stat().st_size
    return {"path": str(path), "files": files, "tree_bytes": total,
            "disk_total": usage.total, "disk_used": usage.used,
            "disk_free": usage.free}


def preflight(path: Path, *, full_window: bool) -> dict:
    snap = disk_snapshot(path)
    decision = "GO" if (not full_window or snap["disk_free"] >= START_FREE) else "NO_GO"
    return {"schema": "M3_R13_RESOURCE_PREFLIGHT_V1", **snap,
            "full_window": full_window, "required_start_free": START_FREE,
            "workspace_limit": WORKSPACE_LIMIT, "end_reserve": END_RESERVE,
            "decision": decision}


def process_peak(process_handle: int) -> dict:
    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("faults", wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in
            ("peak_working_set", "working_set", "peak_paged", "paged",
             "peak_nonpaged", "nonpaged", "pagefile", "peak_pagefile")]
    api = ctypes.WinDLL("psapi", use_last_error=True).GetProcessMemoryInfo
    api.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
    api.restype = wintypes.BOOL
    data = Counters()
    data.cb = ctypes.sizeof(data)
    if not api(wintypes.HANDLE(process_handle), ctypes.byref(data), data.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return {"metric": "PROCESS_MEMORY_COUNTERS.PeakWorkingSetSize",
            "bytes": int(data.peak_working_set), "limit": WORKER_LIMIT}


def finalize_resources(path: Path, peak: dict, job: dict) -> dict:
    snap = disk_snapshot(path)
    child_count = max(0, int(job.get("total", 0)) - 1)
    result = {"schema": "M3_R13_RESOURCE_RESULT_V1", **snap,
              "worker_peak": peak, "job": job,
              "child_processes_inferred": child_count,
              "worker_peak_is_tree_peak": child_count == 0,
              "workspace_limit": WORKSPACE_LIMIT,
              "end_reserve": END_RESERVE}
    result["pass"] = (peak.get("bytes", WORKER_LIMIT + 1) <= WORKER_LIMIT and
                      snap["tree_bytes"] <= WORKSPACE_LIMIT and
                      snap["disk_free"] >= END_RESERVE and
                      child_count == 0 and
                      job.get("job_zero_observed_before_job_close") is True and
                      job.get("root_process_handle_closed") is True and
                      job.get("job_handle_closed") is True)
    return result
