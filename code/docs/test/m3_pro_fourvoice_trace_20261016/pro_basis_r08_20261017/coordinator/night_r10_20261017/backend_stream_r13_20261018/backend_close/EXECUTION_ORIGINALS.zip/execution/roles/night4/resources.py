"""R13 resource contracts and serial write reservations; no import-time IO.

This module starts no process and takes no OS memory measurement. A directory
snapshot is OBSERVED, never a strict peak. Reservation coverage becomes proof
only when the owned runner attests that every writer used this one budget for
the entire lifetime, including logs, temporary files, volumes and failures.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import stat
import threading
import uuid

MIB = 1024 ** 2
GIB = 1024 ** 3
REPARSE_POINT = 0x400


class ResourceViolation(ValueError):
    """Stop the current owned stage; partial artifacts must remain available."""


def _integer(value, name):
    if type(value) is not int or value < 0:
        raise ResourceViolation("NONNEGATIVE_INTEGER_REQUIRED:" + name)
    return value


class Limits:
    __slots__ = ("worker_peak_bytes", "chunk_bytes", "workspace_peak_bytes",
                 "initial_free_bytes", "reserve_free_bytes")

    def __init__(self, worker_peak_bytes=512 * MIB, chunk_bytes=MIB,
                 workspace_peak_bytes=24 * GIB, initial_free_bytes=32 * GIB,
                 reserve_free_bytes=8 * GIB):
        values = dict(worker_peak_bytes=worker_peak_bytes, chunk_bytes=chunk_bytes,
                      workspace_peak_bytes=workspace_peak_bytes,
                      initial_free_bytes=initial_free_bytes,
                      reserve_free_bytes=reserve_free_bytes)
        for key, value in values.items():
            _integer(value, key)
            if value == 0:
                raise ResourceViolation("POSITIVE_LIMIT_REQUIRED:" + key)
            object.__setattr__(self, key, value)
        if (self.worker_peak_bytes > 512 * MIB or self.chunk_bytes > MIB
                or self.workspace_peak_bytes > 24 * GIB
                or self.initial_free_bytes < 32 * GIB
                or self.reserve_free_bytes < 8 * GIB):
            raise ResourceViolation("LIMIT_EXCEEDS_R13_AUTHORIZATION")

    def as_dict(self):
        return {key: getattr(self, key) for key in self.__slots__}

    def __setattr__(self, key, value):
        raise AttributeError("Limits is immutable")


def _configured(limits):
    if limits is None:
        return Limits()
    if type(limits) is not Limits:
        raise ResourceViolation("LIMITS_TYPE_REQUIRED")
    return limits


def _path(value):
    """Canonical lexical path, checking every existing ancestor without follow."""
    result = Path(os.path.abspath(os.fspath(value)))
    for item in (*reversed(result.parents), result):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if (stat.S_ISLNK(info.st_mode)
                or getattr(info, "st_file_attributes", 0) & REPARSE_POINT):
            raise ResourceViolation("REPARSE_OR_LINK:" + str(item))
    return result


def census(root):
    """Count every regular file; never traverse a link, junction or reparse.

    An inaccessible, special or changing entry makes coverage incomplete. All
    suffixes, dotfiles and all directories are included, with no output-only
    filter. Hard links count at every name, conservatively. Bytes are logical
    file lengths; volume free space is a separate physical-volume measurement.
    """
    result = {"schema": "M3_R13_WORKSPACE_CENSUS_V1", "status": "OBSERVED",
              "root": str(root), "files": [], "file_count": 0,
              "directory_count": 0, "total_bytes": 0, "issues": [],
              "complete_file_coverage": False, "strict_peak": False,
              "byte_metric": "SUM_OF_ALL_REGULAR_FILE_LENGTHS"}
    try:
        base = _path(root)
        result["root"] = str(base)
        if not base.is_dir():
            raise ResourceViolation("WORKSPACE_DIRECTORY_REQUIRED")
        pending = [base]
        while pending:
            directory = pending.pop()
            _path(directory)
            result["directory_count"] += 1
            with os.scandir(directory) as entries:
                for entry in entries:
                    name = Path(entry.path)
                    info = entry.stat(follow_symlinks=False)
                    if (stat.S_ISLNK(info.st_mode)
                            or getattr(info, "st_file_attributes", 0) & REPARSE_POINT):
                        result["issues"].append("REPARSE_OR_LINK:" + str(name))
                    elif stat.S_ISDIR(info.st_mode):
                        pending.append(name)
                    elif stat.S_ISREG(info.st_mode):
                        result["files"].append({"path": name.relative_to(base).as_posix(),
                                                "bytes": int(info.st_size)})
                        result["total_bytes"] += int(info.st_size)
                        result["file_count"] += 1
                    else:
                        result["issues"].append("SPECIAL_FILE:" + str(name))
        result["files"].sort(key=lambda item: item["path"])
        result["complete_file_coverage"] = not result["issues"]
    except (OSError, ResourceViolation) as error:
        result["issues"].append(type(error).__name__ + ":" + str(error))
    if result["issues"]:
        result["status"] = "INCOMPLETE"
    return result


def preflight(root, projected_peak_bytes, limits=None):
    """Check the projected TOTAL workspace peak, not only future growth."""
    limits = _configured(limits)
    _integer(projected_peak_bytes, "projected_peak_bytes")
    measured = census(root)
    reasons = []
    free = None
    if not measured["complete_file_coverage"]:
        reasons.append("WORKSPACE_COVERAGE_INCOMPLETE")
    try:
        free = int(shutil.disk_usage(_path(root)).free)
    except (OSError, ResourceViolation) as error:
        reasons.append("FREE_SPACE_UNAVAILABLE:" + str(error))
    if projected_peak_bytes < measured["total_bytes"]:
        reasons.append("PROJECTED_PEAK_BELOW_EXISTING_FILES")
    if max(projected_peak_bytes, measured["total_bytes"]) > limits.workspace_peak_bytes:
        reasons.append("WORKSPACE_24GIB_BOUND")
    growth = max(0, projected_peak_bytes - measured["total_bytes"])
    if free is not None:
        if free < limits.initial_free_bytes:
            reasons.append("INITIAL_FREE_32GIB_BOUND")
        if free - growth < limits.reserve_free_bytes:
            reasons.append("PROJECTED_FREE_RESERVE_8GIB_BOUND")
    return {"schema": "M3_R13_RESOURCE_PREFLIGHT_V1",
            "status": "PASS" if not reasons else "FAIL", "reasons": reasons,
            "limits": limits.as_dict(), "census": measured,
            "projected_peak_bytes": projected_peak_bytes,
            "projected_growth_bytes": growth, "initial_free_bytes": free,
            "projected_free_bytes": None if free is None else free - growth,
            "scope": "STATIC_GEOMETRY_AND_CURRENT_VOLUME_ONLY",
            "memory_measured": False, "execution_allowed": False}


class WorkspaceBudget:
    """One exclusive serial writer with mandatory pre-write reservations.

    The caller performs actual IO, using xb for exclusive and ab for append,
    flushes its userspace buffers so stat observes the written file length,
    then settles in finally with after_write(..., failed=True if needed).
    Failed/partial writes still require that flush-and-settle attempt; a flush
    failure leaves the run failed, never a successful resource proof.
    No deletion/reclamation, sparse seek, overwrite, pending second write or
    unregistered extra writer is supported. Each write is <= chunk_bytes.
    This API does not intercept external tools: their output needs an owned
    bounded writer, or complete coverage stays PENDING.
    """
    def __init__(self, root, limits=None):
        self.root = _path(root)
        self.limits = _configured(limits)
        initial = census(self.root)
        if not initial["complete_file_coverage"]:
            raise ResourceViolation("INITIAL_WORKSPACE_COVERAGE_INCOMPLETE")
        self.initial_free = int(shutil.disk_usage(self.root).free)
        if (initial["total_bytes"] > self.limits.workspace_peak_bytes
                or self.initial_free < self.limits.initial_free_bytes
                or self.initial_free < self.limits.reserve_free_bytes):
            raise ResourceViolation("WORKSPACE_INITIAL_LIMIT")
        self._known = self._inventory(initial)
        self._pending = None
        self._lock = threading.RLock()
        self._failed = []
        self._writes = 0
        self._failed_writes = 0
        self._bytes_written = 0
        self._max_chunk = 0
        self._peak_bound = initial["total_bytes"]
        self._minimum_free_observed = self.initial_free
        self._last = initial

    @staticmethod
    def _inventory(snapshot):
        return {item["path"]: item["bytes"] for item in snapshot["files"]}

    def _snapshot(self):
        snapshot = census(self.root)
        self._last = snapshot
        if not snapshot["complete_file_coverage"]:
            self._failed.append("WORKSPACE_COVERAGE_INCOMPLETE")
            raise ResourceViolation(self._failed[-1])
        return snapshot

    def before_write(self, path, n, *, mode="exclusive"):
        """Reserve before IO; flush actual writes before the mandatory settle."""
        _integer(n, "write_bytes")
        with self._lock:
            if self._failed or self._pending is not None:
                raise ResourceViolation("BUDGET_FAILED_OR_RESERVATION_UNSETTLED")
            if mode not in ("exclusive", "append") or n > self.limits.chunk_bytes:
                raise ResourceViolation("WRITE_MODE_OR_PHYSICAL_CHUNK_BOUND")
            target = _path(path)
            if target == self.root or not target.is_relative_to(self.root):
                raise ResourceViolation("WRITE_OUTSIDE_WORKSPACE")
            name = target.relative_to(self.root).as_posix()
            snapshot = self._snapshot()
            if self._inventory(snapshot) != self._known:
                self._failed.append("UNREGISTERED_FILE_MUTATION")
                raise ResourceViolation(self._failed[-1])
            if ((mode == "exclusive" and target.exists())
                    or (mode == "append" and name not in self._known)):
                raise ResourceViolation("EXCLUSIVE_OR_APPEND_PRECONDITION")
            upper = snapshot["total_bytes"] + n
            free = int(shutil.disk_usage(self.root).free)
            self._minimum_free_observed = min(self._minimum_free_observed, free)
            if upper > self.limits.workspace_peak_bytes:
                raise ResourceViolation("WORKSPACE_RESERVATION_BOUND")
            if free - n < self.limits.reserve_free_bytes:
                raise ResourceViolation("FREE_RESERVE_BEFORE_WRITE")
            reservation = {"token": uuid.uuid4().hex, "path": str(target),
                           "relative_path": name, "mode": mode, "bytes": n,
                           "before_bytes": self._known.get(name, 0),
                           "workspace_upper_bound_bytes": upper}
            self._pending = dict(reservation)
            self._peak_bound = max(self._peak_bound, upper)
            self._max_chunk = max(self._max_chunk, n)
            return reservation

    def after_write(self, reservation, actual_bytes=None, *, failed=False):
        """After flushing to stat-visible size, settle even failed/partial IO.

        This method does not own the caller's output handle and cannot flush
        it. A missing flush must not be hidden by a successful receipt.
        """
        with self._lock:
            if type(reservation) is not dict or reservation != self._pending:
                raise ResourceViolation("UNKNOWN_OR_CHANGED_RESERVATION")
            current = self._snapshot()
            inventory = self._inventory(current)
            name = reservation["relative_path"]
            before_size = reservation["before_bytes"]
            after_size = inventory.get(name, 0)
            growth = after_size - before_size
            expected_other = {key: size for key, size in self._known.items() if key != name}
            actual_other = {key: size for key, size in inventory.items() if key != name}
            reasons = []
            if expected_other != actual_other:
                reasons.append("UNREGISTERED_FILE_MUTATION")
            if (growth < 0 or growth > reservation["bytes"]
                    or (reservation["mode"] == "append" and name not in inventory)):
                reasons.append("RESERVATION_EXCEEDED_OR_FILE_LOST")
            if actual_bytes is not None:
                _integer(actual_bytes, "actual_bytes")
                if actual_bytes != growth:
                    reasons.append("WRITE_COUNT_FILE_LENGTH_MISMATCH")
            if not failed and (name not in inventory or growth != reservation["bytes"]):
                reasons.append("SHORT_WRITE_WITHOUT_FAILURE")
            free = int(shutil.disk_usage(self.root).free)
            self._minimum_free_observed = min(self._minimum_free_observed, free)
            if current["total_bytes"] > self.limits.workspace_peak_bytes:
                reasons.append("WORKSPACE_ACTUAL_BOUND")
            if free < self.limits.reserve_free_bytes:
                reasons.append("FREE_RESERVE_AFTER_WRITE")
            self._peak_bound = max(self._peak_bound, current["total_bytes"])
            self._writes += 1
            self._failed_writes += int(bool(failed))
            self._bytes_written += max(0, growth)
            self._known = inventory
            self._pending = None
            self._failed.extend(reasons)
            result = {"status": "FAIL" if reasons else "SETTLED",
                      "reasons": reasons, "partial_write_failed": bool(failed),
                      "actual_growth_bytes": growth, "workspace_bytes": current["total_bytes"],
                      "free_bytes_observed": free, "reservation": dict(reservation)}
            if reasons:
                raise ResourceViolation(";".join(reasons))
            return result

    def receipt(self, *, exclusive_writer=False, all_writes_reserved=False,
                max_physical_chunk_bytes=None):
        """Runner attestations and measured physical chunk are not census facts.

        Reserved n bounds the requested write, not a buffered writer's actual
        lower-level operations or input reads. Supply the separately measured
        maximum across all physical reads/writes, or leave it PENDING.
        """
        if max_physical_chunk_bytes is not None:
            _integer(max_physical_chunk_bytes, "max_physical_chunk_bytes")
        with self._lock:
            current = self._snapshot()
            unchanged = self._inventory(current) == self._known
            if not unchanged:
                self._failed.append("UNREGISTERED_FILE_MUTATION")
            complete = (unchanged and not self._failed and self._pending is None
                        and exclusive_writer is True and all_writes_reserved is True)
            return {"schema": "M3_R13_WORKSPACE_BUDGET_RECEIPT_V1",
                    "status": "FAIL" if self._failed else "PROVEN_BOUND" if complete else "PENDING",
                    "root": str(self.root), "complete_file_coverage": complete,
                    "all_writes_reserved": all_writes_reserved is True,
                    "exclusive_writer": exclusive_writer is True,
                    "strict_peak": complete, "metric": "RESERVATION_ENFORCED_LOGICAL_BYTE_UPPER_BOUND",
                    "peak_bytes": self._peak_bound, "current_bytes": current["total_bytes"],
                    "current_file_count": current["file_count"], "writes": self._writes,
                    "failed_writes_included": self._failed_writes,
                    "total_growth_bytes": self._bytes_written,
                    "max_reserved_write_bytes": self._max_chunk,
                    "max_physical_chunk_bytes": max_physical_chunk_bytes,
                    "initial_free_bytes": self.initial_free,
                    "min_free_bytes": self._minimum_free_observed,
                    "min_free_metric": "OBSERVED_VOLUME_FREE_NOT_A_CONTINUOUS_VOLUME_PROOF",
                    "reserve_checks_before_and_after_each_write": True,
                    "volume_reserve_bound_complete": False,
                    "volume_reserve_bound_evidence": None,
                    "unsettled_reservations": int(self._pending is not None),
                    "reasons": list(self._failed), "limits": self.limits.as_dict()}


def check_measured_receipt(metrics, limits=None, *, authorized_cap_seconds=None):
    """Judge supplied owned-run evidence; missing proof is never a PASS.

    PeakWorkingSet64 is an OS process-lifetime peak, not a poller maximum.
    Descendants need an independently justified strict concurrent-tree working
    set peak; sums of separate lifetime peaks and Job private-commit peaks are
    not substituted for it. Supervisor memory must be recorded separately.
    """
    limits = _configured(limits)
    if type(metrics) is not dict:
        return {"status": "FAIL", "failures": ["METRICS_OBJECT_REQUIRED"], "pending": []}
    failures, pending = [], []
    memory = metrics.get("worker_memory", {})
    process = metrics.get("process_evidence", {})
    workspace = metrics.get("workspace", {})
    job = metrics.get("job", {})
    timing = metrics.get("timing", {})
    if not all(type(item) is dict for item in (memory, process, workspace, job, timing)):
        return {"status": "FAIL", "failures": ["METRIC_SECTIONS_MUST_BE_OBJECTS"], "pending": []}
    single = (process.get("total_processes") == 1
              and type(process.get("total_processes")) is int
              and process.get("descendants_ever") == 0
              and type(process.get("descendants_ever")) is int
              and process.get("job_total_processes") == 1
              and type(process.get("job_total_processes")) is int
              and process.get("complete_lifetime") is True
              and process.get("attached_before_resume") is True
              and process.get("breakaway_disallowed") is True)
    tree = (memory.get("scope") == "concurrent_process_tree"
            and memory.get("metric") == "STRICT_CONCURRENT_TREE_WORKING_SET"
            and memory.get("strict_peak") is True
            and process.get("complete_lifetime") is True
            and memory.get("aggregate_evidence_complete") is True)
    if not single and not tree:
        pending.append("NO_DESCENDANT_LIFETIME_OR_STRICT_TREE_AGGREGATE_EVIDENCE")
    valid_memory = ((single and memory.get("scope") == "single_worker"
                     and memory.get("metric") == "PeakWorkingSet64"
                     and memory.get("strict_peak") is True) or tree)
    if not valid_memory:
        pending.append("STRICT_WINDOWS_PEAK_WORKING_SET_EVIDENCE_REQUIRED")
    peak = memory.get("bytes")
    if type(peak) is not int or peak <= 0:
        pending.append("PEAK_MEMORY_BYTES_MISSING")
    elif peak > limits.worker_peak_bytes:
        failures.append("MEMORY_512MIB_BOUND")
    supervisor = metrics.get("supervisor_memory")
    if (type(supervisor) is not dict
            or type(supervisor.get("bytes")) is not int or supervisor["bytes"] <= 0
            or type(supervisor.get("metric")) is not str or not supervisor["metric"]):
        pending.append("SUPERVISOR_MEMORY_SEPARATE_RECORD_REQUIRED")
    for flag in ("complete_file_coverage", "all_writes_reserved", "exclusive_writer", "strict_peak"):
        if workspace.get(flag) is not True:
            pending.append("WORKSPACE_PROOF_MISSING:" + flag)
    if workspace.get("metric") != "RESERVATION_ENFORCED_LOGICAL_BYTE_UPPER_BOUND":
        pending.append("FINAL_CENSUS_OR_SAMPLING_IS_NOT_STRICT_WORKSPACE_PEAK")
    if workspace.get("reserve_checks_before_and_after_each_write") is not True:
        pending.append("RESERVE_CHECK_COVERAGE_REQUIRED")
    if (workspace.get("volume_reserve_bound_complete") is not True
            or not workspace.get("volume_reserve_bound_evidence")):
        pending.append("OBSERVED_FREE_SAMPLES_NOT_A_CONTINUOUS_RESERVE_PROOF")
    for key, bound, minimum in (
            ("peak_bytes", limits.workspace_peak_bytes, False),
            ("initial_free_bytes", limits.initial_free_bytes, True),
            ("min_free_bytes", limits.reserve_free_bytes, True),
            ("max_physical_chunk_bytes", limits.chunk_bytes, False)):
        value = workspace.get(key)
        if type(value) is not int or value < 0:
            pending.append("WORKSPACE_METRIC_MISSING:" + key)
        elif (minimum and value < bound) or (not minimum and value > bound):
            failures.append("WORKSPACE_BOUND:" + key)
    if workspace.get("unsettled_reservations") != 0 or type(workspace.get("unsettled_reservations")) is not int:
        pending.append("UNSETTLED_RESERVATIONS")
    if workspace.get("status") == "FAIL" or workspace.get("reasons"):
        failures.append("WORKSPACE_RECORDED_FAILURE")
    active = job.get("active_processes_final")
    if type(active) is int and active > 0:
        failures.append("JOB_NONZERO")
    elif type(active) is not int or active != 0:
        pending.append("JOB_ZERO_EVIDENCE_REQUIRED")
    for flag in ("job_zero_before_close", "root_process_handle_closed", "job_handle_closed"):
        if job.get(flag) is not True:
            pending.append("OWNED_CLEANUP_EVIDENCE_MISSING:" + flag)
    elapsed, cap = timing.get("elapsed_seconds"), timing.get("absolute_cap_seconds")
    numeric = lambda value: type(value) in (int, float) and 0 <= value < float("inf")
    if not numeric(elapsed) or not numeric(cap) or cap == 0:
        pending.append("ABSOLUTE_CAP_TIMING_REQUIRED")
    elif elapsed > cap:
        failures.append("ABSOLUTE_CAP_EXCEEDED")
    if authorized_cap_seconds is None:
        pending.append("FROZEN_AUTHORIZED_STAGE_CAP_REQUIRED")
    elif (not numeric(authorized_cap_seconds) or authorized_cap_seconds == 0
          or authorized_cap_seconds > 900):
        failures.append("INVALID_OR_UNAUTHORIZED_STAGE_CAP")
    elif cap != authorized_cap_seconds:
        failures.append("RECEIPT_CAP_DIFFERS_FROM_FROZEN_STAGE_CAP")
    if timing.get("complete_lifetime") is not True:
        pending.append("ABSOLUTE_CAP_MUST_INCLUDE_START_GENERATE_HASH_CLEANUP")
    if timing.get("absolute_watchdog_enforced") is not True:
        pending.append("ABSOLUTE_WATCHDOG_EVIDENCE_REQUIRED")
    return {"schema": "M3_R13_MEASURED_RESOURCE_DECISION_V1",
            "status": "FAIL" if failures else "PENDING" if pending else "PASS",
            "failures": failures, "pending": pending, "limits": limits.as_dict(),
            "measurement_performed_here": False, "execution_allowed": False,
            "real_verified": False, "board_release_allowed": False}
