import hashlib,json,time
from pathlib import Path
from datetime import datetime,timedelta,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=T/'W_HOUR_REPLAY_09';S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def ref(p):
 p=p.resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def save(p,v):
 assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
auth=D/'AUTHORIZATION_CLOSING.json';assert ref(auth)['sha256']=='138582298f07c5e3103005a05eb574be3c71af397d9b99bc1ae3483035e4ae79' and read(auth)['approved']
l=read(O/'CONSUMPTION_LIVE.json');assert l['recovery_attempts']['W_HOUR_09']['state']=='NOT_STARTED'
for x in read(D/'AUTHORIZATION_W.json')['source_files']:
 a=ref(R/x['path']);assert all(a[k]==x[k] for k in ('bytes','sha256'))
for key in ('P1_FILES_R01','C_CODEC_08','B_FILES_R01'):assert l['recovery_attempts'][key]['state']=='PASS'
remaining=3600+sum(x['cap_seconds'] for x in l['groups'].values() if x['state']=='NOT_STARTED')+1260-sum(x['charged_seconds'] for x in l['network']['operations'])+360-sum(x.get('charged_seconds',0) for x in l['local_git']['operations'])+390+120+60
assert datetime.now(timezone.utc)+timedelta(seconds=remaining)<=datetime.fromisoformat(l['deadline'])
items={};changed=[]
for x in read(T/'W_FILECOUNT_RECOVERY_R01/FREEZE.json')['frozen_files']:
 a=ref(Path(x['path']));assert a==x,('PREVIOUS_FROZEN_DEPENDENCY_CHANGED',x['path']);items[a['path'].casefold()]=a
for p in [auth,D/'AUTHORIZATION_W.json',D/'CLOSING_SUPPLEMENT_PROPOSAL.json',D/'PRELAUNCH_HEADROOM.json',T/'root_run_hour_09.py',T/'hour_09_bridge.py',T/'w_hour_09_worker.py']:
 a=ref(p);items[a['path'].casefold()]=a
inputs=read(T/'W_SCALAR_RECOVERY/FROZEN_INPUTS.json')
for x in inputs['files']:assert ref(Path(x['path']))==x
fp=D/'FREEZE.json';save(fp,{'state':'W_HOUR_09_CURRENT_RUNTIME_FROZEN','frozen_files':list(items.values()),'source_bytes_unchanged_from_passed_B12_C15':True,'original_full_input_reused':ref(T/'W_SCALAR_RECOVERY/FROZEN_INPUTS.json'),'no_failed_backend_output_reused':True,'all_target_writers_closed':True})
key='W_HOUR_09';base=O/'ADMISSIONS'/key;ap=base/'ADMISSION.json';owner=O/'RUNS'/key/'inner';controller=T/'root_run_hour_09.py';bridge=T/'hour_09_bridge.py';adm=read(O/'ADMISSIONS/W_CODEC_08/ADMISSION.json')
adm.update(absolute_cap_seconds=3600,root_deadline_monotonic=time.monotonic()+3600,root_accounting_slot=key,deadline=l['deadline'],source_freeze=ref(fp),hour_replay_authorization=ref(auth),prepared_utc=datetime.now(timezone.utc).isoformat())
adm['external_log_escrows']={k.replace('RUNS/W_CODEC_08/','RUNS/W_HOUR_09/'):v for k,v in adm['external_log_escrows'].items()}
for v in adm['external_log_escrows'].values():
 if 'bridge' in v['evidence']:v['evidence']['bridge']=ref(S/'job_bridge.py')
adm['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller']=ref(controller)
adm['external_log_escrows']['RUNS/W_HOUR_09/inner/GROUP_COMPLETE.json']['evidence']['bridge']=ref(bridge)
for name,role in [('stdout.bin','owner_stdout'),('stderr.bin','owner_stderr'),('RESULT.json','owner_result')]:
 v=json.loads(json.dumps(adm['external_log_escrows']['RUNS/W_HOUR_09/'+name]));v['role']=role;adm['external_log_escrows']['RUNS/W_HOUR_09/inner/'+name]=v
py=str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve());adm['argv']=[py,'-X','utf8','-B',str(T/'w_hour_09_worker.py'),'--admission',str(ap),'--sha256','@ADMISSION_SHA256@','--output',str(owner/'worker')]
save(ap,adm);argv=[py,'-X','utf8','-B',str(bridge),'--admission',str(ap),'--sha256',ref(ap)['sha256'],'--output',str(owner)]
cp=base/'ROOT_CONTRACT.json';save(cp,{'root_approved':True,'slot':'W','attempt_id':key,'wire_group':'W','plan_sha256':adm['plan_sha256'],'cap_seconds':3600,'all_target_writers_closed':True,'new_user_authority':ref(auth),'frozen_files':[*items.values(),ref(fp),ref(ap)],'target_script':str(bridge),'argv':argv,'worker_result_relative_path':'inner/worker/WORKER_COMPLETE.json','bridge_result_relative_path':'inner/GROUP_COMPLETE.json','expected_case_ids':['W01']})
save(D/'FULL_CAPS_BEFORE_W.json',{'available_seconds':(datetime.fromisoformat(l['deadline'])-datetime.now(timezone.utc)).total_seconds(),'all_remaining_caps_and_margin':remaining,'deadline':l['deadline'],'old_charges_restored':False})
print(json.dumps(ref(cp)))
