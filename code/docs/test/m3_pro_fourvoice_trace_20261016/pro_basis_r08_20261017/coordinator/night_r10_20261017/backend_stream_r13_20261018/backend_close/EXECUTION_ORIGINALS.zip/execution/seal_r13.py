"""The two predeclared R13 seal purposes; no tests or Git/network calls."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import time
import zipfile

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
CHUNK = 1048576
ARCHIVE_LIMIT = 32 * CHUNK
STEM = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
CLOSE = ROOT / 'code/docs/test' / STEM / 'backend_stream_r13_20261018/backend_close'


def identity(path):
    count, digest = 0, hashlib.sha256()
    with path.open('rb', buffering=0) as stream:
        for block in iter(lambda: stream.read(CHUNK), b''):
            check()
            count += len(block)
            digest.update(block)
    return {'path': path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT)
            else str(path), 'bytes': count, 'sha256': digest.hexdigest()}


def check():
    assert time.monotonic() < deadline, 'SAME_SEAL_SLOT_EXHAUSTED'


class ChunkedZipTarget:
    def __init__(self, stream):
        self.stream = stream

    def write(self, value):
        data = memoryview(value)
        assert self.stream.tell() + len(data) <= ARCHIVE_LIMIT, 'ARCHIVE_OVER_32MIB'
        for offset in range(0, len(data), CHUNK):
            check()
            part = data[offset:offset + CHUNK]
            assert self.stream.write(part) == len(part), 'ARCHIVE_SHORT_WRITE'
        return len(data)

    def seek(self, *args):
        return self.stream.seek(*args)

    def tell(self):
        return self.stream.tell()

    def flush(self):
        return self.stream.flush()

    def seekable(self):
        return True


def archive(spec):
    destination = Path(spec['destination']).resolve()
    allowed = ({CLOSE / 'SOURCE_PAYLOAD.zip', CLOSE / 'EXECUTION_ORIGINALS.zip'}
               if args.phase == 'S1' else {OUT / 'FINAL_HANDOFF_R13.zip'})
    assert destination in allowed, 'PREDECLARED_SEAL_DESTINATION_ONLY'
    assert not destination.exists(), 'NEVER_RETRY_OR_OVERWRITE_A_SEAL'
    temporary = work / (destination.name + '.part')
    members, seen = [], set()
    inputs = spec['members']
    assert len(inputs) <= 4096
    assert sum(item['file']['bytes'] for item in inputs) <= 256 * CHUNK
    with temporary.open('xb', buffering=0) as raw:
        target = ChunkedZipTarget(raw)
        with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED,
                             compresslevel=1, allowZip64=False) as bundle:
            for item in inputs:
                check()
                descriptor, name = item['file'], item['member']
                assert name and name not in seen and not name.startswith('/')
                assert '\\' not in name and '..' not in name.split('/')
                seen.add(name)
                path = Path(descriptor['path'])
                if not path.is_absolute():
                    path = ROOT / path
                assert path.resolve().is_relative_to(ROOT / 'code')
                count, digest = 0, hashlib.sha256()
                with path.open('rb', buffering=0) as source, bundle.open(name, 'w') as sink:
                    for block in iter(lambda: source.read(CHUNK), b''):
                        check()
                        count += len(block)
                        assert count <= descriptor['bytes'], 'INPUT_GREW_DURING_SEAL'
                        digest.update(block)
                        assert sink.write(block) == len(block), 'ZIP_MEMBER_SHORT_WRITE'
                assert count == descriptor['bytes'] and digest.hexdigest() == descriptor['sha256'], 'SEAL_INPUT_IDENTITY'
                members.append({'member': name, 'original': descriptor})
            manifest = (json.dumps({'schema': 'M3_R13_ARCHIVE_MANIFEST_V1',
                                    'phase': args.phase, 'members': members,
                                    'external_originals': spec.get('external_originals', [])},
                                   ensure_ascii=False, indent=2) + '\n').encode('utf-8')
            assert len(manifest) <= 8 * CHUNK
            with bundle.open('MANIFEST.json', 'w') as sink:
                for offset in range(0, len(manifest), CHUNK):
                    check()
                    block = manifest[offset:offset + CHUNK]
                    assert sink.write(block) == len(block)
        raw.flush()
        os.fsync(raw.fileno())
    check()
    actual = identity(temporary)
    assert actual['bytes'] <= ARCHIVE_LIMIT
    # Verify all archive bytes and CRC while still inside this same seal slot.
    with zipfile.ZipFile(temporary) as bundle:
        assert bundle.namelist() == [item['member'] for item in inputs] + ['MANIFEST.json']
        for item in inputs:
            count, digest = 0, hashlib.sha256()
            with bundle.open(item['member']) as source:
                for block in iter(lambda: source.read(CHUNK), b''):
                    check()
                    count += len(block)
                    digest.update(block)
            assert count == item['file']['bytes'] and digest.hexdigest() == item['file']['sha256']
    check()
    os.replace(temporary, destination)
    return {'file': identity(destination), 'payload_members': len(inputs),
            'payload_and_manifest_members': len(inputs) + 1,
            'all_payload_sizes_SHAs_and_ZIP_CRC_verified': True}


parser = argparse.ArgumentParser()
parser.add_argument('--phase', required=True, choices=('S1', 'S2'))
parser.add_argument('--contract', required=True, type=Path)
parser.add_argument('--sha256', required=True)
args = parser.parse_args()
started = time.monotonic()
deadline = started + 57
raw = args.contract.read_bytes()
assert len(raw) <= 8 * CHUNK and hashlib.sha256(raw).hexdigest() == args.sha256
contract = json.loads(raw)
assert contract['phase'] == args.phase and contract['root_frozen'] is True
assert len(contract['archives']) == (2 if args.phase == 'S1' else 1)
assert contract['plan_sha256'] == '729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3'
work = OUT / 'SEAL' / args.phase
work.mkdir(parents=True, exist_ok=False)
results = [archive(spec) for spec in contract['archives']]
snapshot = []
for descriptor in contract['exact_tracked_tree']:
    actual = identity(ROOT / descriptor['path'])
    assert actual['bytes'] == descriptor['bytes'] and actual['sha256'] == descriptor['sha256'], descriptor['path']
    snapshot.append(actual)
result = {'schema': 'M3_R13_SEAL_RESULT_V1', 'phase': args.phase, 'status': 'PASS',
          'archives': results, 'exact_tracked_tree': snapshot,
          'elapsed_seconds': time.monotonic() - started,
          'ended_utc': datetime.now(timezone.utc).isoformat(),
          'M2_RECEIVED': False, 'M2_ACCEPTED': False}
check()
(work / 'SEAL_RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n',
                                       encoding='utf-8', newline='\n')
print(json.dumps({'phase': args.phase, 'status': 'PASS', 'archives': len(results)}))
