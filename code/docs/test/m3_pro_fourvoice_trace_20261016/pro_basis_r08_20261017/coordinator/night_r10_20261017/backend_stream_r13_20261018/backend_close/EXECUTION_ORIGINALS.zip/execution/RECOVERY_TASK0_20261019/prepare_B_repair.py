"""Root P1/R exact located B software repair metadata, no candidate import."""
import argparse,hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';D=O/'RECOVERY_TASK0_20261019';S=R/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,x):
 assert not p.exists(),str(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 p=p.resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),'bytes':n,'sha256':h.hexdigest()}
p=argparse.ArgumentParser();p.add_argument('slot',choices=('P1','R'));a=p.parse_args();slot=a.slot;wire='P1' if slot=='P1' else 'B';l=read(O/'CONSUMPTION_LIVE.json');assert l['groups'][slot]['state']=='NOT_STARTED' and l['groups']['B']['state']=='FAILED_STOP';assert l['recovery_attempts']['P0_RECOVERY_03']['state']=='PASS'
if slot=='R':assert l['groups']['P1']['state']=='PASS'
fr=read(D/'REPAIR_FREEZE_B01.json')
for x in fr['frozen_files']:
 q=Path(x['path']);q=q if q.is_absolute() else R/q;y=ref(q);assert y['bytes']==x['bytes'] and y['sha256']==x['sha256'],x['path']
base=O/'ADMISSIONS'/slot;base.mkdir(parents=True,exist_ok=False);ap=base/'ADMISSION.json';owner=O/'RUNS'/slot/'inner';worker=owner/'B02/worker' if wire=='B' else owner/'worker';py=str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve());source=read(O/'ADMISSIONS/P0_RECOVERY_03/ADMISSION.json') if slot=='P1' else read(O/'ADMISSIONS/B/ADMISSION.json')
common={'plan_sha256':source['plan_sha256'],'group':wire,'state':'CONSUMED_RUNNING','absolute_cap_seconds':60 if slot=='P1' else 120,'root_deadline_monotonic':time.monotonic()+(60 if slot=='P1' else 120),'prepared_utc':datetime.now(timezone.utc).isoformat(),'source_freeze':ref(D/'REPAIR_FREEZE_B01.json'),'root_accounting_slot':slot,'located_repair':ref(O/'LOCATED_REPAIR.json'),'argv':[py,'-X','utf8','-B',str((S/'selftest.py').resolve()),'--worker','--group',wire,'--admission',str(ap.resolve()),'--admission-sha256','@ADMISSION_SHA256@','--output',str(worker.resolve())]}
for key in ('accounting_profile','external_log_escrows','fixture_templates','delivery_channel_confirmed','delivery'):
 if key in source:common[key]=source[key]
old_run='P0_RECOVERY_03' if slot=='P1' else 'B';common['external_log_escrows']={k.replace('RUNS/'+old_run+'/','RUNS/'+slot+'/'):v for k,v in common['external_log_escrows'].items()};common['accounting_profile']['allocation_unit_bytes']=4096;common['accounting_profile']['enforce_start_free']=False;save(ap,common);ar=ref(ap)
contract={'schema':'M3_R13_ROOT_RUN_CONTRACT_V1','root_approved':True,'slot':slot,'wire_group':wire,'repair_group':'B','plan_sha256':common['plan_sha256'],'cap_seconds':common['absolute_cap_seconds'],'all_target_writers_closed':True,'frozen_files':[*fr['frozen_files'],ref(D/'REPAIR_FREEZE_B01.json'),ar,ref(D/'root_run_after_Bfix.py')],'target_script':str((S/'job_bridge.py').resolve()),'argv':[py,'-X','utf8','-B',str((S/'job_bridge.py').resolve()),'--execute-one','--admission',str(ap.resolve()),'--admission-sha256',ar['sha256'],'--owner-output',str(owner.resolve())],'worker_result_relative_path':(worker/'WORKER_LOCAL_RESULT.json').relative_to(O/'RUNS'/slot).as_posix(),'bridge_result_relative_path':'inner/GROUP_COMPLETE.json','expected_case_ids':['P001'] if slot=='P1' else [f'B{i:02d}' for i in range(1,13)]};cp=base/'ROOT_CONTRACT.json';save(cp,contract);print(json.dumps(ref(cp)))
