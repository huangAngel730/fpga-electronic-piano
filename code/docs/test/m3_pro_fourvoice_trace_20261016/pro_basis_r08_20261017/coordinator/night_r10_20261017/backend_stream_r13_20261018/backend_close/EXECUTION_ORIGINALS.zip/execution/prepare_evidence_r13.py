"""Root metadata preparation only; does not import or execute candidates."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
STEM = 'm3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
CLOSE = ROOT / 'code/docs/test' / STEM / 'backend_stream_r13_20261018/backend_close'


def load(path):
    return json.loads(path.read_text('utf-8'))


def write(name, value):
    (CLOSE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n',
                             encoding='utf-8', newline='\n')


def ref(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


ledger = load(OUT / 'CONSUMPTION_LIVE.json')
now = datetime.now(timezone.utc).isoformat()
source_root = ROOT / 'code/software' / STEM / 'backend_stream_r13_20261018'
source_refs = [ref(path) for path in sorted(source_root.iterdir()) if path.is_file()]
write('SOURCE_MANIFEST.json', {
    'schema': 'M3_R13_SOURCE_MANIFEST_V1', 'state': 'PREPARATION_NOT_EXECUTION_FREEZE',
    'recorded_utc': now, 'functional_baseline': 'e39b36b9b7f956659f7fd5e3ca6dd57e5a34735b',
    'source_tree_checkpoint': '544f5af23fa427db0a931df719dc6135c75a180f',
    'files': source_refs, 'candidate_writer_may_still_be_active': True,
    'identity_verified_not_runtime_accepted': True,
    'freeze_required_before_P0': True,
})
groups = {'K': 8, 'V': 12, 'B': 12, 'W': 1}
write('CASE_RESULTS.json', {
    'schema': 'M3_R13_CASE_RESULTS_V1', 'initial_cases': 33,
    'state': 'NOT_RUN_NO_CANDIDATE_IMPORT_OR_COMPILE',
    'old_40_plus_2_reused_not_replayed': True,
    'cases': [{'id': f'{group}{i:02d}', 'status': 'NOT_RUN',
               'originals': None, 'exit_code': None}
              for group, count in groups.items() for i in range(1, count + 1)],
    'optional_P1_R': 'NOT_STARTED_NOT_ENTITLEMENT_TO_REPEAT',
})
write('RESOURCE_RECEIPT.json', {
    'schema': 'M3_R13_RESOURCE_RECEIPT_V1',
    'state': 'RESOURCE_PROFILE_PENDING_W_NO_GO',
    'limits': load(OUT / 'roles/night5/CAPACITY_AND_DELIVERY.json')['limits'],
    'initial_observation': load(CLOSE / 'BASELINE.json')['initial_disk_observation_not_P0_admission'],
    'candidate_geometry': ref(OUT / 'roles/night5/CAPACITY_AND_DELIVERY.json'),
    'A2_geometry': ref(CLOSE.parent / 'contract_bundle/PROFILE_AND_CAPACITY.json'),
    'full_window_actual_upper_bound': None,
    'worker_peak_bytes': None, 'simultaneous_tree_peak_bytes': None,
    'supervisor_peak_bytes': None, 'all_workspace_peak_bytes': None,
    'all_workspace_and_temporary_writers_covered': False,
    'native_Job_and_handle_evidence': 'PENDING_CURRENT_RUN',
    'old_R12_root_peak_not_reused_as_tree_proof': True,
    'delivery_channel': ref(OUT / 'DELIVERY_CHANNEL_CONFIRMED.json'),
    'delivery_channel_confirmed_not_M2_received': True,
})
write('RESULT_RECEIPT.json', {
    'schema': 'M3_R13_RESULT_RECEIPT_V1', 'state': 'IMPLEMENTATION_AND_STATIC_SELF_REVIEW_IN_PROGRESS',
    'recorded_utc': now, 'actual_START': ledger['actual_START'], 'deadline': ledger['deadline'],
    'source_state': 'NEW_CANDIDATES_NOT_YET_FROZEN_OR_EXECUTED',
    'A': 'CONTRACT9_RECEIVED_STATIC', 'B': 'ORIGINAL_INDEX7_RECEIVED_STATIC',
    'C': 'CANDIDATE13_UNDER_EXCLUSIVE_WRITER_REVISION',
    'source_manifest': 'SOURCE_MANIFEST.json', 'case_results': 'CASE_RESULTS.json',
    'resource_receipt': 'RESOURCE_RECEIPT.json', 'consumption': 'CONSUMPTION.json',
    'new_target_runs': 0, 'R13_SW_COMPLETE': False, 'result_commit': None,
    'real_verified': False, 'math_verified': False, 'C9_run': False,
    'board_release_allowed': False,
    'M2_review': 'PENDING_NOT_SENT',
})
write('FAILURE_HISTORY.json', {
    'schema': 'M3_R13_FAILURE_HISTORY_V1', 'old_failures_preserved': True,
    'old_charged_cap_seconds': 6540,
    'old_reference': load(CLOSE / 'BASELINE.json')['old_consumption_reference'],
    'new_target_failures': [],
    'metadata_failure': ref(OUT / 'INTAKE/M1_R13_NEW/READ_FAIL_01.json'),
    'metadata_failure_repair': 'Flat SHA-addressed aliases; logical paths and bytes unchanged; originals received',
    'pre_freeze_static_findings': [
        'Contract cases must reach actual production contract validator, not toy duplicated conditions',
        'Volume negative cases require observed refusal; V11 ABA and V12 local-only channel must exercise actual guards',
        'B02-B04 need actual owned lifecycle scenarios, double streams, Job0 and handle-close proof',
        'B08 requires actual nonzero advance then cancel, with unchanged retained history',
        'B11 needs all owned workspace and worker/no-descendant or simultaneous tree evidence',
        'B12 needs real terminal tamper and atomic completion barrier, preserving original exception',
        'W admission requires positive resource PASS; unknown/null states cannot consume W',
    ],
    'pre_freeze_findings_not_consumed_test_failures': True,
    'unchanged_retry_allowed': False,
})
for name, slot in [('GATE_01.json', 'GATE_01'), ('GATE_02.json', 'GATE_02')]:
    write(name, {'schema': 'M3_R13_GATE_REFERENCE_V1', 'slot': slot, 'state': 'NOT_RUN',
                 'actual_result': None, 'future_result_in_ignored_output':
                 f'code/output/m3_backend_stream_r13_20261018/RUNS/{slot}/RESULT.json',
                 'exact_tree_verified': False})
write('PUBLICATION_RECEIPT.json', {
    'schema': 'M3_R13_PUBLICATION_REFERENCE_V1', 'state': 'NOT_COMMITTED_NOT_PUSHED',
    'result_commit': None, 'remote_containment': False, 'Gate02_actual': 'PENDING',
    'final_actual_receipt_in_ignored_output':
    'code/output/m3_backend_stream_r13_20261018/PUBLICATION_ACTUAL.json',
    'tracked_bytes_immutable_after_Gate02': True,
})
write('INTEGRATION_HANDOFF.json', {
    'schema': 'M3_R13_INTEGRATION_HANDOFF_V1', 'handoff_id': 'M3-R13-SW-20261019',
    'producer': 'M3', 'consumer': 'M2', 'result_commit': None,
    'state': 'PREPARATION_NOT_DELIVERED',
    'source_files': 13, 'A_contract_objects': 9, 'B_index_objects': 7,
    'declared_unit': 'R13-SW_COMPLETE_ONLY_WHEN_ALL_REQUIRED_CONDITIONS_MET',
    'current_missing': ['C final frozen revision', 'P0/K/V/B/W actual evidence',
                        'W provable full-workspace physical bound and measured resource evidence',
                        'both exact gates, two defined seals, ordinary publication/containment'],
    'channel': 'User confirms forwarding every DELIVERY volume and manifest; actual volumes not produced',
    'LOCAL_COMMITTED': False, 'REMOTE_VERIFIED': False, 'RECEIVED': False,
    'ACCEPTED': False, 'INTEGRATED': False,
    'real_math_C9_physical_board': 'PENDING_SEPARATE_AUTHORITY',
    'board_release_allowed': False,
})
print(json.dumps({'metadata_prepared': True, 'candidate_files': len(source_refs),
                  'target_runs_started': 0}))
