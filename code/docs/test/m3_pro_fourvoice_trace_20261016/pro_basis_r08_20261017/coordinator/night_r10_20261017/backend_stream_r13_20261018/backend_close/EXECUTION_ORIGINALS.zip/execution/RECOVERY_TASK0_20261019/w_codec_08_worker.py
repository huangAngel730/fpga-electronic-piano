"""Located W successor; reuse the complete frozen input from failed W, never its partial outputs."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
p = argparse.ArgumentParser(); p.add_argument('--admission', type=Path, required=True); p.add_argument('--sha256', required=True); p.add_argument('--output', type=Path, required=True); a = p.parse_args()
raw = a.admission.read_bytes(); assert hashlib.sha256(raw).hexdigest() == a.sha256
admission = json.loads(raw)
assert admission['purpose'] == 'W_CODEC_PRIVATE_CSV_CACHE_SUCCESSOR'
sys.path.insert(0, str(SOURCE))
import resources, entry, selftest, binding
from stream_bridge import read_control, identity
from finalize import atomic_json
resources.configure_accounting(admission['accounting_profile'], admission['external_log_escrows'], admission['root_deadline_monotonic'])
output = a.output.resolve(); assert output == OUT / 'RUNS/W_CODEC_08/inner/worker' and not output.exists()
resources.accounting_mkdir(output, parents=True, exist_ok=False)
inputs = Path(admission['frozen_input_directory'])
for descriptor in admission['frozen_inputs']:
    assert identity(Path(descriptor['path'])) == {k:descriptor[k] for k in ('bytes','sha256')}
control = inputs / 'CONTROL.json'
request = read_control(inputs / 'CAPTURE_REQUEST.json')['value']
raw_ref = request['inputs']['raw']
assert raw_ref['bytes'] >= selftest.MIN_RAW_BYTES
actual_input = {}
import functools,time
phase_count=0
phase_dir=output/'PHASES'
resources.accounting_mkdir(phase_dir,parents=True,exist_ok=False)
def phase(label,state):
    global phase_count
    phase_count+=1
    assert phase_count<=128,'FINITE_PHASE_RECORD_BOUND'
    atomic_json(phase_dir/('P%03d_%s.json'%(phase_count,state)),{'label':label,'state':state,'monotonic':time.monotonic()})
original_module=binding._module
functions=('process','convert_files','encode_file','decode_file','project_intake_files','analyze_files','build_bundle','validate_capture')
def observed_module(name,*args,**kwargs):
    module=original_module(name,*args,**kwargs)
    if name=='capture_link_successor.py':
        original_adapt=module.DependencyContext.adapt
        def adapt(context,target):
            original_adapt(context,target)
            for function_name in functions:
                function=getattr(target,function_name,None)
                if not callable(function):continue
                label=str(target.__file__)+'::'+function_name
                def observed(*a,_function=function,_label=label,**kw):
                    phase(_label,'START')
                    try:result=_function(*a,**kw)
                    except BaseException as primary:
                        try:phase(_label,'FAIL')
                        except BaseException as secondary:resources.get_budget().secondary(secondary)
                        raise
                    phase(_label,'END')
                    return result
                setattr(target,function_name,functools.wraps(function)(observed))
        module.DependencyContext.adapt=adapt
    return module
binding._module=observed_module
def observe(event, payload):
    if event == 'after_backend_before_final_verify':
        actual_input.update(payload['result']['inputs']['raw'])
        assert actual_input == raw_ref
entry.install_test_hook(observe)
final_dir = output / 'cases/W01'
resources.accounting_mkdir(final_dir.parent, parents=True, exist_ok=False)
try:
    complete = entry.run(control, identity(control)['sha256'], final_dir)
finally:
    entry.install_test_hook(None)
phase('R13_FINAL_AUDIT_COMPLETE','END')
assert complete['audit']['terminal']['rows'] == selftest.MIN_ROWS and actual_input == raw_ref
phase('R13_EXPORT','START')
delivery = selftest._export_w_originals(admission, final_dir, inputs, actual_input)
phase('R13_EXPORT','END')
result = {'schema':'M3_R13_WORKER_COMPLETE_V1','status':'PASS','group':'W',
 'cases':[{'id':'W01','status':'PASS','observed':{'terminal':complete['audit']['terminal'],'raw_input':raw_ref,'delivery':delivery,
 'whole_output_resources':resources.disk_snapshot(OUT),'global_budget':resources.get_budget().receipt(),
 'input_generation_origin':'First failed W generated full1130662-row input within its charged900s; this successor rehashes/reuses exact immutable input, no partial old outputs reused',
 'source_freeze':admission['source_freeze']}}], 'real_verified':False,'math_verified':False,'board_release_allowed':False}
atomic_json(output / 'WORKER_COMPLETE.json', result)
print(json.dumps({'status':'PASS','case':'W01','input_reused_from_failed_W':True}))
