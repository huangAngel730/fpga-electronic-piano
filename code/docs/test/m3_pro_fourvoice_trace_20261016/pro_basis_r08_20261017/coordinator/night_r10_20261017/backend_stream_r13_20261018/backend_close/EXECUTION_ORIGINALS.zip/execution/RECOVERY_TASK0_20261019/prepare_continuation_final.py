"""Prospective root bookkeeping for the explicit two-hour continuation."""
import hashlib,json
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019'
P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
S=R/'code/software'/P/'backend_stream_r13_20261018'
C=R/'code/docs/test'/P/'backend_stream_r13_20261018/backend_close'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def stamp(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):n+=len(b);h.update(b)
 return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'bytes':n,'sha256':h.hexdigest()}
l=read(O/'CONSUMPTION_LIVE.json');assert l['recovery_attempts']['W_RECOVERY_07']['state']!='CONSUMED_BEFORE_LAUNCH'
auth=read(T/'CONTINUATION_AUTHORIZATION_R01.json')
raw=(O/'GATE_CHILD_R13.ps1').read_text('utf-8')
assert raw.count("2026-10-19T05:00:26+08:00")==1
raw=raw.replace('2026-10-19T05:00:26+08:00',auth['valid_until'])
raw=raw.replace('function Window {',"function Window {\n    Pin $gateContract.continuation (Relative-File $gateContract.continuation.path)\n    Need ($gateContract.continuation.sha256 -ceq '0e9a80b696db3841d94cd512f5d0cb7bf6483bfcd520570d49ee85ca2821b436') 'CONTINUATION_AUTHORITY_CHANGED'")
wrapper=T/'GATE_CHILD_CONTINUATION_R01.ps1';assert not wrapper.exists();wrapper.write_text(raw,encoding='utf-8',newline='\n')
controller=(T/'root_run_scalar_reconciled.py').read_text('utf-8')
old="    assert target == OUT / 'GATE_CHILD_R13.ps1'"
assert old in controller
controller=controller.replace(old,"    assert target == OUT / 'RECOVERY_TASK0_20261019/GATE_CHILD_CONTINUATION_R01.ps1'")
anchor="        if parent == 'P0':"
assert anchor in controller
controller=controller.replace(anchor,"        if parent == 'W' and ledger.get('recovery_attempts', {}).get('W_RECOVERY_07', {}).get('state') == 'PASS':\n            continue\n"+anchor)
dest=T/'root_run_continuation_final.py';assert not dest.exists();dest.write_text(controller,encoding='utf-8',newline='\n')
network=(T/'network_task0.py').read_text('utf-8')
network=network.replace("if args.action == 'query_direct':","if args.action in ('query_direct','fetch','push'):")
network=network.replace("'DIRECT_HTTPS_NEW_USER_TASK0' if args.action == 'query_direct' else 'ORIGINAL_PROXY'","'DIRECT_HTTPS_NEW_USER_TASK0' if args.action in ('query_direct','fetch','push') else 'ORIGINAL_PROXY'")
p=T/'network_continuation_direct.py';assert not p.exists();p.write_text(network,encoding='utf-8',newline='\n')
save(T/'CONTINUATION_IMPLEMENTATION_RECEIPT.json',{'authority':stamp(T/'CONTINUATION_AUTHORIZATION_R01.json'),'wrapper':stamp(wrapper),'root_controller':stamp(dest),'network_direct':stamp(p),'changes':'Deadline successor only plus accept actual W recovery receipt as prerequisite; old files/charges unchanged; no gate/tool/source body changed; direct HTTPS uses the already successful route.'})
print(json.dumps({'wrapper':stamp(wrapper),'controller':stamp(dest)}))

