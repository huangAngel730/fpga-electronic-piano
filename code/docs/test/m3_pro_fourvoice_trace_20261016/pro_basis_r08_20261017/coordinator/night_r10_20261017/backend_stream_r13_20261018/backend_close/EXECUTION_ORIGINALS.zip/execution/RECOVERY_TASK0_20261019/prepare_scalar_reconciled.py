"""Prospective source/inputs freeze and exact user-authorized recovery contracts."""
import argparse,difflib,hashlib,json,time
from datetime import datetime,timedelta,timezone
from pathlib import Path
ROOT=Path.cwd().resolve();OUT=ROOT/'code/output/m3_backend_stream_r13_20261018';HERE=OUT/'RECOVERY_TASK0_20261019';WORK=HERE/'W_SCALAR_RECOVERY'
SOURCE=ROOT/'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,x,new=True):
 assert not new or not p.exists(),str(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 p=p.resolve();h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
p=argparse.ArgumentParser();p.add_argument('mode',choices=('freeze','P1_SCALAR_01','B_SCALAR_06','W_RECOVERY_07'));a=p.parse_args();lp=OUT/'CONSUMPTION_LIVE.json';l=read(lp);auth=WORK/'AUTHORITY_AND_LOCATOR.json';fp=WORK/'FREEZE.json';controller=HERE/'root_run_scalar_reconciled.py'
if a.mode=='freeze':
 assert l['groups']['W']['state']=='FAILED_STOP'
 before=WORK/'BEFORE_binding.py';after=SOURCE/'binding.py';diff=''.join(difflib.unified_diff(before.read_text('utf-8').splitlines(True),after.read_text('utf-8').splitlines(True),fromfile='before_binding.py',tofile='after_binding.py'));assert diff
 (WORK/'REPAIR.diff').write_text(diff,encoding='utf-8',newline='\n')
 old_inputs=OUT/'RUNS/W/inner/worker/inputs/W01';input_refs=[ref(x) for x in sorted(old_inputs.rglob('*')) if x.is_file()]
 save(WORK/'FROZEN_INPUTS.json',{'input_generation_original':'RUNS/W failed on actual backend timeout; full input generation retained','directory':str(old_inputs),'files':input_refs})
 save(auth,{'schema':'M3_USER_TASK0_W_PERFORMANCE_RECOVERY_V1','problem_attempt_ordinal':7,'attempts_limit':8,'authority':'User explicitly authorized up to8 evidence-based repair attempts; latest2h extension retains old consumption, no slot restored','old_W_failed900_charge_retained':True,'new_charge_bucket':'USER_TASK0_RECOVERY_INCREMENT','located_issue':'Original W raw generation completed3062558030B; real D4 still in derived43 projection at timeout. It invokes unchanged pure scalar for72ports repeatedly. Cache only successfully validated immutable bits/width/signed result per private derived module, max4096entries; original decoder handles every new/invalid argument and no exception cached. Input is exact already-generated frozen original, no partial output reused.','source_before':ref(before),'source_after':ref(after),'diff':ref(WORK/'REPAIR.diff'),'input_refs':ref(WORK/'FROZEN_INPUTS.json'),'deadline':l['deadline'],'new_attempts':{'P1_SCALAR_01':60,'B_SCALAR_06':120,'W_RECOVERY_07':900},'old_groups_unchanged':True})
 old=read(HERE/'B04_SEAL_REPAIR/FREEZE.json');items=[]
 for x in old['frozen_files']:
  actual=ref(Path(x['path']));assert Path(x['path']).resolve()==after.resolve() or actual==x,x['path'];items.append(actual)
 items += [ref(auth),ref(WORK/'REPAIR.diff'),ref(WORK/'FROZEN_INPUTS.json'),ref(HERE/'CONTINUATION_AUTHORIZATION_R01.json'),ref(HERE/'w_recovery_worker.py'),ref(HERE/'w_recovery_bridge.py'),*input_refs]
 save(fp,{'state':'REPAIR_FROZEN_BY_ROOT','all_target_writers_closed':True,'frozen_files':items})
 raw=(HERE/'root_run_b04_repair.py').read_text('utf-8');start=raw.index('if attempt_id:\n    assert args.slot') if 'if attempt_id:\n    assert args.slot' in raw else raw.index('if attempt_id:\n    assert attempt_id');end=raw.index("assert slot['state'] ==",start)
 raw=raw[:start]+'''if attempt_id:
    assert attempt_id in ('P1_SCALAR_01','B_SCALAR_06','W_RECOVERY_07')
    assert args.slot == {'P1_SCALAR_01':'P1','B_SCALAR_06':'B','W_RECOVERY_07':'W'}[attempt_id]
    verify(contract['new_user_authority'])
    if args.slot in ('B','W'): assert ledger['recovery_attempts']['P1_SCALAR_01']['state']=='PASS'
    if args.slot == 'W': assert ledger['recovery_attempts']['B_SCALAR_06']['state']=='PASS'
'''+raw[end:]
 raw=raw.replace("get('B04_RECOVERY_05', {}).get('state') == 'PASS'","get('B_SCALAR_06', {}).get('state') == 'PASS'")
 raw=raw.replace("read(OUT / 'W_ADMISSION.json')","read(OUT / 'W_RECOVERY_ADMISSION.json')")
 raw=raw.replace("if attempt_id:\n    remaining += slot['cap_seconds']","remaining += sum(v['cap_seconds'] for k,v in ledger['recovery_attempts'].items() if k in ('P1_SCALAR_01','B_SCALAR_06','W_RECOVERY_07') and v['state']=='NOT_STARTED')")
 raw=raw.replace("OUT / 'RECOVERY_TASK0_20261019/b04_recovery_worker.py')","OUT / 'RECOVERY_TASK0_20261019/b04_recovery_worker.py', OUT / 'RECOVERY_TASK0_20261019/w_recovery_bridge.py')")
 controller.write_text(raw,encoding='utf-8',newline='\n')
 for key,cap,count in [('P1_SCALAR_01',60,1),('B_SCALAR_06',120,12),('W_RECOVERY_07',900,1)]:
  assert key not in l['recovery_attempts'];l['recovery_attempts'][key]={'state':'NOT_STARTED','attempts':0,'charged_seconds':0,'cap_seconds':cap,'cases_max':count,'authority':ref(auth)}
 save(lp,l,False);print(json.dumps({'freeze':ref(fp)}))
else:
 key=a.mode;wire={'P1_SCALAR_01':'P1','B_SCALAR_06':'B','W_RECOVERY_07':'W'}[key];cap=l['recovery_attempts'][key]['cap_seconds'];assert l['recovery_attempts'][key]['state']=='NOT_STARTED'
 remaining=sum(v['cap_seconds'] for v in l['groups'].values() if v['state']=='NOT_STARTED')+sum(v['cap_seconds'] for k,v in l['recovery_attempts'].items() if k in ('P1_SCALAR_01','B_SCALAR_06','W_RECOVERY_07') and v['state']=='NOT_STARTED')+1260-sum(v['charged_seconds'] for v in l['network']['operations'])+360-sum(v.get('charged_seconds',0) for v in l['local_git']['operations'])+60
 assert datetime.now(timezone.utc)+timedelta(seconds=remaining)<=datetime.fromisoformat(l['deadline'])
 freeze=read(fp)
 for x in freeze['frozen_files']:assert ref(Path(x['path']))==x
 base=OUT/'ADMISSIONS'/key;ap=base/'ADMISSION.json';owner=OUT/'RUNS'/key/'inner';worker=owner/('B02/worker' if wire=='B' else 'worker');py=str(Path('C:/Users/songdongkuan/miniconda3/python.exe').resolve())
 adm=read(OUT/('ADMISSIONS/B_RECOVERY_04/ADMISSION.json' if wire=='B' else 'ADMISSIONS/P1_B04_01/ADMISSION.json'));old='B_RECOVERY_04' if wire=='B' else 'P1_B04_01'
 adm.update(group=wire,absolute_cap_seconds=cap,root_deadline_monotonic=time.monotonic()+cap,source_freeze=ref(fp),root_accounting_slot=key)
 adm['external_log_escrows']={k.replace('RUNS/'+old+'/','RUNS/'+key+'/'):v for k,v in adm['external_log_escrows'].items()};adm['external_log_escrows']['CONSUMPTION_LIVE.json']['evidence']['controller']=ref(controller)
 adm['accounting_profile']['initial_roles']={'RUNS/W/inner/worker/inputs/W01/RAW.jsonl':'raw_plain'}
 adm['argv']=[py,'-X','utf8','-B',str(SOURCE/'selftest.py'),'--worker','--group',wire,'--admission',str(ap),'--admission-sha256','@ADMISSION_SHA256@','--output',str(worker)]
 if wire=='W':
  adm.update(purpose='W_SCALAR_CACHE_FROZEN_INPUT_SUCCESSOR',frozen_input_directory=read(WORK/'FROZEN_INPUTS.json')['directory'],frozen_inputs=read(WORK/'FROZEN_INPUTS.json')['files']);adm['accounting_profile']['enforce_start_free']=True
  save(OUT/'W_RECOVERY_ADMISSION.json',{'GO':True,'all_resource_and_source_requirements_met':True,'frozen_inputs':ref(WORK/'FROZEN_INPUTS.json'),'source_freeze':ref(fp),'authority':ref(auth),'whole_output_old_raw_funded_same_raw_plain_no_regeneration_or_deletion':True})
 save(ap,adm);ar=ref(ap);target=HERE/'w_recovery_bridge.py' if wire=='W' else SOURCE/'job_bridge.py'
 argv=[py,'-X','utf8','-B',str(target),'--admission',str(ap),'--sha256',ar['sha256'],'--output',str(owner)] if wire=='W' else [py,'-X','utf8','-B',str(target),'--execute-one','--admission',str(ap),'--admission-sha256',ar['sha256'],'--owner-output',str(owner)]
 cp=base/'ROOT_CONTRACT.json';save(cp,{'root_approved':True,'slot':wire,'attempt_id':key,'wire_group':wire,'repair_group':'B','plan_sha256':adm['plan_sha256'],'cap_seconds':cap,'all_target_writers_closed':True,'new_user_authority':ref(auth),'frozen_files':[*freeze['frozen_files'],ref(fp),ref(ap),ref(controller)],'target_script':str(target),'argv':argv,'worker_result_relative_path':('inner/B02/worker/WORKER_LOCAL_RESULT.json' if wire=='B' else 'inner/worker/WORKER_COMPLETE.json' if wire=='W' else 'inner/worker/WORKER_LOCAL_RESULT.json'),'bridge_result_relative_path':'inner/GROUP_COMPLETE.json','expected_case_ids':[f'B{i:02d}' for i in range(1,13)] if wire=='B' else ['W01'] if wire=='W' else ['P001']});print(json.dumps(ref(cp)))
