"""Prepare one predeclared gate/seal contract without launching any target."""
import argparse,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019'
P='m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017'
C=R/'code/docs/test'/P/'backend_stream_r13_20261018/backend_close';S=R/'code/software'/P/'backend_stream_r13_20261018'
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):
 assert not p.exists();p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def stamp(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):n+=len(b);h.update(b)
 return {'path':p.relative_to(R).as_posix() if p.is_relative_to(R) else p.as_posix(),'bytes':n,'sha256':h.hexdigest()}
def stamp_abs(p):
 result=stamp(p);result['path']=p.resolve().as_posix();return result
p=argparse.ArgumentParser();p.add_argument('phase',choices=['GATE_01','GATE_01_PATH_01','S1','S1_LIVE_01','GATE_02','S2']);a=p.parse_args();phase=a.phase
wire_phase={'GATE_01_PATH_01':'GATE_01','S1_LIVE_01':'S1'}.get(phase,phase)
ledger=read(O/'CONSUMPTION_LIVE.json')
allow=read(C/'PUBLISH_ALLOWLIST.json');paths=allow['source_files']+allow['evidence_files'];assert len(paths)==49 and len(set(paths))==49
tree=[stamp(R/x) for x in paths if not (wire_phase in ('GATE_01','S1') and x.endswith('.zip'))]
base=O/'ADMISSIONS'/phase;base.mkdir(parents=True,exist_ok=False)
python=Path('C:/Users/songdongkuan/miniconda3/python.exe')
if phase=='S1_LIVE_01':
 target=T/'seal_r13_s1_recovery.py';cap=60
 original_members=[];external=[];total=0
 for f in sorted(O.rglob('*')):
  if not f.is_file() or '/DELIVERY/' in f.as_posix() or '/.r13_volumes/' in f.as_posix() or '/SEAL/' in f.as_posix():continue
  rel=f.relative_to(O).as_posix()
  if rel=='CONSUMPTION_LIVE.json' or rel.startswith(('DELIVERY/','SEAL/','RUNS/S1_LIVE_01/')):continue
  if f.suffix not in ('.json','.bin','.md','.diff','.py','.ps1','.txt','.zip') or f.stat().st_size>8*1048576:continue
  if rel.startswith('RECOVERY_TASK0_20261019/') and any(k in f.name for k in ('RESPONSE.bin','_RESULT.json')) and f.stat().st_size>2*1048576:continue
  desc=stamp(f);total+=desc['bytes'];assert total<=200*1048576
  original_members.append({'file':desc,'member':'execution/'+rel})
 for f in C.iterdir():
  if f.is_file() and f.suffix!='.zip':original_members.append({'file':stamp(f),'member':'formal_snapshot/'+f.name})
 external=[stamp(T/'DELIVERY_CHANNEL_R02_GITHUB.json'),stamp(T/'W_TRANSFER_RECEIPT.json')]
 old_contract=O/'ADMISSIONS/S1/SEAL_CONTRACT.json'
 child={'phase':phase,'plan_sha256':'729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3','old_S1_contract':stamp(old_contract),'old_failed_S1':stamp(O/'RUNS/S1/RESULT.json'),'execution_archive':{'destination':str(C/'EXECUTION_ORIGINALS.zip'),'members':original_members,'external_originals':external},'exact_tracked_tree':tree}
 childpath=base/'SEAL_CONTRACT.json';save(childpath,child)
 argv=[str(python),'-X','utf8','-B',str(target),'--contract',str(childpath),'--sha256',stamp(childpath)['sha256']]
elif wire_phase.startswith('GATE_'):
 out=base/'ENV';out.mkdir()
 target=T/'GATE_CHILD_HOUR_09.ps1'
 child={'schema':'M3_R13_GATE_CONTRACT_V1','approved':True,'root':str(R),'slot':wire_phase,'cap_seconds':900,'not_before':'2026-10-19T00:00:26+08:00','deadline':ledger['deadline'],'files':tree,'output':str(out),'python':stamp_abs(python),'gate_script':stamp_abs(R/'code/scripts/check_repo.ps1'),'enter_environment':stamp_abs(R/'code/scripts/enter_fpga_env.ps1'),'shell':stamp_abs(Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')),'authority':stamp(C/'PLAN.json'),'authorization':stamp(C/'AUTHORIZATION.json'),'continuation':stamp(T/'W_HOUR_REPLAY_09/AUTHORIZATION_CLOSING.json')}
 childpath=base/'GATE_CONTRACT.json';save(childpath,child)
 argv=[child['shell']['path'],'-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',str(target),'-ContractPath',str(childpath),'-ContractSha256',stamp(childpath)['sha256']]
 cap=900
else:
 target=O/'seal_r13.py';cap=60
 if phase=='S1':
  source_members=[{'file':stamp(R/x),'member':Path(x).name} for x in allow['source_files']]
  original_members=[];external=[];total=0
  for f in sorted(O.rglob('*')):
   if not f.is_file() or '/DELIVERY/' in f.as_posix() or '/.r13_volumes/' in f.as_posix() or '/SEAL/' in f.as_posix():continue
   # Finite execution evidence; full raw/volume payloads have an independent accessible asset channel.
   rel=f.relative_to(O).as_posix()
   if f.suffix not in ('.json','.bin','.md','.diff','.py','.ps1','.txt','.zip') or f.stat().st_size>8*1048576:continue
   if rel.startswith(('DELIVERY/','SEAL/')):continue
   if rel.startswith('RECOVERY_TASK0_20261019/') and any(k in f.name for k in ('RESPONSE.bin','_RESULT.json')) and f.stat().st_size>2*1048576:continue
   desc=stamp(f);total+=desc['bytes'];assert total<=200*1048576
   original_members.append({'file':desc,'member':'execution/'+rel})
  for f in C.iterdir():
   if f.is_file() and f.suffix!='.zip':original_members.append({'file':stamp(f),'member':'formal_snapshot/'+f.name})
  external=[stamp(T/'DELIVERY_CHANNEL_R02_GITHUB.json')]
  if (T/'W_TRANSFER_RECEIPT.json').exists():external.append(stamp(T/'W_TRANSFER_RECEIPT.json'))
  archives=[{'destination':str(C/'SOURCE_PAYLOAD.zip'),'members':source_members},{'destination':str(C/'EXECUTION_ORIGINALS.zip'),'members':original_members,'external_originals':external}]
 else:
  members=[]
  for f in [O/'PUBLICATION_ACTUAL.json',O/'CONSUMPTION_LIVE.json',O/'SEAL/S1/SEAL_RESULT.json',O/'RUNS/GATE_01/RESULT.json',O/'RUNS/GATE_02/RESULT.json']:
   members.append({'file':stamp(f),'member':f.relative_to(O).as_posix()})
  archives=[{'destination':str(O/'FINAL_HANDOFF_R13.zip'),'members':members}]
 child={'phase':phase,'root_frozen':True,'plan_sha256':'729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3','archives':archives,'exact_tracked_tree':tree}
 childpath=base/'SEAL_CONTRACT.json';save(childpath,child)
 argv=[str(python),'-X','utf8','-B',str(target),'--phase',phase,'--contract',str(childpath),'--sha256',stamp(childpath)['sha256']]
root={'root_approved':True,'slot':wire_phase,'plan_sha256':'729cb21bd4b759f7d5738bdc14964bee1eaf5da053eee20b4a278acf651357d3','cap_seconds':cap,'all_target_writers_closed':True,'target_script':str(target),'argv':argv,'frozen_files':tree+[stamp(target),stamp(childpath)]}
if phase=='GATE_01_PATH_01':
 root['attempt_id']=phase
 root['new_user_authority']=stamp(T/'GATE_PATH_RECOVERY_11/AUTHORIZATION.json')
if phase=='S1_LIVE_01':
 root['attempt_id']=phase
 root['new_user_authority']=stamp(T/'S1_LIVE_RECOVERY_12/AUTHORIZATION.json')
 root['frozen_files'] += [stamp(C/'SOURCE_PAYLOAD.zip'),stamp(O/'ADMISSIONS/S1/SEAL_CONTRACT.json')]
dest=base/'ROOT_CONTRACT.json';save(dest,root)
print(json.dumps(stamp(dest)))
