"""Unexecuted R13 storage candidate: bounded, byte-exact logical streams.

This does not replace D4, run a target, own a Job, or grant W admission.
C must explicitly bind real D4 IO to this format and preserve every comparison.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import time
import zlib

CHUNK = 1 << 20
CONTROL_LIMIT = 8 << 20
WORKSPACE_CAP = 24 << 30
MAX_VOLUMES = 16384


class VolumeReject(ValueError):
    pass


def need(condition, reason):
    if not condition:
        raise VolumeReject(reason)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def no_alias(path):
    path = Path(os.path.abspath(path))
    for item in (path, *path.parents):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        need(not stat.S_ISLNK(info.st_mode), "PATH_SYMLINK")
        need(not (getattr(info, "st_file_attributes", 0)
                  & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 1024)),
             "PATH_REPARSE_POINT")
    return path


def scoped(root, relative):
    root = no_alias(root)
    need(not Path(relative).is_absolute(), "RELATIVE_PATH_REQUIRED")
    path = no_alias(root / relative)
    need(path != root and path.is_relative_to(root), "PATH_ESCAPE")
    return path


def strict_pairs(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


class Budget:
    """Root supplies the original W monotonic start, never a fresh sub-timer."""

    def __init__(self, started_monotonic, *, cap_seconds=900, check_hook=None):
        need(type(started_monotonic) in (int, float), "ROOT_START_REQUIRED")
        need(cap_seconds == 900, "W_CAP_MUST_BE_900")
        now = time.monotonic()
        need(0 <= started_monotonic <= now, "ROOT_START_NOT_IN_THIS_CLOCK")
        self.start = started_monotonic
        self.deadline = started_monotonic + cap_seconds
        self.check_hook = check_hook

    def check(self):
        need(time.monotonic() < self.deadline, "W_WHOLE_SLOT_DEADLINE")
        if self.check_hook is not None:
            self.check_hook()
        need(time.monotonic() < self.deadline, "W_WHOLE_SLOT_DEADLINE")


class PhysicalLedger:
    """Accounts this store; root must also measure ALL other workspace bytes.

    Reservations never refund automatically. Root's disk/process-tree observer
    remains authoritative. This local ledger alone is not a resource PASS.
    """

    def __init__(self, budget, *, already_live_bytes, cap=WORKSPACE_CAP):
        need(type(already_live_bytes) is int and already_live_bytes >= 0,
             "ALL_EXISTING_WORKSPACE_BYTES_REQUIRED")
        need(cap == WORKSPACE_CAP and already_live_bytes <= cap, "DISK_PROFILE")
        self.budget = budget
        self.used = already_live_bytes
        self.peak_reserved = already_live_bytes
        self.cap = cap

    def reserve(self, count):
        self.budget.check()
        need(type(count) is int and count >= 0, "PHYSICAL_SIZE")
        need(self.used + count <= self.cap, "WORKSPACE_24_GIB_WOULD_BE_EXCEEDED")
        self.used += count
        self.peak_reserved = max(self.used, self.peak_reserved)


class LogicalWriter:
    """At most 1 MiB decoded per volume; gzip is used only if smaller than raw.

    finish() is explicit. close()/abort() never drains or marks completion.
    Original failed volumes are retained. No automatic deletions.
    """

    def __init__(self, root, role, ledger, *, block_size=CHUNK):
        need(re.fullmatch(r"[A-Za-z0-9_]{1,64}", role) is not None, "ROLE_NAME")
        need(type(block_size) is int and 1 <= block_size <= CHUNK, "BLOCK_BOUND")
        self.root, self.role, self.ledger = no_alias(root), role, ledger
        need(self.root.is_dir(), "ROOT_MUST_ALREADY_EXIST")
        self.block_size = block_size
        self.buffer = bytearray()
        self.digest = hashlib.sha256()
        self.logical_bytes = self.lines = 0
        self.entries = []
        self.closed = self.finished = False

    def write(self, data):
        need(not self.closed, "WRITER_CLOSED")
        need(isinstance(data, (bytes, bytearray, memoryview)), "BINARY_WRITE_ONLY")
        view = memoryview(data)
        total = len(view)
        while view:
            self.ledger.budget.check()
            count = min(len(view), self.block_size - len(self.buffer))
            self.buffer.extend(view[:count])
            view = view[count:]
            if len(self.buffer) == self.block_size:
                self._flush()
        return total

    def _flush(self):
        if not self.buffer:
            return
        self.ledger.budget.check()
        decoded = bytes(self.buffer)
        compressor = zlib.compressobj(1, zlib.DEFLATED, 31)
        compressed = compressor.compress(decoded) + compressor.flush()
        codec, payload = (("gzip", compressed) if len(compressed) < len(decoded)
                          else ("raw", decoded))
        number = len(self.entries)
        need(number < MAX_VOLUMES, "VOLUME_METADATA_BOUND")
        name = f"{self.role}.{number:08d}.block"
        path = scoped(self.root, name)
        self.ledger.reserve(len(payload))
        with path.open("xb") as stream:
            written = stream.write(payload)
            need(written == len(payload), "SHORT_PHYSICAL_WRITE")
        entry = {"number": number, "path": name, "offset": self.logical_bytes,
                 "decoded_bytes": len(decoded),
                 "decoded_sha256": hashlib.sha256(decoded).hexdigest(),
                 "encoded_bytes": len(payload),
                 "encoded_sha256": hashlib.sha256(payload).hexdigest(),
                 "codec": codec, "lf_before": self.lines,
                 "lf_in_volume": decoded.count(b"\n")}
        self.entries.append(entry)
        self.digest.update(decoded)
        self.logical_bytes += len(decoded)
        self.lines += entry["lf_in_volume"]
        self.buffer.clear()
        self.ledger.budget.check()

    def finish(self):
        need(not self.closed, "WRITER_CLOSED")
        self._flush()
        manifest = {"schema": "M3_R13_LOSSLESS_LOGICAL_STREAM_V1",
                    "role": self.role, "block_limit": self.block_size,
                    "logical_bytes": self.logical_bytes,
                    "logical_sha256": self.digest.hexdigest(),
                    "lf_count": self.lines, "volumes": self.entries,
                    "byte_concatenation_before_utf8_decode": True,
                    "stored_bytes_bound": "sum(encoded)<=logical; metadata separate",
                    "origin": "SOFTWARE_STORAGE_NOT_REAL_AUTHORITY"}
        raw = canonical(manifest)
        need(len(raw) <= CONTROL_LIMIT, "MANIFEST_CONTROL_LIMIT")
        self.ledger.reserve(len(raw))
        path = scoped(self.root, self.role + ".manifest.json")
        with path.open("xb") as stream:
            for offset in range(0, len(raw), CHUNK):
                self.ledger.budget.check()
                piece = raw[offset:offset + CHUNK]
                need(stream.write(piece) == len(piece), "SHORT_MANIFEST_WRITE")
        self.ledger.budget.check()
        self.closed = self.finished = True
        return {"path": str(path), "bytes": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "logical_bytes": self.logical_bytes,
                "logical_sha256": self.digest.hexdigest()}

    def abort(self):
        self.buffer.clear()
        self.closed = True

    close = abort


def load_manifest(reference, budget):
    path = no_alias(reference["path"])
    need(type(reference["bytes"]) is int
         and 0 <= reference["bytes"] <= CONTROL_LIMIT, "MANIFEST_SIZE")
    raw = bytearray()
    with path.open("rb") as stream:
        while True:
            budget.check()
            block = stream.read(CHUNK)
            if not block:
                break
            raw.extend(block)
            need(len(raw) <= min(CONTROL_LIMIT, reference["bytes"]),
                 "MANIFEST_TOO_LONG")
    need(len(raw) == reference["bytes"]
         and hashlib.sha256(raw).hexdigest() == reference["sha256"],
         "MANIFEST_IDENTITY")
    value = json.loads(bytes(raw).decode("utf-8"),
                       object_pairs_hook=strict_pairs)
    need(value.get("schema") == "M3_R13_LOSSLESS_LOGICAL_STREAM_V1",
         "MANIFEST_SCHEMA")
    need(type(value["block_limit"]) is int
         and 1 <= value["block_limit"] <= CHUNK, "MANIFEST_BLOCK_LIMIT")
    offset = lf = 0
    seen = set()
    need(type(value["volumes"]) is list
         and len(value["volumes"]) <= MAX_VOLUMES, "VOLUME_METADATA_BOUND")
    for number, entry in enumerate(value["volumes"]):
        need(type(entry["number"]) is int and entry["number"] == number,
             "VOLUME_ORDER")
        need(entry["path"] not in seen, "VOLUME_DUPLICATE")
        seen.add(entry["path"])
        need(type(entry["offset"]) is int and entry["offset"] == offset,
             "LOGICAL_GAP_OR_OVERLAP")
        need(type(entry["decoded_bytes"]) is int
             and 1 <= entry["decoded_bytes"] <= value["block_limit"],
             "DECODED_SIZE_BOUND")
        need(type(entry["encoded_bytes"]) is int
             and 1 <= entry["encoded_bytes"] <= entry["decoded_bytes"],
             "ENCODED_SIZE_BOUND")
        need(entry["codec"] in ("raw", "gzip"), "VOLUME_CODEC")
        need(entry["lf_before"] == lf
             and type(entry["lf_in_volume"]) is int
             and 0 <= entry["lf_in_volume"] <= entry["decoded_bytes"],
             "LINE_OFFSET")
        for key in ("decoded_sha256", "encoded_sha256"):
            need(re.fullmatch("[0-9a-f]{64}", entry[key]) is not None,
                 "FULL_VOLUME_SHA")
        offset += entry["decoded_bytes"]
        lf += entry["lf_in_volume"]
    need(type(value["logical_bytes"]) is int
         and value["logical_bytes"] == offset, "LOGICAL_TOTAL_LENGTH")
    need(value["lf_count"] == lf, "LOGICAL_LINE_COUNT")
    need(re.fullmatch("[0-9a-f]{64}", value["logical_sha256"]) is not None,
         "FULL_STREAM_SHA")
    return path.parent, value


class LogicalReader(io.RawIOBase):
    """The entire logical SHA is certified only after caller consumes EOF."""

    def __init__(self, reference, budget):
        super().__init__()
        self.root, self.manifest = load_manifest(reference, budget)
        self.budget = budget
        self.number = self.count = self.lf = 0
        self.block = b""
        self.position = 0
        self.digest = hashlib.sha256()
        self.eof_verified = False

    def readable(self):
        return True

    def seekable(self):
        return False

    def _next(self):
        self.budget.check()
        if self.number == len(self.manifest["volumes"]):
            need(self.count == self.manifest["logical_bytes"]
                 and self.digest.hexdigest() == self.manifest["logical_sha256"]
                 and self.lf == self.manifest["lf_count"], "LOGICAL_EOF_IDENTITY")
            self.eof_verified = True
            self.block, self.position = b"", 0
            return False
        entry = self.manifest["volumes"][self.number]
        path = scoped(self.root, entry["path"])
        with path.open("rb") as stream:
            encoded = stream.read(entry["encoded_bytes"])
            extra = stream.read(1)
        need(len(encoded) == entry["encoded_bytes"]
             and not extra
             and hashlib.sha256(encoded).hexdigest() == entry["encoded_sha256"],
             "ENCODED_VOLUME_IDENTITY")
        if entry["codec"] == "raw":
            decoded = encoded
        else:
            decoder = zlib.decompressobj(31)
            decoded = decoder.decompress(encoded, entry["decoded_bytes"])
            if not decoder.eof and decoder.unconsumed_tail:
                trailer_output = decoder.decompress(decoder.unconsumed_tail, 1)
                need(not trailer_output, "DECODED_SIZE_OVERFLOW")
            need(decoder.eof and not decoder.unused_data
                 and not decoder.unconsumed_tail, "GZIP_TRUNCATED_OR_EXTRA")
        need(len(decoded) == entry["decoded_bytes"]
             and hashlib.sha256(decoded).hexdigest() == entry["decoded_sha256"],
             "DECODED_VOLUME_IDENTITY")
        need(decoded.count(b"\n") == entry["lf_in_volume"], "VOLUME_LINE_COUNT")
        self.block, self.position = decoded, 0
        self.number += 1
        return True

    def readinto(self, target):
        need(not self.closed, "READER_CLOSED")
        self.budget.check()
        requested = min(len(target), CHUNK)
        if requested == 0:
            return 0
        if self.position == len(self.block) and not self._next():
            return 0
        count = min(requested, len(self.block) - self.position)
        piece = self.block[self.position:self.position + count]
        target[:count] = piece
        self.position += count
        self.count += count
        self.lf += piece.count(b"\n")
        self.digest.update(piece)
        return count

    def read(self, size=-1):
        need(type(size) is int and 0 <= size <= CHUNK, "BOUNDED_READ_REQUIRED")
        result = bytearray(size)
        count = self.readinto(result)
        return bytes(result[:count])

    def close(self):
        # No close-drain and no success if a consumer stopped early.
        self.block = b""
        super().close()


if __name__ == "__main__":
    raise SystemExit("ROOT_OWNED_GROUP_ONLY_NOT_A_STANDALONE_TEST_RUNNER")
