"""Root static final binding after recorded writer self-review; no candidate execution."""
import json,hashlib,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd().resolve();O=R/'code/output/m3_backend_stream_r13_20261018';T=O/'RECOVERY_TASK0_20261019';D=R/'code/output/m3_business_precheck_r14_20261019';B=T/'R14_ROOT_RECONCILIATION_R02';B.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_text('utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
roots=['PLAN.json','SOURCE_BINDINGS.json','DEPENDENCIES.json','SELF_REVIEW.md','HANDOFF.json','MANIFEST.json']
for n in roots:shutil.copyfile(D/n,B/n)
old=read(B/'MANIFEST.json');deltas=[]
for x in old['payloads']:
 p=R/x['path'];a=ref(p)
 if any(a[k]!=x[k] for k in ('bytes','sha256')):deltas.append({'old':x,'current':a})
assert len(deltas)==13
packs=[];count=0
for p in sorted(x for x in D.iterdir() if x.is_dir()):
 sources=sorted(p.glob('*.py.txt'));assert len(sources)==2
 case=read(p/'CASE_SPEC.json');cases=case['cases'];ids=[c['id'] for c in cases];assert len(set(ids))==len(ids)
 assert all(c.get('runtime_result','NOT_RUN')=='NOT_RUN' for c in cases)
 receipt=read(p/'STATIC_RECEIPT.json')
 packs.append({'id':p.name,'sources':[ref(s) for s in sources],'case_spec':ref(p/'CASE_SPEC.json'),'static_receipt':ref(p/'STATIC_RECEIPT.json'),'case_specifications':len(cases),'actual_case_invocations':0,'runtime_result':'NOT_RUN','writer_result':'Recorded static self-review in own receipt; current bytes frozen by final root manifest'})
 count+=len(cases)
assert len(packs)==6 and count==100
save(D/'SOURCE_BINDINGS.json',{'schema':'M3_R14_FINAL_SOURCE_BINDINGS_V2','state':'EXACT_UNRUN_STATIC_BYTES','packs':packs,'total_case_specifications':count,'candidate_execution':0,'old_bindings_preserved':ref(B/'SOURCE_BINDINGS.json'),'formation_PLAN_bytes_unchanged':True})
h=read(B/'HANDOFF.json');h.update(schema='M3_R14_STATIC_HANDOFF_V2',handoff_id='M3-R14-PRECHECK-PREP-20261019-V2',case_specifications=count,R13_state_at_handoff='W_CODEC_08 FAILED_STOP fixed supervisor timeout; no full replay per latest user',updated_utc=datetime.now(timezone.utc).isoformat(),state='STATIC_PREPARATION_COMPLETE_UPLOAD_PENDING')
h['supersedes']='M3-R14-PRECHECK-PREP-20261019-V1';h['old_root_originals']=ref(B/'MANIFEST.json');h['reconciliation']='Root MANIFEST was formed before recorded late static self-review; source/spec changes retained. No candidate syntax/import/test run. 13 changed payloads rebound; new case total100 supersedes89.'
save(D/'HANDOFF.json',h)
(D/'SELF_REVIEW.md').write_text((B/'SELF_REVIEW.md').read_text('utf-8')+'\n\n终版 V2：上传前身份检查拒收旧清单，定位为角色静态自审后 13 个文件已更新。D 收据记录 MAIN2_DAYTIME_STATIC_TAKEOVER_R01；E 保留旧11案例/源码原文并新增8个未运行规格，F/G/I 的有界输入、证据请求及单成员因果组拒收修订各留本包历史。现为 D13/E19/F14/G21/H17/I16，共100个 NOT_RUN 规格。旧六个根文件逐字节备份到 R13 Task0 的 R14_ROOT_RECONCILIATION_R02，当前30文件重新绑定，没有覆盖源候选或角色历史。根增量只读自审结果另附回执，语法与行为均未验。\n',encoding='utf-8',newline='\n')
files=sorted(p for p in D.rglob('*') if p.is_file());assert len(files)==30
save(D/'MANIFEST.json',{'schema':'M3_R14_STATIC_MANIFEST_V2','payloads':[ref(p) for p in files if p.name!='MANIFEST.json'],'payload_count':29,'exact_file_count':30,'all_candidate_cases':'NOT_RUN','case_specifications':100,'old_manifest':ref(B/'MANIFEST.json')})
save(B/'RECONCILIATION_RECEIPT.json',{'schema':'M3_R14_ROOT_RECONCILIATION_V2','cause':'Late recorded static self-review after initial root freeze; no runtime candidate changes imported or executed','deltas':deltas,'old_roots':[ref(B/n) for n in roots],'current_roots':[ref(D/n) for n in roots],'candidate_calls':0,'total_cases':100,'actual_level':'L0','failed_archive_attempt':'archive_static_delivery_r02.py exit1 before payload write; original empty STATIC_DELIVERY_R01 preserved','updated_utc':datetime.now(timezone.utc).isoformat()})
print(json.dumps({'state':'R14_STATIC_PREP_V2_REBOUND','case_specifications':count,'manifest':ref(D/'MANIFEST.json')}))

q=read(B/'RECONCILIATION_RECEIPT.json');q['root_auxiliary_text_review']={'result':'No blocking issue for static candidate preparation in specified E/F/G/I increments','checked':'E two sources + E cases, F coverage_check, G level_rules, I blocker_dag and four package static receipts; 12 current source/spec references sizes/SHA verified','not_checked':'Syntax, imports, runtime behavior, graph correctness, all business closure'};save(B/'RECONCILIATION_RECEIPT.json',q)

