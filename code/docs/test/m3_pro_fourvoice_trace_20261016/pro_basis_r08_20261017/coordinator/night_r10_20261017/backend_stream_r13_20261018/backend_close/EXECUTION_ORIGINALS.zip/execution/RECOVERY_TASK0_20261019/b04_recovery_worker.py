"""One located B04 observation repair; reuse unchanged same-night business evidence."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path.cwd().resolve()
OUT = ROOT / 'code/output/m3_backend_stream_r13_20261018'
SOURCE = ROOT / 'code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/backend_stream_r13_20261018'

def read(path):
    return json.loads(path.read_text('utf-8'))

def ref(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def save(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    assert len(raw) <= 8 * 1048576 and not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb', buffering=0) as stream:
        for offset in range(0, len(raw), 1048576):
            block = raw[offset:offset + 1048576]
            assert stream.write(block) == len(block)

p = argparse.ArgumentParser()
p.add_argument('--admission', type=Path, required=True)
p.add_argument('--sha256', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert ref(a.admission)['sha256'] == a.sha256
admission = read(a.admission)
assert admission['purpose'] == 'B04_LATE_MEMBER_REAP_ONLY'
output = a.output.resolve()
assert output == OUT / 'RUNS/B04_RECOVERY_05/inner'
assert not output.exists()
output.mkdir(parents=True)
for item in admission['old_originals']:
    assert ref(Path(item['path'])) == item
sys.path.insert(0, str(SOURCE))
import job_bridge
call, events = job_bridge.frozen_owned_call(admission['root_deadline_monotonic'])
argv = [str(Path(sys.executable).resolve()), '-X', 'utf8', '-B',
        str(SOURCE / 'job_bridge.py'), '--fixture', 'timeout']
actual = call(argv, ROOT, output / 'B04', 5, natural_wait=1.0)
assessment = job_bridge.assess(actual, 5, events,
     expected_exit='OWNED_TERMINATED_TIMEOUT', expected_code=124, require_descendant=True)
stdout = (output / 'B04/stdout.bin').read_bytes()
assert b'R13_PARENT_READY child_pid=' in stdout and b'R13_CHILD_READY' in stdout
assert b'R13_PARENT_DONE' not in stdout and b'R13_CHILD_DONE' not in stdout
save(output / 'B04_ACTUAL.json', {'owned': actual, 'assessment': assessment})
assert assessment['status'] == 'PASS', json.dumps(assessment)
old_bridge = read(OUT / 'RUNS/B_RECOVERY_04/stdout.bin')
old_worker_path = OUT / 'RUNS/B_RECOVERY_04/inner/B02/worker/WORKER_LOCAL_RESULT.json'
old_worker = read(old_worker_path)
assert old_bridge['parent_cases']['B02']['assessment']['status'] == 'PASS'
assert old_bridge['parent_cases']['B03']['assessment']['status'] == 'PASS'
assert {case['id'] for case in old_worker['cases']} == {f'B{i:02d}' for i in range(1, 13)}
assert all(case['status'] == 'PASS' for case in old_worker['cases'] if case['id'] not in {'B02', 'B03', 'B04'})
old_bridge['parent_cases']['B04'] = {'owned': actual, 'assessment': assessment}
old_bridge.update(status='PASS', B02_B03_B04_parent_observation=True,
     recovery_scope='Only B04 executed here. B02/B03 and9 business cases reused from exact unchanged same-night B_RECOVERY_04 originals.',
     previous_bridge=ref(OUT / 'RUNS/B_RECOVERY_04/stdout.bin'),
     actual_B04=ref(output / 'B04_ACTUAL.json'))
save(output / 'GROUP_COMPLETE.json', old_bridge)
old_worker.update(reuse_scope='Previous same-night software cases preserved; no software case executed in this B04 recovery.',
     previous_worker=ref(old_worker_path), actual_B04=ref(output / 'B04_ACTUAL.json'))
save(output / 'WORKER_LOCAL_RESULT.json', old_worker)
print(json.dumps({'scope': 'B04_ONLY_WITH_EXPLICIT_PREVIOUS_CASE_REUSE', 'status': 'PASS'}))
