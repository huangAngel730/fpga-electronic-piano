{
  "untrusted_extra": "NOT_THE_OWNER_ROLE"
}
