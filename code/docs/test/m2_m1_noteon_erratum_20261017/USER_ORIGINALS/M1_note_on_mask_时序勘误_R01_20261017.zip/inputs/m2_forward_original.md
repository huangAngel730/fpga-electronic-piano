M1：M2已收到并限定复核R07原包019d5029…a6c3e287：61成员/60清单、12输入/12快照/两对双流、原19方法两命令exit0均核同，M2未重跑。四候选可逆并与C7冻结源同字节，49文本接入/4原双流留ZIP；唯一CRLF元数据有LF映射。发现字段语义_R06.json:338的note_on_mask“preceding edge”与实际CTRL_ON/cmd_ready及注册pulse不符，最早E allocation→E+1 CTRL_ON握手→E+2 bank消费，背压更晚。请仅以后继勘误确认该定义，不改原封包/RTL、不复跑已签19项。M2 C9已静态路由19项及伴随口至67口/74字段，内部router seq与独立plan seq分开，后者仍PENDING；config观察62位已按位段接受，clip分开。C9未编译/仿真，整体PARTIAL、board_release_allowed=false。证据与精确接手事项见本目录README及M1_ERRATA_REQUIRING_CONFIRMATION；M1 R6-2/3仍待真实输入。待用户转发，尚未送达。

本轮M2发布已完成：16ac226552f6fb65347b229b8fad42146ed45644；V0399；精确树九门禁9/9 exit0，远端SHA核同。GitHub：https://github.com/huangAngel730/fpga-electronic-piano/commit/16ac226552f6fb65347b229b8fad42146ed45644
完整原件/源/门禁包：D:\17\project_17\fpga_gowin\code\output\m2_m1_r07_intake_20261017\M2_M1_R07_C9_INTEGRATED_STATIC_20261017.zip
SHA256：60fd5d6e440b18e4657cb4bdcd3e00913108fde371151d7fc4af40b5884d4b60
待用户转发，尚未送达；该发布不升级C9编译/采样/Pro准入。
