"""Package a documentation-only successor; never edit the frozen sources."""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import intake

ROOT = Path(__file__).resolve().parent
OUT = Path('D:/嵌赛/高云二/拓展/22_M1_note_on时序勘误_20261017')
CONTENT = ROOT / 'delivery'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else data.encode('utf-8'))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    m = json.loads((ROOT / 'SOURCE_MANIFEST.json').read_bytes())
    known = {x['id']: x for x in m['files']}
    old_raw = (ROOT / known['original_semantics']['copy']).read_bytes()
    old = json.loads(old_raw)
    original_zip = (ROOT / known['m1_original_zip']['copy']).read_bytes()
    assert sha(original_zip) == '019d50298c171b4359c7882a092f11f5b582033a8d81cb318f22b817a6c3e287'
    expected = {
        'router': 'ec69d5d63cf9bd79abe794f95a92338a32a702d56422bdcbb3079dd200eea4c4',
        'bank': '31c25b7e6eb22714d01c7d0f0ceb7131b3fb301d1aab54bebd041dace2fb4502',
        'audio': '193bc5cd9c7675b7f97564223ce39c7ba8d488f2028dfbadbbb033887ab82f63',
        'chain': '076da7f76d641d0e9a8c2a0d910a1ff929ed923639877d36e320887fe095c995',
    }
    for key, digest in expected.items():
        assert known[key]['sha256'] == digest
    idx = next(i for i, f in enumerate(old['fields']) if f['semantic_id'] == 'note_on_mask')
    assert idx == 4
    prev = old['fields'][idx]['definition']
    assert prev == ('Registered one-edge pulse consumed by DDS/ADSR at this edge. '
                    'Allocation commit happened on the preceding edge; '
                    'source/channel/note/generation describe the current lane.')
    replacement = (
        'At a rising-edge pre-NBA sample with reset inactive, this is the current '
        'registered slot_note_on pulse consumed by the lane voice/ADSR Note On inputs '
        'on this edge. The pulse was asserted by nonblocking assignment after the '
        'preceding CTRL_ON && cmd_ready handshake edge H, not by the allocation edge. '
        'For a successful ALLOC_APPLY && slot_valid edge E, with no intervening reset '
        'abort, H is the first subsequent CTRL_ON && cmd_ready edge and consumption '
        'occurs at C=H+1. The earliest handshake is H=E+1 and the earliest consumption '
        'is C=E+2; CTRL_ON backpressure defers H and C. Source/channel/note/generation '
        'are the live registered lane identity committed at E. A Note On pulse does '
        'not itself imply sample_tick/advance_mask or a DDS phase reset.'
    )
    patched = deepcopy(old)
    patched['fields'][idx]['definition'] = replacement
    check = deepcopy(patched)
    check['fields'][idx]['definition'] = prev
    assert check == old
    source_evidence = []
    anchors = {
        'router': {
            129: 'slot_note_on<=0;slot_note_off<=0;',
            162: "slot_generation[allocated_slot]<=slot_generation[allocated_slot]+1'b1;",
            163: 'state<=CTRL_ON;',
            165: 'CTRL_ON:if(cmd_ready)begin slot_note_on[target_slot]<=1;state<=IDLE;end',
            215: 'wire obs_note_on_consume_w = rst_n && (|slot_note_on);',
            232: 'obs_note_on_consume_w ? slot_note_on :',
        },
        'bank': {
            69: 'assign obs_slot_note_on=slot_note_on;',
            167: '.clk(clk),.rst_n(rst_n),.sample_tick(lane_tick),.note_on(slot_note_on[i]),.note_off(slot_note_off[i]),',
            171: '.note_on(slot_note_on[i]),.note_off(slot_note_off[i]),',
        },
    }
    for key, lines in anchors.items():
        data = (ROOT / known[key]['copy']).read_bytes()
        text = data.decode('utf-8').splitlines()
        for number, expected_line in lines.items():
            assert text[number-1].strip() == expected_line
            source_evidence.append(dict(source=key, sha256=sha(data), line=number, text=text[number-1]))
    overlay = dict(
        schema='M1_SOURCE_SEMANTICS_ERRATA_R01', status='M1_CONFIRMED_SOURCE_ONLY',
        original_zip_sha256=sha(original_zip),
        target_path='code/docs/test/m1_r05_pcm_oracle_20261016/pro_r06_20261017/source_semantics/字段语义_R06.json',
        target_sha256=sha(old_raw), target_schema=old['schema'],
        target_semantic_id='note_on_mask',
        operations=[
            dict(op='test', path=f'/fields/{idx}/semantic_id', value='note_on_mask'),
            dict(op='test', path=f'/fields/{idx}/definition', value=prev),
            dict(op='replace', path=f'/fields/{idx}/definition', value=replacement),
        ],
        applying_instruction='Verify the complete target byte SHA256 first. Apply to a new successor in memory or a new file; preserve the frozen original and original ZIP. This envelope contains an RFC6902-style operations list, not a complete replacement contract.',
        source_evidence=source_evidence,
        boundary=dict(old_tests_rerun=False, rtl_modified=False, hdl_executed=False,
                      plan_seq='PENDING_INDEPENDENT_PLAN_BINDING',
                      R6_2='PENDING_REAL_INPUT', R6_3='PENDING_REAL_INPUT',
                      board_release_allowed=False))
    write(CONTENT / 'NOTE_ON_MASK_ERRATA_R01.json', json_bytes(overlay))
    md = f'''# M1 对 M2 第20批 note_on_mask 时序勘误的确认

M1 确认原 `字段语义_R06.json:338` 中 “Allocation commit happened on the preceding edge” 不正确。原文件、四份 RTL、原封包与已签 19 项测试全部保留；本后继只修订 `note_on_mask.definition` 的文字定义。

原封包 SHA256：`{sha(original_zip)}`。原语义文件 SHA256：`{sha(old_raw)}`。本次依据为本地冻结源静态阅读，等级 L0；没有新增软件测试组、HDL 编译/仿真、EDA 或板测。

## 确认后的时序定义

采样口径仍是 `posedge clk / pre-NBA`，位宽 4、无符号、`CONSUMED_NOTE_ON_PULSE` 与全部既有字段、端口不变。

- E 是 `ALLOC_APPLY && slot_valid` 成功沿。该沿 NBA 更新 lane 的 source/channel/note/generation，并令状态进入 `CTRL_ON`；该沿不产生 Note On 消费。
- H 是 E 之后第一个 `CTRL_ON && cmd_ready` 成功握手沿，最早 H=E+1。该沿 NBA 才把 `slot_note_on[target_slot]` 置 1。
- 若中间没有复位取消，消费沿 C=H+1，最早 C=E+2。C 沿 pre-NBA 采到注册脉冲，voice 与 ADSR 的 Note On 输入在该沿消费；随后默认清零。
- `CTRL_ON` 背压推迟 H 和 C，不能写成固定的 E+1 或固定延迟。复位可能中止交易，不能从 allocation 单独推定一定发生消费。
- Note On 脉冲不等于 `sample_tick` / `advance_mask`，不额外声称 DDS 相位复位；音频推进沿和原算法保持原定义。

下面是由源码推导的边沿例子，**不是新仿真结果**：

| 场景 | allocation E | CTRL_ON 握手 H | Note On 消费 C |
| --- | --- | --- | --- |
| 无背压 | 100 | 101 | 102 |
| 101、102 沿 cmd_ready=0 | 100 | 103 | 104 |
| H 前复位 | 100 | 无成功握手 | 不保证消费 |

无背压时，101 沿 pre-NBA 仍见脉冲 0，101 沿 NBA 后置 1；102 沿 pre-NBA 才见 1。所谓“前一沿”只适用于握手 H 相对消费 C，不能用于 allocation E 相对 C。

## 可核出处

- [router 冻结源](inputs/router.sv)：129 行默认清零；156–163 行 allocation 与身份/世代提交、转 CTRL_ON；165 行握手注册脉冲；215、232 行消费观察。
- [bank 冻结源](inputs/bank.sv)：69 行直接导出脉冲；167、171 行直接送 voice/ADSR。
- [原语义 JSON](inputs/original_semantics.json)：338 行错误原句保留。
- [带 SHA 前置条件的单字段补丁](NOTE_ON_MASK_ERRATA_R01.json)：仅替换 `/fields/4/definition`。采用时先核原文件完整 SHA，并生成新的后继版本；不要回写原文件或原 ZIP。

## 给 M2 / M3 的接手说明

请把本确认与原语义文件一起引用，在后继定义中采用该单字段勘误。M3 的独立事件日历按真实 H/C 消费沿关联 lane 与 generation；不得由 allocation 固定加一推算，也不能把内部 router seq 当独立 plan seq。

本确认没有重验 C9。M2 转发称 C9 为 67 口/74 字段、config 62 位位段已接受、clip 分开、独立 plan seq 仍 PENDING；这些仅记录为 M2 已报告状态，不冒称 M1 独立核过新 C9。R6-2/3 继续等待真实同版输入，`board_release_allowed=false`。

## 到件与发布边界

已收到 [M2/20 原消息](inputs/m2_forward_original.md)。Git 远端引用本轮成功更新到 `{m['latest_commit']}`，当前 M1 任务单与 R07 已取得；7 个所需 blob（含 M2 详细勘误、C9 复核文件、最新总览和看板）未取回。指定对象下载先遇 DNS 失败，DNS 恢复后再次请求遇低速超时；无全局网络配置更改。M2 提供的 D:\\17 外包路径在本机不存在，SHA `60fd5d6e440b18e4657cb4bdcd3e00913108fde371151d7fc4af40b5884d4b60` 尚未由 M1 复验。

本后继只在本地交付目录形成，未写入原 Git 工作树、未暂存/提交/推送；缺发布前置文件，不执行新精确树九门禁，也不把 M2 的 V0399 9/9 当作本后继门禁。原 q 工作树已有内容和未发布提交保持原样。完整来源、读取失败、原包及静态核对结果在 ZIP 中。

待用户转发，尚未送达。
'''
    write(CONTENT / 'M1_NOTE_ON_MASK_ERRATA_R01.md', md)
    for item in m['files']:
        if 'copy' in item:
            data = (ROOT / item['copy']).read_bytes()
            assert sha(data) == item['sha256']
            write(CONTENT / item['copy'], data)
    write(CONTENT / 'SOURCE_MANIFEST.json', json_bytes(m))
    old_member_report = []
    with zipfile.ZipFile(ROOT / known['m1_original_zip']['copy']) as z:
        manifest = json.loads(z.read('MEMBER_MANIFEST.json'))
        assert len(z.namelist()) == 61 and len(manifest['files']) == 60
        assert z.testzip() is None
        for item in manifest['files']:
            data = z.read(item['path'])
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
            if item['path'].startswith('repo/'):
                rel = item['path'][5:]
                qdata = (intake.REPO / rel).read_bytes()
                assert qdata == data, rel
                old_member_report.append(dict(path=rel, sha256=sha(qdata)))
    final_head = intake.git('final_local_head', ['rev-parse', 'HEAD'])
    final_status = intake.git('final_status', ['status', '--porcelain=v1'])
    tracked_diff = intake.git('final_tracked_diff', ['diff', '--name-only'])
    staged_diff = intake.git('final_staged_diff', ['diff', '--cached', '--name-only'])
    assert final_head == (ROOT / 'runs/local_head/stdout.bin').read_bytes()
    assert final_status == (ROOT / 'runs/initial_status/stdout.bin').read_bytes()
    assert not tracked_diff.strip() and not staged_diff.strip()
    for p in sorted((ROOT / 'runs').rglob('*')):
        if p.is_file():
            write(CONTENT / p.relative_to(ROOT), p.read_bytes())
    verification = dict(status='PASS_DOCUMENT_STATIC_CHECK_ONLY', original_zip_members=61,
        original_zip_manifest_payloads=60, original_repo_members_still_byte_identical=old_member_report,
        source_anchors_checked=len(source_evidence), overlay_only_changed_json_pointer=f'/fields/{idx}/definition',
        rtl_unchanged=True, original_json_unchanged=True, old_tests_rerun=False,
        hdl_compile_or_simulation=False, nine_gate=False, committed=False, pushed=False,
        board_release_allowed=False)
    write(CONTENT / 'STATIC_VERIFICATION_R01.json', json_bytes(verification))
    for src in [ROOT / 'intake.py', Path(__file__)]:
        write(CONTENT / 'packaging_scripts' / src.name, src.read_bytes())
    failures = dict(format='NORMALIZED_TOOL_RESULT_TRANSCRIPT_NOT_RAW_STREAMS',
        fetch_metadata=dict(result='PASS', from_commit='ef4fbc74b9d24e08de1e09d0be0eb3163118f258', to_commit=m['latest_commit']),
        failures=[
            dict(action='sandbox direct git fetch metadata', exit_code=1, result='schannel SEC_E_NO_CREDENTIALS'),
            dict(action='elevated specified 11 blob fetch first attempt', exit_code=1, result='Could not resolve host: github.com'),
            dict(action='Resolve-DnsName github.com', exit_code=0, result='20.205.243.166'),
            dict(action='elevated same blob fetch after DNS recovery', exit_code=1, result='Operation too slow. Less than 1 bytes/sec transferred the last 20 seconds'),
            dict(action='read-only raw GitHub fallback for 2 M2 docs', result='404; no document content obtained'),
        ],
        local_reads='Actual subprocess stdout/stderr and receipts are under runs/. Missing blobs were read with GIT_NO_LAZY_FETCH=1 and remain missing, not fabricated.',
        publication='NOT_ATTEMPTED_REQUIRED_LATEST_BLOBS_UNAVAILABLE', global_git_config_changed=False)
    write(CONTENT / 'NETWORK_AND_PUBLICATION_STATUS.json', json_bytes(failures))
    members = []
    for p in sorted(CONTENT.rglob('*')):
        if p.is_file() and p.name != 'MEMBER_MANIFEST.json':
            data = p.read_bytes()
            members.append(dict(path=p.relative_to(CONTENT).as_posix(), bytes=len(data), sha256=sha(data)))
    write(CONTENT / 'MEMBER_MANIFEST.json', json_bytes(dict(schema='M1_R20_ERRATA_PACKAGE_V1', files=members)))
    zip_path = OUT / 'M1_note_on_mask_时序勘误_R01_20261017.zip'
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(CONTENT.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(CONTENT).as_posix())
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(members)+1
        for x in members:
            data = z.read(x['path'])
            assert len(data) == x['bytes'] and sha(data) == x['sha256']
    receipt = dict(status='LOCAL_DOCUMENT_ERRATUM_COMPLETE', zip=str(zip_path),
        bytes=zip_path.stat().st_size, sha256=sha(zip_path.read_bytes()),
        members=len(members)+1, static_validation='PASS', original_zip_sha256=sha(original_zip),
        original_source_json_sha256=sha(old_raw), changed_definition='/fields/4/definition',
        original_files_unchanged=True, new_test_groups=0, hdl_runs=0,
        unpublished=True, board_release_allowed=False, notification='待用户转发，尚未送达')
    write(OUT / 'FINAL_RECEIPT.json', json_bytes(receipt))
    write(OUT / 'NOTE_ON_MASK_ERRATA_R01.json', (CONTENT / 'NOTE_ON_MASK_ERRATA_R01.json').read_bytes())
    write(OUT / 'M1_NOTE_ON_MASK_ERRATA_R01.md', (CONTENT / 'M1_NOTE_ON_MASK_ERRATA_R01.md').read_bytes())
    for p in sorted((CONTENT / 'inputs').rglob('*')):
        if p.is_file():
            write(OUT / p.relative_to(CONTENT), p.read_bytes())
    forward = f'''# 给 M2 / M3：M1 第20批勘误确认（待用户转发，尚未送达）

M1 确认 note_on_mask 原定义的 “preceding edge” 有误。设 E 为成功 allocation 沿，H 为后续 CTRL_ON && cmd_ready 握手沿，reset 不打断时消费沿 C=H+1；最早 E→E+1→E+2，背压可继续推迟。前一沿对应握手 H，不对应 allocation E。4 位/无符号/pre-NBA/端口及原语义其余部分保持，Note On 不代表 sample advance 或 DDS 相位复位。

本包只提供后继文字和绑定原 JSON SHA 的单字段替换补丁；原 R07 ZIP、四份 RTL、原语义与 19 项历史测试没有改动或重跑。已静态核源码关键行、原包61成员/60清单全部 CRC/大小/SHA，并对仍在 q 的原封包 repo 成员逐字节核同。不是新编译/仿真，也不确认 C9 实际运行。

交付 ZIP：`{zip_path.name}`，SHA256 `{receipt['sha256']}`，{receipt['bytes']} 字节。请将本后继和原语义文件共同引用，M3 按真实消费沿关联身份，独立 plan seq 仍需独立绑定。R6-2/3 真实输入未到，board_release_allowed=false。

本地未暂存/提交/推送。远端引用已取到 {m['latest_commit']}；但详细 C9/勘误及最新总览/看板共7个指定 blob 下载失败，M2 D:\\17 封包本机不可读，未复验其完整外包 SHA。遵守发布前置条件，本后继没有执行精确树九门禁。后续可由 M2 接入此文档勘误；不能把 M2 V0399 门禁或本次 L0 静态核对代作后继运行验收。
'''
    write(OUT / '给M2_M3_勘误确认与交接.md', forward)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
