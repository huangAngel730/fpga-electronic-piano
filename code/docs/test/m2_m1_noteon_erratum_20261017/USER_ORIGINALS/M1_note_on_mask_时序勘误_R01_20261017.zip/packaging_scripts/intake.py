"""Read-only intake for the M2/20 source-semantics erratum."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Users/lc/.codex/visualizations/2026/10/14/01a138d3-c198-7b02-aba4-64f9e7960af9/q')
M2 = '16ac226552f6fb65347b229b8fad42146ed45644'
BASE = 'code/docs/test/m2_m1_r07_intake_20261017/'
SEM = 'code/docs/test/m1_r05_pcm_oracle_20261016/pro_r06_20261017/source_semantics/'
RTL = 'code/rtl/audio/m1_pro_observer_r06_20261017/'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def git(label, args):
    dest = ROOT / 'runs' / label
    dest.mkdir(parents=True, exist_ok=True)
    argv = ['git', '-c', 'core.longpaths=true', *args]
    start = time.time()
    p = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=40, env=ENV)
    (dest / 'stdout.bin').write_bytes(p.stdout)
    (dest / 'stderr.bin').write_bytes(p.stderr)
    write_json(dest / 'receipt.json', dict(argv=argv, cwd=str(REPO),
        start_unix=start, seconds=time.time()-start, exit_code=p.returncode,
        stdout_sha256=sha(p.stdout), stderr_sha256=sha(p.stderr),
        git_no_lazy_fetch=True))
    if p.returncode:
        raise RuntimeError(f'{label}: {p.returncode}; see raw stderr')
    return p.stdout


def main():
    current = git('remote_head', ['rev-parse', 'origin/develop']).decode().strip()
    git('local_head', ['rev-parse', 'HEAD'])
    git('initial_status', ['status', '--porcelain=v1'])
    entries = [
        ('m2_readme', M2, BASE + 'README.md'),
        ('m2_errata_request', M2, BASE + 'M1_ERRATA_REQUIRING_CONFIRMATION.md'),
        ('m2_acceptance', M2, BASE + 'ACCEPTANCE.json'),
        ('m2_c9_static', M2, BASE + 'C9_STATIC_AUDIT.json'),
        ('m2_c9_decision', M2, 'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/c9_m1_semantics_20261017/SOURCE_DECISION_R06C9.json'),
        ('latest_agents', current, 'AGENTS.md'),
        ('latest_m1_task', current, 'code/docs/M1_完赛任务单_2026-10-15.md'),
        ('latest_overview', current, 'code/docs/138K四声部后续集成任务总览_2026-10-15.md'),
        ('latest_board', current, 'code/docs/任务看板.md'),
        ('latest_start', current, 'code/docs/三人开工任务说明.md'),
        ('latest_r07', current, 'code/docs/Pro基础持续推进与M3扩充分工任务单_R07_2026-10-17.md'),
    ]
    manifest = []
    for label, commit, path in entries:
        try:
            data = git(label, ['show', commit + ':' + path])
        except RuntimeError:
            manifest.append(dict(id=label, commit=commit, path=path,
                status='UNAVAILABLE_LOCAL_BLOB_NO_LAZY_FETCH', read=False))
            continue
        suffix = Path(path).suffix
        dest = ROOT / 'inputs' / (label + suffix)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        manifest.append(dict(id=label, commit=commit, path=path, bytes=len(data),
            sha256=sha(data), git_blob=sha1_blob(data), copy=str(dest.relative_to(ROOT))))
    local = [
        ('original_semantics', REPO / SEM / '字段语义_R06.json'),
        ('router', REPO / RTL / 'm1td_polyphonic_event_router.sv'),
        ('bank', REPO / RTL / 'm1td_polyphonic_envelope_bank.sv'),
        ('audio', REPO / RTL / 'm1td_audio_candidate.sv'),
        ('chain', REPO / RTL / 'm1td_timbre_delay_chain.sv'),
        ('m2_forward_original', Path('D:/嵌赛/高云二/拓展/M2/20/FORWARD_TO_M1_PUBLISHED.md')),
        ('m1_original_zip', Path('D:/嵌赛/高云二/拓展/21_M1十九字段语义与观察出口_20261017/M1_十九字段语义与观察出口_R07_20261017.zip')),
    ]
    for label, path in local:
        data = path.read_bytes()
        dest = ROOT / 'inputs' / (label + path.suffix)
        dest.write_bytes(data)
        manifest.append(dict(id=label, path=str(path), bytes=len(data), sha256=sha(data), copy=str(dest.relative_to(ROOT))))
    write_json(ROOT / 'SOURCE_MANIFEST.json', dict(m2_commit=M2, latest_commit=current, files=manifest))
    print(json.dumps(dict(status='INTAKE_WITH_EXPLICIT_GAPS', files=len(manifest),
        unavailable=sum(x.get('read') is False for x in manifest), latest=current)))


def sha1_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


if __name__ == '__main__':
    main()
