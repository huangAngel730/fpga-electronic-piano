# d53 补充材料中 7 件源码快照与 9 件 M1 第18批静态说明的限定复核

目标 `d53fcd42488141f8711173f1b20df14361f19b49`，相对 `ffc8b4c`；只读复核，无被审程序、HDL、EDA、设备执行，无源码/共享状态/C4修改。

结论：7件源码/工程/CST快照全部与已签旧版本 `0f13d04` 的实际源路径逐字节一致，可按L0历史原件保留。9件说明全文读过，可作为L0字段差额说明保留；M1第18批外部包本体未齐，不能把M3关于manifest16/16及FIELD_MAP正确性的转述升级成M2已核。

|序号|快照|已签旧源|大小|SHA256|实际阅读边界|
|---|---|---|---:|---|---|
|1|`code/docs/test/m3_dual_slider_138k_candidate_20261015/pro_integrate_successor_20261017/INPUT_ORIGINALS/current_board_shell.sv`|`0f13d04:code/rtl/board/audio_visual_display_probe.sv`|6886|`6eca6bb7a4adae483ec4c802530392d3545174b2946d64724081320b317d2390`|Full 132-line UTF-8 body; visual-event shell, local diagnostic time, old 50MHz video reference and existing instantiated blocks. No HDL run.|
|2|`code/docs/test/m3_dual_slider_138k_candidate_20261015/pro_integrate_successor_20261017/INPUT_ORIGINALS/current_project.gprj`|`0f13d04:code/build/electronic_piano.gprj`|5640|`0cca0b9494486f4ef70b09cd59f1dc9fabca10ab3fa8a26914fa0d24fb055b57`|Full 83-line XML body and enabled file list; Device GW5AT-60B / GW5AT-LV60PG484AC1/I0, old 60K project. No project execution.|
|4|`code/docs/test/m3_dual_slider_138k_candidate_20261015/pro_integrate_successor_20261017/INPUT_ORIGINALS/pro_cst_candidate.cst`|`0f13d04:code/rtl/138K_Pro/tang_mega_138k-pro_pins.cst`|18688|`f647104f7b74800890d0283a438b226301bff3a3429a04ec0f6df63c9026e8ba`|CST lines 1-85 and last 35; complete byte SHA identity, not electrical/package/Bank certification.|
|78|`code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/intake_20261017/INPUT_ORIGINALS/038_electronic_piano_top.sv`|`0f13d04:code/rtl/board/electronic_piano_top.sv`|35358|`fb3aba0246ee3bd71a123cc954cb05df8c3236605310ae17310ac1420cae908a`|Top source lines 1-90 header/old60K target/electrical/reset/purpose notes; complete byte SHA identity, not a new full functional review.|
|79|`code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/intake_20261017/INPUT_ORIGINALS/048_tang_mega_138k-pro_pins.cst`|`0f13d04:code/rtl/138K_Pro/tang_mega_138k-pro_pins.cst`|18688|`f647104f7b74800890d0283a438b226301bff3a3429a04ec0f6df63c9026e8ba`|Identical to index4 CST; same limited text reading and complete byte identity.|
|82|`code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/intake_20261017/INPUT_ORIGINALS/supplement_02_tb_normal.sv`|`0f13d04:code/tb/audio_out/m3_clock40_pcm_serial_acceptance/tb_normal.sv`|4496|`f4b156443a44448a5133b17284b68611eb7dfdc5486417db127095fe870bb5ef`|Full 84-line TB; old sealed40MHz chain stimulus/private u_core hierarchy/end/timeout. Not eligible as new public observer TB.|
|83|`code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/intake_20261017/INPUT_ORIGINALS/supplement_03_serial_capture.sv`|`0f13d04:code/tb/audio_out/m3_clock40_pcm_serial_acceptance/serial_capture.sv`|2677|`b6cfb059fd54d7ecc4cc3c1dcd035e9d97dad334b3c8e9fee8e28d33467f23be`|Full65-line serial observer; PRE_NBA handshakes, adoption log, BCLK/WS/DIN shift decode. Not a new sidecar/finish/epoch proof.|

7件均为IDENTICAL，无CRLF或其它空白归一。old60K project/top、旧Pro通用pin模板、旧TB不能用于签当前Pro source list/Part/Bank或公开捕获；tb_normal仍读取私有层级，保持旧测试原件身份，不复用为新公开observer。

9件day_m1_batch18说明（逐件身份见JSON）：
- index62 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/day_m1_batch18_20261017/FIELD_DELTA.json`：7794 bytes，SHA `84f83f16305b1e9ef1d3ea58e812ff063849457ae304593aba08392155e30f01`，全文读取/JSON解析。
- index63 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/day_m1_batch18_20261017/INPUT_SHA.json`：2486 bytes，SHA `398759273f77b47044bfe1f9e248891f2fce394e181a22272ae038aa2886b5c9`，全文读取/JSON解析。
- index64 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/day_m1_batch18_20261017/RESULT.txt`：3239 bytes，SHA `0b8f403342367d4ab4219762e476dfeaca840f3b30cdcaa833c6095764fa8970`，全文读取/JSON解析。
- index65 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/day_m1_batch18_coordinator_20261017/INPUT_SHA.json`：4092 bytes，SHA `46e23ce69004f224e814cbe93a0c7b9ad6b0086782c92981db2ee31da09257b8`，全文读取/JSON解析。
- index66 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/day_m1_batch18_coordinator_20261017/M2_FORWARD.md`：2778 bytes，SHA `47d747db4224510b8bbcb559c431db3b73764943459333e5790b4213e9885e0b`，全文读取/JSON解析。
- index67 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_binding_20261017/day_m1_batch18_coordinator_20261017/RESULT.md`：4621 bytes，SHA `61df7ba8d554926487cccb00269789154bc25edfb7ac612600de85a3f4db60f3`，全文读取/JSON解析。
- index91 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_serial_successor_20261017/day_m1_batch18_20261017/INPUT_SHA.json`：5104 bytes，SHA `725230410527e12d1d0a74fe7664a79a3bdfb85a74269d3ae371c6738c1b4196`，全文读取/JSON解析。
- index92 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_serial_successor_20261017/day_m1_batch18_20261017/RESULT.txt`：4147 bytes，SHA `62bfe7c1049ec34ffa26a8141258fb6fcbe83cff889e4e79e052ed542d5450e3`，全文读取/JSON解析。
- index93 `code/docs/test/m3_pro_fourvoice_trace_20261016/pro_serial_successor_20261017/day_m1_batch18_20261017/SERIAL_FIELD_DELTA.json`：5209 bytes，SHA `0321acad4d4f3f083947f5e6c6e2db7523ac99d8b46bfb9b4ddfa988640cb5a2`，全文读取/JSON解析。

从已有旧C原件独立进行JSON/JSONL读取：496条逐对象一致；19 FRAME、76 ACCEPT/LANE_TICK、75 RETURN/PUBLISH、71 CONSUME、5 CANCEL；PUBLISH/CANCEL交集4个身份(0,15,0,0,61)至(0,15,3,3,64)。这是原C合成日历字节/对象核验，未运行M1 mapper。CALENDAR_CONTRACT SHA与第18批声明精确相同。

未取得的外部原件（本次精确检查范围，不冒称全盘搜索）：
- `E:/FPGA/GAOYUNFPGA/night_task/10.17/FROM_M1/M1_第18批独立日历字段适配_20261017/给M3和M2_第18批日历适配回复.md`，SHA `d9410044ff897efb3bba9b8e361f0e0290d87d7e3a277a032ae885acfc7daa68`。
- `E:/FPGA/GAOYUNFPGA/night_task/10.17/FROM_M1/M1_第18批独立日历字段适配_20261017/INTAKE_STATUS.json`，SHA `bf13df22ab8dc7f2727464bdcd89bb309f7f5e46cc69b47e7693cb1e72b0f805`。
- `E:/FPGA/GAOYUNFPGA/night_task/10.17/FROM_M1/M1_第18批独立日历字段适配_20261017/MANIFEST.json`，SHA `07469e30eddb8e31f17ca21a1afe6471fef48515fab4b4c7f3eee27f7f071c34`。
- `E:/FPGA/GAOYUNFPGA/night_task/10.17/FROM_M1/M1_第18批独立日历字段适配_20261017/mapped/FIELD_MAP.json`，SHA `83cb365313788cec24594fcc2d8446d58a313c486fd1c43565ca959714332c6e`。
- `E:/FPGA/GAOYUNFPGA/night_task/10.17/FROM_M1/M1_第18批独立日历字段适配_20261017/mapped/RECEIPT.json`，SHA `9d45b49f32fe608f569542de8e09af86fa1901afbe9c4974716ab95a8ccc61d4`。
- `M1_第18批独立日历字段适配_20261017 mapper (exact relative path not listed in coordinator INPUT_SHA)`，SHA `1a5e24bff9d6c97f061a2ea71ffe18611e8b27121386ce45e88d77ea44a147f9`。

外部manifest本体缺失，因此不能枚举/重新核验其完整16载荷+manifest共17件；已取得的三个C原件不等于取得完整第18批。M1旧Pro算法ZIP已按原SHA核本体并直接载荷扫描，没有命中上述新批次缺件SHA。

总控三件INPUT_SHA/M2_FORWARD/RESULT自称被R06吸收、INPUT_AUDIT_ONLY/NOT_FOR_PUBLICATION。当前补充提交可历史归档，必须保持失效标记，不能视为当前执行/通知/发布许可。B1/B2说明的分拍/共同tick、生命周期、lane/stereo ID、config/effect、reset、PCM/clip/TX/finish缺口与现行fail-closed方向一致；历史“缺真实出口”等表述不覆盖后来的M2 C3/C4/C5实际进度。

实际边界：L0只读来源和静态差额核对；真实Pro仍PENDING，board_release_allowed=false。来源匹配不证明实际工具/物理身份、数学黄金或真实捕获。

机器原件：`SOURCE_BINDINGS.json`、`FOLLOWUP_BINDINGS.json`、`READ_ONLY_REVIEW.json`；父窗口原97件精确正文位于`remaining97_bodies`。
