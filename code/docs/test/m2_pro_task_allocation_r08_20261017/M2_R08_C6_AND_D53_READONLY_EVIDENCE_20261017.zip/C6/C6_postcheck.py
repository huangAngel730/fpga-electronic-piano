"""Independent ZIP/body inspection; do not import or execute the C6 builder."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

O=Path(__file__).parent
ROOT=Path('D:/17/project_17/fpga_gowin')
B=ROOT/'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017'
D=ROOT/'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017'
BASE=ROOT/'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
def ident(p):
    b=p.read_bytes()
    return {'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)}
with zipfile.ZipFile(D/'SOURCE_CLOSURE_R06C6.zip') as z:
    names=z.namelist()
    crc=z.testzip()
    data={n:z.read(n) for n in names}
with zipfile.ZipFile(D/'SOURCE_CLOSURE_R06C5.zip') as z:
    old={n:z.read(n) for n in z.namelist() if n!='MANIFEST.json'}
with zipfile.ZipFile(BASE) as z:
    original={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
manifest=json.loads(data['MANIFEST.json'])
decision=json.loads((D/'SOURCE_DECISION_R06C6.json').read_text(encoding='utf-8'))
claims=manifest['payloads']
checks={
    'crc_ok':crc is None,
    'member_identity_unique':len(names)==len(set(names))==len({n.casefold() for n in names}),
    'all_paths_canonical':all(not n.startswith('/') and '\\' not in n and ':' not in n and all(p not in {'','.','..'} for p in n.split('/')) for n in names),
    'all_payloads_listed':set(data)==set(claims)|{'MANIFEST.json'},
    'all_payload_size_and_sha':all({'bytes':len(data[n]),'sha256':sha(data[n])}==v for n,v in claims.items()),
    'external_decision_matches':{k:v for k,v in decision.items() if k!='archive'}==manifest,
    'archive_identity_matches':decision['archive']==ident(D/'SOURCE_CLOSURE_R06C6.zip'),
    'builder_identity_matches':decision['builder']==ident(B/'prepare_selected_sources_r06c6.py'),
    'retained_C5_bodies_equal':all(data[n]==body for n,body in old.items() if n!='inputs/compile.f'),
}
raw_list=data['inputs/compile.f']
lines=raw_list.decode('utf-8').splitlines()
units=lines[1:]
checks.update({
    'list_byte_equal_published':raw_list==(B/'SOURCE_LIST_R06C6.f').read_bytes(),
    'include_option':lines[0]=='+incdir+include',
    '71_unique_source_paths':len(units)==len(set(units))==71,
    'all_source_bodies_present':all('inputs/'+n in data for n in units),
    'sources_equal_C5_order':units==old['inputs/compile.f'].decode('utf-8').splitlines(),
})
headers=sorted(n for n in data if n.startswith('inputs/include/'))
roms=sorted(n for n in data if n.startswith('inputs/rom/'))
checks['two_headers']=len(headers)==2
checks['header_frozen_identity']=all(data[n]==original['source_closure/'+n] for n in headers)
checks['nine_roms']=len(roms)==9
checks['rom_frozen_identity']=all(data[n]==original['source_closure/'+n] for n in roms)
modules={};edges=[];seen=set()
def remove_comments(s):
    return re.sub(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/',lambda m:m[0] if m[0].startswith('"') else ' ',s)
def visit(name):
    if name in seen:return
    seen.add(name)
    text=remove_comments(data[name].decode('utf-8-sig'))
    for header in re.findall(r'`include\s+"([^"]+)"',text):
        target='inputs/include/'+header
        edges.append((name,header,target))
        if target in data:visit(target)
for n in units:
    name='inputs/'+n
    text=remove_comments(data[name].decode('utf-8-sig'))
    text=re.sub(r'"(?:\\.|[^"\\])*"','',text)
    for module in re.findall(r'\bmodule\s+(\w+)',text):modules.setdefault(module,[]).append(n)
    visit(name)
checks.update({
    'include_recursive_coverage':all(target in data for _,_,target in edges),
    'two_headers_reached':sorted(n for n in seen if n.startswith('inputs/include/'))==headers,
    '3_literal_include_edges':len(edges)==3,
    '73_unique_modules':len(modules)==73 and all(len(v)==1 for v in modules.values()),
    'shared_ROM_unique_owner':modules['sine_wavetable_1024']==['sources/m1td_dds_oscillator.sv'],
    'dds_leaf_unique_owner':modules['dds_oscillator']==['selected/dds_oscillator_leaf.sv'],
    'leaf_identity':sha(data['inputs/selected/dds_oscillator_leaf.sv'])=='303e3a9927e743d4149ceae4bb8754ebb8abdfb14638d407254b8e555dfcd3bd',
    'no_C4_mixed':sha(data['inputs/selected/m2_r06_tx_identity_sidecar.sv'])=='67e5aba7d697687ac31acb1347483314c67adeb4b37046b9626a5551fdb7c69c',
    'tool_conditions_explicit':manifest['tool_neutral_usage_conditions']['cwd_relative_to_unpacked_root']=='inputs' and manifest['tool_neutral_usage_conditions']['include_directories_relative_to_cwd']==['include'],
    'no_tool_compatibility_claim':manifest['tool_neutral_usage_conditions']['compiler_option_compatibility'].startswith('NOT_TESTED'),
    'no_execution_claim':manifest['HDL_executed'] is False and manifest['execution_admission'] is None and manifest['board_release_allowed'] is False,
})
result={'checks':checks,'all_passed':all(checks.values()),'counts':{'zip_members':len(data),'payloads':len(claims),'units':len(units),'roms':len(roms),'headers':len(headers),'literal_modules':len(modules),'literal_include_edges':len(edges)},'include_edges':edges,'files':[ident(p) for p in [B/'prepare_selected_sources_r06c6.py',B/'SOURCE_LIST_R06C6.f',D/'SOURCE_DECISION_R06C6.json',D/'SOURCE_CLOSURE_R06C6.zip']],'executed_builder_in_postcheck':False,'HDL_calls':0,'actual_level':'L0_STATIC_SOURCE_PACKAGE'}
(O/'C6_POSTCHECK_REPAIR01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['all_passed'] else 1)
