from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

O = Path(__file__).parent
ROOT = Path('D:/17/project_17/fpga_gowin')
BUILD = ROOT/'code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017'
DOC = ROOT/'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017'
BUILDER = BUILD/'prepare_selected_sources_r06c6.py'
BASE = ROOT/'code/docs/test/m2_138k_pro_fourvoice_candidate_20261016/same_version_binding_20261017/M2_PRO_SAME_VERSION_STATIC_BINDING_20261017.zip'
inputs = [BUILDER, BASE, BUILD/'prepare_selected_sources_r06c5.py',
          BUILD/'SOURCE_LIST_R06C5.f', DOC/'SOURCE_CLOSURE_R06C5.zip',
          DOC/'SOURCE_DECISION_R06C5.json']
def identity(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
before=[identity(p) for p in inputs]
argv=[sys.executable,'-B','-X','utf8',str(BUILDER)]
start={'authorization':'M2-owned C6 file-only seal once; no M3 budget or HDL',
       'argv':argv,'cwd':str(ROOT),'started_utc':datetime.now(timezone.utc).isoformat(),
       'inputs':before,'python':identity(Path(sys.executable))}
with (O/'C6_RUN_ONCE_START.json').open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(start,indent=2)+'\n')
t=time.monotonic()
r=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=30,check=False)
(O/'C6_stdout.raw').write_bytes(r.stdout)
(O/'C6_stderr.raw').write_bytes(r.stderr)
after=[identity(p) for p in inputs]
receipt={**start,'finished_utc':datetime.now(timezone.utc).isoformat(),
         'elapsed_seconds':time.monotonic()-t,'exit_code':r.returncode,
         'inputs_after':after,'inputs_unchanged':before==after,
         'stdout':identity(O/'C6_stdout.raw'),'stderr':identity(O/'C6_stderr.raw'),
         'HDL_calls':0,'EDA_calls':0,'device_calls':0,'pure_package_builder_calls':1}
with (O/'C6_RUN_RECEIPT.json').open('x',encoding='utf-8',newline='\n') as f:
    f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'exit_code':r.returncode,'inputs_unchanged':before==after,
                  'elapsed_seconds':receipt['elapsed_seconds'],
                  'stdout':r.stdout.decode('utf-8'),'stderr':r.stderr.decode('utf-8')}))
raise SystemExit(r.returncode)
