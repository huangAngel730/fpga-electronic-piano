# M2 C6 最小修正实施回执

本次仅在 M2 授权的 build/docs 两目录新增四件；C5 全部文件保持原字节，C3/C4 RTL、原冻结源、M3 源、共享状态未修改。未 Git add/commit/push。

## 实际修改

- `code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/prepare_selected_sources_r06c6.py`：新纯文件封包器；从 SHA 固定的 C5 源包保留 71 单元、C3 四源和九 ROM，按原冻结 ZIP 的 SHA 加回两份头；拒绝漏头、SHA 漂移、路径逃逸/重复、未决 include 和重复字面模块。递归扫描源及已引用头，不执行被封装源。
- 同目录 `SOURCE_LIST_R06C6.f`：首行 `+incdir+include`，随后 71 单元原顺序不变；72 个非空行。
- docs/test 对应目录 `SOURCE_DECISION_R06C6.json` 与 `SOURCE_CLOSURE_R06C6.zip`：原 C5 留存，C6 包含两个原字节头、依赖图、工具使用条件和新 manifest。

## 实际执行与原件

唯一封包子命令为 `python -B -X utf8 code/build/138k_pro_fourvoice_candidate_20261016/r06_public_chain_20261017/prepare_selected_sources_r06c6.py`；实际解释器绝对路径、argv/cwd、UTC、输入/Python SHA、双流和退出码在 `C6_RUN_ONCE_START.json` / `C6_RUN_RECEIPT.json`，原双流 `C6_stdout.raw` / `C6_stderr.raw`。exit 0，0.47308610001346096 秒，全部冻结输入/C5 文件前后同 SHA。封包器只运行一次；HDL/EDA/设备 0，不消费 M3 预算。

独立回读校验的首轮因我方脚本用 Windows 反斜杠 path 与 manifest 正斜杠 path 直接比较，产生两项假失败、exit 1；原报告 `C6_POSTCHECK.json` 保留。仅修改独立校验脚本的路径规范化与报告输出名后，第二次只读回读 exit 0，29 项全通过，见 `C6_POSTCHECK_REPAIR01.json`。没有修改 C6 产物，没有第二次封包。

## 产物身份

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| prepare_selected_sources_r06c6.py | 11276 | 2905a5210f1d05edaeb2516ba34e181daff5f330c174b63dc4ee28cf7d662e0a |
| SOURCE_LIST_R06C6.f | 2326 | df9f5f18af8d95ba3c7e4f609bf143c16e9f457a479fdfa02f96232557f829b4 |
| SOURCE_DECISION_R06C6.json | 26200 | 38b19a744e07572c45b8ab2eeb8cf08e5d2291ba6687f6e0d941b4a4f1992a4c |
| SOURCE_CLOSURE_R06C6.zip | 180266 | 155177a23ae724a1c8d9a0ca3480781d0b76ae62f5a95f59c65a15a96e0d70e4 |

ZIP 86 成员（85 载荷+manifest），CRC、manifest/body 大小/SHA、外置 JSON 与内置 manifest 全核同；71 唯一单元、九 ROM、两个头、73 唯一字面模块、三条 include 边。C5 除 compile.f 外的全部 82 载荷原字节保留；compile.f 仅前加 include 选项，C3 四源未变。DDS leaf 仍为 `303e3a99...cd3bd`，唯一共享 ROM 定义仍在 `sources/m1td_dds_oscillator.sv`。

## 使用条件与未验证项

解包后编译及运行 cwd 必须是 `inputs/`，source list 是其下 `compile.f`；include 搜索目录为 `include/`，ROM 相对路径为 `rom/<原文件名>`。list 的 `+incdir+include` 仅编码既定搜索语义；具体编译器是否接受此拼写 **NOT_TESTED**，工具适配器须在精确工具准入时核语法并保持 cwd、顺序和 include 目录语义，不能据此直接执行编译。

实际等级 **L0_STATIC_SOURCE_PACKAGE**：仅纯文件身份、路径、字面依赖和模块唯一性验证，不是 HDL 编译/预处理/elaboration/仿真、Pro 物理或板测通过。M1 真语义、R7-A 整机 TB、实际 ROM 参数覆盖及精确工具/执行器准入均待；`execution_admission=null`、`board_release_allowed=false`。
