open_project {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_m2td_endpoint_probe_20261015_r01/m2_fourvoice_timbre_delay_board_top.gprj}
set_option -top_module m2_fourvoice_timbre_delay_board_top
set_option -verilog_std sysv2017
set_option -place_option 0
set_option -route_option 2
set_option -ireg_in_iob 1
set_option -oreg_in_iob 1
set_option -ioreg_in_iob 1
set_option -correct_hold_violation 1
set_option -clock_route_order 0
set_option -route_maxfan 23
set_option -include_path {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_m2td_endpoint_probe_20261015_r01/inputs/include}
run all
