"""Recover the existing publish checkout without overwriting staged files."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
REPO = Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
RUN = ROOT / ('recover_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
RUN.mkdir()
argv = ['git', '-c', 'core.longpaths=true', '-c', 'http.proxy=',
        '-c', 'http.lowSpeedLimit=1', '-c', 'http.lowSpeedTime=20',
        'checkout-index', '--all']
env = dict(os.environ)
env.pop('GIT_NO_LAZY_FETCH', None)
env['GIT_TRACE'] = str(RUN / 'git_trace.log')
start = time.monotonic()
with (RUN / 'stdout.raw').open('wb') as out, (RUN / 'stderr.raw').open('wb') as err:
    proc = subprocess.Popen(argv, cwd=REPO, env=env, stdout=out, stderr=err)
    timed_out = False
    try:
        code = proc.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out = True
        stopped = subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
        (RUN / 'owned_stop.stdout.raw').write_bytes(stopped.stdout)
        (RUN / 'owned_stop.stderr.raw').write_bytes(stopped.stderr)
        code = proc.wait(timeout=10)
receipt = dict(argv=argv, cwd=str(REPO), exit_code=code, timed_out=timed_out,
               seconds=time.monotonic()-start, pid=proc.pid)
for name in ['stdout.raw', 'stderr.raw']:
    data = (RUN / name).read_bytes()
    receipt[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
(RUN / 'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(run=str(RUN), **receipt)), flush=True)
