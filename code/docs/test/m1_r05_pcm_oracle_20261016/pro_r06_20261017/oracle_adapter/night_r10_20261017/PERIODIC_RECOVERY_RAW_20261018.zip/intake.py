"""Bounded read-only intake of the current M2/M3 handoff."""
from pathlib import Path
import hashlib,json,subprocess,time

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
REF=subprocess.check_output(['git','rev-parse','origin/develop'],cwd=REPO).decode().strip()
FILES=[
 'code/docs/Pro基础无实物夜间总任务单_R10_2026-10-17.md',
 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/task_day4_completion_20261017/HANDOFF.json',
 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/task_day4_completion_20261017/FINAL_SELF_REVIEW.json',
 'code/docs/test/m3_pro_fourvoice_trace_20261016/pro_basis_r07_20261017/oracle_bundle_bridge/c9_completion_r01/README.md',
]
rows=[]
for i,name in enumerate(FILES):
    argv=['git','-c','core.longpaths=true','-c','http.proxy=','-c','http.lowSpeedLimit=1','-c','http.lowSpeedTime=20','show',REF+':'+name]
    t=time.monotonic()
    p=subprocess.run(argv,cwd=REPO,capture_output=True,timeout=40)
    run=ROOT/'runs'/str(i);run.mkdir(parents=True,exist_ok=True)
    (run/'stdout.raw').write_bytes(p.stdout);(run/'stderr.raw').write_bytes(p.stderr)
    r=dict(ref=REF,path=name,argv=argv,exit=p.returncode,seconds=time.monotonic()-t,
       stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest())
    rows.append(r)
    (run/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if p.returncode==0:
        dest=ROOT/'inputs'/REF/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.stdout)
    print(json.dumps(r,ensure_ascii=False),flush=True)
    if p.returncode:break
(ROOT/'INTAKE.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
