"""Persist the bounded GitHub intake and failed publication recovery."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parent
WORK = Path('D:/嵌赛/高云二/m1_r10_work_20261017')
REPO = Path('C:/Users/lc/.codex/visualizations/2026/10/14/01a138d3-c198-7b02-aba4-64f9e7960af9/q')
PUB = Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
REL = Path('code/docs/test/m1_r05_pcm_oracle_20261016/pro_r06_20261017/oracle_adapter/night_r10_20261017')
DOC = REPO / REL
REF = '358c16c2a927e3684c075dfc5ede70a6a67e036a'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
def both(name, data):
    for base in [REPO, PUB]: write(base/REL/name, data)

intake = json.loads((ROOT/'INTAKE.json').read_bytes())
assert len(intake)==4 and all(x['exit']==0 for x in intake)
recoveries = sorted(ROOT.glob('recover_*/receipt.json'))
assert len(recoveries)==2
raw_name = 'PERIODIC_RECOVERY_RAW_20261018.zip'
raw_path = DOC / raw_name
assert not raw_path.exists()
with zipfile.ZipFile(raw_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in [ROOT/'INTAKE.json', ROOT/'intake.py', ROOT/'recover_snapshot.py', Path(__file__)]:
        z.write(p, p.relative_to(ROOT).as_posix())
    for parent in [ROOT/'runs'] + [p.parent for p in recoveries]:
        for p in sorted(parent.rglob('*')):
            if p.is_file(): z.write(p, p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(raw_path) as z: assert z.testzip() is None
(PUB/REL/raw_name).write_bytes(raw_path.read_bytes())
receipt = dict(schema='M1_R10_GITHUB_CHECK_V1', checked_utc=datetime.now(timezone.utc).isoformat(),
    remote_commit=REF, source_receipts=intake,
    m3_handoff_id='M3-TASK-DAY4-C9-20261017-01',
    m3_handoff_status='METADATA_OBSERVED_NOT_ADDRESSED_TO_M1_NOT_FULL_PACKAGE_ACCEPTED',
    m3_claimed_result_commit='af25fa5e14d9c3a288e7d8a6a6d05f2f9cf75f95',
    findings=['Latest total R10 retains the same M1 task and existing consumed software budgets.',
      'M3 new handoff names M2 as consumer; its metadata does not supply an admitted real C9 job to M1.',
      'Bridge README describes a mechanical MATH_INPUT_BUNDLE, not actual real C9 acceptance evidence.',
      'No software, HDL, EDA or device tests were run during this periodic check.'],
    next_action='Await exact real C9 original artifacts and M2 admission; resume publication only after evidenced transport recovery.',
    raw_archive=dict(path=(REL/raw_name).as_posix(),bytes=raw_path.stat().st_size,sha256=sha(raw_path)),
    publication_recovery=[json.loads(p.read_bytes()) for p in recoveries],
    polling=dict(automation_id='m1-m2',state='CONFIGURED_ACTIVE_FIRST_SCHEDULED_WAKE_NOT_YET_VERIFIED',
      interval_minutes=30,target_thread='01a138d3-c198-7b02-aba4-64f9e7960af9',
      deadline_beijing='2026-10-18T03:55:00+08:00',
      deadline_basis='Conservative original START cap; unchanged by this check.'))
both('GITHUB_INTAKE_20261018.json',receipt)
outbox=json.loads((DOC/'OUTBOX.json').read_bytes())
outbox['previous_publication_blockers']=outbox['blockers']
outbox['blockers']=['Incomplete baseline checkout and remaining missing promisor objects.',
  'Recovery failed after 20.750 seconds on c911ecf9c83debc1a4030e8592d83110e34546de.',
  'One retry failed after 21.281 seconds on 754fed45d9263829b84075463e849268318520d2.']
outbox['latest_remote_observed']=REF
outbox['latest_check_receipt']=(REL/'GITHUB_INTAKE_20261018.json').as_posix()
outbox['recovered_prior_blocker']='e87beade8bbc8b28d3c8a3f25f7a92d2430bfaa4 now exists as a cached blob; full tree still unavailable.'
outbox['checkout_caution']='Failed checkout-index can create empty baseline files. Verify every tracked baseline file and restore exact blobs before gate; do not stage baseline deletions or empty files.'
outbox['polling']=receipt['polling']
outbox['recovery_attempts_this_check']=2
outbox['recovery_paused_until_new_transport_evidence']=True
both('OUTBOX.json',outbox)
handoff=json.loads((DOC/'HANDOFF.json').read_bytes())
handoff['blockers']=outbox['blockers']+['Actual original C9 math job and exact M2 admission still absent.']
handoff['latest_check_receipt']=outbox['latest_check_receipt']
both('HANDOFF.json',handoff)
paths=json.loads((WORK/'PUBLICATION_FILES.json').read_bytes())
paths+= [(REL/name).as_posix() for name in [raw_name,'GITHUB_INTAKE_20261018.json']]
assert len(paths)==len(set(paths))==40
write(WORK/'PUBLICATION_FILES.json',paths)
manifest=json.loads((DOC/'DELIVERY_MANIFEST.json').read_bytes())
excluded={'DELIVERY_MANIFEST.json','HANDOFF.json','OUTBOX.json'}
manifest['files']=[dict(path=p,bytes=(REPO/p).stat().st_size,sha256=sha(REPO/p))
  for p in sorted(paths) if Path(p).name not in excluded]
both('DELIVERY_MANIFEST.json',manifest)
handoff['manifest']['sha256']=sha(DOC/'DELIVERY_MANIFEST.json')
both('HANDOFF.json',handoff)
print(json.dumps(dict(files=len(paths),receipt='GITHUB_INTAKE_20261018.json',raw_sha256=sha(raw_path)),ensure_ascii=False))
