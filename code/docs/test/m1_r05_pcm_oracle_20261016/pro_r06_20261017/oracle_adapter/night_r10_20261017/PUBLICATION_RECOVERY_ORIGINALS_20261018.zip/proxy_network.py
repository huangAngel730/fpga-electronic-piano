"""Bounded native Git through the user's currently enabled local system proxy."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,subprocess,sys,threading,time

ROOT=Path(__file__).resolve().parent
PUB=Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
PROXY='http://127.0.0.1:26001'
GIT=['git','-c','core.longpaths=true','-c','http.proxy='+PROXY,'-c','http.version=HTTP/1.1',
     '-c','credential.interactive=false','-c','http.lowSpeedLimit=1','-c','http.lowSpeedTime=20']
def main():
    mode=sys.argv[1]
    progress_file=ROOT/('REMOTE_OBJECT_RECOVERY_PROGRESS.json' if mode=='remote_objects' else 'OBJECT_RECOVERY_PROGRESS.json')
    folder=ROOT/('proxy_'+mode+'_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    folder.mkdir()
    stdin=None
    if mode=='remote':argv=GIT+['ls-remote','--heads','origin','develop'];limit=30
    elif mode=='fetch':argv=GIT+['fetch','--no-tags','origin','develop'];limit=30
    elif mode in ('objects','remote_objects'):
        wanted=json.loads(progress_file.read_bytes())['remaining']
        count=int(sys.argv[2]);wanted=wanted[:count]
        assert wanted
        assert all(len(x)==40 and all(ch in '0123456789abcdef' for ch in x) for x in wanted)
        (folder/'wanted.txt').write_bytes((''.join(x+'\n' for x in wanted)).encode('ascii'))
        stdin=(folder/'wanted.txt').open('rb')
        argv=GIT+['-c','fetch.negotiationAlgorithm=noop','fetch','origin','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--filter=blob:none','--stdin'];limit=120
    elif mode=='push':argv=GIT+['push','--porcelain','--quiet','origin','HEAD:refs/heads/develop'];limit=30
    else:raise ValueError(mode)
    dependency=PUB/'code/software/t052_runner_acceptance_candidate_20261012/windows_job.py'
    dependency_sha=hashlib.sha256(dependency.read_bytes()).hexdigest()
    assert dependency_sha=='5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b'
    spec=importlib.util.spec_from_file_location('m1_pinned_network_job',dependency)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    job=module.WindowsJob()
    t=time.monotonic()
    env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None)
    with (folder/'stdout.raw').open('wb') as out,(folder/'stderr.raw').open('wb') as err:
        proc=subprocess.Popen(argv,cwd=PUB,env=env,stdin=stdin,stdout=out,stderr=err,creationflags=0x00000004|0x08000000)
        job.attach_and_resume(proc)
        watchdog=threading.Timer(limit-1,job.terminate);watchdog.daemon=True;watchdog.start()
        timed_out=False
        try:code=proc.wait(timeout=limit-2)
        except subprocess.TimeoutExpired:
            timed_out=True
            job.terminate()
            code=proc.wait(timeout=2)
        finally:
            watchdog.cancel()
            job.close()
    if stdin:stdin.close()
    rec=dict(argv=argv,cwd=str(PUB),job_dependency_sha256=dependency_sha,owned_job_closed=True,
      proxy_basis='Enabled HKCU Internet Settings ProxyServer read in this session; no persistent Git configuration modified.',
      exit_code=code,timed_out=timed_out,seconds=time.monotonic()-t,limit_seconds=limit,
      streams={name:dict(bytes=(folder/name).stat().st_size,sha256=hashlib.sha256((folder/name).read_bytes()).hexdigest()) for name in ['stdout.raw','stderr.raw']})
    (folder/'RESULT.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if mode in ('objects','remote_objects') and code==0:
        progress=json.loads(progress_file.read_bytes())
        remaining=progress['remaining']
        checked=subprocess.run(['git','--no-lazy-fetch','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],
          input=(''.join(x+'\n' for x in remaining)).encode('ascii'),cwd=PUB,env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),capture_output=True,timeout=15)
        assert checked.returncode==0
        still=[x.split()[0].decode() for x in checked.stdout.splitlines() if x.endswith(b' missing')]
        progress.update(remaining=still,recovered_count=progress['recovered_count']+len(remaining)-len(still))
        progress_file.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(remaining_objects=len(still),recovered_objects=progress['recovered_count'])),flush=True)
    print(json.dumps(dict(folder=str(folder),**rec),ensure_ascii=False),flush=True)
    for name in ['stdout.raw','stderr.raw']:print((folder/name).read_text(encoding='utf-8',errors='replace')[-2200:],flush=True)
    return code
if __name__=='__main__':raise SystemExit(main())
