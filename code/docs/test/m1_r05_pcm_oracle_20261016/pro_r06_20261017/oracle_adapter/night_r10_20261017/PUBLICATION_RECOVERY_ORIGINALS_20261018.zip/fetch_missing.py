"""Use native promisor fetch batches to recover missing baseline blobs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
PUB=Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
def main():
    audit=json.loads((ROOT/'RECOVERY_AUDIT.json').read_bytes())
    oids=sorted(audit['missing_objects'])
    start=int(sys.argv[1]);count=int(sys.argv[2])
    chosen=oids[start:start+count]
    assert chosen
    folder=ROOT/('fetch_blobs_%04d_%s'%(start,datetime.now(timezone.utc).strftime('%H%M%S')))
    folder.mkdir()
    raw=(''.join(x+'\n' for x in chosen)).encode('ascii')
    (folder/'wanted_oids.txt').write_bytes(raw)
    argv=['git','-c','core.longpaths=true','-c','http.proxy=','-c','http.lowSpeedLimit=1',
      '-c','http.lowSpeedTime=20','-c','http.version=HTTP/1.1',
      '-c','credential.interactive=false','-c','fetch.negotiationAlgorithm=noop',
      'fetch','origin','--no-tags','--no-write-fetch-head','--recurse-submodules=no',
      '--filter=blob:none','--stdin']
    env=dict(os.environ);env.pop('GIT_NO_LAZY_FETCH',None)
    t=time.monotonic()
    with (folder/'wanted_oids.txt').open('rb') as inp,(folder/'stdout.raw').open('wb') as out,(folder/'stderr.raw').open('wb') as err:
        p=subprocess.Popen(argv,cwd=PUB,env=env,stdin=inp,stdout=out,stderr=err)
        expired=False
        try:rc=p.wait(timeout=120)
        except subprocess.TimeoutExpired:
            expired=True
            stopped=subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True)
            (folder/'stop.stdout.raw').write_bytes(stopped.stdout);(folder/'stop.stderr.raw').write_bytes(stopped.stderr)
            rc=p.wait(timeout=10)
    r=dict(argv=argv,cwd=str(PUB),exit_code=rc,timeout=expired,seconds=time.monotonic()-t,requested=len(chosen),offset=start,
      stdout_sha256=hashlib.sha256((folder/'stdout.raw').read_bytes()).hexdigest(),
      stderr_sha256=hashlib.sha256((folder/'stderr.raw').read_bytes()).hexdigest())
    (folder/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(folder=str(folder),**r),ensure_ascii=False),flush=True)
    print((folder/'stderr.raw').read_text(encoding='utf-8',errors='replace')[-1500:],flush=True)
    return rc
if __name__=='__main__':raise SystemExit(main())
