"""Capture the unmodified repository gate on the complete publish tree."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes as c
from ctypes import wintypes as w
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
PUB=Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
PWSH=Path('C:/Users/lc/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
GIT=['git','--no-lazy-fetch','-c','core.longpaths=true']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(args):return subprocess.check_output(GIT+args,cwd=PUB,env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),timeout=30)
def main():
    label='gate_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    folder=ROOT/label;folder.mkdir()
    source=PUB/'code/scripts/check_repo.ps1'
    expected=git(['show',':code/scripts/check_repo.ps1'])
    assert source.read_bytes()==expected
    status=git(['status','--porcelain=v1','-z','--untracked-files=normal'])
    assert all(x[:2]==b'A ' for x in status.split(b'\0') if x)
    index=git(['ls-files','--stage','-z'])
    (folder/'index.before.raw').write_bytes(index)
    manifest=[]
    for record in index.rstrip(b'\0').split(b'\0'):
        meta,name=record.split(b'\t',1);mode,oid,stage=meta.decode().split()
        path=PUB/name.decode('utf-8');raw=path.read_bytes()
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid,name
        manifest.append(dict(path=name.decode('utf-8'),oid=oid,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    (folder/'TREE_BEFORE.json').write_text(json.dumps(dict(head=git(['rev-parse','HEAD']).decode().strip(),tree=git(['write-tree']).decode().strip(),files=manifest),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Reuse the already measured local CPU topology and retain native test limits.
    topo=json.loads((ROOT.parent/'publication_20261016_R02/ACTUAL_CPU_SET_TOPOLOGY.json').read_bytes())['rows']
    fastest=max(x['efficiency_class'] for x in topo);chosen={}
    for row in topo:
        if row['group']==0 and row['efficiency_class']==fastest:chosen.setdefault(row['core'],row['logical_processor'])
    mask=sum(1<<p for p in chosen.values())
    kernel=c.WinDLL('kernel32',use_last_error=True)
    kernel.GetCurrentProcess.restype=w.HANDLE
    kernel.SetProcessAffinityMask.argtypes=[w.HANDLE,c.c_size_t];kernel.SetProcessAffinityMask.restype=w.BOOL
    kernel.GetProcessAffinityMask.argtypes=[w.HANDLE,c.POINTER(c.c_size_t),c.POINTER(c.c_size_t)];kernel.GetProcessAffinityMask.restype=w.BOOL
    assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),mask),c.get_last_error()
    actual=c.c_size_t();system=c.c_size_t()
    assert kernel.GetProcessAffinityMask(kernel.GetCurrentProcess(),c.byref(actual),c.byref(system))
    assert actual.value==mask
    env=dict(os.environ,GOWIN_HOME='D:/嵌赛/SOFTWARE/Gowin/Gowin_V1.9.11.03_Education_x64',
      GOWIN_PROGRAMMER_HOME='D:/嵌赛/SOFTWARE/Gowin/Gowin_V1.9.11.03_Education_x64/Programmer',
      GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_NO_LAZY_FETCH='1')
    env['PATH']='E:/python3.10;'+env['PATH']
    argv=[str(PWSH),'-NoProfile','-ExecutionPolicy','Bypass','-File',str(source)]
    launch=dict(argv=argv,cwd=str(PUB),started_utc=datetime.now(timezone.utc).isoformat(),
      tool_sha256=sha(PWSH),gate_sha256=sha(source),timeout_seconds=1000,
      affinity_mask=hex(mask),scope='This capture process and descendants only; scripts and native time limits unchanged.')
    (folder/'LAUNCH.json').write_text(json.dumps(launch,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(folder=str(folder),launch=launch),ensure_ascii=False),flush=True)
    t=time.monotonic()
    with (folder/'stdout.raw').open('wb') as out,(folder/'stderr.raw').open('wb') as err:
        proc=subprocess.Popen(argv,cwd=PUB,env=env,stdout=out,stderr=err)
        expired=False
        try:code=proc.wait(timeout=1000)
        except subprocess.TimeoutExpired:
            expired=True
            stop=subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
            (folder/'stop.stdout.raw').write_bytes(stop.stdout);(folder/'stop.stderr.raw').write_bytes(stop.stderr)
            code=proc.wait(timeout=10)
    same_index=git(['ls-files','--stage','-z'])==index
    drift=[]
    for entry in manifest:
        path=PUB/entry['path']
        if not path.is_file() or path.stat().st_size!=entry['bytes'] or sha(path)!=entry['sha256']:drift.append(entry['path'])
    result=dict(**launch,exit_code=code,timed_out=expired,seconds=time.monotonic()-t,
      index_unchanged=same_index,tracked_drift=drift,
      streams={name:dict(bytes=(folder/name).stat().st_size,sha256=sha(folder/name)) for name in ['stdout.raw','stderr.raw']})
    (folder/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False),flush=True)
    assert same_index and not drift
    return code
if __name__=='__main__':raise SystemExit(main())
