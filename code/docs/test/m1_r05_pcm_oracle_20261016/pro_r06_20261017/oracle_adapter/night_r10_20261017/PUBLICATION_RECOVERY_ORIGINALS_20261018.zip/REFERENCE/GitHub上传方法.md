# GitHub上传方法

更新日期：2026-10-18。供本项目 M1／M2／M3 及各自 agent 转发使用。

本文整理的是本机已有源码和原始日志能够支持的做法。本文只是一份操作说明，不代替各自任务单的发布授权、写集、执行预算或 M2 复核。其他电脑应先核对自己的环境。

## 1. 先看这几个关键点

本机成功使用的组合是：**HTTPS 远端＋本机有效 HTTP 代理＋单次命令指定 HTTP/1.1＋真正有界的 Git 进程＋独立 Git 写调用＋发布后远端包含核验**。

遇到问题时，先分清三个层次：

| 层次 | 典型现象 | 应该处理什么 |
|---|---|---|
| 网络／代理 | 连接超时、连接重置、代理端口拒绝连接 | 核本机实际代理、协议及有界网络日志 |
| 认证／执行权限 | 401／403、Permission denied、自动审批拒绝 | 核账号权限或通过正式审批入口申请本次操作权限 |
| Git／协作 | non-fast-forward、推错分支、暂存混入他人文件 | 核本地提交、远端历史、写入归属及最终门禁 |

三类问题不能混在一起处理。尤其 `.git/FETCH_HEAD` 或 `.git/objects` 无法写入，通常不能靠换代理解决。

**不要一开始就反复 push、增加 http.postBuffer、关闭 SSL 校验、改全局配置或强推。**

## 2. 本机实际成功过什么

以下来自原有 `network.json` 和各次 `RESULT.json`，不是本次为了写说明重新推送的测试：

| 操作记录 ID | 北京时间 | Git 原始退出码 | 网络执行耗时 |
|---|---|---:|---:|
| drill_push | 2026-10-18 00:35:34 | 0 | 4.578 秒 |
| r10_source_push | 2026-10-18 01:01:59 | 0 | 5.203 秒 |
| r10_metadata_push | 2026-10-18 01:05:47 | 0 | 4.547 秒 |
| oct18_capture_source_push | 2026-10-18 01:35:23 | 0 | 3.547 秒 |
| oct18_capture_receipt_push | 2026-10-18 01:41:18 | 0 | 3.797 秒 |

本机也发生过失败：2026-10-18 07:25 左右，一次 fetch 原始退出码为 255，stderr 为：

```text
error: cannot open '.git/FETCH_HEAD': Permission denied
```

该次失败在写本地 Git 元数据时发生。随后通过系统正式审批入口，执行同一已授权的有界 fetch，退出 0。没有改 ACL、换仓库、换协议或强行绕过审批。

此前已发布交付的一个完整提交为：

```text
3202946161f6df6985effe7f2824c97cc4daf03f
```

它只是历史成功证据。**实际发布必须核验自己本轮的完整提交 SHA，不能拿上面这个旧提交代替。**

## 3. 本机参数，以及同学必须重新核对的参数

| 项目 | 本机已使用的值 | 转发后怎么处理 |
|---|---|---|
| 仓库 | https://github.com/huangAngel730/fpga-electronic-piano.git | 确认 origin 确实指向本项目 |
| 集成分支 | develop | 沿用项目规则，不随意改 main |
| Git | C:/Program Files/Git/cmd/git.exe | 核本机实际 Git 路径 |
| Python | C:/Users/songdongkuan/miniconda3/python.exe | 使用自己的已核解释器路径 |
| 代理 | http://127.0.0.1:7892 | 核自己代理客户端的 HTTP／Mixed 监听端口 |
| HTTP 版本 | HTTP/1.1 | 本机已验证的单次命令参数 |
| 凭据设置 | credential.interactive=false | 本机沿用设置；不提供凭据，效果取决于凭据助手 |
| 网络执行预算 | 单次目标不超过 30 秒 | 必须由实际执行器落实，不能只写在提示词里 |

### 3.1 127.0.0.1:7892 不是大家通用的代理地址

`127.0.0.1` 表示**执行命令的那台电脑自己**。同学电脑如果没有在 7892 端口运行代理，照抄就会失败。

先在自己已有、获准使用的代理客户端中确认 HTTP／Mixed 端口，以及它是否运行。只知道浏览器能上网，不足以证明 agent 的 Git 已走相同代理。

不要扫描一堆端口碰运气，也不要把另一台电脑的 WLAN 地址直接填成本机代理。跨机代理需要单独核网络和授权。

### 3.2 这里的代理参数针对 HTTPS 远端

先检查：

```powershell
git remote get-url origin
```

本机使用 `https://github.com/...`。如果对方实际是 `git@github.com:...`，那是 SSH；下面的 `http.proxy` 不能当作 SSH 代理配置使用。

使用现有 SSH 流程的同学，先核自己的密钥、SSH 客户端和网络。不要为绕过明确拒绝，擅自改远端或协议。

### 3.3 优先使用单次命令参数

本机网络 Git 的实际参数形式如下：

```powershell
git -c http.proxy=http://127.0.0.1:7892 -c http.version=HTTP/1.1 -c credential.interactive=false ls-remote --exit-code origin refs/heads/develop
```

这条命令只查询远端。代理地址按自己的实际环境替换；应交给自己已验证的有界执行入口运行。

`-c` 将配置用于这次 Git 调用，避免为了本次任务改动共享或全局配置。HTTP 代理和 HTTP/1.1 参数的含义见 [Git 官方配置说明](https://git-scm.com/docs/git-config)。

HTTP/1.1 是本机成功组合中的一项；本文没有证明所有人的超时都由 HTTP/2 导致。

## 4. 发布前先做这些只读检查

在自己真正的仓库根目录执行。下面每行都应独立调用，检查完输出再决定下一步：

```powershell
git status --short
```

```powershell
git diff --cached --name-only
```

```powershell
git branch --show-current
```

```powershell
git rev-parse HEAD
```

需要确认实际 Git 目录／worktree 位置时：

```powershell
git rev-parse --show-toplevel
```

```powershell
git rev-parse --git-dir
```

判定要点：

- 同一工作树／index 只有一个 Git 发布者。不要和正在工作的总控或其他窗口同时 add、commit、fetch、push。
- 先识别他人的脏文件、暂存和未发布提交；不是自己本轮的内容不能顺带发布。
- 不使用 `git add .` 或 `git add -A` 全量暂存。
- `git branch --show-current` 输出空白时，通常处于 detached HEAD；不要照抄 develop 分支的推送入口。
- 后续网络和提交操作都应在这个已确认的工作目录执行，不能靠“当前终端应该就在仓库里”推断。

## 5. 获取远端信息，不能一上来自动 pull

先使用有界入口查询 `refs/heads/develop`。需要读取新提交、检查祖先关系时，再 fetch。

本机 fetch 的实际 Git 参数为：

```powershell
git -c http.proxy=http://127.0.0.1:7892 -c http.version=HTTP/1.1 -c credential.interactive=false fetch origin
```

fetch 会写本地 Git 元数据，可能需要正式权限审批；它不等于把新源码合入工作树。

fetch 成功之后，分别查看：

```powershell
git rev-parse origin/develop
```

```powershell
git log --left-right --oneline HEAD...origin/develop
```

有差异时，在安全检查点按项目既有授权处理。**不要让 agent 为了“上传成功”自动 pull／rebase、覆盖脏修改、切换分支或复制一个新仓库规避问题。**

## 6. 本机现成的有界网络入口

### 6.1 已验证入口和依赖

以下是仓库根目录下的相对路径，Windows 环境使用：

```text
code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/night_drill_r01/network.py
```

本文读取到的该版本 SHA-256：

```text
add7a4195f70e8ad7dd23fb50b46892cda1d5d3a09edefd70794a145579016c5
```

依赖：

```text
code/software/t052_runner_acceptance_candidate_20261012/windows_job.py
```

依赖 SHA-256：

```text
5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b
```

两个文件均必须可取得并核同。不要把 network.py 单独复制到桌面运行：它按固定目录层级推导仓库根目录，并引用上述依赖。

该版本固定了本机 Git 路径、代理端口、origin/develop 和输出目录。**路径、代理、平台或分支不匹配时，不是原样通用脚本。** 在自己的授权范围内准备适配、核对源码和执行许可后再使用；不能改掉 SHA 检查来强行启动，也不能擅改已冻结原件。未完成验证的后继不能冒充本版本已实测。

### 6.2 命令示例

先确认自己的 Python 命令和版本：

```powershell
Get-Command python
```

```powershell
python --version
```

以下示例使用 PATH 中已核的 `python`，实际也可使用自己的解释器绝对路径。每条是单独一次工具调用，操作 ID 换成自己本次交付的唯一身份。

查询：

```powershell
python -B -X utf8 code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/night_drill_r01/network.py remote m2_delivery_20261018_unit01_remote
```

获取：

```powershell
python -B -X utf8 code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/night_drill_r01/network.py fetch m2_delivery_20261018_unit01_fetch
```

推送：仅在第 7 节的发布条件全部满足、本地 HEAD 位于 develop 且就是要发布的提交时使用。

```powershell
python -B -X utf8 code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/night_drill_r01/network.py push m2_delivery_20261018_unit01_push
```

**注意：该旧入口的 push 固定执行 `push origin develop`，不支持自动替换成 detached HEAD 推送。**

### 6.3 它怎样避免 Git 一直挂住

已核源码采用以下机制：

1. Git 子进程先以挂起、无控制台方式创建，加入本次专属 Windows Job Object 后再恢复运行。
2. 标准输出和错误分别写原始二进制文件，避免依赖聊天输出或大管道缓冲。
3. Git 正常等待预算约 28 秒。
4. 独立看门狗约 29 秒触发，终止本次自有 Job；Job 句柄关闭也会清理其进程树。
5. 保存 PID、原始退出码、耗时及状态；预算目标为网络执行阶段不超过 30 秒。解释器初始化、前置文件准备等耗时另计。

这不是给整个系统执行 `taskkill /IM git.exe`，不会为了结束自己的超时上传去杀其他窗口的 Git。

**工具的 yield_time_ms 不是上述硬超时。** 工具说“进程仍在运行／返回 session”也不等于失败或已取消。只在界面上等待 30 秒，或者只捕获一个超时异常，都不能证明子进程已结束。Python 对超时后进程清理的要求可查 [subprocess 官方说明](https://docs.python.org/3.12/library/subprocess.html)。

### 6.4 日志在哪里、看哪个退出码

相对于仓库根目录：

```text
code/output/m3_m2_night_drill_20261017/state/network.json
code/output/m3_m2_night_drill_20261017/runs/<operation_id>_01/LAUNCH.json
code/output/m3_m2_night_drill_20261017/runs/<operation_id>_01/RESULT.json
code/output/m3_m2_night_drill_20261017/runs/<operation_id>_01/stdout.bin
code/output/m3_m2_night_drill_20261017/runs/<operation_id>_01/stderr.bin
```

获准的一次重试使用同一 operation_id，对应 `_02` 目录，并须提供真实的 `--retry-basis`。不要换 ID 把同一失败当新任务重试。

先看 RESULT 中的 `exit_code`、`process_exit_code`、`status`、`elapsed_seconds`，再看 stderr 原文。有时外层 PowerShell 只显示退出 1，而内层 Git 原始退出码是 255；两层不能混写。

如果看门狗退出、只有 LAUNCH 而没有最终 RESULT，按结果未知保全原件，不能补写成功。

### 6.5 这个版本的边界必须说清

旧 network.py 的重试记录按 operation_id 保存；它本身不是完整的交付 outbox，也不能单独防止人为换 ID 后重复同一失败。

因此，发布者还必须维护自己的持久交付队列／故障账本，将完整成果 SHA、交接身份、重试消费和实际网络日志绑定。本文不把“已有网络入口”说成“整个双机协作机制已验收”。同一共享输出目录也不能由多个窗口同时改写。

## 7. 正常上传的完整顺序

以下不是一键脚本。**每个 Git 写命令各自独立调用，每次 add 只列一个明确文件。** 所有路径换成本轮实际获准文件。

### 第一步：核授权、并发修改和远端

按第 4、5 节检查。确认没有把他人的暂存、提交和大产物混进本轮。

本地位于 develop 时，再确认 HEAD 与本地 develop 引用一致：

```powershell
git rev-parse HEAD
```

```powershell
git rev-parse refs/heads/develop
```

### 第二步：只暂存本轮明确文件

例如，下面两条必须是两次独立调用：

```powershell
git add code/software/本轮授权目录/实际文件.py
```

```powershell
git add code/docs/test/本轮授权目录/实际报告.md
```

普通路径按本项目实测优先采用单文件 `git add 路径`。文件名可能被当作选项时仍需 `--`；不能把 `--` 本身认定成权限故障根因。

再分别检查：

```powershell
git diff --cached --name-only
```

```powershell
git diff --cached --check
```

```powershell
git diff --cached --stat
```

清单、内容、大小及所属任务都要核实。发现他人暂存时停止，不替对方撤销或代发。

### 第三步：跑最终待发布树的门禁

本项目要求：

```powershell
.\code\scripts\check_repo.ps1
```

必须实际九项全 PASS、退出 0，并留存原命令、双流、耗时及输入身份。源码／依赖／发布树变化后，旧树 PASS 不能直接覆盖新树。

门禁可能持续数分钟，**不是 Git 网络操作的 30 秒预算**；应使用项目已认可的门禁运行环境和有界入口。它包括仓库基线回归，不等于本轮新 C9／Pro 真链、EDA 或板测通过。

本机确实用过自己安装的 PowerShell 7、Python 和 FPGA 环境；其绝对路径不适合另一台电脑照抄。不要通过关闭门禁、改检查项或重用旧 PASS 来解决环境缺件。

### 第四步：形成自己的提交

```powershell
git commit -m "Describe the completed authorized delivery"
```

随后单独记录完整提交 SHA：

```powershell
git rev-parse HEAD
```

如需 V／D／T 正式编号，按项目规则：最后一次成功 fetch 后才取号；编号与功能提交分开，只在自己有共享文件写权限时登记。

### 第五步：保存待发送队列，再普通推送

正式发送前额外用有界入口核对远端，按需成功 fetch。若远端已经推进，先核差异；需要同步时回到安全工作点，只按已有授权处理。同步改变源码、依赖或最终待发布树后，必须重核对应验证和最终门禁，不能拿同步前的 PASS 直接推送。正式编号仍在最后一次成功 fetch 之后处理。

在自己任务单允许的位置持久记录至少这些字段：

```json
{
  "handoff_id": "REPLACE_WITH_THIS_DELIVERY_ID",
  "producer": "M2",
  "consumer": "REPLACE_WITH_REAL_CONSUMER",
  "result_commit": "REPLACE_WITH_FULL_40_HEX_COMMIT",
  "remote": "origin",
  "branch": "develop",
  "state": "PUSH_PENDING",
  "retry_used": 0,
  "gate": {"status": "FILL_ACTUAL_RESULT", "exit_code": null},
  "manifest": [],
  "attempts": []
}
```

这是字段模板，不是已通过的回执。填写自己的真实 manifest、原件 SHA、门禁树和日志；保存成功后才能开始本次发送。

本地 develop 的实际 Git 推送参数为：

```powershell
git -c http.proxy=http://127.0.0.1:7892 -c http.version=HTTP/1.1 -c credential.interactive=false push --porcelain --quiet origin develop
```

同样应由已授权、有界的执行器运行。不要将 Git push 和后面的检查拼进一条复合 shell 调用。

如果是真实 detached HEAD worktree，本项目 Git 规范允许唯一发布者在满足同样门禁和权限条件时显式指定：

```powershell
git -c http.proxy=http://127.0.0.1:7892 -c http.version=HTTP/1.1 -c credential.interactive=false push --porcelain --quiet origin HEAD:refs/heads/develop
```

这条是另一种明确目标的推送参数；**上面的旧 network.py 不提供这种模式**。须由该工作树自己的已授权有界入口执行，不能为了套旧脚本而切换分支、改别人的 develop 或绕过拒绝。

### 第六步：推完必须重新核远端

先有界查询远端，再成功 fetch。随后单独运行：

```powershell
git merge-base --is-ancestor YOUR_FULL_DELIVERY_COMMIT_SHA origin/develop
```

将占位内容换成刚才记录的完整 40 位提交。

- 退出 0：本次已获取的远端历史包含你的成果提交。
- 退出 1：该远端历史不包含它。
- 其他非零：核验本身出错，不能当作已经上传。

这是 Git 官方定义的判据，见 [git-merge-base](https://git-scm.com/docs/git-merge-base)。

队友在你之后又追加提交，远端 tip 可以与自己的 SHA 不同；只要祖先关系核同即可。反过来，单纯看到本地 `git log`、网页旧文件、`Everything up-to-date` 或某个远端 SHA，都不足以证明本轮成果已交付。

核同后更新自己的 outbox 为 REMOTE_VERIFIED，并保留远端 SHA、时间和实际退出码。RECEIVED／ACCEPTED／INTEGRATED 分别由接收、验收和集成事实支持，不能替接收方代签。

## 8. agent 显示权限不足时怎么处理

本项目有一个已实测的坑：把 Git 写入与检查、分号或管道放在同一条 PowerShell 命令里，可能无法命中执行规则，最终留在只读 Git 元数据的沙盒。

不要这样组织一次工具调用：

```text
git add file1 file2; git diff --cached; git commit ...; git push ...
```

应拆成独立工具调用：一次单文件 add；一次检查；一次 commit；一次 push。工作目录通过工具自己的 workdir 字段指定。

拆开后仍报 `.git/FETCH_HEAD` 或 `.git/objects` Permission denied 时，先核实际运行环境、命令形态和 Git 目录；在系统提供的**正式审批入口**申请这次已授权操作需要的权限。用户已经授权上传，和工具进程实际获得文件／网络权限，是两件事。

对提供 exec_command 参数的 agent，可采用如下调用形态；这是说明，不能代替真实授权：

```json
{
  "cmd": "git add code/docs/test/OWN_ALLOWED_DIRECTORY/OWN_FILE.md",
  "workdir": "YOUR_ACTUAL_REPOSITORY_ROOT",
  "sandbox_permissions": "require_escalated",
  "justification": "用户已授权发布本任务，只暂存指定文件；请求写入本工作树 Git 元数据所需权限。",
  "prefix_rule": ["git"]
}
```

只有当前客户端确实支持这些参数时才使用。正式审批若明确拒绝，就保存原文并停止依赖操作；不能换工具、改 ACL、复制仓库、改协议或提升系统权限绕过。也不要把 Windows 管理员权限与 agent 沙盒权限混为一谈。

## 9. 常见报错的分流处理

| 报错／现象 | 判断和下一步 |
|---|---|
| 连接 GitHub 超时／connection reset | 看原 stderr，核本机已批准的代理和 HTTPS 路径；临时故障最多一次有依据重试 |
| 连接 127.0.0.1:7892 被拒绝 | 本机代理服务、端口或配置不匹配；不能不断换端口盲试 |
| 401／403／Authentication failed／publickey | 认证或仓库权限；由账号持有人按既有凭据流程处理。参数不能凭空产生权限，勿发密码／token给聊天 |
| cannot open .git/FETCH_HEAD／objects Permission denied | 本地 Git 元数据权限；独立命令、正确工作目录、正式审批 |
| non-fast-forward | 远端已推进；fetch 后核双方提交，在安全点按既有授权处理冲突，再验最终树；不强推 |
| Everything up-to-date 但新文件没出现 | 核是否未暂存／未提交、是否推错分支、HEAD 是否等于本地 develop、是否查看了错误仓库或分支 |
| 大文件或服务端规则拒绝 | 保存服务端原文，按任务单已批准的交付方式处理；不要盲改历史或靠调大缓冲掩盖原因 |
| push 超时，结果不明 | 先查询＋fetch＋完整提交祖先核验；已包含则不再推，无法查询则保留 UNKNOWN |
| 工具已返回 session，任务还在跑 | 先查看原执行会话和日志，不再启动第二个 push |
| .git/index.lock 已存在 | 先查已有 Git 发布者／进程。不要未经归属确认就删锁或杀所有 Git |
| 自动审批明确拒绝 | 记录具体被拒动作和理由，停止依赖操作，等所需授权／权限解决 |

同一临时故障最多重试一次。后续恢复必须有任务单允许的新依据；半小时唤醒、换 operation_id、换聊天或新建 Goal 都不能清零次数。

## 10. 给同学 agent 的可转发指令

下面一段可在同学已授权上传其本轮交付后转发给自己的 agent：

> 请先阅读本项目现行 AGENTS.md、Git协作规范和本人最新任务单，只发布我已授权且已达到交接条件的文件。先核工作树、暂存、未发布提交及唯一发布者，保留他人修改。核本机实际 HTTPS 远端、Python／Git 路径、凭据和已批准代理端口，不能照抄另一台电脑的127.0.0.1:7892。可参考GitHub上传方法中的单次http.proxy、HTTP/1.1和本机已验证有界入口；Git网络操作落实真实时限，不把工具yield当作取消。git add每次一文件，add／commit／push各自独立调用，必要权限通过当前客户端正式审批入口申请。最终待发布树实际九项门禁全PASS后普通推develop，detached worktree按既有规范明确HEAD目标，禁止force。发布前保存持久outbox和完整成果SHA。临时故障最多一次有依据重试；结果不明先核远端，不换ID恢复次数，不绕过明确拒绝。成功fetch后，以git merge-base --is-ancestor完整SHA origin/develop的真实退出码核验交付，回传完整SHA、命令、双流、门禁、失败史、消费及待接收状态。不顺带重跑业务或扩大工具许可。

如果 agent 仍失败，请让它一次提供以下信息，而不是只说“超时”：

1. 仓库路径、远端仓库／分支和实际完整成果 SHA。
2. 原命令、cwd、使用的 Git／Python／代理地址（隐去任何凭据）。
3. 外层工具退出码、原始 Git 退出码、实际耗时及 stderr 原文。
4. 门禁是否实际通过、失败次数、是否还存在运行中的旧上传。
5. 系统审批是通过、待批还是明确拒绝。
6. 远端祖先核验结果；无法核验就明确 UNKNOWN。

## 11. 本文依据与使用边界

本文编写时只读取了现有脚本、协作规范和历史日志；没有为演示重新 add／commit／push，没有修改代理、凭据、权限、自动化或主任务源码，也没有要求其他窗口执行任何动作。

本机证据入口（仓库内相对路径）：

- `AGENTS.md`
- `code/docs/Git协作规范.md`
- `code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/coordinator/night_r10_20261017/night_drill_r01/network.py`
- `code/software/t052_runner_acceptance_candidate_20261012/windows_job.py`
- `code/output/m3_m2_night_drill_20261017/state/network.json`
- `code/output/m3_m2_night_drill_20261017/runs/<operation_id>_<attempt>/`

output 日志通常被 Git 忽略；另一台电脑不能因为知道这些路径就声称已取到原件。需要跨机复核时，使用对应交付已经公开、可访问的原件包与 manifest，或按任务单交接。

官方参数说明：

- [Git 配置：代理、HTTP 协议等](https://git-scm.com/docs/git-config)
- [Git：祖先关系与退出码](https://git-scm.com/docs/git-merge-base)
- [Python 3.12：子进程等待、超时与清理](https://docs.python.org/3.12/library/subprocess.html)
