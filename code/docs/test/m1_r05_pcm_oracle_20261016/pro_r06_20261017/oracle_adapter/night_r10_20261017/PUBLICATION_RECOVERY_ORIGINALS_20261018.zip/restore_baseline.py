"""Restore only audited missing/truncated baseline files from native Git blobs."""
from pathlib import Path
from datetime import datetime,timezone
import collections,hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
PUB=Path('D:/嵌赛/高云二/m1_r10_publish_20261017')
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
GIT=['git','--no-lazy-fetch','-c','core.longpaths=true']
def call(args,raw=None,timeout=90):
    p=subprocess.run(GIT+args,cwd=PUB,env=ENV,input=raw,capture_output=True,timeout=timeout)
    if p.returncode:raise RuntimeError(p.stderr.decode('utf-8',errors='replace'))
    return p.stdout
def oid(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def main():
    audit=json.loads((ROOT/'RECOVERY_AUDIT.json').read_bytes())
    items=audit['absent']+audit['wrong']
    assert len(items)==3037
    assert not set(x['path'] for x in items)&set(audit['payload_files'])
    wanted=sorted(set(x['oid'] for x in items))
    check=call(['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],(''.join(x+'\n' for x in wanted)).encode())
    missing=[x.split()[0].decode() for x in check.splitlines() if x.endswith(b' missing')]
    if missing:
        (ROOT/'REMAINING_MISSING_OIDS.json').write_text(json.dumps(missing,indent=2)+'\n',encoding='ascii')
        print(json.dumps(dict(status='WAITING_OBJECTS',missing=len(missing))),flush=True)
        return 3
    group=collections.defaultdict(list)
    for x in items:group[x['oid']].append(x)
    restored=[];unchanged=[]
    t=time.monotonic()
    for start in range(0,len(wanted),64):
        batch=wanted[start:start+64]
        result=call(['cat-file','--batch'],(''.join(x+'\n' for x in batch)).encode())
        pos=0
        for expected in batch:
            end=result.index(b'\n',pos)
            got,kind,size=result[pos:end].decode('ascii').split()
            assert got==expected and kind=='blob'
            pos=end+1;n=int(size);data=result[pos:pos+n];pos+=n
            assert result[pos:pos+1]==b'\n';pos+=1
            assert oid(data)==expected
            for item in group[expected]:
                path=PUB/item['path']
                resolved=path.resolve()
                assert resolved.is_relative_to(PUB.resolve())
                if path.exists():
                    current=path.read_bytes()
                    if oid(current)==expected:
                        unchanged.append(item['path']);continue
                    assert item in audit['wrong'] and len(current)==0,item['path']
                path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(data)
                restored.append(dict(path=item['path'],bytes=len(data),oid=expected))
        assert pos==len(result)
        print(json.dumps(dict(processed_oids=min(start+64,len(wanted)),total_oids=len(wanted),restored_files=len(restored))),flush=True)
    rec=dict(schema='M1_R10_BASELINE_RESTORATION_V1',completed_utc=datetime.now(timezone.utc).isoformat(),
      seconds=time.monotonic()-t,restored=restored,already_exact=unchanged,index_modified=False)
    (ROOT/'BASELINE_RESTORATION.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    status=call(['status','--porcelain=v1','-z','--untracked-files=normal'])
    rows=[x for x in status.split(b'\0') if x]
    assert len(rows)==len(audit['payload_files']) and all(x[:2]==b'A ' for x in rows)
    tree=call(['write-tree']).decode().strip()
    print(json.dumps(dict(status='BASELINE_RESTORED',restored=len(restored),already_exact=len(unchanged),tree=tree)),flush=True)
    return 0
if __name__=='__main__':raise SystemExit(main())
