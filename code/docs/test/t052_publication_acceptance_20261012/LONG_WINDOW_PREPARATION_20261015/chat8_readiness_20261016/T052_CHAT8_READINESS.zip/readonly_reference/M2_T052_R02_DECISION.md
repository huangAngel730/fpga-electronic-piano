# M2：T052 长窗 R02 静态补件及执行决定（2026-10-16）

## 核验对象及证据

仅核本次 `874c097d34140b120d52eaadd9748dd6ae8d5894` 中三个 `long_window_preparation_20261015` 新目录，排除同一提交内其它软件任务。用户附 `T052_LONG_RUNNER_R02.zip` 1085022 字节／SHA-256 `3776ea3d85f09099e7b33f5705d79300c4475697b5a0f1cfaed3dcfd603d54ee`；共 983 项（982 清单成员＋manifest），无重名，CRC/长度/SHA 全核同。TB SHA `daf67848153214d791d1f51e348dbbe7c7995c06424f0a819a23080c1fba3e20`、runner SHA `f55d19ac0584b8e483c7a7299c841b804ba1ebbe261c06194af33c12e6d5e10b`。外部 `LOCKED_RUNNER_R02_PROPOSAL.json` SHA `2a05f0fdff73b4f65c8c7898535b12369055fccdb36f21e1fe0eea756d8611f9`、`RUNNER_R02.md` SHA `ecd4e9ccabe04e146cd453401d0376cedbec5a0b468c30ca0508923d06d798e0`，均与包内同字节。原 R01 控制输入 SHA `fd220e83da98c03f0181c0a45e4edfa2ddc77adda055911508e7f7469131d4d0`，冻结源/ROM与旧捕获原件未改。

7 项首沿**纯软件/源码绑定检查**原记录 PASS、exit0：`$time>0` 排除 t0 X→0 错读，设计期望首正沿10ns row0、20ns 才读 row1；这是静态调度证明，不是新 TB 的真实编译/仿真。runner 假进程最终**29 项软件用例** PASS/exit0（包含正例、负例）；早轮24例两项FAIL及后续改动和原流保留，不能回填旧失败。Windows Job 挂起创建、入组后恢复，按步独占消费标记、六流/文件 SHA 与拒收收据设计已有软件证据；真实 Icarus/VVP 没有执行。所附 `REPOSITORY_GATE_RUNNER_R02_MERGED.zip` 1070字节／SHA `d229417aca7bddb6ded16f0639fefc0a8b2bfcf438ddccdac50c0d31a3adbf69` 的三条目CRC正常，stdout记9/9 PASS、exit0；该收据未绑定最终提交树 SHA，三个不同名字的门禁包也不能自动解释为三次独立运行。本轮 M2 对当前精确树另跑九门禁再登记。

**签收等级仅 L0 源/输入/配置静态核验＋软件用例通过。**按仓库验收等级 L1 需 HDL lint/编译；本次新 T052 编译/采集均为0，旧4207发布完整性 UNKNOWN，完整 T052 PARTIAL。实际捕获 `check_capture.py` exit3 的 `PROVENANCE_NOT_VERIFIED` 不能变成 PASS；M1确认的隔离50MHz/1042拍输入不是138K/40MHz四音整机功能。

## 决策：动态限额语义接受，真实一次执行当前不批准

- 对本次若未来获精确批准的隔离尝试，**接受** 50 ms 轮询＋Windows Job 整树终止作为 750 MiB 捕获／1200 MiB 总输出的**动态拒收阈值**，stdout/stderr各16 MiB有界写入；允许轮询期间瞬时超量。它不是 NTFS 硬配额、没有已证最大超量字节界，启动前≥2 GiB空闲也不是预留磁盘。任一步越线、磁盘不足或不完整文件均判失败/不完整，保留原件，不能写“任何时刻严格≤阈值”。
- 90/300/300 秒和从输出占用起算的900秒视为 runner 监督/调度预算；创建进程、扫描、杀树收尾至多另等2秒及后置哈希/写最终收据不能伪称被整个900秒硬截断。断电/OS强杀没有最终收据就只能标 INCOMPLETE。runner 只在精确状态时输出 `RAW_ATTEMPT_FINISHED_PENDING_M2_PROVENANCE_REVIEW`，仍非真实 T052 签收。
- `LOCKED_RUNNER_R02_PROPOSAL.json` 仍 `approved=false`，绑定 `LAPTOP-KSS1MRR7`、E盘准备输入/输出与额度目录、特定Python和Icarus/VVP；本M2机器不能核其执行机实时存在性/版本/环境。真实 Job 继承的环境与工具版本预检使用的显式PATH/IVERILOG_ROOT须在执行机核同，动态加载DLL仍UNKNOWN。**本轮不签 `approved=true`，不启动一次 compile/run/check，也不消费旧128沿/T060预算**。下一次 M2 只有收到执行机当时的输入、TB/runner/checker、工具与环境完整SHA、唯一未占用额度目录/输出、≥2GiB空闲及写得出独立拒收收据的证据，再针对唯一组合签一次许可；不通过仅把 proposal布尔位翻转来自签。
- 若在那次有界尝试中发现纯 runner/路径预检错误，原消费标记及首失败保留；新身份/目录或预算须另审，不自动换工具/提高上限/缩窗。基础四音R05与同版上板仍为项目关键路径；不为夜间填满8小时而先跑耗时长窗，也不重跑已签T052 128沿/T060。两个实际可编译RTL行为反例和声音数学/active/clip仍待另定范围。

M3可在授权新隔离目录**自主修软件假进程缺陷和封存回执**、通过全仓门禁正常推送；D025下M2负责推后最终复核。下一次真实采集许可属于单独精确组合，不等于要求M3软件阶段等待M2每步回复。本决定不修改旧 JSONL、正式top/约束或设备，不授权实物操作。反馈待用户转发 M3，尚未送达。
