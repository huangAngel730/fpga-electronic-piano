# M1 → M3：T052 长窗输入与事务确认 R01

2026-10-15；计划版本 `T052_LONG_50M1042_FROZEN_FCW_R01`。本回复确认 M1 的输入及验收语义，供 M3 准备精确输入与工具材料、交 M2 决定是否采集。**不是新编译或 RTL 运行许可。** 实际等级仅 L0 文档与源码静态核对；未提交、未推送。

## 1. 基线及频率决定

保持冻结 FCW，lane 顺序为 `04B17E4D / 0962FC9A / 12C5F935 / 258BF26A`，不提出新的非倍频版本，不追认旧 capture。此选择只适用于 **T052 v5 / 50 MHz 隔离测试源**，不覆盖另一个 R04 / 138K / 40 MHz 基础整机声音合同中的非倍频输入。

| lane | FCW | 逻辑 Fs=48000 时 Hz | 理想 50MHz/1042 时 Hz |
|---|---|---:|---:|
| 0 | 04B17E4D | 880.000021 | 879.718511 |
| 1 | 0962FC9A | 1760.000043 | 1759.437023 |
| 2 | 12C5F935 | 3520.000096 | 3518.874057 |
| 3 | 258BF26A | 7040.000193 | 7037.748113 |

按 `f=FCW×Fs/2^32` 换算。四路接近八度倍频，现场计划与新长窗均包含四次逐路独奏及一次四路合奏；不能只凭合奏 FFT 上四个峰认定四个振荡器。现场还需独奏定位、四路实际贡献、纯正弦 RTL 通路与同版采集证据。现场频率按实测 Fs 换算，不把理想时钟或 WAV 容器 48000 当实测采样率。本计划不包含设备操作。

冻结依赖身份来自 `code/docs/test/t052_publication_acceptance_20261012/CONTROL_PREPARATION_20261012/source_manifest.json`；本机只读基线 HEAD 为 `0007db7fad1fbf35d67dd4d9a1f5ede6c46e1b23`。

| 对象 | SHA-256 |
|---|---|
| v5 `t052_polyphony_test_source.sv` | `89ddb8b73bda6e5c83c7b617640cddf3294fb194a9b7955746c28a2e0f2eddeb` |
| `dds_oscillator.sv` | `3cd758e28da8f76a30da38cb2dfcd458db5743d4ea4f38e072a43d7f83719f04` |
| `pcm_mixer_4voice.sv` | `93fb6e88e55ea84f2e322b0cf8b94a1a2c2e13618e302e7d24ec8657c92bb99a` |
| `sine_1024_8192.mem` | `5e1dbd3797f353686f5e567831b56d6dcf9bee55c423097b471ade93203e84b2` |

前三份源及 ROM 的归档精确成员已只读重算 SHA，符合 manifest。DUT 从 manifest 指定 `RAW_EVIDENCE.zip` 成员取，另外三项从 `READONLY_T052_DEPENDENCIES.zip` 成员取；不以工作树同名文件替代。源、ROM、旧模型和旧日志不改。

## 2. 同意的判据与必要补充

同意输入计划独立、逐 posedge 记录完整控制、按冻结 FSM 独立推导 ready/accept/valid/ID、三元身份、真实控制取消及 END 全事务闭合。补齐以下限定后作为本版合同：

1. **观察相位**：cycle c 的输入在此前 negedge 稳定，正沿 PRE-NBA 读取。独立计划、公开端口实际输入、公开输出及发布轨迹互相比对。期望不得由实际 `calc_ready/result_valid`、输出个数或缺失名单生成。
2. **期望能力** `ready_expected=(state_expected==IDLE)`；真接受 `rst_n && !frame_tick && !cancel && sample_req && ready_expected`。DUT `calc_ready` 只参与逐沿比较，不决定黄金账本；frame/cancel 沿 ready 能力仍可为 1，但不能接受。
3. **发布必须含控制门控**：实际候选为 `rst_n && !frame_tick && !cancel && result_valid_PRE && result_ready_PRE`。同沿 reset/frame/cancel 优先，旧 valid 与 ready 即使均为 1 也不算发布。独立应发布集合先由计划和 FSM 计算，再与真实候选逐项比较，不能只检查日志中已有的发布。
4. **冻结日历**：接受 c；CALC 在 c+1；HOLD 首次注册 valid 在 c+2 沿后；首次 PRE-NBA valid 和最早消费均在 c+3。握手沿后回 IDLE，最早下一接受 c+4；不允许同一消费沿直接重接。ID 在无效期可能保留旧值，只有 reset/frame/cancel 清 0，不能要求正常消费后立即清 ID。
5. **身份** `[reset_epoch, accept_serial, req_id]` 只作软件关联，不新增 RTL 端口。初始化低复位对应 epoch 1；以后每次实际高→低断言开新 epoch，持续低不重复计；各 epoch 的 serial 从 1 开始，仅按独立真接受递增。32 位 req_id 可重复、可回绕，不承担唯一性。
6. **取消**只终结当时仍开放的一笔接受；frame/cancel/reset 没有开放事务时不凭空增加取消。已发布事务不能事后改判取消。同沿 frame+cancel 只取消一次，可并列原因。取消保留此前四路 DDS 的实际接受推进，reset 才清相位；enable/mask 不能阻止接受或 DDS 推进。
7. **异步复位**另记实际 rst_n 断言/释放的仿真时间与下一可见 cycle，不能仅靠 posedge rst_n。驱动不插入计划外窄脉冲；每次事件与计划相符。reset 断言即终结旧开放事务，不能等到下一个 posedge 另记第二次取消。初始 X→0 单独作为初始化证据，不误计为额外寿命。
8. **闭合**逐笔恰好一次发布或明确取消，`A=P+C` 且 open=0；无重复、取消后发布、错 ID、错 serial、跨 epoch 或额外事务。缺沿、缺 END、复位来源不全或开放事务不能 PASS；证据不足维持 UNKNOWN，可证明的矛盾判 FAIL。END 计数来自独立计划，不信任 capture 自报。

复用已有冻结合同 `code/docs/test/t052_publication_acceptance_20261012/CONTRACT.md` 及 `CONTROL_PREPARATION_20261012/CONTROL_CONTRACT.md` 的 PRE-NBA/取消定义。本文件只给新输入及 M1 语义，不实现或改写 M3 checker、runner、observer。

## 3. 精确调度：公共规则

时钟周期 20ns（50MHz）；cycle 0 的 posedge 为 10ns，cycle c 为 `10+20c ns`。cycle 0 输入在初始化时给定；其后所有控制仅在上一 negedge 设置，复位也遵守此时间表。唯一窗口为 **cycle 0…8,536,335（含端点），共 8,536,336 个 posedge**；最后一沿观察完成后至少留 1ns 再 END/finish，不追加功能沿。仿真被观察的末沿时间为 170,726,710ns。

除下述覆盖项外，默认 `rst_n=1, frame_tick=0, cancel=0, sample_req=0, req_id=0, enable=1, mask=F, result_ready=1`；四 FCW 始终保持第 1 节值。区间两端均包含。任何未列出的 posedge 都必须存在完整输入/输出行，不能用稀疏请求日志替代。

## 4. 前置事务段：cycle 0…255

rst_n 仅在 `0…3` 和 `128…131` 为 0；其余为 1。实际复位释放分别在 cycle 4、132 前 negedge。除初始断言外唯一后续断言在 cycle 128 前 negedge：该时刻取消 124 接受且仍 HOLD 的事务，开启 epoch 2。此段默认 enable=1、mask=F，除下表三项静音接受。

接受刺激表（sample_req=1；除列明项外其他控制用默认值）：

| cycle | req_id（32位十六进制） | 额外输入 | 独立静态预期归宿 |
|---:|---|---|---|
| 4 | FFFFFFFE | — | 7 发布 |
| 8 | FFFFFFFF | — | 11 发布 |
| 12 | 00000000 | — | 15 发布（ID 回绕） |
| 16 | 00000000 | ready 在 16…23 为 0 | 24 发布（重复 ID） |
| 25 | 00000000 | — | 26 cancel |
| 27 | 00000001 | — | 29 frame（首次 HOLD 注册前） |
| 30 | 00000002 | — | 33 cancel（原本 valid&&ready 同沿） |
| 34 | 00000003 | ready 在 34…40 为 0 | 41 frame（背压后释放同沿） |
| 42 | 00000004 | — | 43 frame+cancel，只取消一次 |
| 46 | 00000005 | enable=0, mask=F | 49 发布静音，仍算接受/发布 |
| 50 | 00000006 | enable=1, mask=0 | 53 发布静音 |
| 54 | 00000007 | enable=0, mask=0 | 57 发布静音 |
| 58 | 00000008 | — | 61 发布 |
| 124 | A5A5A5A5 | ready 在 124…127 为 0 | cycle 128 前异步 reset 取消 |
| 132 | A5A5A5A5 | — | 135 发布，属于新 epoch |

额外无接受刺激，均 sample_req=1、req_id=DEADBEEF、enable=1、mask=F：

- cycle `5,6,7`：仅忙状态请求；7 同时消费旧结果，仍不接受此请求。
- cycle `26,33,45`：cancel=1；cycle `29,41,44`：frame_tick=1；cycle `43`：frame_tick=cancel=1。这些控制沿均不接受，不重复计算取消。

以上列表给全此段 sample_req=1 的所有沿；其他沿 sample_req=0。frame/cancel 也只在上列沿为 1。ready=0 仅上述三个区间，其余含取消沿均为 1；enable/mask 特例仅作用在表列请求沿，其余恢复默认。cycle 136…255 空闲，不再发请求或控制脉冲。

静态手算：此段 A=15、P=9、C=6，末尾 open=0；epoch 1 接受 14 笔，epoch 2 在 132 接受 serial=1。计数仅是计划预期，**不是 RTL PASS**。复位、背压、同沿优先、重复/回绕是新长窗自身的定位用输入，不重跑旧 128 沿或旧专项入口。

## 5. 连续声音段：8192 帧

全局 frame index `j=0…8191`，帧首 `F(j)=256+1042j`，该帧占 `F…F+1041`。

| j 区间 | enable | mask | 本段预期正常发布样本 |
|---|---:|---|---:|
| 0…1023 | 1 | 1（lane0 独奏） | 1024 |
| 1024…2047 | 1 | 2（lane1 独奏） | 1024 |
| 2048…3071 | 1 | 4（lane2 独奏） | 1024 |
| 3072…4095 | 1 | 8（lane3 独奏） | 1024 |
| 4096…8191 | 1 | F（四路合奏） | 4096 |

本段覆盖公共默认值：rst_n=1、cancel=0；上述 enable/mask 在整帧稳定，FCW 不变；req_id 在整帧稳定为 `(FFFFFFF0 + floor(j/2)) mod 2^32`（相邻帧重复，j=32 时回绕到 0）。

- 每帧仅 offset 0 为 frame_tick=1；offset 1 为 sample_req=1。若 `j mod 64=0`，offset 2、3、4 也令 sample_req=1（这些沿忙，不能再接受）；其余 offset 的 sample_req=0。
- 若 `j mod 64=0`，offset 0…31 的 result_ready=0，32…1041 为 1；其余帧 result_ready 始终 1。固定调度完全不读取 DUT ready/valid，不因 DUT 快慢自适应延长。
- 每帧只应在 F+1 接受；普通帧在 F+4 发布，指定背压帧在 F+32 发布；下个 frame 前均闭合。无接受或额外接受均为矛盾，不以少收样本通过。
- 本段不插 reset/cancel；四路 DDS 均在每次接受推进，独奏 mask 不冻结其他路相位，不在段切换时补 reset。8192 个接受等间距 1042 拍；不能按实际发布时间间距当采样间距。

四次独奏各约 21.34ms，合奏约 85.36ms（理想时钟）；逐段必须完整达标。四路合奏“贡献”指四条已使能、各有非零样本的不同 FCW 通路，不要求每个采样瞬间四条均非零；正弦零交叉不降低 active count。mask 非零且 enable=1 时 active 应为 popcount(mask)。

## 6. 排空、数学边界与 M3 后续

排空 cycle `8,536,320…8,536,335`：rst_n=1、frame_tick=cancel=sample_req=0、enable=1、mask=F、FCW 不变、req_id 保持末帧值 `00000FEF`、result_ready=1。不得用末尾 reset/frame/cancel 清掉未知开放事务。END 独立静态预期 **A=8207、P=8201、C=6、open=0**，epoch 2 总接受 8193 笔；声音段严格另计 A=P=8192、C=0。

本 v5 是纯 DDS 测试源，无 ADSR/音色/效果链；不搬 R04 的 ADSR 或相位取表模板。本次相位只审接受推进、取消不回滚、reset 清零语义，ROM 同步读及逐样本 PCM 数学仍按精确 v5 已签来源复用。本文件不新写黄金、不新算 8201 条 PCM、不将旧数学通过自动升级为新长窗 PCM 通过。

若拟将新长窗也声明声音数学通过，M3 必须在送 M2 的范围中单列新增日志的四 lane signed16→PCM24（左移8）、左右值、mask/enable、active、宽位和/饱和/clip 与实际采样映射；沿用原冻结规则，仅覆盖新 capture，不重放旧 4207 数学或旧专项。四路独奏/合奏段齐套也只证明该隔离输入，不证明生产四复音、第五音抢占、真实声卡 FFT、138K 时序或实物通过。

M3 接续提交：本输入版本及精确逐沿输入 SHA、投影一致性；工具绝对路径/版本/身份及前后 SHA；TB/observer/checker 及完整依赖 SHA；reset 事件时点、三轨迹/END 格式；一次隔离编译＋一次实际 RTL 运行的精确命令、仿真截止、墙钟/日志大小上限及失败即停规则。该计划有约 854 万沿，须先给 M2 日志与资源估算；如需缩短/分批，先发布新的明确输入版本，不静默删沿或截断本版窗口。工具和输出范围由 M2 最终确认，不能把 M1 的输入确认当执行放行。

已签 128 沿控制窗口、T060 原 H A/B、旧数学与旧反例不重跑；旧 4207 发布完整性继续 UNKNOWN，旧 capture/checker 和原失败原件保持。完整 T052 仍 PARTIAL。
