# M1十九字段语义与观察出口

入口：repo/code/docs/test/m1_r05_pcm_oracle_20261016/pro_r06_20261017/source_semantics/README.md。
四份候选、19字段合同、M2字段对应、19个新自检及原双流、可逆diff和旧源本体均在包内。
L0候选/静态软件检查；未运行HDL、EDA或板测。真实数学/集成与board_release_allowed仍待M2及同版输入。
当前Git发布状态以PUBLICATION_DECISION.json为准。旧源只读参考，禁止把同名新旧模块同时编译。
