"""Seal the new subsystem status tests; V0323 evidence remains untouched."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
RUNS=[ROOT/'code/output'/n for n in ['M2_N32_audio_subsystem_final_20261014_01','M2_N32_audio_subsystem_wait_final_20261014_01']]
GATE=ROOT/'code/output/M2_N32_subsystem_publish_gate_20261014_01'
DEST=ROOT/'code/docs/evidence/m2_n32_audio_subsystem_20261014'
def ident(path):
    data=path.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
gate=json.loads((GATE/'receipt.json').read_bytes())
assert gate['passed'] and gate['exit']==0 and not gate['timeout']
DEST.mkdir(exist_ok=False)
receipts=[];files=[Path(__file__),ROOT/'code/output/m2_n32_subsystem_gate_20261014_01.py']
for run in RUNS:
    receipt=json.loads((run/'receipt.json').read_bytes())
    assert receipt['status']=='PASS' and receipt['source_before']==receipt['source_after']
    for path,digest in receipt['source_after'].items():assert ident(Path(path))['sha256']==digest,path
    snapshots=json.loads((run/'snapshot_manifest.json').read_bytes())
    for item in snapshots:assert ident(run/item['snapshot'])==dict(bytes=item['bytes'],sha256=item['sha256'])
    receipts.append(dict(path=(run/'receipt.json').relative_to(ROOT).as_posix(),case=receipt['case'],seconds=receipt['seconds'],steps=len(receipt['steps']),inputs=len(receipt['source_before'])))
    files += [p for p in run.rglob('*') if p.is_file() and p.suffix not in {'.exe','.vvp','.dll'}]
for path,digest in gate['inputs_after'].items():assert ident(ROOT/path)['sha256']==digest,path
files+=list(GATE.glob('*.json'))+list(GATE.glob('*.log'))
files+=list((ROOT/'code/tb/audio_out/m2_n32_output_candidate_20261013').glob('*'))
files+=list((ROOT/'code/rtl/audio_out/m2_n32_output_candidate_20261013').glob('*.sv'))
files+=[ROOT/'code/scripts/run_m2_n32_output_transport.py']
manifest=dict(scope='New isolated N32/R1 shell: occupied population and frame-credit latency functional tests; no new sound math/STA/production',runs=receipts,
    gate=dict(seconds=gate['seconds'],inputs=len(gate['inputs_after']),exit=gate['exit'],passed=True),members=[])
archive=DEST/'RAW_EVIDENCE.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as package:
    for path in sorted(set(files)):
        if not path.is_file():continue
        name=path.relative_to(ROOT).as_posix();data=path.read_bytes()
        manifest['members'].append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        package.writestr(name,data)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for item in manifest['members']:
        data=package.read(item['path']);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
manifest['archive']=ident(archive)
(DEST/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(runs=receipts,gate=manifest['gate'],archive=manifest['archive'],members=len(manifest['members'])),indent=2))
