cd {C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin/code/output/M2_N32_prom_authorized_syn_20261013_01/project}
open_project {C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin/code/output/M2_N32_prom_authorized_syn_20261013_01/project/n32_prom_resource.gprj}
set_option -top_module m2_n32_prom_resource
set_option -verilog_std sysv2017
set_option -include_path {C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin/code/build/138k_polyphony_resource/prepared/N32_R1_20261011_01/include}
run syn
