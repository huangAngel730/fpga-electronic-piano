"""Seal exact merged gate and permit source; no test or capture execution."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
GATE=ROOT/'code/output/M2_N32_acceptance_merged_gate_20261014_01'
gate=json.loads((GATE/'receipt.json').read_bytes())
assert gate['passed'] and gate['exit']==0 and not gate['timeout']
for name,digest in gate['inputs_after'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
DEST=ROOT/'code/docs/evidence/m2_acceptance_merged_gate_20261014'
DEST.mkdir(exist_ok=False)
approval=ROOT/'code/docs/test/t052_publication_acceptance_20261012/CONTROL_PREPARATION_20261012/M2_APPROVAL_20261014_CONFIG_eaf33285.json'
assert json.loads(approval.read_bytes())['approved'] is False
paths=list(GATE.glob('*.log'))+list(GATE.glob('*.json'))+[Path(__file__),ROOT/'code/output/m2_n32_acceptance_merged_gate_20261014_01.py',approval]
archive=DEST/'RAW_GATE.zip'
records=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as package:
    for path in paths:
        data=path.read_bytes();name=path.relative_to(ROOT).as_posix()
        records.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        package.writestr(name,data)
assert zipfile.ZipFile(archive).testzip() is None
manifest=dict(scope='Exact merged-code publication gate and disabled T052 draft; budget-start repair pending, no actual T052 RTL',
    gate_seconds=gate['seconds'],inputs=len(gate['inputs_after']),gate_passed=True,
    members=records,archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(DEST/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:manifest[k] for k in ['gate_seconds','inputs','gate_passed','archive_bytes','archive_sha256']},indent=2))
