"""Required fresh gate after new executable acceptance delivery was merged."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'code/output/M2_N32_acceptance_merged_gate_20261014_01'
OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('owned_gate',ROOT/'code/scripts/run_t025_top_stat.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
started=time.monotonic()
names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode('utf-8').split('\0')
names=sorted({n for n in names if n and (ROOT/n).is_file() and Path(n).suffix.lower() in {'.py','.ps1','.sv','.svh','.v','.tcl','.sdc','.cst','.gprj','.hex','.mem','.yaml','.yml'}})
def snapshot():return {n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}
before=snapshot()
command=[r'C:\Users\Angel17\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'code/scripts/check_repo.ps1')]
receipt=dict(command=command,total_bound=600,passed=False,inputs_before=before,
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    reason='New executable T052/T060 delivery0b5f453 merged; prior subsystem gate does not cover this tree')
try:
    rc,timeout=runner.run_bounded(command,OUT,600-(time.monotonic()-started))
    after=snapshot();text=(OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')+(OUT/'stderr.log').read_text(encoding='utf-8',errors='replace')
    receipt.update(exit=rc,timeout=timeout,seconds=time.monotonic()-started,inputs_after=after)
    receipt['passed']=rc==0 and not timeout and before==after and text.count('[PASS]')==9 and '[FAIL]' not in text and receipt['seconds']<600
    print(text[-4500:])
except Exception as e:receipt['error']=type(e).__name__+': '+str(e)
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
if time.monotonic()-started>=600:
    receipt.update(passed=False,error='TOTAL600_RECEIPT_TAIL')
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:receipt.get(k) for k in ['passed','exit','timeout','seconds','error']}))
sys.exit(0 if receipt['passed'] else 1)
