"""Read sealed original reports only; no HDL, synthesis or old test replay."""
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'code/output/M2_N32_prom_authorized_syn_20261013_01/project/impl/gwsynthesis'
SEALED = ROOT / 'code/docs/evidence/m2_n32_prom_synthesis_20261013'
OUT = ROOT / 'code/output/M2_N32_report_static_followup_20261013_01'
OUT.mkdir(exist_ok=False)
manifest = json.loads((SEALED / 'MANIFEST.json').read_text(encoding='utf-8'))
names = ['n32_prom_resource_syn.rpt.html', 'n32_prom_resource_syn_resource.html',
         'n32_prom_resource_syn_rsc.xml', 'n32_prom_resource.prj']
identities = {}
for name in names:
    path = BASE / name
    data = path.read_bytes()
    original = manifest['members']['project/impl/gwsynthesis/' + name]
    assert len(data) == original['bytes']
    assert hashlib.sha256(data).hexdigest() == original['sha256'], name
    identities[name] = original


class Tables(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows = []
        self.row = None
        self.cell = None

    def handle_starttag(self, tag, attrs):
        if tag == 'tr':
            self.row = []
        if tag in ('td', 'th'):
            self.cell = []

    def handle_endtag(self, tag):
        if tag in ('td', 'th') and self.cell is not None:
            if self.row is None:  # Gowin hierarchy table omits some opening tr tags.
                self.row = []
            self.row.append(' '.join(''.join(self.cell).split()))
            self.cell = None
        if tag == 'tr' and self.row is not None:
            self.rows.append(self.row)
            self.row = None

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)


tree = ET.fromstring((BASE / names[2]).read_bytes())
operators = ('MULTALU27X18', 'MULT27X36')
self_counts = {key: sum(int(node.attrib.get(key, '0')) for node in tree.iter()) for key in operators}
top = next(node for node in tree.iter() if node.attrib.get('name') == 'm2_n32_prom_resource')
for key in operators:
    assert self_counts[key] == int(top.attrib['T_' + key].split('(')[0])
hierarchy = Tables()
hierarchy.feed((BASE / names[1]).read_text(encoding='utf-8'))
assert hierarchy.rows[0][4] == 'DSP NUMBER'
assert all(len(row) == 8 for row in hierarchy.rows[1:])
operator_total = sum(int(row[4]) for row in hierarchy.rows[1:] if row[4].isdigit())
assert operator_total == sum(self_counts.values()) == 170
summary = Tables()
summary.feed((BASE / names[0]).read_text(encoding='utf-8'))
dsp_row = next(row for row in summary.rows if row and row[0] == 'DSP')
assert dsp_row == ['DSP', '']
for key in operators:
    assert next(row for row in summary.rows if row and row[0] == key)[1] == str(self_counts[key])
clock = next(row for row in summary.rows if len(row) > 3 and row[1] == 'clk' and 'MHz' in row[2])
assert clock[2:5] == ['100.000(MHz)', '6.109(MHz)', '178']
prj = ET.fromstring((BASE / names[3]).read_bytes())
options = {node.attrib.get('type'): node.attrib.get('value') for node in prj.iter('Option')}
assert options['global_freq'] == '100.000'
timing_text = ' '.join(' '.join(row) for row in summary.rows)
assert 'Inferring Phase 1' in timing_text and 'Elapsed time = 0h 10m 53s' in timing_text
allocator = next(node for node in tree.iter() if node.attrib.get('name') == 'u_allocator')
result = dict(scope='Original synthesis report static followup only; no new tool calls',
              source_reports=identities, operator_counts=self_counts,
              hierarchy_DSP_NUMBER_sum=operator_total,
              physical_DSP_blocks=None, physical_DSP_capacity=None,
              diagnostic='170 is the report macro count; main DSP aggregate is blank. No physical-unit conversion or capacity admission.',
              effective_synthesis_global_frequency_MHz=100.0,
              estimated_clock_frequency_MHz=6.109, estimated_clock_logic_levels=178,
              infer_phase_1_elapsed_seconds=653,
              allocator_resources={k: allocator.attrib.get('T_' + k) for k in ['Register', 'Lut', 'Alu']},
              resource_admission=False, physical_STA='NOT_RUN', new_EDA_calls=0)
(OUT / 'static_followup.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in names:
    assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == identities[name]['sha256']
DEST = ROOT / 'code/docs/evidence/m2_n32_report_static_followup_20261013'
DEST.mkdir(exist_ok=False)
with zipfile.ZipFile(DEST / 'RAW_STATIC_AUDIT.zip', 'x', compression=zipfile.ZIP_DEFLATED) as package:
    for path in [Path(__file__), OUT / 'static_followup.json'] + [BASE / name for name in names]:
        package.write(path, path.relative_to(ROOT).as_posix())
archive = DEST / 'RAW_STATIC_AUDIT.zip'
assert zipfile.ZipFile(archive).testzip() is None
(DEST / 'MANIFEST.json').write_text(json.dumps(dict(scope=result['scope'], source_reports=identities,
    archive_bytes=archive.stat().st_size, archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()), indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({k: result[k] for k in ['operator_counts', 'hierarchy_DSP_NUMBER_sum', 'physical_DSP_blocks', 'effective_synthesis_global_frequency_MHz', 'infer_phase_1_elapsed_seconds', 'allocator_resources', 'new_EDA_calls']}, indent=2))
print('Evidence:', DEST)
