# T052 四声部复音测试源 —— 使用说明（当前状态：返修 v5）

更新时间：2026-10-13 | 复核：M2 V0303 | 完整 T052：**PARTIAL（未闭合）**

## 一句话现状

v5 已闭合 M2 V0292 的 frame_tick 阻断与 V0303 的短边界／commit 链／4207 数学比对；
**发布完整性仍未签收**——checker 会误收「删一个结果后 END 4206」和「截到 4096 后修 END」
两份反例。完整性后继（M3 任务 2）与 runner 软件后继（任务 3）**均已交付**；
后续由**接任方／M2 统筹**，M1 不重复实现、不新增 TB。

## 版本状态

| 版本 | 状态 | 说明 |
|---|---|---|
| v2 / v3 / v4 | **已废弃** | 分别被 M2 复核出未签收项；包仍保留在原处，仅作历史 |
| **v5** | **当前** | SHA `c7981d106d162a45ee3580188a401f9dad81da64bd00e085c2dbf2fb49558e2c`（506,698 B，65 成员，CRC 全通过） |
| v6+ | 未计划 | 完整性后继、runner 后继均已交付，由接任方／M2 统筹；M1 侧如需动 DUT 须先经 M2 |

## v5 已闭合

- **frame_tick 优先级**（V0292 阻断）：`calc_ready = (state==IDLE)` 只报告能力，
  `accept = calc_ready && sample_req && !frame_tick && !cancel`；FSM 中 frame/cancel
  优先于 IDLE/CALC/HOLD。帧沿不接受、不推进相位；valid/HOLD 下清旧 valid。
- **六个短边界**：handshake TB 覆盖 IDLE 帧+sample 同沿、HOLD 帧清旧 valid、
  CALC 帧清 context、帧后 ID 恢复，全部 PASS。
- **commit 链**：`frames=8 commits=7 requests=8 underrun=0 clip=2 last_gap=1042`。
  注：commit TB 用分数节拍（见下「两种帧节拍」）。
- **数学比对**：4207/4207 发布结果与独立模型逐样本一致。
- **严格负例**：v5 相关 6 份（`unknown_tail` / `truncated` / `mask17` / `valmismatch` /
  `endcount` / `negid`）全部 exit 1；正例 exit 0。
  **这是 M1 报告，本次重跑的原日志未随附**（M2 已暂记，不要求重跑）。
  另：同目录 5 份 `bad*_*.log` 是 **v4 期遗留**（引用 4137 条，非 v5 的 4207 条），
  与 v5 不配套，仅作历史保留，不作 v5 负例证据。
- **错误变体**：2 份，编译 0／仿真 0／检查 1（4195 与 27 处不匹配），含完整源与日志。

## v5 未闭合（诚实边界）

- **发布完整性未签收**：checker 误收 V0303 两份完整反例。根因是 `ACC` 集合由 DUT 自身
  `calc_ready` 输出定义，缺少独立于 DUT 输出的接受依据 —— 逐条缺口见
  [`T052_输入控制记录清单.md`](T052_输入控制记录清单.md)。
- **现有记录不足以辨别「丢失」与「取消」**：只有逐「接受」记录，无逐沿记录；
  无 frame/cancel/reset 沿号与覆盖窗口；capture 非 PRE_NBA 完整握手；
  无事务寿命/代次标签；取消用例存在 ID 口径不一致（TB 用 `acc_id` 写日志，
  而 DUT 实际 `req_id` 为 `0x90000001`）。**M1 不申请改判，认同 M3 的 UNKNOWN。**
- 未做 Gowin 综合 / PnR / STA；138K 40MHz 正式接入**归 M2**。
- 未做板级采集与现场 FFT；**归 M3**。
- 帧频标注见下「两种帧节拍」；真实晶振误差未测，**不写实测精确 48 kHz**。
- 频点标签遗留问题：FCW `0x04B17E4D` 按 48 kHz/32 bit 合同约 **880 Hz**，不是 440 Hz；
  本版未改该换算，标签按实际 FCW 注明。
- 负边界（负超界）本次 0 命中；32 bit ID 未构造 `0xFFFFFFFF` 真回绕；
  enable 完整关闭/重启未单独验证。

## 两种帧节拍（**勿混用结论**）

两个 TB 的帧节拍**不同源**，各自结论不能互相套用：

| TB | 帧节拍实现 | 实际帧频 | 可支撑的结论 |
|---|---|---|---|
| `tb_t052_polyphony.sv`（主 TB） | **固定 1042 拍**：`frame_cnt == 11'd1041` 回零 | 50 MHz ÷ 1042 = **47984.6 Hz** | 只用于复音数据路径与检查器配对；**不支撑 48 kHz 结论** |
| `tb_t052_commit_chain.sv` | **分数累加**：每拍 `+48000`，`≥50_000_000` 发 tick 并相减 | 长期平均 **恰 48 kHz**，帧距取 **1041/1042 的间隔分布** | 支撑帧距、代次提交、欠载、clip 计数 |

即：`last_gap=1042` 与 1041/1042 的间隔分布属于 **commit TB**；主 TB 是固定 1042 拍，
不得用主 TB 的 4207 条记录去论证 48 kHz 或 1041/1042 帧距。
主 TB 用固定分频是为了让接受轨迹与帧扫边界严格可复算，**不是** 48 kHz 整机结论。

## 文件与 SHA（v5）

| 文件 | SHA256 |
|---|---|
| `t052_polyphony_test_source.sv`（DUT） | `89ddb8b73bda6e5c83c7b617640cddf3294fb194a9b7955746c28a2e0f2eddeb` |
| `tb_t052_polyphony.sv` | `aa78d6899b97c0e3206cb7abb33ad0bffd765e801d3f6fba51ee86b3f519d8e7` |
| `tb_t052_handshake.sv` | `5f656009e6dd461f8c8604a2c59a991d673479364ccbfb6bfb22c513290937d7` |
| `tb_t052_commit_chain.sv` | `11099c7aff066ed6d8d2b99a2caca983555235a01f68484e444d0dd060f258d2` |
| `check_t052_rtl.py` | `994f1da009557ac3ab0ecb4a5e030f4a592c4c8dcd0a5c6c4dad7722bce1df98` |
| `run_tb.py` | `19143e58314784556555eba8acf2ef3af5ff335382d045530efdccb7a6948658` |
| `t052_polyphony_reference.py` | `df8d192830682280a388d4e27da573141fa624877141b761de0ccfce13c8145d` |
| `test_t052_polyphony_reference.py` | `720b43b9e141a03cc2a54c896f7fcf8b959bfb05527157d963473fd72fe9f15f` |

包内规范路径：`code/rtl/audio/`、`code/model/`、`code/tb/audio/t052_polyphony/`、`code/docs/test/`。

## 接口（局部隔离合同，不改正式公共接口）

| 方向 | 信号 | 说明 |
|---|---|---|
| in | `clk` | 50 MHz |
| in | `rst_n` | 低有效异步拉低 |
| in | `frame_tick` | 帧边界，与 `cancel` 同级最高优先：丢弃旧结果 |
| in | `sample_req` | 逻辑采样请求 |
| out | `calc_ready` | 可接受一次请求（只报告能力，可含帧沿） |
| in | `req_id[31:0]` | 请求 ID（32 bit） |
| in | `enable` | 总使能 |
| in | `voice_enable_mask[3:0]` | 声部使能 mask |
| in | `fcw_lane0..3[31:0]` | 四路频率控制字 |
| in | `cancel` | 取消（与 `frame_tick` 同优先） |
| out | `result_valid` | 结果有效，held 至握手 |
| in | `result_ready` | 消费者背压 |
| out | `result_req_id[31:0]` | 结果对应请求 ID |
| out | `voices_left/right[95:0]` | 每 24 bit 一声部（16 bit 左移 8） |
| out | `active_voice_count[31:0]` | 已锁存 mask 的置位数 |
| out | `clip_any` | mixer 宽位和饱和结果 |

## 时序口径

- `calc_ready = (state==IDLE)`；`accept = calc_ready && sample_req && !frame_tick && !cancel`。
- DDS 仅在 `accept` 沿推进一次；**取值 = 推进前相位**（先取样后推进）。
- 接受的请求其 ID/mask/enable/FCW 在 CALC 沿冻结；已发生的相位推进**不回滚**（只有 reset 清相位）。
- 结果在 HOLD 保持稳定，直到 `result_valid && result_ready` 握手；背压不产生重复推进。
- frame_tick/cancel 优先级高于 IDLE/CALC/HOLD，同沿不接受新请求。

## 运行

```bash
cd code/tb/audio/t052_polyphony
python run_tb.py          # 自动定位仓库根；ModelSim（本机实测）或 Icarus
python ../../../model/test_t052_polyphony_reference.py
```

`run_tb.py` 联合判定：编译退出 0 **且**仿真退出 0 **且**本次新建产物存在 **且**
PASS 标记出现 **且**独立数学比较通过。任一不满足即非零退出。
模拟器在 ASCII 临时目录运行（ModelSim 无法在中文路径建 `work` 库），产物复制回
`code/output/t052_run_<stamp>/`；输出目录带时间戳，**拒绝覆盖**。

## 已删除的做法（勿回退）

- 内部 `sample_counter` / `10'd1042` 节拍：**已删除**（位宽截断）。改由外部
  `frame_tick` / `sample_req` 驱动。
- `automatic` 局部声明：已全部移除。
- 局部 `0x7F00` 削波阈值：**已删除**，改回复用 `pcm_mixer_4voice` 的宽位和 + 24 bit 饱和。

## 只读依赖（v5 未改一字节）

`polyphonic_pcm_commit` / `pcm_mixer_4voice` / `pcm_result_hold` / `pcm_frame_buffer` /
`pcm_clip_counter` / `dds_oscillator` / 公共包 / 生产 top / 约束 / ROM 全部只读引用。

## M2 / M3 后续

- **M3**：任务 2（发布完整性后继）与任务 3（runner 软件后继）**均已交付**。
- **后续**：由**接任方／M2 统筹**。M1 不重复 checker／runner，不新增 TB。
- **M1**：保留算法与 DUT 所有权；v5 与旧证据原样保留。
- **补证路线**：按 M2 **V0313** 先闭合**驱动、独立日历、来源绑定**三项，
  **RTL 采集尚未批准**。

无综合／PnR／STA／安装／串口／接线／烧录／下载。
