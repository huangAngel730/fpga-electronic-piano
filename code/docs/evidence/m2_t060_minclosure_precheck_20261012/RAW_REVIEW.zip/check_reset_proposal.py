"""M2 source-pinned SOFTWARE proposal, not a modified M3 plan or RTL capture."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
PORTABLE = OUT / "sealed/run/portable"
HERE = PORTABLE / "code/software/audio_math_acceptance_candidate/t060_minclosure_20261011"
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from fixtures import rows  # noqa: E402
from fsm_oracle import event_word  # noqa: E402
from prepare import check_import_origins, load_roms  # noqa: E402

check_import_origins()
base = json.loads((PORTABLE / "plan_B.json").read_text(encoding="utf-8"))
proposal = deepcopy(base)
new_inputs = {"1510": {"rst_n": 0}, "1514": {"rst_n": 1},
              "1518": {"event": event_word(0, 900)}, "1540": {"frame": 1}}
assert not set(new_inputs).intersection(base["inputs"])
proposal["inputs"].update(new_inputs)
roms = load_roms()
before = list(rows(base, roms, "SYNTHETIC_SOFTWARE_TEST"))
after = list(rows(proposal, roms, "SYNTHETIC_SOFTWARE_TEST"))
assert [r for r in before if r.get("cycle", 0) < 1510] == [
    r for r in after if r.get("cycle", 0) < 1510]
assert proposal["cases"] == base["cases"] and proposal["end_cycle"] == 1600
resets = [r for r in after if r["tag"] == "RESET"]
assert len(resets) == 2 and resets[-1]["cycle"] == 1510 and resets[-1]["epoch"] == 2
first = next(r for r in after if r["tag"] == "EDGE" and r["epoch"] == 2)
assert first["cycle"] == 1514
for field in ("occupied", "generations", "dds_phase", "lfo_phase", "env_state",
              "env_level", "bank_valid", "pcm_valid", "pending_valid",
              "play_left", "play_right", "request_id"):
    assert first[field] == 0, field
commits = [r for r in after if r.get("commit") and r["epoch"] == 2]
assert len(commits) == 1 and commits[0]["pcm_id"] == 1
result = dict(kind="M2 proposed B suffix software oracle only; not RTL",
              original_plan_sha256=hashlib.sha256((PORTABLE / "plan_B.json").read_bytes()).hexdigest(),
              appended_inputs=new_inputs, four_old_case_rows_unchanged_before_1510=True,
              end_cycle_unchanged=1600, reset_epochs=[r["epoch"] for r in resets],
              clean_first_edge_fields_verified=True,
              recovery_commit_cycle=commits[0]["cycle"],
              recovery_request_id=1, oracle_result=True,
              original_M3_plan_modified=False, RTL_run=False,
              execution_authorized=False)
(OUT / "proposed_B_reset_suffix.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, ensure_ascii=False))
