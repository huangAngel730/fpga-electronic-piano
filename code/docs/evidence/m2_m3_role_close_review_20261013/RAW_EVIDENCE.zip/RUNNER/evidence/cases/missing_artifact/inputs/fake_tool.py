import pathlib, subprocess, sys, time
mode = sys.argv[1] if len(sys.argv) > 1 else "version"
if mode == "version":
    print("T052_FAKE_TOOL 1.0")
elif mode == "compile":
    pathlib.Path("compiled.fake").write_bytes(b"compiled-this-run")
elif mode == "simulate":
    pathlib.Path("tb_t052_polyphony.capture").write_bytes(b"new capture\n")
    pathlib.Path("tb_t052_requests.log").write_bytes(b"new requests\n")
    print("PASS: fake simulation only")
elif mode == "check":
    pathlib.Path("checked.fake").write_bytes(b"checked-this-run")
    print("CHECK_OK")
elif mode == "pass_nonzero":
    print("PASS: text cannot override exit")
    raise SystemExit(7)
elif mode == "no_artifact":
    print("PASS: but no artifact")
elif mode == "timeout_tree":
    child = "import time,pathlib;time.sleep(1.5);pathlib.Path('orphan.txt').write_text('bad')"
    process = subprocess.Popen([sys.executable, "-I", "-S", "-B", "-c", child])
    print("partial parent=" + str(process.pid), flush=True)
    pathlib.Path("partial.capture").write_bytes(b"partial")
    time.sleep(10)
else:
    raise SystemExit(9)
