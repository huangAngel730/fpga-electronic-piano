# M3 给 M2：T052 独立 runner 后继与帧端口投影软件后继

M2，按最新四项任务单，本轮完成两项次优先软件后继，统一本地提交为
`a00355e3593c6fc3c1ecb704feded21257f9c3fb`。截至本通知生成时，GitHub
网络 DNS/443 不可达，三次普通推送（含一次 HTTP/1.1 兼容方式）均未送达，
本地 `develop` 相对 `origin/develop@cdb8e04` 领先 1；请勿把本通知视为远端已上传。
用户恢复网络后将普通推送同一提交，不 force、不改写历史。

1. T052 独立 runner 后继仅新增
   `code/software/t052_runner_acceptance_candidate_20261012/` 与
   `code/docs/test/t052_runner_acceptance_20261012/`。没有修改 M1 的
   `run_tb.py`。固定工具绝对路径、版本查询和可执行文件 SHA，冻结 DUT/TB/ROM/
   checker 输入前后身份，要求 compile/simulate/check 联合成功；拒绝旧 capture/
   request、覆盖输出、缺 ROM/依赖/工具、假 PASS、缺产物和超时。Windows 超时只
   终止本步私有 Job Object，保留 partial stdout/stderr 和可见产物。9 项假工具软件
   用例通过，状态 `SOFTWARE_FAKE_TOOLS_ONLY_PASS`，退出 0，3.265 秒；
   ModelSim/Icarus/Gowin 运行数均为 0。封存 ZIP SHA256
   `1bcb67e4ecf8c68cde168312512865ebd782ba21d7895aec2f6656ef95b2f335`，
   68089 bytes、139 members，并已再次校验 CRC/成员/SHA。

2. `pin_projection` 后继仅新增
   `code/software/polyphony_frame_acceptance_candidate_20261012/pin_projection_20261012/`
   与配套文档。明确 raw result credit、ID-qualified ready、真实
   `valid && ready`、pending/held/play 和 frame pre-NBA 发送口径；软件 epoch 与抽象
   backpressure 不冒充真实 pin；原 b2d 无准确 clip，新隔离
   `b2d_event_audio_clipped` 仅按精确 SHA 绑定。11 项单测、2 份完整正例、5 份完整
   定向反例、缺文件及拒覆盖均符合预期，状态
   `PIN_PROJECTION_SOFTWARE_L0_L1_PASS`，退出 0，0.781 秒，总 300 秒/单步 90 秒。
   首次闭包白名单漏列标准库 `base64/io/zipfile` 的失败发生在任何子步骤前，已连同
   修后成功证据一起封存。最终封存 ZIP SHA256
   `4a57db065174a392c75a880937260a293fe7ee1d1cbf575d8375aab048e2c80d`，
   62928 bytes、57 members，并已再次校验。

3. 仓库 `check_repo.ps1` 强制九项门禁最终全 PASS。首轮因 WindowsApps
   `python.exe` 占位程序不可执行而在前三项 PASS 后中止；将已核验 Python 3.11 目录
   临时置于 PATH 首位后原样重跑，九项全 PASS。该基础门禁包含既有 T007/T019
   仿真，但本轮没有执行 T052/T060 新 RTL 捕获、lower/compile/VVP、Gowin、综合、
   PnR、STA 或设备操作。

本轮只签两个软件 L0/L1 候选，不升级 c36e58f、clipped 后继或旧声音数学结论，
不代表 T052/T060/T061 完整闭合、真实 RTL 逐沿、生产接入、资源或物理时序通过。
T060 精确 A/B 一次补采和 T052 128 沿薄 TB/observer 静态准备未混入本提交。
请按增量复核；编号和共享登记仍由 M2 处理。

随附统一包内部的 `M3_T052_runner_pin_projection_a00355e_20261013.zip` 是从提交
`a00355e` 直接 `git archive` 生成的精确 17 文件内容；内包 SHA256
`d319eb475dc84da1dd57782c503439fbb2e452fa05cb069a0d8316809a184f60`，
139542 bytes、30 个 ZIP entries、CRC 通过。

待用户转发，尚未送达。
