"""Reproduce two software-only review findings, no real tools or waiting."""
import argparse
import copy
import json
from pathlib import Path
import sys
from unittest.mock import patch

root = Path(__file__).resolve().parents[3]
cli = argparse.ArgumentParser()
cli.add_argument("--output", required=True, type=Path)
out = cli.parse_args().output.resolve()
if out.exists():
    raise ValueError("REFUSE_EXISTING_OUTPUT")
out.mkdir(parents=True)
runner_dir = root / "code/software/t052_runner_acceptance_candidate_20261012"
sys.path.insert(0, str(runner_dir))
import runner
import test_runner

case = out / "runner"
case.mkdir()
config = test_runner.fixture(case)
now = [0.0]
original_budget, original_collect, original_write = runner.Budget, runner._collect_artifacts, runner.write_json


def fake_process(output, label, argv, cwd, cap, budget):
    (output / (label + ".stdout.bin")).write_bytes(b"PASS: CHECK_OK")
    (output / (label + ".stderr.bin")).write_bytes(b"")
    names = {"compile": ["compiled.fake"], "simulate": ["tb_t052_polyphony.capture", "tb_t052_requests.log"], "check": ["checked.fake"]}.get(label, [])
    for name in names:
        (cwd / name).write_bytes(b"synthetic")
    return dict(label=label, exit_code=0, timed_out=False, launch_error=None)


def collect(path, budget):
    result = original_collect(path, budget)
    now[0] = 19.0
    return result


def write(path, value, exclusive=True):
    original_write(path, value, exclusive)
    if Path(path).name == "receipt.json":
        now[0] += 2.0


with patch.object(runner, "Budget", lambda seconds: original_budget(seconds, lambda: now[0])), patch.object(runner, "_run_process", fake_process), patch.object(runner, "_collect_artifacts", collect), patch.object(runner, "write_json", write):
    result = runner.run(config, case / "out")
assert result["exit_code"] == 0 and result["elapsed_seconds"] == 19 and now[0] == 21

sys.path.insert(0, str(root / "code/software/polyphony_frame_acceptance_candidate_20261012/pin_projection_20261012"))
from projection_check import check
from vectors import complete_trace, reset_trace, write_trace

accepted = []
for name, trace, value in (("float", complete_trace(), 3.0), ("bool", reset_trace(), False)):
    trace = copy.deepcopy(trace)
    trace[-1]["commits"] = value
    path = out / ("END_" + name + ".jsonl")
    write_trace(path, trace)
    check(path)
    accepted.append(name)
print(json.dumps(dict(runner_clock=now[0], receipt_elapsed=result["elapsed_seconds"], runner_exit=result["exit_code"], noninteger_END_accepted=accepted, real_process_calls=0)))
