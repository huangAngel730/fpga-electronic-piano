cd {C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin/code/output/M2_N32_controller_review_20261011_01/final_fault_tests/nonzero/project}
open_project {C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin/code/output/M2_N32_controller_review_20261011_01/final_fault_tests/nonzero/project/n32_r1_resource.gprj}
set_option -top_module b2l_resource_probe
set_option -verilog_std sysv2017
set_option -synthesis_tool GowinSynthesis
set_option -include_path {C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin/code/build/138k_polyphony_resource/prepared/N32_R1_20261011_01/include}
run syn
