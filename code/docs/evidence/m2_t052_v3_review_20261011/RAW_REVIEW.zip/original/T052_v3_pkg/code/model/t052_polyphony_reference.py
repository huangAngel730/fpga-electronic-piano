#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 四声部复音参考模型（返修v3）

严格镜像 t052_polyphony_test_source.sv 的 NBA / 旧状态口径：
- accept = IDLE && sample_req && calc_ready && !abort
- abort = cancel | frame_tick，当沿最高优先（丢弃旧结果）
- DDS 仅在 accept 沿推进一次；取值为推进前的相位
- 结果在未收到 result_ready 时保持（held）
"""
import sys
from pathlib import Path


def load_rom(path):
    rom = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            s = line.strip()
            if s and not s.startswith('//'):
                v = int(s, 16) & 0xFFFF
                rom.append(v - 0x10000 if v >= 0x8000 else v)
    return rom


def sat24(x):
    if x > 8388607:
        return 8388607, True
    if x < -8388608:
        return -8388608, True
    return x, False


class T052Reference:
    def __init__(self, rom_path):
        self.rom = load_rom(rom_path)
        self.reset()

    def reset(self):
        self.state = "IDLE"
        self.phase = [0, 0, 0, 0]
        self.fcw_q = [0, 0, 0, 0]
        self.mask_q = 0
        self.id_q = 0
        self.en_q = 0
        self.mask_d = 0
        self.id_d = 0
        self.wt_d = [0, 0, 0, 0]
        self.sample_q = [0, 0, 0, 0]
        self.result_valid = 0
        self.result_req_id = 0
        self.left = 0
        self.right = 0
        self.active = 0
        self.clip = 0
        self._phase_advanced_on_accept = None

    def tick(self, *, frame_tick=0, sample_req=0, req_id=0, enable=0,
             mask=0, fcw=(0, 0, 0, 0), cancel=0, result_ready=0):
        """推进一个时钟沿，返回本沿结束后的输出。"""
        abort = 1 if (cancel or frame_tick) else 0
        calc_ready = 1 if (self.state == "IDLE" and not abort) else 0
        accept = 1 if (self.state == "IDLE" and sample_req and calc_ready and not abort) else 0

        nxt = dict(self.__dict__)

        if abort:
            nxt['state'] = "IDLE"
            nxt['result_valid'] = 0
        else:
            if self.state == "IDLE":
                nxt['result_valid'] = 0
                if accept:
                    nxt['fcw_q'] = list(fcw)
                    nxt['mask_q'] = mask & 0xF
                    nxt['id_q'] = req_id & 0xFFFFFFFF
                    nxt['en_q'] = 1 if enable else 0
                    # 先取样（推进前相位），再推进一次
                    nxt['sample_q'] = [
                        self.rom[(self.phase[j] >> 22) & 0x3FF] for j in range(4)
                    ]
                    nxt['phase'] = list(self.phase)
                    for j in range(4):
                        nxt['phase'][j] = (nxt['phase'][j] + nxt['fcw_q'][j]) % (1 << 32)
                    nxt['state'] = "CALC"
            elif self.state == "CALC":
                nxt['wt_d'] = list(self.sample_q)
                nxt['mask_d'] = self.mask_q
                nxt['id_d'] = self.id_q
                nxt['state'] = "HOLD"
            elif self.state == "HOLD":
                nxt['result_valid'] = 1
                nxt['result_req_id'] = self.id_d
                l = [0, 0, 0, 0]
                act = 0
                for j in range(4):
                    if (self.mask_d >> j) & 1 and self.en_q:
                        l[j] = self.wt_d[j] << 8
                        act += 1
                s, cl = 0, False
                for j in range(4):
                    s += l[j]
                s24, c = sat24(s)
                nxt['left'] = s24
                nxt['right'] = s24
                nxt['active'] = act
                nxt['clip'] = 1 if c else 0
                if result_ready:
                    nxt['result_valid'] = 0
                    nxt['state'] = "IDLE"

        obj = self.__dict__
        for k, v in nxt.items():
            obj[k] = v
        return {
            'calc_ready': calc_ready,
            'result_valid': self.result_valid,
            'result_req_id': self.result_req_id,
            'left': self.left,
            'right': self.right,
            'active': self.active,
            'clip': self.clip,
        }


def main():
    import os
    rom = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom):
        print(f"FAIL: ROM不存在: {rom}")
        return 1
    m = T052Reference(rom)
    print(f"加载ROM: {rom} ({len(m.rom)} 点)")

    # 单请求：accept -> CALC -> HOLD
    m.tick(sample_req=1, req_id=7, enable=1, mask=0b0001, fcw=(0x04B17E4D, 0, 0, 0))
    m.tick()                   # CALC 锁存
    r = m.tick()               # HOLD 发布
    assert r['result_valid'] == 1, "HOLD 应发布 result_valid"
    assert r['result_req_id'] == 7, "ID 应等于接受请求的 ID"
    assert r['active'] == 1, "活跃数应为1"
    print(f"  单请求: id={r['result_req_id']} L={r['left']} active={r['active']} clip={r['clip']}")

    # 保持：无 result_ready 时不落地
    r2 = m.tick()
    assert r2['result_valid'] == 1, "未握手应保持 valid"
    assert r2['result_req_id'] == 7, "保持期间 ID 稳定"
    # 握手后清除
    r3 = m.tick(result_ready=1)
    assert r3['result_valid'] == 0 or m.state == "IDLE", "握手后应清除"
    print("  held/握手: OK")

    print("所有自检通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
