#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 仿真运行器（返修v3）

- 定位仓库根与只读依赖；唯一 ASCII 输出目录；拒绝覆盖已有结果
- 支持 ModelSim(vlog/vsim) 与 Icarus(iverilog/vvp)
- 判定：编译退出0 且 仿真退出0 且 捕获完整 且 独立数学比较通过
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def find_root(start):
    cur = Path(start).resolve()
    for _ in range(6):
        if (cur / "code" / "rtl").is_dir():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


def find_tool(candidates):
    for c in candidates:
        p = Path(c)
        if p.exists():
            return str(p)
    for c in candidates:
        w = shutil.which(Path(c).name)
        if w:
            return w
    return None


def main():
    here = Path(__file__).resolve().parent

    root = find_root(here)
    if root is None:
        print("FAIL: 未找到仓库根（含 code/rtl）")
        return 1

    rtl_audio = root / "code" / "rtl" / "audio"
    rtl_mixer = root / "code" / "rtl" / "mixer"
    rom = root / "code" / "model" / "generated" / "wavetables" / "sine_1024_8192.mem"

    # DUT 位于 code/rtl/audio（原授权布局）；兼容本目录副本
    dut = rtl_audio / "t052_polyphony_test_source.sv"
    if not dut.exists():
        dut = here / "t052_polyphony_test_source.sv"
    if not dut.exists():
        print(f"FAIL: 缺少 DUT（code/rtl/audio/t052_polyphony_test_source.sv）")
        return 1
    if not (here / "tb_t052_polyphony.sv").exists():
        print("FAIL: 缺少 TB（code/tb/audio/t052_polyphony/tb_t052_polyphony.sv）")
        return 1
    if not rom.exists():
        print(f"FAIL: ROM 不存在: {rom}")
        return 1

    vlog = find_tool([r"F:/modelsim/win64/vlog.exe", "vlog"])
    vsim = find_tool([r"F:/modelsim/win64/vsim.exe", "vsim"])
    iverilog = find_tool(["iverilog"])
    vvp = find_tool(["vvp"])
    use_modelsim = bool(vlog and vsim)

    if not use_modelsim and not (iverilog and vvp):
        print("NOT_RUN: 未找到 vlog/vsim 或 iverilog/vvp，RTL 仿真未执行")
        return 3

    out = Path(tempfile.mkdtemp(prefix="t052_"))
    # 复制所需源到 ASCII 工作目录
    for f in (dut,
              rtl_audio / "dds_oscillator.sv",
              rtl_mixer / "pcm_mixer_4voice.sv",
              here / "tb_t052_polyphony.sv",
              rom):
        if not f.exists():
            print(f"FAIL: 缺少源文件 {f}")
            return 1
        shutil.copy(f, out)

    tb = "tb_t052_polyphony"
    compile_cmd = (
        [vlog, "-sv", "+incdir+.", "t052_polyphony_test_source.sv",
         "dds_oscillator.sv", "pcm_mixer_4voice.sv", "tb_t052_polyphony.sv"]
        if use_modelsim else
        [iverilog, "-g2012", "-o", f"{tb}.vvp", "-I", ".",
         "t052_polyphony_test_source.sv", "dds_oscillator.sv",
         "pcm_mixer_4voice.sv", "tb_t052_polyphony.sv"]
    )
    run_cmd = (
        [vsim, "-c", "-do", "run -all; quit -f", tb,
         f"+WAVETABLE_PATH={rom.name}"]
        if use_modelsim else
        [vvp, f"{tb}.vvp", f"+WAVETABLE_PATH={rom.name}"]
    )

    print(f"root={root}")
    print(f"work={out}")
    print(f"tool={'ModelSim' if use_modelsim else 'Icarus'}")

    cp = subprocess.run(compile_cmd, cwd=out, capture_output=True, text=True,
                        timeout=300)
    (out / "compile.log").write_text(cp.stdout + cp.stderr, encoding="utf-8")
    if cp.returncode != 0:
        print(f"FAIL: 编译退出 {cp.returncode}")
        print((cp.stdout + cp.stderr)[-1500:])
        return 1

    try:
        rp = subprocess.run(run_cmd, cwd=out, capture_output=True, text=True,
                            timeout=900, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired as e:
        print(f"FAIL: 仿真超时: {e}")
        return 1
    (out / "vsim.log").write_text((rp.stdout or "") + (rp.stderr or ""),
                                  encoding="utf-8")

    # 持久化捕获与请求记录
    for name in ("tb_t052_polyphony.capture", "tb_t052_requests.log"):
        p = out / name
        if p.exists():
            shutil.copy(p, Path.cwd() / name)

    cap = Path.cwd() / "tb_t052_polyphony.capture"
    req = Path.cwd() / "tb_t052_requests.log"

    # 联合判定：仿真退出0 + PASS标记 + capture存在 + 独立比较通过
    ok = rp.returncode == 0 and "PASS:" in (rp.stdout or "")
    if not cap.exists() or not req.exists():
        print("FAIL: 缺少 capture 或请求记录")
        ok = False

    if ok:
        ck = subprocess.run(
            [sys.executable, str(here / "check_t052_rtl.py"),
             str(req), str(cap), str(rom)],
            capture_output=True, text=True, encoding="utf-8", errors="replace")
        out_txt = (ck.stdout or "").strip()
        # 控制台可能为 GBK，避免打印时二次编码失败
        try:
            print(out_txt)
        except UnicodeEncodeError:
            print(out_txt.encode("ascii", "replace").decode("ascii"))
        ok = ck.returncode == 0

    print(f"compile_exit=0 sim_exit={rp.returncode} success={ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
