#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 Python 单元测试（返修v3）—— 对应 v3 事务契约"""
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from t052_polyphony_reference import T052Reference

ROM = "generated/wavetables/sine_1024_8192.mem"


def _mk():
    return T052Reference(ROM)


def _one(m, rid=1, mask=0b1111, fcws=(0x04B17E4D, 0x0962FC9A, 0x12C5F935, 0x258BF26A)):
    m.tick(sample_req=1, req_id=rid, enable=1, mask=mask, fcw=fcws)
    m.tick()
    return m.tick()


def test_accept_and_result():
    print("测试1: 接受请求并产出结果")
    m = _mk()
    r = _one(m)
    assert r['result_valid'] == 1, "应产出 result_valid"
    assert r['result_req_id'] == 1, "result_req_id 应等于 req_id"
    print("  PASS")


def test_mask_active_count():
    print("测试2: mask 与活跃数")
    m = _mk()
    r = _one(m, rid=2, mask=0b0101)
    assert r['active'] == 2, f"活跃数应为2，实际{r['active']}"
    m2 = _mk()
    r2 = _one(m2, rid=3, mask=0b1111)
    assert r2['active'] == 4, "全开活跃数应为4"
    m3 = _mk()
    r3 = _one(m3, rid=4, mask=0b0000)
    assert r3['active'] == 0, "全关活跃数应为0"
    print("  PASS")


def test_hold_until_ready():
    print("测试3: 未握手时保持(held)")
    m = _mk()
    _one(m)
    r = m.tick()
    assert r['result_valid'] == 1, "未握手应保持 valid"
    assert r['result_req_id'] == 1, "保持期间 ID 稳定"
    m.tick(result_ready=1)
    r2 = m.tick()
    assert r2['result_valid'] == 0, "握手后应清除"
    print("  PASS")


def test_cancel_discards():
    print("测试4: 取消不发布结果")
    m = _mk()
    m.tick(sample_req=1, req_id=9, enable=1, mask=0b1111, fcw=(0x10000000, 0, 0, 0))
    m.tick(cancel=1)
    for _ in range(10):
        r = m.tick()
        assert r['result_valid'] == 0, "取消后不应发布"
    print("  PASS")


def test_32bit_id_wrap():
    print("测试5: 32bit ID 回绕")
    for rid in (0xFFFFFFFF, 0x00000000, 0x12345678):
        m = _mk()
        r = _one(m, rid=rid)
        assert r['result_req_id'] == rid, f"ID {rid:#x} 应原样回传"
    print("  PASS")


def test_pcm24_saturation():
    print("测试6: 四路满幅 PCM24 正饱和")
    m = _mk()
    # 推进相位到正峰地址后四路同相取样
    m.tick(sample_req=1, req_id=1, enable=1, mask=0b1111,
           fcw=(0x40000000,) * 4)
    m.tick()
    m.tick(result_ready=1)
    m.tick(sample_req=1, req_id=2, enable=1, mask=0b1111, fcw=(0x40000000,) * 4)
    m.tick()
    r = m.tick()
    assert r['clip'] == 1, "四路满幅应报告削波"
    assert r['left'] == 8388607, f"应夹到 8388607，实际 {r['left']}"
    print("  PASS")


def main():
    print("=" * 70)
    print("T052 Python 单元测试（返修v3）")
    print("=" * 70)
    print()
    if not os.path.exists(ROM):
        print(f"FAIL: ROM不存在: {ROM}")
        return 1
    try:
        test_accept_and_result()
        test_mask_active_count()
        test_hold_until_ready()
        test_cancel_discards()
        test_32bit_id_wrap()
        test_pcm24_saturation()
        print()
        print("=" * 70)
        print("所有6项测试通过")
        print("=" * 70)
        return 0
    except AssertionError as e:
        print(f"\nFAIL: {e}")
        return 1
    except Exception as e:
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
