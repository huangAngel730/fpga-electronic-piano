#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 独立数学检查器（返修v3）

独立重算：32位相位回绕、ROM 地址/取样对齐、mask、24bit 左移8定标、
宽位和与 24bit 饱和、活跃数、削波。逐样本与 DUT 捕获比对。

用法: python check_t052_rtl.py <requests.log> <capture> <rom.mem>
"""
import sys
from pathlib import Path

PHASE_MOD = 1 << 32
PCM_MAX, PCM_MIN = 8388607, -8388608


def load_rom(path):
    rom = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            s = line.strip()
            if s and not s.startswith('//'):
                v = int(s, 16) & 0xFFFF
                rom.append(v - 0x10000 if v >= 0x8000 else v)
    return rom


def parse_reqs(path):
    out = []
    for line in Path(path).read_text(encoding='utf-8', errors='replace').splitlines():
        p = line.split()
        if p and p[0] == 'REQ':
            out.append((int(p[1]), p[2], p[3], p[4], p[5], int(p[6])))
    return out


def parse_caps(path):
    out = []
    for line in Path(path).read_text(encoding='utf-8', errors='replace').splitlines():
        if not line.strip():
            continue
        t = line.replace('=', ' ').split()
        # ID= <id> v0= .. v1= .. v2= .. v3= .. ACT= .. CLIP= ..
        out.append({
            'id': int(t[1]),
            'v': [int(t[3]), int(t[5]), int(t[7]), int(t[9])],
            'act': int(t[11]),
            'clip': int(t[13]),
        })
    return out


def main():
    if len(sys.argv) != 4:
        print("用法: python check_t052_rtl.py <requests.log> <capture> <rom.mem>")
        return 2
    req_p, cap_p, rom_p = sys.argv[1:4]
    for p in (req_p, cap_p, rom_p):
        if not Path(p).exists():
            print(f"FAIL: 文件不存在: {p}")
            return 1

    rom = load_rom(rom_p)
    reqs = parse_reqs(req_p)
    caps = parse_caps(cap_p)

    if len(reqs) != len(caps):
        print(f"FAIL: 请求数({len(reqs)}) != 捕获数({len(caps)})")
        return 1

    phases = [0, 0, 0, 0]
    bad = 0
    for idx, (rid, h0, h1, h2, h3, vmask) in enumerate(reqs):
        fcws = [int(h0, 16), int(h1, 16), int(h2, 16), int(h3, 16)]
        # 取样 = 推进前相位
        sample = [rom[(phases[j] >> 22) & 0x3FF] for j in range(4)]
        for j in range(4):
            phases[j] = (phases[j] + fcws[j]) % PHASE_MOD

        exp_v, act = [], 0
        for j in range(4):
            if (vmask >> j) & 1:
                exp_v.append(sample[j] << 8)
                act += 1
            else:
                exp_v.append(0)

        total = sum(exp_v)
        if total > PCM_MAX:
            exp_clip, exp_mixsum = 1, PCM_MAX
        elif total < PCM_MIN:
            exp_clip, exp_mixsum = 1, PCM_MIN
        else:
            exp_clip, exp_mixsum = 0, total

        c = caps[idx]
        if c['id'] != rid or c['v'] != exp_v or c['act'] != act or c['clip'] != exp_clip:
            bad += 1
            if bad <= 5:
                print(f"  idx={idx} id={rid}: got {c} exp v={exp_v} act={act} clip={exp_clip} sum={exp_mixsum}")

    n = len(reqs)
    print(f"逐样本比对: {n - bad}/{n} 一致（含 24bit 定标/宽位和/饱和/削波）")
    if bad == 0 and n >= 4096:
        print(f"PASS: {n} 个结果与独立模型一致")
        return 0
    print(f"FAIL: {bad} 处不匹配")
    return 1


if __name__ == "__main__":
    sys.exit(main())
