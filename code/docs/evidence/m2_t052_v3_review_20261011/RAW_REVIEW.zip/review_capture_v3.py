"""Readonly v3 capture arithmetic and fail-closed probes, no full RTL rerun."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "original/T052_v3_pkg"
ROM = ROOT / "dependencies/sine_1024_8192.mem"
CHECKER = PKG / "code/tb/audio/t052_polyphony/check_t052_rtl.py"


def execute(label, requests, captures, expected):
    command = [sys.executable, "-B", "-X", "utf8", str(CHECKER),
               str(requests), str(captures), str(ROM)]
    result = subprocess.run(command, capture_output=True, timeout=30)
    (ROOT / (label + ".stdout.bin")).write_bytes(result.stdout)
    (ROOT / (label + ".stderr.bin")).write_bytes(result.stderr)
    assert result.returncode == expected, (label, result.returncode, result.stderr)
    return dict(label=label, command=command, exit_code=result.returncode,
                stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                stderr_sha256=hashlib.sha256(result.stderr).hexdigest())


def main():
    rp, cp = PKG / "logs/tb_t052_requests.log", PKG / "logs/tb_t052_polyphony.capture"
    requests, captures = rp.read_text("ascii").splitlines(), cp.read_text("ascii").splitlines()
    assert len(requests) == len(captures) == 4137
    table = [int(token, 16) for token in ROM.read_text("ascii").split()]
    assert len(table) == 1024
    table = [n - 65536 if n & 32768 else n for n in table]
    phase = [0] * 4
    masks, clipping, mismatches = set(), 0, []
    regex = re.compile(r"ID=(\d+) v0=(-?\d+) v1=(-?\d+) v2=(-?\d+) v3=(-?\d+) ACT=(\d+) CLIP=([01])")
    for index, (req, capture) in enumerate(zip(requests, captures)):
        p = req.split()
        assert len(p) == 7 and p[0] == "REQ"
        rid, fcw, mask = int(p[1]), [int(x, 16) for x in p[2:6]], int(p[6])
        assert 0 <= rid < 1 << 32 and 0 <= mask < 16
        m = regex.fullmatch(capture)
        assert m
        got = [int(x) for x in m.groups()]
        lanes = [table[a >> 22] * 256 if mask & (1 << i) else 0 for i, a in enumerate(phase)]
        clipped = int(not -(1 << 23) <= sum(lanes) <= (1 << 23) - 1)
        if got != [rid, *lanes, mask.bit_count(), clipped]:
            mismatches.append(index)
        for i in range(4):
            phase[i] = (phase[i] + fcw[i]) & 0xffffffff
        masks.add(mask)
        clipping += clipped
    assert not mismatches and masks == set(range(16))
    steps = [execute("golden_math", rp, cp, 0)]
    probe = ROOT / "new_checker_probes"
    probe.mkdir(exist_ok=False)
    mutants = {
        "unknown_request": (requests + ["UNKNOWN request record"], captures),
        "paired_tail_4096": (requests[:4096], captures[:4096]),
        "mask17": ([requests[0][:-1] + "17"] + requests[1:], captures),
    }
    for label, (rq, cq) in mutants.items():
        r, c = probe / (label + ".req"), probe / (label + ".cap")
        r.write_bytes(("\n".join(rq) + "\n").encode("ascii"))
        c.write_bytes(("\n".join(cq) + "\n").encode("ascii"))
        steps.append(execute(label, r, c, 0))
    c = probe / "all_clip_flip.cap"
    c.write_bytes(("\n".join(x[:-1] + str(1 - int(x[-1])) for x in captures) + "\n").encode("ascii"))
    steps.append(execute("clip_flip_reject", rp, c, 1))
    summary = dict(rows=4137, lanes=16548, ID_ACT_CLIP_matches=True,
                   mismatches=mismatches, masks=sorted(masks),
                   observed_clip_true_rows=clipping,
                   falsely_accepted_mutants=list(mutants),
                   v2_clip_flip_leak_closed=True,
                   actual_mixed_pcm_output_observed=False,
                   actual_right_channel_observed=False,
                   source_request_log="Successful-result task log, not accepted/reset/cancel/tick timeline",
                   ROM_sha256=hashlib.sha256(ROM.read_bytes()).hexdigest(),
                   steps=steps, full_T052=False, new_full_RTL_rerun=False)
    (ROOT / "capture_review.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
