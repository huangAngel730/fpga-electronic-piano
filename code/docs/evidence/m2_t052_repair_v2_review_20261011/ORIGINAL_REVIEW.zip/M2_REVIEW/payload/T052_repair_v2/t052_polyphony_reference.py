#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 四声部复音纯正弦参考模型（返修v2）"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from dds_model import WavetableOscillator

def load_wavetable_from_mem(rom_file: str) -> list:
    wavetable = []
    with open(rom_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('//'):
                value = int(line, 16)
                if value >= 0x8000:
                    value = value - 0x10000
                wavetable.append(value)
    return wavetable

class T052PolyphonyReference:
    def __init__(self, rom_file: str):
        wavetable = load_wavetable_from_mem(rom_file)
        self.dds = [WavetableOscillator(table=wavetable, fcw=0) for _ in range(4)]
        self.state = "IDLE"
        self.fcw_latched = [0, 0, 0, 0]
        self.voice_enable_latched = 0
        self.request_id_latched = 0
        self.cancelled = False
        self._pending_result = None

    def reset(self):
        for dds in self.dds:
            dds.reset()
        self.state = "IDLE"
        self.fcw_latched = [0, 0, 0, 0]
        self.voice_enable_latched = 0
        self.request_id_latched = 0
        self.cancelled = False
        self._pending_result = None

    def tick(self, req_valid, request_id, fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3, 
             voice_enable, cancel, sample_request):
        result = {
            'req_ready': False, 'result_ready': False, 'result_id': 0,
            'pcm_voice0': 0, 'pcm_voice1': 0, 'pcm_voice2': 0, 'pcm_voice3': 0,
            'active_voice_count': 0, 'clip_any': False
        }
        if self.state == "IDLE":
            result['req_ready'] = not cancel
            if req_valid and not cancel:
                self.fcw_latched = [fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3]
                self.voice_enable_latched = voice_enable & 0xF
                self.request_id_latched = request_id & 0xFF
                self.cancelled = False
                for i, dds in enumerate(self.dds):
                    dds.set_fcw(self.fcw_latched[i])
                self.state = "PROCESSING"
        elif self.state == "PROCESSING":
            if cancel:
                self.cancelled = True
            if self.cancelled:
                self.state = "IDLE"
            elif sample_request:
                samples = [dds.step() for dds in self.dds]
                masked_samples = []
                active_count = 0
                for i in range(4):
                    if (self.voice_enable_latched >> i) & 1:
                        masked_samples.append(samples[i])
                        active_count += 1
                    else:
                        masked_samples.append(0)
                self._pending_result = {
                    'result_id': self.request_id_latched,
                    'pcm_voice0': masked_samples[0], 'pcm_voice1': masked_samples[1],
                    'pcm_voice2': masked_samples[2], 'pcm_voice3': masked_samples[3],
                    'active_voice_count': active_count,
                    'clip_any': any(abs(s) >= 0x7F00 for s in masked_samples)
                }
                self.state = "COMMIT"
        elif self.state == "COMMIT":
            if not self.cancelled and self._pending_result:
                result['result_ready'] = True
                result.update(self._pending_result)
            self.cancelled = False
            self.state = "IDLE"
        return result

def calculate_fcw(frequency_hz, sample_rate=48000):
    return int((frequency_hz / sample_rate) * (2**32)) & 0xFFFFFFFF

def main():
    import os
    print("T052 四声部复音参考模型自检（返修v2）")
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"错误: ROM文件不存在: {rom_file}")
        return 1
    model = T052PolyphonyReference(rom_file=rom_file)
    fcw_440 = calculate_fcw(440.0)
    result = model.tick(True, 1, fcw_440, 0, 0, 0, 0b0001, False, False)
    for _ in range(10):
        model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    model.tick(False, 0, 0, 0, 0, 0, 0, False, True)
    result = model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    assert result['result_ready'] and result['active_voice_count'] == 1
    print("所有测试通过")
    return 0

if __name__ == "__main__":
    sys.exit(main())
