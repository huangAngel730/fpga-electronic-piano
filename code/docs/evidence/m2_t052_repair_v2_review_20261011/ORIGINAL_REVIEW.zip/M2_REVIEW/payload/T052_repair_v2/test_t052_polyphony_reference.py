#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 Python单元测试（返修v2）"""
import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from t052_polyphony_reference import T052PolyphonyReference, calculate_fcw

def test_fcw_calculation():
    print("测试1: FCW计算")
    fcw_440 = calculate_fcw(440.0, 48000)
    expected = int((440.0 / 48000.0) * (2**32))
    assert fcw_440 == expected, f"FCW计算错误"
    print(f"  FCW(440Hz) = 0x{fcw_440:08x}")
    print("  PASS\n")

def test_single_voice():
    print("测试2: 单声部 (440 Hz, voice_enable=0001)")
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"  跳过: ROM文件不存在\n")
        return
    model = T052PolyphonyReference(rom_file=rom_file)
    fcw_440 = calculate_fcw(440.0)
    result = model.tick(True, 1, fcw_440, 0, 0, 0, 0b0001, False, False)
    assert result['req_ready'], "应接受请求"
    for _ in range(10):
        model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    model.tick(False, 0, 0, 0, 0, 0, 0, False, True)
    result = model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    assert result['result_ready'], "应有结果"
    assert result['active_voice_count'] == 1, "活跃声部应为1"
    print(f"  PCM: v0={result['pcm_voice0']:+6d}")
    print("  PASS\n")

def test_four_voices():
    print("测试3: 四声部 (440/880/1760/3520 Hz, voice_enable=1111)")
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"  跳过: ROM文件不存在\n")
        return
    model = T052PolyphonyReference(rom_file=rom_file)
    fcw_440 = calculate_fcw(440.0)
    fcw_880 = calculate_fcw(880.0)
    fcw_1760 = calculate_fcw(1760.0)
    fcw_3520 = calculate_fcw(3520.0)
    model.tick(True, 2, fcw_440, fcw_880, fcw_1760, fcw_3520, 0b1111, False, False)
    for _ in range(10):
        model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    model.tick(False, 0, 0, 0, 0, 0, 0, False, True)
    result = model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    assert result['result_ready'], "应有结果"
    assert result['active_voice_count'] == 4, "活跃声部应为4"
    print(f"  活跃声部数: {result['active_voice_count']}")
    print("  PASS\n")

def test_voice_mask():
    print("测试4: Mask测试 (voice_enable=0101)")
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"  跳过: ROM文件不存在\n")
        return
    model = T052PolyphonyReference(rom_file=rom_file)
    fcw = calculate_fcw(440.0)
    model.tick(True, 3, fcw, fcw, fcw, fcw, 0b0101, False, False)
    for _ in range(10):
        model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    model.tick(False, 0, 0, 0, 0, 0, 0, False, True)
    result = model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
    assert result['active_voice_count'] == 2, "活跃声部应为2"
    assert result['pcm_voice1'] == 0, "voice1应被mask"
    assert result['pcm_voice3'] == 0, "voice3应被mask"
    print("  PASS\n")

def test_cancel():
    print("测试5: 取消请求")
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"  跳过: ROM文件不存在\n")
        return
    model = T052PolyphonyReference(rom_file=rom_file)
    fcw = calculate_fcw(440.0)
    model.tick(True, 4, fcw, 0, 0, 0, 0b1111, False, False)
    model.tick(False, 0, 0, 0, 0, 0, 0, True, False)
    for _ in range(20):
        result = model.tick(False, 0, 0, 0, 0, 0, 0, False, False)
        assert not result['result_ready'], "取消后不应有结果"
    print("  PASS\n")

def test_reset():
    print("测试6: 复位")
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"  跳过: ROM文件不存在\n")
        return
    model = T052PolyphonyReference(rom_file=rom_file)
    fcw = calculate_fcw(440.0)
    model.tick(True, 5, fcw, fcw, fcw, fcw, 0b1111, False, False)
    model.reset()
    assert model.state == "IDLE", "复位后应为IDLE"
    for dds in model.dds:
        assert dds.phase == 0, "复位后相位应为0"
    print("  PASS\n")

def main():
    print("=" * 70)
    print("T052 Python单元测试（返修v2）")
    print("=" * 70)
    print()
    rom_file = "generated/wavetables/sine_1024_8192.mem"
    if not os.path.exists(rom_file):
        print(f"错误: ROM文件不存在: {rom_file}")
        print("测试将跳过需要ROM的项目")
        return 1
    try:
        test_fcw_calculation()
        test_single_voice()
        test_four_voices()
        test_voice_mask()
        test_cancel()
        test_reset()
        print("=" * 70)
        print("所有6项测试通过")
        print("=" * 70)
        return 0
    except AssertionError as e:
        print(f"\n错误: {e}")
        return 1
    except Exception as e:
        print(f"\n异常: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
