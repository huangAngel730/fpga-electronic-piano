# T052 Testbench 使用说明（返修v2）

## 概述

本目录包含T052四声部复音测试源的SystemVerilog testbench和Python运行器（返修v2版本）。

## 返修v2主要变更

1. **外部采样请求**：移除内部sample_counter，使用外部sample_request输入
2. **完整接口**：添加request_id、voice_enable、result_ready、四路独立PCM、active_voice_count
3. **取消逻辑修复**：PROCESSING状态的取消阻止结果发布
4. **移除automatic**：修复Icarus Verilog兼容性
5. **16种mask测试**：覆盖所有voice_enable组合
6. **频点修正**：440/880/1760/3520Hz（非原来的220/440/880/1760Hz）

## 文件列表

- `tb_t052_polyphony.sv` - SystemVerilog testbench
- `run_tb.py` - Python仿真运行器
- `README.md` - 本文件

## 前置条件

### RTL仿真
需要Icarus Verilog工具链：
- `iverilog` - Verilog编译器（版本14.0+）
- `vvp` - Verilog仿真器

### Python环境
- Python 3.7+
- 无额外依赖

### ROM文件
需要波表ROM文件：
```
code/model/generated/wavetables/sine_1024_8192.mem
```

## 使用方法

### 方式1: Python运行器（推荐）

```bash
cd code/tb/audio/t052_polyphony
python run_tb.py
```

运行器会自动：
1. 查找项目根目录和依赖文件
2. 创建ASCII临时目录
3. 编译所有必需的源文件
4. 运行仿真（超时300秒）
5. 检查PASS标记和成功计数
6. 生成捕获文件

### 方式2: 手动运行

**编译**:
```bash
iverilog -g2012 -o tb.vvp \
  -I ../../../rtl \
  -I ../../../rtl/audio \
  t052_polyphony_test_source.sv \
  ../../../rtl/audio/dds_oscillator.sv \
  tb_t052_polyphony.sv
```

**运行**:
```bash
vvp tb.vvp +WAVETABLE_PATH=../../../model/generated/wavetables/sine_1024_8192.mem
```

## 测试场景

Testbench执行6个测试场景：

1. **单声部440Hz** (10次, voice_enable=0001)
   - 验证单个DDS振荡器工作

2. **四声部440/880/1760/3520Hz** (10次, voice_enable=1111)
   - 验证四路混音和同步采样

3. **Mask测试** (5次, voice_enable=0101)
   - 验证voice_enable mask功能

4. **16种mask组合** (16次)
   - 遍历所有可能的voice_enable组合（0000-1111）

5. **大量随机请求** (4096次)
   - 压力测试，满足"至少4096个成功结果"要求
   - 随机FCW值，全部声部使能

6. **取消测试**
   - 验证PROCESSING状态的cancel不发布结果

## 成功标准

仿真成功需要：
- ✅ 编译无错误
- ✅ 运行无fatal错误
- ✅ 至少4096个成功的PCM输出
- ✅ 所有PCM值在16-bit有符号范围内
- ✅ 取消测试通过（无T052_CANCELLED_REQUEST_PUBLISHED错误）
- ✅ 生成捕获文件
- ✅ 输出"PASS: 至少4096个成功结果"

## 输出文件

- `tb.vvp` - 编译后的仿真可执行文件
- `tb_t052_polyphony.capture` - PCM输出捕获文件

捕获文件格式：
```
ID=<req_id> PCM v0=<voice0> v1=<voice1> v2=<voice2> v3=<voice3> ACT=<count> CLIP=<0|1>
```

## 接口说明

### 新增接口（vs 原版）

**输入**:
- `request_id[7:0]` - 请求ID（0-255）
- `voice_enable[3:0]` - 声部使能mask（bit i对应lane i）
- `sample_request` - 外部采样请求（50MHz/1042=47.986kHz）

**输出**:
- `result_ready` - 结果就绪（替代pcm_valid）
- `result_id[7:0]` - 结果ID（对应请求ID）
- `pcm_voice0/1/2/3[15:0]` - 四路独立PCM输出
- `active_voice_count[2:0]` - 活跃声部数（0-4）

## 常见问题

### 1. 编译错误：automatic不支持
**问题**: Icarus报错不支持automatic声明

**解决**: 已在返修v2中移除所有automatic声明

### 2. 取消测试失败：T052_CANCELLED_REQUEST_PUBLISHED
**问题**: 取消后仍发布PCM结果

**解决**: 已修复，PROCESSING状态取消后不进入COMMIT

### 3. 位宽溢出：sample_counter为18
**问题**: `10'd1042`被截断

**解决**: 已改为`11'd1042`，使用11-bit计数器

### 4. runner路径错误
**问题**: 无法找到依赖文件

**解决**: 使用find_project_root()自动查找项目根目录

### 5. 缺ROM时误报通过
**问题**: ROM不存在时仍退出0

**解决**: 已修复，缺ROM返回非零退出码

## 验证等级

本TB提供的验证等级：
- ✅ **RTL功能验证**: 通过仿真验证RTL行为
- ✅ **接口完整性**: 验证所有输入输出信号
- ✅ **边界测试**: 16种mask组合
- ✅ **取消语义**: 验证取消不发布结果
- ❌ **Gowin综合**: 由M2负责
- ❌ **PnR和STA**: 由M2负责
- ❌ **板级验证**: 由M3负责

## 注意事项

1. TB使用随机数生成FCW，每次运行结果会不同
2. 捕获文件仅用于调试，不代替现场音频分析
3. 仿真通过不等于FPGA实际工作正常
4. 需要M2进行综合和时序分析
5. 需要M3进行现场音频验证

## 参考

- RTL模块: `code/rtl/audio/t052_polyphony_test_source.sv`
- Python模型: `code/model/t052_polyphony_reference.py`
- M2反馈: `M1_T052返修包_M2独立复核反馈_2026-10-11.md`
