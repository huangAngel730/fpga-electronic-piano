// T052 四声部复音纯正弦测试源（返修v2）
// 修复：外部sample请求、完整接口、取消逻辑、四路独立PCM
`timescale 1ns/1ps

module t052_polyphony_test_source #(
    parameter ROM_FILE = "model/generated/wavetables/sine_1024_8192.mem"
) (
    input  logic        sys_clk,
    input  logic        sys_rst_n,
    input  logic        req_valid,
    output logic        req_ready,
    input  logic [7:0]  request_id,
    input  logic [31:0] fcw_lane0,
    input  logic [31:0] fcw_lane1,
    input  logic [31:0] fcw_lane2,
    input  logic [31:0] fcw_lane3,
    input  logic [3:0]  voice_enable,
    input  logic        cancel,
    input  logic        sample_request,
    output logic        result_ready,
    output logic [7:0]  result_id,
    output logic signed [15:0] pcm_voice0,
    output logic signed [15:0] pcm_voice1,
    output logic signed [15:0] pcm_voice2,
    output logic signed [15:0] pcm_voice3,
    output logic [2:0]  active_voice_count,
    output logic        clip_any
);

    typedef enum logic [1:0] {
        IDLE, PROCESSING, COMMIT
    } state_t;

    state_t state, state_next;
    logic [31:0] fcw_latched[0:3];
    logic [3:0]  voice_enable_latched;
    logic [7:0]  request_id_latched;
    logic        cancelled;

    always_ff @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            state <= IDLE;
            cancelled <= 1'b0;
            fcw_latched[0] <= 32'h0;
            fcw_latched[1] <= 32'h0;
            fcw_latched[2] <= 32'h0;
            fcw_latched[3] <= 32'h0;
            voice_enable_latched <= 4'h0;
            request_id_latched <= 8'h0;
        end else begin
            state <= state_next;
            if (state == IDLE && req_valid && !cancel) begin
                cancelled <= 1'b0;
                fcw_latched[0] <= fcw_lane0;
                fcw_latched[1] <= fcw_lane1;
                fcw_latched[2] <= fcw_lane2;
                fcw_latched[3] <= fcw_lane3;
                voice_enable_latched <= voice_enable;
                request_id_latched <= request_id;
            end else if (state == PROCESSING && cancel) begin
                cancelled <= 1'b1;
            end else if (state == COMMIT) begin
                cancelled <= 1'b0;
            end
        end
    end

    always_comb begin
        state_next = state;
        case (state)
            IDLE: if (req_valid && !cancel) state_next = PROCESSING;
            PROCESSING: begin
                if (cancelled) state_next = IDLE;
                else if (sample_request) state_next = COMMIT;
            end
            COMMIT: state_next = IDLE;
            default: state_next = IDLE;
        endcase
    end

    assign req_ready = (state == IDLE) && !cancel;

    logic signed [15:0] wt_sample[0:3];
    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : gen_dds
            dds_oscillator #(.ROM_FILE(ROM_FILE)) dds_inst (
                .sys_clk(sys_clk),
                .sys_rst_n(sys_rst_n),
                .sample_tick(sample_request && (state == PROCESSING) && !cancelled),
                .fcw(fcw_latched[i]),
                .wt_sample(wt_sample[i])
            );
        end
    endgenerate

    logic signed [15:0] masked_sample[0:3];
    logic [2:0] active_count;
    always_comb begin
        active_count = 3'd0;
        for (int j = 0; j < 4; j = j + 1) begin
            if (voice_enable_latched[j]) begin
                masked_sample[j] = wt_sample[j];
                active_count = active_count + 1;
            end else begin
                masked_sample[j] = 16'sd0;
            end
        end
    end

    always_ff @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            result_ready <= 1'b0;
            result_id <= 8'h0;
            pcm_voice0 <= 16'sd0;
            pcm_voice1 <= 16'sd0;
            pcm_voice2 <= 16'sd0;
            pcm_voice3 <= 16'sd0;
            active_voice_count <= 3'd0;
            clip_any <= 1'b0;
        end else begin
            if (state == COMMIT && !cancelled) begin
                result_ready <= 1'b1;
                result_id <= request_id_latched;
                pcm_voice0 <= masked_sample[0];
                pcm_voice1 <= masked_sample[1];
                pcm_voice2 <= masked_sample[2];
                pcm_voice3 <= masked_sample[3];
                active_voice_count <= active_count;
                clip_any <= (masked_sample[0] >= 16'sh7F00 || masked_sample[0] <= -16'sh7F00) ||
                           (masked_sample[1] >= 16'sh7F00 || masked_sample[1] <= -16'sh7F00) ||
                           (masked_sample[2] >= 16'sh7F00 || masked_sample[2] <= -16'sh7F00) ||
                           (masked_sample[3] >= 16'sh7F00 || masked_sample[3] <= -16'sh7F00);
            end else begin
                result_ready <= 1'b0;
            end
        end
    end

endmodule
