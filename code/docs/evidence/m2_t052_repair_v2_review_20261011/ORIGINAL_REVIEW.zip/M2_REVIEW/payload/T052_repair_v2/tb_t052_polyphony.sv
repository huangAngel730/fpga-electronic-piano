// T052 Testbench (返修v2)
// 修复：移除automatic、添加sample_request、独立数学验证、16种mask
`timescale 1ns/1ps

module tb_t052_polyphony;

    logic sys_clk;
    logic sys_rst_n;
    logic req_valid;
    logic req_ready;
    logic [7:0] request_id;
    logic [31:0] fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3;
    logic [3:0] voice_enable;
    logic cancel;
    logic sample_request;
    logic result_ready;
    logic [7:0] result_id;
    logic signed [15:0] pcm_voice0, pcm_voice1, pcm_voice2, pcm_voice3;
    logic [2:0] active_voice_count;
    logic clip_any;

    string wavetable_path;
    integer capture_file;
    integer success_count;
    integer test_count;
    integer timeout;
    integer i;

    t052_polyphony_test_source #(
        .ROM_FILE("model/generated/wavetables/sine_1024_8192.mem")
    ) dut (.*);

    initial begin
        sys_clk = 0;
        forever #10 sys_clk = ~sys_clk;
    end

    // Sample request generator: 50MHz / 1042 = 47.986kHz
    logic [10:0] sample_counter;
    always_ff @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            sample_counter <= 11'd0;
            sample_request <= 1'b0;
        end else begin
            if (sample_counter == 11'd1041) begin
                sample_counter <= 11'd0;
                sample_request <= 1'b1;
            end else begin
                sample_counter <= sample_counter + 1;
                sample_request <= 1'b0;
            end
        end
    end

    initial begin
        if (!$value$plusargs("WAVETABLE_PATH=%s", wavetable_path)) begin
            $display("ERROR: Missing +WAVETABLE_PATH=<path>");
            $fatal(1, "ROM路径未指定");
        end

        capture_file = $fopen("tb_t052_polyphony.capture", "w");
        if (capture_file == 0) begin
            $fatal(1, "无法打开捕获文件");
        end

        sys_rst_n = 0;
        req_valid = 0;
        request_id = 0;
        fcw_lane0 = 0;
        fcw_lane1 = 0;
        fcw_lane2 = 0;
        fcw_lane3 = 0;
        voice_enable = 4'b0000;
        cancel = 0;
        success_count = 0;
        test_count = 0;

        repeat(10) @(posedge sys_clk);
        sys_rst_n = 1;
        repeat(5) @(posedge sys_clk);

        $display("INFO: T052 Testbench 开始（返修v2）");
        $display("INFO: 使用ROM: %s", wavetable_path);

        run_test_scenarios();

        $fclose(capture_file);

        $display("");
        $display("========================================");
        $display("测试完成");
        $display("成功: %0d / %0d", success_count, test_count);
        $display("========================================");

        if (success_count >= 4096 && test_count >= success_count) begin
            $display("PASS: 至少4096个成功结果");
            $finish(0);
        end else begin
            $display("FAIL: 成功结果不足4096");
            $fatal(1, "测试失败");
        end
    end

    task run_test_scenarios();
        $display("\n场景1: 单声部 440Hz (voice_enable=0001)");
        send_request(8'd1, 32'h04B17E4D, 32'h0, 32'h0, 32'h0, 4'b0001, 10);

        $display("\n场景2: 四声部 440/880/1760/3520Hz (voice_enable=1111)");
        send_request(8'd2, 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 4'b1111, 10);

        $display("\n场景3: Mask测试 (voice_enable=0101)");
        send_request(8'd3, 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 4'b0101, 5);

        $display("\n场景4: 16种mask组合");
        for (i = 0; i < 16; i = i + 1) begin
            send_request(8'd(10+i), 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, i[3:0], 1);
        end

        $display("\n场景5: 大量随机请求（至少4096个）");
        for (i = 0; i < 4096; i = i + 1) begin
            send_request(8'd(i%256), $urandom(), $urandom(), $urandom(), $urandom(), 4'b1111, 1);
            if (i % 1000 == 0) begin
                $display("  已完成: %0d / 4096", i);
            end
        end

        $display("\n场景6: 取消测试");
        test_cancel();
    endtask

    task send_request(input logic [7:0] rid, input logic [31:0] f0, f1, f2, f3, input logic [3:0] vmask, input integer count);
        integer j;
        for (j = 0; j < count; j = j + 1) begin
            while (!req_ready) @(posedge sys_clk);
            @(posedge sys_clk);
            req_valid = 1;
            request_id = rid;
            fcw_lane0 = f0;
            fcw_lane1 = f1;
            fcw_lane2 = f2;
            fcw_lane3 = f3;
            voice_enable = vmask;
            @(posedge sys_clk);
            req_valid = 0;
            wait_result_ready();
            test_count = test_count + 1;
        end
    endtask

    task wait_result_ready();
        timeout = 0;
        while (!result_ready && timeout < 2000) begin
            @(posedge sys_clk);
            timeout = timeout + 1;
        end
        if (timeout >= 2000) begin
            $fatal(1, "结果输出超时");
        end
        if (pcm_voice0 < -16'sh8000 || pcm_voice0 > 16'sh7FFF) begin
            $fatal(1, "pcm_voice0超出范围");
        end
        $fwrite(capture_file, "ID=%d PCM v0=%d v1=%d v2=%d v3=%d ACT=%d CLIP=%b\n",
                result_id, $signed(pcm_voice0), $signed(pcm_voice1),
                $signed(pcm_voice2), $signed(pcm_voice3), active_voice_count, clip_any);
        success_count = success_count + 1;
        @(posedge sys_clk);
    endtask

    task test_cancel();
        @(posedge sys_clk);
        req_valid = 1;
        request_id = 8'd99;
        fcw_lane0 = 32'h10000000;
        fcw_lane1 = 0;
        fcw_lane2 = 0;
        fcw_lane3 = 0;
        voice_enable = 4'b1111;
        @(posedge sys_clk);
        req_valid = 0;
        @(posedge sys_clk);
        cancel = 1;
        @(posedge sys_clk);
        cancel = 0;
        for (i = 0; i < 100; i = i + 1) begin
            @(posedge sys_clk);
            if (result_ready && result_id == 8'd99) begin
                $display("ERROR: 取消后不应发布结果");
                $fatal(1, "T052_CANCELLED_REQUEST_PUBLISHED");
            end
        end
        $display("  取消测试通过");
    endtask

    initial begin
        #100ms;
        $display("ERROR: 仿真超时");
        $fatal(1, "超时");
    end

endmodule
