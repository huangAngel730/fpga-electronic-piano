#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 Python仿真运行器（返修v2）"""
import sys
import os
import subprocess
import tempfile
import shutil
from pathlib import Path


def find_project_root():
    """查找项目根目录（包含code/目录）"""
    current = Path(__file__).resolve().parent
    for _ in range(5):
        if (current / "code").is_dir():
            return current
        if current.parent == current:
            break
        current = current.parent
    return None


def run_tb_t052_polyphony(work_dir: Path, rom_file: Path, base_dir: Path, timeout: int = 300) -> dict:
    """运行T052 testbench"""
    result = {
        'success': False,
        'exit_code': -1,
        'stdout': '',
        'stderr': '',
        'capture_file': None
    }

    if not rom_file.exists():
        result['stderr'] = f"ROM文件不存在: {rom_file}"
        return result

    try:
        subprocess.run(['iverilog', '-V'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        result['stderr'] = "iverilog未找到，跳过RTL仿真"
        result['exit_code'] = -2
        return result

    work_dir.mkdir(parents=True, exist_ok=True)

    # 源文件路径
    rtl_dir = base_dir / "code" / "rtl"
    sources = [
        Path(__file__).parent / "t052_polyphony_test_source.sv",
        rtl_dir / "audio" / "dds_oscillator.sv",
        Path(__file__).parent / "tb_t052_polyphony.sv"
    ]

    missing = [str(s) for s in sources if not s.exists()]
    if missing:
        result['stderr'] = f"源文件缺失: {missing}"
        return result

    print("编译RTL...")
    compile_cmd = [
        'iverilog',
        '-g2012',
        '-o', str(work_dir / 'tb.vvp'),
        '-I', str(rtl_dir),
        '-I', str(rtl_dir / 'audio'),
    ] + [str(s) for s in sources]

    try:
        proc = subprocess.run(
            compile_cmd,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=str(work_dir)
        )
        result['stdout'] += proc.stdout
        result['stderr'] += proc.stderr

        if proc.returncode != 0:
            result['exit_code'] = proc.returncode
            return result

        print("  编译成功")
    except subprocess.TimeoutExpired:
        result['stderr'] += "\n编译超时"
        return result

    print("运行仿真...")
    run_cmd = [
        'vvp',
        str(work_dir / 'tb.vvp'),
        f'+WAVETABLE_PATH={rom_file.resolve()}'
    ]

    try:
        proc = subprocess.run(
            run_cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(work_dir),
            encoding='utf-8',
            errors='replace'
        )
        result['stdout'] += proc.stdout
        result['stderr'] += proc.stderr
        result['exit_code'] = proc.returncode

        capture_file = work_dir / "tb_t052_polyphony.capture"
        if capture_file.exists():
            result['capture_file'] = capture_file

        if "PASS: 至少4096个成功结果" in result['stdout']:
            result['success'] = True
            print("  仿真通过")
        else:
            print(f"  仿真失败 (exit {result['exit_code']})")

    except subprocess.TimeoutExpired:
        result['stderr'] += f"\n仿真超时 ({timeout}秒)"
        result['exit_code'] = -3

    return result


def main():
    print("=" * 70)
    print("T052 Python仿真运行器（返修v2）")
    print("=" * 70)
    print()

    base_dir = find_project_root()
    if not base_dir:
        print("错误: 无法找到项目根目录")
        return 1

    print(f"项目根目录: {base_dir}")

    rom_file = base_dir / "code" / "model" / "generated" / "wavetables" / "sine_1024_8192.mem"

    if not rom_file.exists():
        print(f"错误: ROM文件不存在: {rom_file}")
        return 1

    with tempfile.TemporaryDirectory(prefix='t052_', dir='C:/Temp' if os.path.exists('C:/Temp') else None) as tmpdir:
        work_dir = Path(tmpdir) / "tb_t052_polyphony"

        print(f"工作目录: {work_dir}")
        print(f"ROM文件: {rom_file}")
        print()

        result = run_tb_t052_polyphony(work_dir, rom_file, base_dir, timeout=300)

        print()
        print("=" * 70)
        print("仿真结果")
        print("=" * 70)
        print(f"退出码: {result['exit_code']}")
        print(f"成功: {result['success']}")

        if result['capture_file'] and result['capture_file'].exists():
            lines = result['capture_file'].read_text(encoding='utf-8', errors='replace').splitlines()
            print(f"捕获行数: {len(lines)}")

        print()
        print("标准输出:")
        print(result['stdout'][-2000:] if len(result['stdout']) > 2000 else result['stdout'])

        if result['stderr']:
            print()
            print("标准错误:")
            print(result['stderr'][-1000:] if len(result['stderr']) > 1000 else result['stderr'])

        return 0 if result['success'] else 1


if __name__ == "__main__":
    sys.exit(main())
