// M2 diagnostics only. The delivered DUT and true DDS remain unchanged.
`timescale 1ns/1ps
module tb_m2_t052_v2_diagnostic;
  reg sys_clk=0, sys_rst_n=0, req_valid=0, cancel=0, sample_request=0;
  reg [7:0] request_id=0;
  reg [31:0] fcw_lane0=32'h017fffff, fcw_lane1=32'h02468013;
  reg [31:0] fcw_lane2=32'h038abcde, fcw_lane3=32'h05271357;
  reg [3:0] voice_enable=15;
  wire req_ready,result_ready,clip_any;
  wire [7:0] result_id;
  wire signed [15:0] pcm_voice0,pcm_voice1,pcm_voice2,pcm_voice3;
  wire [2:0] active_voice_count;
  integer mode=0,i,guard,count=0;
  t052_polyphony_test_source dut(.*);
  always #10 sys_clk=~sys_clk;
  task request(input integer id, mask);
    begin
      @(negedge sys_clk);
      while(!req_ready) @(negedge sys_clk);
      request_id=id; voice_enable=mask; req_valid=1;
      @(negedge sys_clk); req_valid=0;
    end
  endtask
  task sample;
    begin
      repeat(3) @(negedge sys_clk);
      sample_request=1;
      @(negedge sys_clk); sample_request=0;
    end
  endtask
  task wait_result;
    begin
      guard=0;
      while(!result_ready && guard<20) begin @(posedge sys_clk); #1; guard=guard+1; end
      if(!result_ready) $fatal(1,"DIAGNOSTIC_RESULT_TIMEOUT");
    end
  endtask
  initial begin
    if(!$value$plusargs("CASE=%d",mode)) mode=0;
    repeat(4) @(negedge sys_clk); sys_rst_n=1;
    repeat(2) @(negedge sys_clk);
    if(mode==0) begin
      for(i=0;i<64;i=i+1) begin
        request(i,i%16); sample(); wait_result();
        $display("V2PCM %0d %0d %0d %0d %0d %0d %0d %0d %0d",i,result_id,i%16,
          $signed(pcm_voice0),$signed(pcm_voice1),$signed(pcm_voice2),$signed(pcm_voice3),
          active_voice_count,clip_any);
        count=count+1;
        repeat(2) @(negedge sys_clk);
      end
      $display("M2_CAPTURE_ONLY samples=%0d",count); $finish;
    end else if(mode==1) begin
      request(11,15);
      cancel=1;
      repeat(4) begin @(posedge sys_clk); #1; if(result_ready) $fatal(1,"PROCESSING_CANCEL_PUBLISHED"); end
      @(negedge sys_clk); cancel=0;
      $display("V2_PROCESSING_CANCEL_NONCOINCIDENT_PASS"); $finish;
    end else if(mode==2) begin
      request(22,15); sample();
      // sample() returns on the negative edge preceding the COMMIT edge.
      cancel=1;
      @(posedge sys_clk); #1;
      $display("COMMIT_CANCEL result_ready=%0d id=%0d",result_ready,result_id);
      if(result_ready) $fatal(1,"V2_COMMIT_CANCEL_PUBLISHED");
      $display("V2_COMMIT_CANCEL_PASS"); $finish;
    end else if(mode==3) begin
      fcw_lane0=32'h40000000;fcw_lane1=32'h40000000;
      fcw_lane2=32'h40000000;fcw_lane3=32'h40000000;
      request(30,15); sample();wait_result(); repeat(2) @(negedge sys_clk);
      request(31,15); sample();wait_result();
      $display("SATURATION_PROBE %0d %0d %0d %0d clip=%0d",
          $signed(pcm_voice0),$signed(pcm_voice1),$signed(pcm_voice2),$signed(pcm_voice3),clip_any);
      if(pcm_voice0!==16'sd8192 || pcm_voice1!==16'sd8192 || pcm_voice2!==16'sd8192 || pcm_voice3!==16'sd8192)
        $fatal(1,"SATURATION_FIXTURE_NOT_AT_POSITIVE_PEAK");
      if(!clip_any) $fatal(1,"V2_PCM24_POSITIVE_SATURATION_NOT_REPORTED");
      $finish;
    end else if(mode==4) begin
      request(44,15);
      repeat(3) @(negedge sys_clk);
      cancel=1;sample_request=1;
      @(posedge sys_clk); #1;
      // Context only: observed phase is diagnosed externally against model.
      $display("COINCIDENT_CANCEL_PHASE %0d",dut.gen_dds[0].dds_inst.phase_acc);
      @(negedge sys_clk); cancel=0;sample_request=0;
      repeat(5) begin @(posedge sys_clk); #1; if(result_ready) $fatal(1,"COINCIDENT_CANCEL_RESULT_PUBLISHED"); end
      $display("V2_COINCIDENT_CANCEL_CAPTURE_ONLY"); $finish;
    end else if(mode==5) begin
      // No post-compute ready input exists. Observe automatic result disappearance.
      request(55,15);sample();wait_result();
      $display("RESULT_PULSE current=%0d",result_ready);
      @(posedge sys_clk); #1; $display("RESULT_PULSE next=%0d",result_ready);
      if(!result_ready) $fatal(1,"V2_RESULT_NOT_HELD_NO_RESULT_READY_INPUT");
      $finish;
    end else $fatal(1,"INVALID_DIAGNOSTIC_CASE");
  end
  initial begin #1000000; $fatal(1,"M2_DIAGNOSTIC_WATCHDOG"); end
endmodule
