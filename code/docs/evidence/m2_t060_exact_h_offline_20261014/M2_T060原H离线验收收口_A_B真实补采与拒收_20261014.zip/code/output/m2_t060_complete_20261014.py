"""User-authorized T060 diagnostic and minimum closure orchestration.

Every attempt has new exclusive output. Original H, consumed old marker,
failed capture attempt and current user changes are immutable.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OLD = Path('C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin')
DIAG = OLD / 'code/output/M2_T060_compile_diagnostic_20261013_01'
DIAG_OUT = ROOT / 'code/output/M2_T060_compile_actual_20261014_01'
ARCHIVE = OLD / 'code/docs/evidence/m2_ab_failure_t052_static_review_20261013/RAW_EVIDENCE.zip'
PREFIX = 'received/T060/m3_t060_AB_authorized_20261012_01/'
CAD = Path('D:/Gowin/oss-cad-suite')
ORIGINAL_RUNNER = OLD / 'code/software/audio_math_acceptance_candidate/t060_minclosure_20261011/controlled_runner.py'
PORTABLE = ROOT / 'code/output/M2_T060_fresh_inputs_20261014_01'
AB_OUT = ROOT / 'code/output/M2_T060_fresh_AB_20261014_01'
PYTHON = Path('C:/Users/Angel17/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')


def identity(path):
    data = Path(path).read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def dump(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def load_runner(path):
    sys.path.insert(0, str(Path(path).parent))
    spec = importlib.util.spec_from_file_location('exact_controlled_runner', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def diagnostic():
    started = time.monotonic()
    DIAG_OUT.mkdir(exist_ok=False)
    lib = load_runner(ORIGINAL_RUNNER)
    budget = lib.Budget(90)
    budget.started = started
    receipt = dict(status='FAIL_PARTIAL', exit_code=1, failure=None, tool_runs=0,
                   automatic_retries=0, total_limit_seconds=90, lower_runs=0,
                   vvp_runs=0, new_EDA_calls=0, machine=platform.node(),
                   authorization='User2026-10-14: complete T060; fresh independent diagnostic then minimum A/B',
                   old_attempt_restored=False, steps=[])
    try:
        p = DIAG / 'diagnostic_receipt.json'
        assert identity(p)['sha256'] == '0afd1c24967ac27b674e87c3b3839b3e42f713f255416c18e486765138c44c7d'
        prepared = json.loads(p.read_bytes())
        work = DIAG_OUT / 'inputs'
        work.mkdir()
        before = {}
        for name, expected in prepared['inputs'].items():
            budget.limit(90)
            source = DIAG / 'inputs' / name
            assert identity(source) == expected, name
            before[str(source)] = expected
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(source.read_bytes())
            assert identity(target) == expected
        tool_before = {}
        for name, expected in prepared['proposed_tool_files'].items():
            budget.limit(90)
            assert identity(Path(name)) == expected, name
            tool_before[name] = expected
        assert not (work / 'diagnostic_A.vvp').exists()
        command = prepared['proposed_command']
        receipt.update(command=command, cwd=str(work), sources_before=before,
                       tools_before=tool_before, diagnostic_preparation=identity(p))
        dump(DIAG_OUT / 'NEW_DIAGNOSTIC_ATTEMPT.json', dict(machine=platform.node(),
             authority=receipt['authorization'], preparation=identity(p), attempt=1))
        env = os.environ.copy()
        env['PATH'] = os.pathsep.join([str(CAD/'bin'), str(CAD/'lib'), env.get('PATH','')])
        env['YOSYSHQ_ROOT'] = str(CAD) + os.sep
        receipt['tool_runs'] = 1
        receipt['steps'].append(lib.step(DIAG_OUT, 'compile_only', command, work, budget, 90, env=env))
        assert (work / 'diagnostic_A.vvp').is_file()
        receipt['new_vvp_identity_only_NOT_EXECUTED'] = identity(work/'diagnostic_A.vvp')
        after = {name: identity(Path(name)) for name in before}
        tool_after = {name: identity(Path(name)) for name in tool_before}
        budget.limit(90)
        assert before == after and tool_before == tool_after
        receipt.update(status='COMPILE_ONLY_PASS_NOT_AUDIO_ACCEPTANCE', exit_code=0,
                       sources_after=after, tools_after=tool_after)
    except Exception as error:
        receipt.update(failure=type(error).__name__+': '+str(error))
    receipt['elapsed_seconds'] = time.monotonic()-started
    if receipt['elapsed_seconds'] >= 90:
        receipt.update(status='FAIL_PARTIAL', exit_code=1, failure='DIAGNOSTIC_TOTAL90')
    dump(DIAG_OUT/'receipt.json', receipt)
    if time.monotonic()-started >= 90:
        receipt.update(status='FAIL_PARTIAL', exit_code=1, failure='DIAGNOSTIC_RECEIPT_TAIL90')
        dump(DIAG_OUT/'terminal_failure.json', receipt)
    print(json.dumps({k:receipt[k] for k in ['status','exit_code','failure','tool_runs','elapsed_seconds']}))
    return receipt['exit_code']


def prepare_ab():
    started = time.monotonic()
    diagnostic_receipt = json.loads((DIAG_OUT/'receipt.json').read_bytes())
    assert diagnostic_receipt['exit_code'] == 0 and diagnostic_receipt['tool_runs'] == 1
    assert diagnostic_receipt['vvp_runs'] == 0
    assert identity(ARCHIVE)['sha256'] == '6a531fae9c846ad2098c26919cc063cac9df9e84f7ff89a18e4d4890c92ccf56'
    PORTABLE.mkdir(exist_ok=False)
    with zipfile.ZipFile(ARCHIVE) as archive:
        original = json.loads(archive.read(PREFIX+'receipt.json'))
        pins = original['sources_before']
        assert len(pins) == 177
        for name, expected in pins.items():
            relative = Path(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            data = archive.read(PREFIX+'snapshot/'+name)
            assert dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) == expected
            target = PORTABLE/relative
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:
                stream.write(data)
    tools = {name:(CAD/('bin/'+name+'.exe')).as_posix() for name in ['yosys','iverilog','vvp']}
    tools['python'] = PYTHON.as_posix()
    paths = {Path(path) for path in tools.values()}
    for folder in [CAD/'bin',CAD/'lib',PYTHON.parent]:
        paths.update(folder.glob('*.dll'))
        if folder == PYTHON.parent:
            paths.update(folder.glob('python*.zip'))
    for folder in [CAD/'lib/ivl',CAD/'share/yosys',PYTHON.parent/'DLLs',PYTHON.parent/'Lib']:
        assert folder.is_dir()
        paths.update(p for p in folder.rglob('*') if p.is_file() and 'site-packages' not in p.parts and '__pycache__' not in p.parts)
    inventories = {}
    for path in sorted(paths):
        assert time.monotonic()-started < 300
        inventories[path.as_posix()] = identity(path)
    d = json.loads((DIAG/'diagnostic_receipt.json').read_bytes())
    for name,expected in d['proposed_tool_files'].items():
        assert inventories[name] == expected
    for group in ['A','B']:
        assert not (PORTABLE/('future_group_'+group)/(group+'.vvp')).exists()
        assert not (PORTABLE/('future_group_'+group)/'allocator.v').exists()
        assert not (PORTABLE/('future_group_'+group)/'minclosure.jsonl').exists()
    compile_sources = d['proposed_command'][10:-2]
    assert len(compile_sources)==18 and all(path.startswith('sources/') for path in compile_sources)
    config = dict(schema=1,execution_authorized=False,groups=['A','B'],total_seconds=900,
        proposed_execution_machine=dict(role='M2_CURRENT_MACHINE_NEW_USER_AUTHORIZED_ATTEMPT',computer_name=platform.node()),
        tools=tools,tool_files=inventories,inputs=pins,
        software_relative='code/software/audio_math_acceptance_candidate/t060_minclosure_20261011',
        tb_relative='code/tb/board/m3_midi_pcm_acceptance/t060_minclosure_20261011',
        compile_sources=compile_sources,end_cycles={'A':4095000,'B':1600},
        mutations={'A':[['retirement_reuse_wrong_generation','MINCLOSURE_RETIRE_IDENTITY'],
                        ['accepted_panic_missing_off','MINCLOSURE_PANIC_RELEASE']],
                   'B':[['frame_accepts_old_result','MINCLOSURE_CANCEL_OLD_ID'],
                        ['advance_rolled_back','MINCLOSURE_ADVANCE_NONROLLBACK_MATH']]},
        old_permission_restored=False,baseline='EXACT_OLD_H_BYTE_IDENTICAL',
        diagnostic=identity(DIAG_OUT/'receipt.json'),new_user_authorization='2026-10-14 user: complete T060',
        static_dependency_inventory_not_observed_DLL_loads=True)
    config_path = PORTABLE/'CONTROLLED_CONFIG_NEW_LOCAL.json'
    dump(config_path,config)
    approval = dict(authority='M2',execution_authorized=True,config_sha256=identity(config_path)['sha256'],
        groups=['A','B'],attempt=1,notice='User2026-10-14 explicitly requested complete T060. Independent90s compile-only diagnostic passed. New exact H A/B one attempt900s, lower/compile90s capture300s software90s; no retry/EDA/device, old marker immutable.')
    dump(PORTABLE/'M2_NEW_AB_APPROVAL.json',approval)
    proof=dict(status='FRESH_EXACT_AB_PREPARED',inputs=177,tool_files=len(inventories),
        original_archive=identity(ARCHIVE),new_config=identity(config_path),approval=identity(PORTABLE/'M2_NEW_AB_APPROVAL.json'),
        all177_original_bytes_unchanged=True,new_tool_execution=False,old_residual_copied=False,
        original_tool_identity_may_differ=True,new_machine=platform.node(),seconds=time.monotonic()-started)
    assert proof['seconds'] < 300
    dump(PORTABLE/'NEW_PREPARATION_RECEIPT.json',proof)
    print(json.dumps(proof))
    return 0


def execute_ab():
    config_path = PORTABLE/'CONTROLLED_CONFIG_NEW_LOCAL.json'
    prepared = json.loads((PORTABLE/'NEW_PREPARATION_RECEIPT.json').read_bytes())
    assert identity(config_path) == prepared['new_config']
    assert identity(PORTABLE/'M2_NEW_AB_APPROVAL.json') == prepared['approval']
    assert not AB_OUT.exists() and not (PORTABLE/'ONE_SHOT_ATTEMPT.json').exists()
    runner = PORTABLE/'code/software/audio_math_acceptance_candidate/t060_minclosure_20261011/controlled_runner.py'
    lib = load_runner(runner)
    result = lib.run(config_path,AB_OUT,PORTABLE/'M2_NEW_AB_APPROVAL.json')
    print(json.dumps({k:result.get(k) for k in ['status','exit_code','failure','elapsed_seconds','execution_authorized']}))
    return result['exit_code']


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['diagnostic','prepare-ab','execute-ab'])
    args = parser.parse_args()
    raise SystemExit({'diagnostic':diagnostic,'prepare-ab':prepare_ab,'execute-ab':execute_ab}[args.mode]())
