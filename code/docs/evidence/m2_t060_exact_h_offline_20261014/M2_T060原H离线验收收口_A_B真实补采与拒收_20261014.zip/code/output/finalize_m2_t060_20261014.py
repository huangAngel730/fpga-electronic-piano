"""Close exact T060 offline scope from signed old and real new evidence.

No replay of old captures, no new tool calls, no modification of old receipts.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OLD = Path('C:/Users/Angel17/.codex/worktrees/m2-138k-migration/fpga_gowin')
RUN = ROOT / 'code/output/M2_T060_fresh_AB_20261014_01'
PREP = ROOT / 'code/output/M2_T060_fresh_inputs_20261014_01'
DIAG = ROOT / 'code/output/M2_T060_compile_actual_20261014_01'
DEST = ROOT / 'code/output/M2_T060_completed_delivery_20261014_01'
HERE = PREP / 'code/software/audio_math_acceptance_candidate/t060_minclosure_20261011'


def ident(path):
    data = Path(path).read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


diagnostic = json.loads((DIAG/'receipt.json').read_bytes())
assert diagnostic['exit_code'] == 0 and diagnostic['tool_runs'] == 1
assert diagnostic['lower_runs'] == 0 and diagnostic['vvp_runs'] == 0
assert diagnostic['elapsed_seconds'] < 90
assert diagnostic['sources_before'] == diagnostic['sources_after']
assert diagnostic['tools_before'] == diagnostic['tools_after']
receipt = json.loads((RUN/'receipt.json').read_bytes())
assert receipt['status'] == 'EXACT_A_B_CAPTURE_AND_FOUR_REFUSALS_PASS'
assert receipt['exit_code'] == 0 and receipt['failure'] is None and receipt['execution_authorized'] is True
assert receipt['automatic_retries'] == 0 and receipt['elapsed_seconds'] < 900
assert receipt['sources_before'] == receipt['sources_after'] and len(receipt['sources_after']) == 177
assert receipt['tools_before'] == receipt['tools_after'] and len(receipt['tools_after']) == 1399
for name,item in receipt['sources_after'].items():
    assert ident(PREP/name) == item, name
    assert ident(RUN/'snapshot'/name) == item, name
for name,item in receipt['tools_after'].items():
    assert ident(Path(name)) == item, name
config_path = PREP/'CONTROLLED_CONFIG_NEW_LOCAL.json'
config = json.loads(config_path.read_bytes())
assert ident(config_path) == receipt['config']
approval_path = PREP/'M2_NEW_AB_APPROVAL.json'
approval = json.loads(approval_path.read_bytes())
assert approval['config_sha256'] == receipt['config']['sha256']
marker_path = PREP/'ONE_SHOT_ATTEMPT.json'
marker = json.loads(marker_path.read_bytes())
assert marker['config'] == receipt['config'] and marker['approval'] == approval
assert Path(marker['output']) == RUN
assert len(receipt['steps']) == 16
steps = {s['label']:s for s in receipt['steps']}
for step in receipt['steps']:
    assert not step['timeout'] and step['cleanup_failure'] is None
    assert step['exit_code'] == step['expected_exit']
    assert step['elapsed_seconds'] < step['cap_seconds']
    for channel in ('stdout','stderr'):
        assert ident(RUN/(step['label']+'.'+channel+'.txt')) == step[channel]
    if step['diagnostic']:
        raw = (RUN/(step['label']+'.stdout.txt')).read_bytes() + (RUN/(step['label']+'.stderr.txt')).read_bytes()
        assert step['diagnostic'].encode('utf-8') in raw

captures = {}
rows = {}
for group, expected in [('A',24586),('B',1595)]:
    path = RUN/'snapshot'/('future_group_'+group)/'minclosure.jsonl'
    rows[group] = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
    check = json.loads((RUN/(group+'_exact_check.stdout.txt')).read_bytes())
    assert check['status'] == 'MINCLOSURE_EXACT_FIXTURE_MATCH' and check['records'] == expected
    assert len(rows[group]) == expected
    assert rows[group][0]['origin'] == 'RTL' and rows[group][-1]['tag'] == 'END'
    assert sum(row['tag']=='END' for row in rows[group]) == 1
    assert rows[group][-1]['cycle'] == config['end_cycles'][group]
    edges = [row for row in rows[group] if row['tag']=='EDGE']
    assert len(edges) == rows[group][-1]['counts']['EDGE']
    assert sum(row['tag']=='RESET' for row in rows[group]) == rows[group][-1]['counts']['RESET']
    captures[group] = dict(path=str(path),**ident(path),records=len(rows[group]),END=rows[group][-1],
                          commits=sum(row['commit'] for row in edges),independent_check='PASS_ACTUALLY_EXECUTED',
                          checker_execution=steps[group+'_exact_check'])

a = [r for r in rows['A'] if r['tag']=='EDGE']
aa = {r['cycle']:r for r in a}
release_ticks = sum(r['tick'] for r in a if r['env_state']==6 and r['cycle']<4060000)
assert release_ticks == 4800
assert aa[27300]['event_valid'] and aa[27300]['event_ready']
assert aa[4026791]['release_done']==1 and aa[4026791]['env_state']==0
assert aa[4026793]['router_state']==11
assert aa[4026796]['occupied']==0
assert aa[4060400]['event_valid'] and aa[4060400]['event_ready']
assert aa[4060404]['occupied']==1 and aa[4060404]['generations']==2
assert aa[4072400]['event_valid'] and aa[4072400]['event_ready']
assert (aa[4072400]['event']>>61)==5 and aa[4072400]['deferred']==1
assert aa[4072600]['releasing']==1 and aa[4072600]['env_state']==6
assert aa[4072600]['pedal']==0 and aa[4072600]['keys']==0 and aa[4072600]['deferred']==0
assert any(r['commit'] and r['pcm_left']!=0 for r in a if r['cycle']<27300)
assert any(r['commit'] and r['pcm_left']!=0 for r in a if r['cycle']>4060404)
frames = [r['cycle'] for r in a if r['frame']]
assert all(right-left in (833,834) for left,right in zip(frames,frames[1:]))
plan_b = json.loads((PREP/'plan_B.json').read_bytes())
b = {r['cycle']:r for r in rows['B'] if r['tag']=='EDGE'}
expected_phase = dict(before_math=2,advance_same_edge=5,after_advance=6,held_backpressure=7)
cancel_coverage = []
for case in plan_b['cases']:
    hit = b[case['cycle']]
    assert hit['frame']==1 and hit['request_id']==case['old_id']
    assert hit['phase']==expected_phase[case['name']] and hit['tick']==0 and hit['commit']==0
    recovered = next(r for r in b.values() if r['cycle']>hit['cycle'] and r['epoch']==1
                     and r['commit'] and r['pcm_id']==case['old_id']+1)
    cancel_coverage.append(dict(case=case['name'],hit_cycle=hit['cycle'],old_id=case['old_id'],
                               actual_phase=hit['phase'],old_commit=0,recovery_cycle=recovered['cycle'],
                               recovery_id=recovered['pcm_id'],recovery_PCM=[recovered['pcm_left'],recovered['pcm_right']]))
assert b[424]['dds_phase']==b[425]['dds_phase']
assert b[724]['tick']==1 and b[725]['dds_phase']==b[724]['dds_phase']+39370534
assert all(b[n]['bank_valid']==1 and b[n]['bank_ready']==0 for n in (1030,1031,1032,1033))
assert len({(b[n]['bank_id'],b[n]['bank_waves'],b[n]['bank_envelopes']) for n in (1030,1031,1032,1033)})==1
assert b[1514]['epoch']==2 and b[1514]['occupied']==0 and b[1514]['dds_phase']==0
assert b[1571]['epoch']==2 and b[1571]['pcm_id']==1 and b[1571]['commit']==1
assert not any(r['commit'] and r['pcm_id'] in (1,3,5,7) and r['epoch']==1 for r in b.values())

# Reuse signed exact-capture2 scope. Pure source/receipt aggregation, not a math replay.
scope_path = OLD/'code/software/audio_math_acceptance_candidate/t060_minclosure_20261011/scope.py'
spec = importlib.util.spec_from_file_location('readonly_signed_t060_scope',scope_path)
scope_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scope_module)
old_scope, old_paths = scope_module.build()
signed_identities = {str(path):ident(path) for path in old_paths+[scope_path]}
assert old_scope['old_entry']['exit_code']==3 and old_scope['old_entry']['modified'] is False
assert len(old_scope['END_metadata'])==3 and len(old_scope['exact_fixture_flags'])==2
assert old_scope['no_flag_based_golden_selection'] and not old_scope['applies_to_other_inputs']
old_scope['reused_router_and_math']['retirement_capture_proved'] = False  # Preserve the original receipt claim.
refusals = {s['label']:dict(exit=s['exit_code'],diagnostic=s['diagnostic'])
            for s in receipt['steps'] if '_reject_' in s['label']}
assert len(refusals)==4 and all(item['exit']==1 for item in refusals.values())

DEST.mkdir(exist_ok=False)
closure = dict(schema=1,status='T060_EXACT_H_OFFLINE_ACCEPTANCE_SCOPE_COMPLETE',
    acceptance_scope='Signed original H capture2 math/route/strict structure plus new exact H A/B functional gap evidence; approved original diagnostic exclusions retained',
    t060_offline_acceptance_complete=True,all_possible_inputs_verified=False,production_N32_verified=False,
    physical_STA_verified=False,board_audio_verified=False,t061_complete=False,
    original_receipts_unchanged=True,old_exit3_unchanged=True,old_failure_unchanged=True,
    diagnostic_elapsed_seconds=diagnostic['elapsed_seconds'],new_AB_elapsed_seconds=receipt['elapsed_seconds'],
    new_attempt=ident(marker_path),new_config=ident(config_path),new_approval=ident(approval_path),
    original_signed_scope_REUSED=old_scope,original_signed_sources=signed_identities,
    new_captures=captures,real_retirement=dict(release_tick_count=4800,release_done_first_cycle=4026791,
        retirement_command_cycle=4026793,occupied_clear_cycle=4026796,reallocate_accept_cycle=4060400,
        reallocated_generation=2,sample_cadence='833/833/834 source plan unchanged',reset_not_used_for_retirement=True),
    accepted_panic=dict(cycle=4072400,source=1,channel=0,previously_deferred=True,
        release_observed_by_cycle=4072600,not_immediate_occupied_clear=True),
    cancellation_cases=cancel_coverage,reset_recovery=dict(epoch=2,release_cycle=1514,new_commit_cycle=1571,new_id=1),
    four_complete_capture_refusals=refusals,new_EDA_calls=0,new_device_operations=0,
    old_56_counterexamples_replayed=False,old_4207_or_capture2_math_replayed=False,
    repository_registered=False,git_published=False,
    remaining='Hardware/production integration and generic workload coverage are outside this offline acceptance scope; N32/T061 separate and still PARTIAL.')
write_new(DEST/'T060_OFFLINE_CLOSURE.json',closure)
before_sources = dict(signed_identities)
assert before_sources == {str(path):ident(path) for path in old_paths+[scope_path]}
raw_files = [p for p in RUN.rglob('*') if p.is_file() and p.suffix.lower() not in ('.exe','.dll','.vvp')]
raw_files += [p for p in DIAG.rglob('*') if p.is_file() and p.suffix.lower() not in ('.exe','.dll','.vvp')]
raw_files += [config_path,approval_path,marker_path,PREP/'NEW_PREPARATION_RECEIPT.json',
              Path(__file__),ROOT/'code/output/m2_t060_complete_20261014.py',DEST/'T060_OFFLINE_CLOSURE.json']
manifest = dict(scope=closure['acceptance_scope'],qualified_status=closure['status'],members=[],
    exclusions='Large executable tool/vvp binaries stay in original local output, their SHA retained; old signed captures/negatives are reused by immutable receipts, not replayed.')
archive = DEST/'M2_T060原H离线验收收口_A_B真实补采与拒收_20261014.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as package:
    for path in sorted(set(raw_files)):
        data = path.read_bytes()
        name = path.relative_to(ROOT).as_posix()
        manifest['members'].append(dict(path=name,**ident(path)))
        package.writestr(name,data)
    for path in old_paths+[scope_path]:
        name = 'REUSED_SIGNED_REFERENCE/'+path.relative_to(OLD).as_posix()
        data = path.read_bytes()
        manifest['members'].append(dict(path=name,**ident(path)))
        package.writestr(name,data)
    package.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for item in manifest['members']:
        data = package.read(item['path'])
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
manifest['archive'] = dict(path=str(archive),**ident(archive))
write_new(DEST/'DELIVERY.json',manifest)
print(json.dumps(dict(status=closure['status'],diagnostic_seconds=diagnostic['elapsed_seconds'],
    AB_seconds=receipt['elapsed_seconds'],A_records=24586,B_records=1595,A_commits=captures['A']['commits'],
    B_commits=captures['B']['commits'],true_release_ticks=4800,refusals=4,
    members=len(manifest['members']),archive=manifest['archive'],git_published=False),ensure_ascii=False,indent=2))
