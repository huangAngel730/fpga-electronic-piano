# 138K 基础音频唯一候选：T056 L_locations_guard065（2026-10-15）

**结论：精确离线 L5 与交付字节身份成立；当前仍阻断物理下载/上板声学签收。**本页是入口清单，不扩大旧结果，也不把待测写作通过。未运行新 EDA/RTL/烧录。

## 精确候选身份

- 源提交 `0bb5c66862dcbd9dc3894b055d9703e2b3cd0e76`；构建入口提交 `a0cb805`；profile `138k_c40_hold065`；原目录 `code/rtl/138K_try/hold_trials_20261005/L_locations_guard065/`，一次完整构建目录 `code/build/138k_l/runs/run_20261006_a0cb805_exact/`。
- 目标 `GW5AST-LV138PG484AC1/I0`，用户已确认 138K C／NEO Dock 31005。封存适配收据中 56 个 `project/inputs` 的实际 SHA 逐项匹配；构建工程 SHA `03c746832579d2f33351fc03357a7c911ee7fc10034523a10e5079896ca606e7`，冻结收据 SHA `d421c369965d016f4f7f8e9d8a5da8514c585d26f5ae1cc63f1b2a0f9a6f3c3a`。
- 构建 exit0、一次 400.923s，Setup +1.279ns/Hold 0/Recovery +0.706/Removal +0.331ns，四时钟域 Setup/Hold TNS 和违例端点为零；Logic18823/FF8669/DSP46/BSRAM20。此结论只属于该精确组，后续任一源码/ROM/时钟/约束变化需重新验收。
- 原 `.fs` 36242859 字节/SHA `598ec9bdf4fe20718f0f0a79a94cc6daed518103c1c4007ce2fec6231f2fff48`，pin 报告 SHA `ec9e8211568ca0a4a5aef79eaeb3d48e703505f37dd7fdb180c228da85627130`，CST SHA `9860341591be1db845d21af91377896cf3eaefbbf4db73d81bc45284d7312bab`，SDC SHA `3c2bc9cfdaf788f29ee7b1d4d691e36c55feae886d539651f991fcb0c2fff6a6`。发布 14 文件与 C/31005 交付 9 文件均逐项 SHA 匹配，ZIP CRC 无误。`RECOVERY_138K_C.md` 不承诺 Flash 有可用镜像；当前无独立 138K golden `.fs`。

## 可复用证据与界限

- T055 对封存 L 的数字子链：5849 PCM 握手、5848 完整串行帧（首尾半槽边界），左右逐样本和 3 帧欠载恢复、两个可编译行为反例按原收据限定通过；已有启动/失锁/复位专项按相同来源 REUSED，不重跑。
- 固定走线 L 版 CST 与引脚报告及 C/31005 资料的 14 个端口/四组 TMDS 差分对已交叉核对；PT8211 BCLK/WS/DIN、PA_EN 低有效与板载功放链路仅是资料/引脚一致，不是实际电压或模拟输出实测。
- T060 原 H 指定离线验收 V0328 已完成，但**不是同一 L 工程**，只能作为算法/事务合同参考；不据其 A/B 给本 L 版签新的硬件等级。T052 新128沿只证明独立控制小窗 L2；旧 4207 发布完整性 UNKNOWN。L 的 SOURCE_MODE=1 是单路固定音，不是 T052 要求的 N 路独立纯正弦自证，故不把一音、四声部结构或多谐波峰误报为赛题复音验收通过。

## 上板前尚缺的真实事实

1. Bank3/4/5 实际供电：Dock TP21(VCCO_3)、TP22(VCCO_4)，核心 FB13 的 VCCIO5 侧（用 TP23 先断电确认导通），分别记录对 GND 直流电压；声明 BANK_VCCIO=3.3 不能代实测。
2. 外接 MIDI 适配器接 FPGA 前的输出 VH/VL/过冲及 FPGA 侧 GND 到 Dock GND 导通；不重复确认用户已确定的 C/31005 或板上固定线。
3. 若本次演示 HDMI：记录 DVI_DIR_SEL 实际 TX 状态及 +5VD；不能由默认电阻推断。实物音频 PT8211/PA_EN/左右声道、采样率和 T052 N 路纯正弦 FFT 需要后续同码流现场证据。
4. 用户对**这份 SHA 的 SRAM-only 下载**单独放行；恢复策略只保证断电后 SRAM 临时像消失，未备份/验证 Flash，不能承诺自动恢复旧版本。此清单不是下载许可。

**判定**：现可用作上板前的离线 L5 基线与文件交接；电压/外设/恢复及用户下载许可未闭，状态仍为 `NO_BOARD_RELEASE`。后续功能接入（双音色、延迟、曲谱、波形、N32）不可借用本版时序或 `.fs` 结论。
