# T057/T062 曲谱 RAM → 演奏事件 → PCM：M2 接口与仲裁核对（2026-10-15）

当前等级仅**静态 L0**。绑定证据见 `INPUT_IDENTITIES.json`。T062 使用提交 `5e1d13c` 后的同步双银行 `score_transfer_bram_candidate.sv`，旧RAM停止使用。本轮不改协议、正式顶层、FIFO、音频算法或引脚；没有实际用户下载曲谱文件、PC↔板UART、BLE链路或播放实录，不宣称已有闭环。

## 已经存在和真正断点

T057严格JSON接收 1..512 个事件，8 字节记录 `<IBBBB` 即 tick:u32（48kHz样本计数）、kind:u8（0 NoteOn，1 NoteOff）、channel:u8、note:u8、velocity:u8；零力度 NoteOn在编码时归一为NoteOff。RAM在本地40MHz单域提供 `committed_valid/count/score_id`、`commit_pulse` 和独立读口：`rd_req`, `rd_index[8:0]` → 下一拍 `rd_valid`, `rd_event[63:0]`。上传 ACK/READ 只证明存储。现有板级score接收overlay及N32草案均把 `rd_req=0`，所以**没有任何曲谱记录送入演奏事件 FIFO**。

基础顶层已有 MIDI source_id=0、按键 source_id=1 的共同 32项 FIFO；演奏核心 `event_valid/ready` 共享输出。不能把score的8字节记录直接当成统一64位 `performance_event_t`：两者位序/字段不同。建议独立播放适配器只从已经COMMIT的bank读取，映射 NoteOn/NoteOff 到 `audio_defs_pkg::make_note_event(4'd2, channel[3:0], note[6:0], midi_velocity_to_10bit(velocity[6:0]))`；其他8位非法值由T057/T062入库时拒收，运行时若身份漂移则失效而非截断悄悄送音。source_id=2 作为提议，受控接口冻结前再核团队来源编号分配。

## 最小接线和拍序（拟验证，不是既成实测）

1. `score_commit_pulse`/score_id/count 都在40MHz域；当score仍在播放又有新COMMIT，应先送仅score来源的all-notes-off并停止新旧读请求，再从新曲谱tick0重启；不能把已发布bank的旧读值当新曲的首事件。复位令播放请求、当前世代、held事件和时间计数清零；RAM旧字节无committed_valid不得播放。
2. 每次 `rd_req` 对应一个index，仅在读口空闲发起；下一拍对 `rd_valid` 捕获 `rd_event` 到保持寄存器，与当次score_id/提交世代/index绑定。COMMIT同沿读请求按T062合同返回旧bank，因此切换必须冲刷在途旧读。播放器 `valid` 保持、`ready` 前不推进index/时间，也不丢同tick多条事件；tick按音频 `i2s_frame_tick` 推进，不能按40MHz墙钟推进。绝不能回压I2S帧节拍，播放迟到只记延迟/拒收统计。
3. 仲裁不能在现有 FIFO 内部直接增加第三写口。先让已有按键/MIDI FIFO优先，若其 `event_valid=1`，播放器保持score有效但 `ready=0`；否则score的已到期事件进入当前声音核心。`event_valid` 与`event_data`需在背压期间保持。使用独立复用壳可避免变更既有按钮/MIDI仲裁。无饥饿保证的绝对优先级需要限定演奏负载/延迟处理：实时MIDI长时不断输入时score可能迟到，不能删掉或提前跳过音符。
4. end-of-score与中途ABORT不同：ABORT只取消未发布暂存，不停当前演奏；最后事件消费后等待必要Release/明确停止判据，不把上传末尾当PCM完成。可先只做PC有线COMMIT触发播放的**私有候选**，但T057协议没有PLAY命令；公开交互何时开始（COMMIT即启动/本地按键/新增受控命令）须在正式接口定案前明确。M3的`.mid`导入只负责把用户网上下载文件变成T057记录，不能代替FPGA端播放。

## 下一次必要验证

用精确冻结RAM、board score_uart双向口、真实40MHz接收+逐条读时序与两个来源并发测试：非8字节对齐DATA/COMMIT同沿旧bank/连续两次COMMIT/最后条重复tick/背压/实时MIDI抢占/复位/旧代丢弃/上传失败仍保旧曲，检查完整统一事件序列与PCM/ID及I2S帧相关性。两件可编译行为错误：旧bank读事件混入新世代、背压导致同tick漏一条；严格checker必须非零拒收。新模块/顶层/约束变更先走M2受控接口和**新组合**资源/STA；M3旧BLE软件目标构建与原UART仿真各自REUSED，不重跑。没有实际下载`.mid`或M3事件证据时只停在本接口审查，不标播放通过。
