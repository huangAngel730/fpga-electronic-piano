`timescale 1ns/1ps
module tb_v4_readonly_boundary;
  logic clk=0; always #10 clk=~clk;
  logic rst_n=0,frame_tick=0,sample_req=0,enable=1,cancel=0;
  logic calc_ready,result_valid,result_ready=0,clip_any;
  logic [31:0] req_id=32'hfffffff0,result_req_id,active_voice_count;
  logic [3:0] voice_enable_mask=15;
  logic [31:0] fcw_lane0=32'h40000000,fcw_lane1=32'h40000000;
  logic [31:0] fcw_lane2=32'h40000000,fcw_lane3=32'h40000000;
  logic [95:0] voices_left,voices_right;
  integer mode,accepted=0,published=0,first_valid=0;
  logic [95:0] kept_l,kept_r;
  logic [31:0] kept_id,kept_active;
  logic kept_clip;
  t052_polyphony_test_source dut(.*);
  always @(posedge clk) begin
    if(rst_n && sample_req && calc_ready && !frame_tick && !cancel) accepted=accepted+1;
    if(rst_n && result_valid && result_ready && !cancel && !frame_tick)
      published=published+1;
  end
  initial begin
    if(!$value$plusargs("CASE=%d",mode)) mode=0;
    repeat(4) @(negedge clk); rst_n=1;
    repeat(2) @(negedge clk);
    result_ready=(mode==0);
    if(mode==3) frame_tick=1;
    sample_req=1;
    @(negedge clk); sample_req=0;
    if(mode==3) begin
      frame_tick=0;
      $display("FRAME_ACCEPT accepted=%0d phase=%0d",accepted,dut.g_dds[0].u_dds.phase_acc);
      if(accepted!=0 || dut.g_dds[0].u_dds.phase_acc!=0)
        $fatal(1,"V4_FRAME_EDGE_ACCEPTED_OR_PHASE_ADVANCED");
      $finish;
    end
    if(mode==5) begin
      frame_tick=1; @(negedge clk); frame_tick=0;
      repeat(5) @(negedge clk);
      if(result_valid || dut.g_dds[0].u_dds.phase_acc!=32'h40000000) $fatal(1,"V5_CALC_FRAME_CANCEL_OR_ROLLBACK");
      result_ready=1; req_id=32'habcdef01; sample_req=1;
      @(negedge clk); sample_req=0; repeat(12) @(negedge clk);
      if(published!=1 || result_req_id!=32'habcdef01) $fatal(1,"V5_CALC_FRAME_RECOVERY");
      $display("V5_CALC_FRAME_CANCEL_NO_ROLLBACK_AND_RECOVERY_PASS"); $finish;
    end
    if(mode==0) begin
      repeat(12) begin @(posedge clk); #1; if(result_valid) first_valid++; end
      $display("ALWAYS_READY accepted=%0d valid_edges=%0d published=%0d",accepted,first_valid,published);
      if(accepted!=1) $fatal(1,"READY_FIXTURE_ACCEPTANCE");
      if(published!=1) $fatal(1,"V3_ALWAYS_READY_ACCEPTED_RESULT_LOST");
      $display("ALWAYS_READY_PASS"); $finish;
    end
    wait(result_valid); @(negedge clk);
    kept_l=voices_left; kept_r=voices_right; kept_id=result_req_id;
    kept_active=active_voice_count; kept_clip=clip_any;
    repeat(5) begin
      @(negedge clk);
      if(!result_valid || voices_left!==kept_l || voices_right!==kept_r ||
        result_req_id!==kept_id || active_voice_count!==kept_active || clip_any!==kept_clip)
        $fatal(1,"V3_HELD_OUTPUT_CHANGED");
    end
    if(mode==1) begin
      result_ready=1; @(negedge clk); result_ready=0;
      if(published!=1) $fatal(1,"V3_HELD_HANDSHAKE_COUNT");
      $display("HELD_VALID_ALL_OUTPUTS_STABLE_AND_ONE_HANDSHAKE_PASS"); $finish;
    end else if(mode==2) begin
      cancel=1; @(negedge clk); cancel=0;
      repeat(5) begin @(posedge clk); #1; if(result_valid) $fatal(1,"V3_HELD_CANCEL_OLD_VALID"); end
      if(published!=0) $fatal(1,"V3_CANCEL_PUBLISHED");
      $display("HELD_CANCEL_PASS"); $finish;
    end else if(mode==4) begin
      frame_tick=1; @(negedge clk); frame_tick=0;
      $display("FRAME_HOLD result_valid=%0d id=%0h",result_valid,result_req_id);
      if(result_valid) $fatal(1,"V4_FRAME_EDGE_OLD_HELD_RESULT_NOT_CANCELLED");
      $finish;
    end else $fatal(1,"BAD_CASE");
  end
  initial begin #10000; $fatal(1,"DIAGNOSTIC_TIMEOUT"); end
endmodule
