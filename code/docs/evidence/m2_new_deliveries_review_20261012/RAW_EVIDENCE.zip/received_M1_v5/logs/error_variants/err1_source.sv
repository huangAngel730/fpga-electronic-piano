// T052 四声部复音纯正弦测试源（返修v3）
// 恢复原局部事务契约：frame_tick 优先，sample_req/calc_ready 一次接受，
// result_valid/result_ready 消费者背压，四路PCM24左右 + 32bit ID/活跃数。
// 复用 dds_oscillator 与 pcm_mixer_4voice，不改其源。
`timescale 1ns/1ps

module t052_polyphony_test_source #(
    parameter ROM_FILE = "model/generated/wavetables/sine_1024_8192.mem"
) (
    input  logic        clk,               // 50 MHz
    input  logic        rst_n,             // 低有效异步拉低
    input  logic        frame_tick,        // 帧边界，优先取消旧结果
    input  logic        sample_req,        // 逻辑采样请求
    output logic        calc_ready,        // 可接受一次请求
    input  logic [31:0] req_id,            // 请求ID（32bit）
    input  logic        enable,            // 总使能
    input  logic [3:0]  voice_enable_mask, // 声部使能mask
    input  logic [31:0] fcw_lane0,
    input  logic [31:0] fcw_lane1,
    input  logic [31:0] fcw_lane2,
    input  logic [31:0] fcw_lane3,
    input  logic        cancel,            // 取消（与 frame_tick 同优先）
    output logic        result_valid,      // 结果有效，held 直到 result_ready
    input  logic        result_ready,      // 消费者背压
    output logic [31:0] result_req_id,
    output logic [95:0] voices_left,       // 每 24bit 一声部
    output logic [95:0] voices_right,
    output logic [31:0] active_voice_count,
    output logic        clip_any
);

    typedef enum logic [1:0] {IDLE, CALC, HOLD} state_t;
    state_t state;

    logic [31:0] fcw_q[0:3];
    logic [3:0]  mask_q;
    logic [31:0] id_q;
    logic        en_q;

    // frame_tick / cancel 的职责（M2 V0292 要求）：
    // - calc_ready 只报告"本模块是否有能力接下一代"，可含帧沿（否则 commit 链
    //   在帧边界永远拿不到 ready，request 恒为 0）。
    // - 真正的接受显式排除 frame_tick 与 cancel：帧沿即使有 sample_req 也不得
    //   接受新请求、不得推进 DDS 相位。
    // - FSM 中 frame_tick/cancel 分支优先级高于 IDLE/CALC/HOLD：清旧 valid/context。
    wire cancel_evt = cancel;
    wire frame_evt  = frame_tick;

    logic dds_tick;
    logic accept;

    // 同步查表数据（1 拍延迟）
    logic signed [15:0] wt[0:3];
    logic signed [15:0] wt_d[0:3];
    logic [3:0] mask_d;
    logic [31:0] id_d;
    logic en_d;

    assign calc_ready = (state == IDLE);
    assign accept = calc_ready && sample_req && !frame_evt && !cancel_evt;
    assign dds_tick = accept;

    // 采样：DDS 直连输入 FCW。
    // accept 只发生在 IDLE，此时输入 FCW 稳定；DDS 仅在 accept 沿推进一次，
    // 因此推进所用 FCW 等同于被接受请求的 FCW（无同沿旧值问题）。
    genvar gi;
    generate
        for (gi = 0; gi < 4; gi = gi + 1) begin : g_dds
            dds_oscillator #(.ROM_FILE(ROM_FILE)) u_dds (
                .sys_clk(clk),
                .sys_rst_n(rst_n),
                .sample_tick(dds_tick),
                .fcw((gi >= 0) ? fcw_lane0 :
                     (gi == 1) ? fcw_lane1 :
                     (gi == 2) ? fcw_lane2 : fcw_lane3),
                .wt_sample(wt[gi])
            );
        end
    endgenerate

    // 24bit 符号扩展 + 左移8：{wt, 8'h00}
    logic [95:0] mix_l, mix_r;
    always_comb begin
        for (int j = 0; j < 4; j = j + 1) begin
            mix_l[24*j +: 24] = (mask_d[j] && en_d) ? {wt_d[j], 8'h00} : 24'sd0;
            mix_r[24*j +: 24] = (mask_d[j] && en_d) ? {wt_d[j], 8'h00} : 24'sd0;
        end
    end

    logic signed [23:0] mixed_l, mixed_r;
    logic clip_l, clip_r, clip_x;

    pcm_mixer_4voice u_mix (
        .voices_left(mix_l), .voices_right(mix_r),
        .mixed_left(mixed_l), .mixed_right(mixed_r),
        .clip_left(clip_l), .clip_right(clip_r), .clip_any(clip_x)
    );

    // 活跃数：已锁存 mask 的置位数（不把瞬时零交叉计成不活跃）
    logic [31:0] active_q;
    always_comb begin
        active_q = 32'd0;
        for (int j = 0; j < 4; j = j + 1)
            if (mask_d[j] && en_d) active_q = active_q + 32'd1;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            fcw_q[0] <= 32'h0; fcw_q[1] <= 32'h0;
            fcw_q[2] <= 32'h0; fcw_q[3] <= 32'h0;
            mask_q <= 4'h0; id_q <= 32'h0; en_q <= 1'b0;
            wt_d[0] <= 16'sd0; wt_d[1] <= 16'sd0;
            wt_d[2] <= 16'sd0; wt_d[3] <= 16'sd0;
            mask_d <= 4'h0; id_d <= 32'h0; en_d <= 1'b0;
            result_valid <= 1'b0;
            result_req_id <= 32'h0;
            voices_left <= 96'd0; voices_right <= 96'd0;
            active_voice_count <= 32'd0;
            clip_any <= 1'b0;
        end else begin
            // frame_tick / cancel 优先级高于 IDLE/CALC/HOLD：
            // 清旧 valid 与 context，安排新代；已发生的 DDS 相位推进不回滚。
            if (frame_evt || cancel_evt) begin
                state <= IDLE;
                result_valid <= 1'b0;
                result_req_id <= 32'h0;
                voices_left <= 96'd0; voices_right <= 96'd0;
                active_voice_count <= 32'd0;
                clip_any <= 1'b0;
                mask_q <= 4'h0; id_q <= 32'h0; en_q <= 1'b0;
                mask_d <= 4'h0; id_d <= 32'h0; en_d <= 1'b0;
            end else begin
                case (state)
                    IDLE: begin
                        result_valid <= 1'b0;
                        if (accept) begin
                            fcw_q[0] <= fcw_lane0; fcw_q[1] <= fcw_lane1;
                            fcw_q[2] <= fcw_lane2; fcw_q[3] <= fcw_lane3;
                            mask_q <= voice_enable_mask; id_q <= req_id; en_q <= enable;
                            state <= CALC;
                        end
                    end
                    CALC: begin
                        // 查表数据已就绪（dds 同步读），锁存并进入 HOLD
                        wt_d[0] <= wt[0]; wt_d[1] <= wt[1];
                        wt_d[2] <= wt[2]; wt_d[3] <= wt[3];
                        mask_d <= mask_q; id_d <= id_q; en_d <= en_q;
                        state <= HOLD;
                    end
                    HOLD: begin
                        // 仅在"旧 result_valid 已有效 && result_ready"时握手。
                        // 这样 ready 常1 时，valid 仍至少可见一个完整沿（首沿发布、
                        // 次沿才消耗），不会把首次有效结果抹掉。
                        if (result_valid && result_ready) begin
                            result_valid <= 1'b0;
                            state <= IDLE;
                        end else begin
                            result_valid <= 1'b1;
                            result_req_id <= id_d;
                            voices_left <= mix_l;
                            voices_right <= mix_r;
                            active_voice_count <= active_q;
                            clip_any <= clip_x;
                        end
                    end
                    default: state <= IDLE;
                endcase
            end
        end
    end

endmodule
