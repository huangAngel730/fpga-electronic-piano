// T052 v4 集成 TB：producer + polyphonic_pcm_commit（只读实例化，不改公共源）
// 核 1041/1042 帧距、代次提交、零额外欠载、reset 首帧、正负饱和与 clip 一次计数。
`timescale 1ns/1ps

module tb_t052_commit_chain;

    logic clk, rst_n;

    // ---- 帧节拍：50MHz/48000 = 1041.667 拍，用分数累加得 1042/1041 交替 ----
    logic frame_tick;
    logic [31:0] frame_acc;
    logic [31:0] frames_seen;
    logic [10:0] last_gap, gap;
    logic [10:0] gap_cnt;
    logic gap_valid;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_acc <= 32'd0;
            frame_tick <= 1'b0;
        end else begin
            // 每拍加 48000；>=50_000_000 时发 tick 并减去
            if (frame_acc + 32'd48000 >= 32'd50_000_000) begin
                frame_acc <= frame_acc + 32'd48000 - 32'd50_000_000;
                frame_tick <= 1'b1;
            end else begin
                frame_acc <= frame_acc + 32'd48000;
                frame_tick <= 1'b0;
            end
        end
    end

    // 帧距测量：gap_cnt 在 tick 沿加 1，使 N 拍间隔测得 N
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gap_cnt <= 11'd0; last_gap <= 11'd0; gap_valid <= 1'b0; frames_seen <= 32'd0;
        end else begin
            gap_cnt <= gap_cnt + 11'd1;
            if (frame_tick) begin
                last_gap <= gap_cnt + 11'd1;
                gap_cnt <= 11'd0;
                gap_valid <= (frames_seen > 0);
                frames_seen <= frames_seen + 32'd1;
            end
        end
    end

    // ---- producer ----
    logic        calc_ready, sample_req;
    logic [31:0] sample_req_id;
    logic        result_valid, result_ready;
    logic [31:0] result_req_id;
    logic [95:0] voices_left, voices_right;
    logic [31:0] active_voice_count;
    logic        clip_any;
    logic        enable;
    logic [3:0]  voice_enable_mask;
    logic [31:0] fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3;
    logic        cancel;

    t052_polyphony_test_source dut (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .sample_req(sample_req), .calc_ready(calc_ready),
        .req_id(sample_req_id), .enable(enable),
        .voice_enable_mask(voice_enable_mask),
        .fcw_lane0(fcw_lane0), .fcw_lane1(fcw_lane1),
        .fcw_lane2(fcw_lane2), .fcw_lane3(fcw_lane3),
        .cancel(cancel),
        .result_valid(result_valid), .result_ready(result_ready),
        .result_req_id(result_req_id),
        .voices_left(voices_left), .voices_right(voices_right),
        .active_voice_count(active_voice_count), .clip_any(clip_any)
    );

    // ---- commit chain（只读实例化）----
    logic signed [23:0] play_left, play_right;
    logic        pending_valid, commit_pulse;
    logic [31:0] audio_frame_count, pcm_request_count, pcm_commit_count;
    logic [31:0] audio_underrun, clip_count;

    polyphonic_pcm_commit u_commit (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .calc_ready(calc_ready), .sample_req(sample_req),
        .sample_req_id(sample_req_id),
        .result_valid(result_valid), .result_ready(result_ready),
        .result_req_id(result_req_id),
        .voices_left(voices_left), .voices_right(voices_right),
        .play_left(play_left), .play_right(play_right),
        .pending_valid(pending_valid), .commit_pulse(commit_pulse),
        .audio_frame_count(audio_frame_count),
        .pcm_request_count(pcm_request_count),
        .pcm_commit_count(pcm_commit_count),
        .audio_underrun(audio_underrun), .clip_count(clip_count)
    );

    integer errors;
    integer i;

    // 持续锁存：是否曾观察到正饱和提交样本（避免窄窗口漏采）
    logic saw_clip_max;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) saw_clip_max <= 1'b0;
        else if (play_left === 24'sh7FFFFF) saw_clip_max <= 1'b1;
    end

    initial begin
        clk = 0;
        forever #10 clk = ~clk;
    end

    task chk(input string name, input logic cond);
        if (!cond) begin
            $display("CHECK_FAIL: %s", name);
            errors = errors + 1;
        end
    endtask

    initial begin
        errors = 0;
        rst_n = 0; cancel = 0; enable = 1'b1; voice_enable_mask = 4'b1111;
        fcw_lane0 = 32'h04B17E4D; fcw_lane1 = 32'h0962FC9A;
        fcw_lane2 = 32'h12C5F935; fcw_lane3 = 32'h258BF26A;

        repeat (8) @(negedge clk);
        rst_n = 1;

        // ---- 正常帧序列：跑 200 帧，核帧距 ----
        for (i = 0; i < 200; i = i + 1) begin
            @(posedge frame_tick);
            @(negedge clk);
            if (gap_valid) chk("frame gap must be 1041/1042", (last_gap == 11'd1041) || (last_gap == 11'd1042));
        end

        chk("frame count advanced", audio_frame_count > 32'd100);
        chk("no extra underrun on normal frames", audio_underrun == 32'd0);
        chk("commits happened", pcm_commit_count > 32'd100);
        chk("commit count <= request count", pcm_commit_count <= pcm_request_count);

        // ---- reset 首帧 ----
        rst_n = 0;
        repeat (5) @(negedge clk);
        chk("reset clears commit count", pcm_commit_count == 32'd0);
        chk("reset clears underrun", audio_underrun == 32'd0);
        chk("reset clears clip count", clip_count == 32'd0);
        rst_n = 1;
        // 复位后第一帧不应立即计欠载
        @(posedge frame_tick);
        repeat (3) @(negedge clk);
        chk("first frame after reset: no underrun counted before commit",
            audio_underrun <= 32'd1);

        // ---- 正饱和：四路满幅 8192 -> 和 8388608 -> 夹 8388607，clip 计 1 ----
        // 必须先复位把四路相位对齐到 0：FCW=0x40000000 使 addr 走 0→256→512→768→0，
        // 只有 addr=256 处 rom=8192，四路同相才能得到 4×8192×256=8388608 > 8388607。
        rst_n = 0;
        repeat (5) @(negedge clk);
        rst_n = 1;
        repeat (3) @(negedge clk);
        begin
            logic [31:0] clip_before;
            fcw_lane0 = 32'h40000000; fcw_lane1 = 32'h40000000;
            fcw_lane2 = 32'h40000000; fcw_lane3 = 32'h40000000;
            voice_enable_mask = 4'b1111;
            enable = 1'b1;
            repeat (4) @(negedge clk);
            clip_before = clip_count;
            chk("clip_count cleared by reset", clip_before == 32'd0);
            for (i = 0; i < 24 && clip_count == clip_before; i = i + 1) begin
                @(posedge frame_tick);
                repeat (8) @(negedge clk);
            end
            $display("DBG sat: clip=%0d before=%0d saw=%b frames=%0d",
                     clip_count, clip_before, saw_clip_max, audio_frame_count);
            chk("clip_count increases on saturation", clip_count > clip_before);
            chk("positive saturation clamps to 24'h7FFFFF", saw_clip_max);
        end

        // ---- 关闭 enable：输出应为 0 且不再累加 clip ----
        enable = 1'b0;
        voice_enable_mask = 4'b0000;
        for (i = 0; i < 3; i = i + 1) @(posedge frame_tick);
        repeat (4) @(negedge clk);
        chk("disabled output is zero", play_left == 24'sd0);

        // ---- 32bit ID 接近回绕 ----
        enable = 1'b1; voice_enable_mask = 4'b1111;
        for (i = 0; i < 3; i = i + 1) @(posedge frame_tick);
        repeat (4) @(negedge clk);

        $display("----------------------------------------");
        $display("frames=%0d commits=%0d requests=%0d underrun=%0d clip=%0d last_gap=%0d",
                 audio_frame_count, pcm_commit_count, pcm_request_count,
                 audio_underrun, clip_count, last_gap);
        if (errors == 0) begin
            $display("PASS: commit chain checks OK");
            $finish(0);
        end else begin
            $display("FAIL: %0d check(s) failed", errors);
            $fatal(1, "commit chain failed");
        end
    end

    initial begin
        #500ms;
        $display("FAIL: timeout");
        $fatal(1, "timeout");
    end

endmodule
