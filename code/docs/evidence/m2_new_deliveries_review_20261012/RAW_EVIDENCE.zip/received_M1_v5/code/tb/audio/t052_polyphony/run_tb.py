#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 simulation runner (v5)

M2 V0292 requests implemented here:
- explicit, unique, fresh output directory (timestamped); refuses to overwrite
- never reads stale captures from the caller's cwd
- per-step timeouts recorded as receipts (compile / run / checker)
- ModelSim work library created explicitly (vlib)
- joint decision: compile exit 0 AND sim exit 0 AND PASS marker AND
  this run's capture+request files exist AND independent comparison passes
- receipt.json records tool/source/ROM identity and every step's exit code
"""
import hashlib
import json
import shutil
import subprocess
import tempfile
import sys
import time
from pathlib import Path


def find_root(start):
    cur = Path(start).resolve()
    for _ in range(6):
        if (cur / "code" / "rtl").is_dir():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


def find_tool(candidates):
    for c in candidates:
        p = Path(c)
        if p.exists():
            return str(p)
    for c in candidates:
        w = shutil.which(Path(c).name)
        if w:
            return w
    return None


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run_step(cmd, cwd, timeout, receipt, name):
    t0 = time.time()
    try:
        r = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True,
                           timeout=timeout, encoding="utf-8", errors="replace")
        out = r.stdout or ""
        err = r.stderr or ""
        receipt["steps"].append({
            "name": name, "cmd": cmd, "exit": r.returncode,
            "seconds": round(time.time() - t0, 2), "timeout": False,
            "stdout_sha256": hashlib.sha256(
                out.encode("utf-8", "replace")).hexdigest(),
            "stderr_sha256": hashlib.sha256(
                err.encode("utf-8", "replace")).hexdigest()})
        return r.returncode, out, err
    except subprocess.TimeoutExpired:
        receipt["steps"].append({"name": name, "cmd": cmd, "exit": None,
                                 "seconds": round(time.time() - t0, 2),
                                 "timeout": True})
        return None, "", "TIMEOUT after %ss" % timeout


def main():
    here = Path(__file__).resolve().parent
    root = find_root(here)
    if root is None:
        print("FAIL: repo root (with code/rtl) not found")
        return 1

    rtl_audio = root / "code" / "rtl" / "audio"
    rtl_mixer = root / "code" / "rtl" / "mixer"
    rom = root / "code" / "model" / "generated" / "wavetables" / "sine_1024_8192.mem"

    dut = rtl_audio / "t052_polyphony_test_source.sv"
    if not dut.exists():
        dut = here / "t052_polyphony_test_source.sv"
    tb_src = here / "tb_t052_polyphony.sv"

    for p, label in ((dut, "DUT (code/rtl/audio)"), (tb_src, "TB"), (rom, "ROM")):
        if not p.exists():
            print("FAIL: missing %s: %s" % (label, p))
            return 1

    vlog = find_tool([r"F:/modelsim/win64/vlog.exe", "vlog"])
    vsim = find_tool([r"F:/modelsim/win64/vsim.exe", "vsim"])
    vlib = find_tool([r"F:/modelsim/win64/vlib.exe", "vlib"])
    iverilog = find_tool(["iverilog"])
    vvp = find_tool(["vvp"])
    use_modelsim = bool(vlog and vsim)
    if not use_modelsim and not (iverilog and vvp):
        print("NOT_RUN: neither vlog/vsim nor iverilog/vvp found; RTL sim not executed")
        return 3

    stamp = time.strftime("%Y%m%d_%H%M%S")
    out_root = root / "code" / "output" / ("t052_run_" + stamp)
    if out_root.exists():
        print("FAIL: output dir already exists, refusing to overwrite: %s" % out_root)
        return 1
    out_root.mkdir(parents=True)
    # ModelSim 无法在含非 ASCII 的路径下建库，故模拟器在 ASCII 暂存目录运行，
    # 再把日志/捕获/receipt 复制回 code/output 持久保存。
    work = Path(tempfile.mkdtemp(prefix="t052_sim_"))
    (out_root / "work_dir.txt").write_text(str(work), encoding="utf-8")

    receipt = {
        "runner": "run_tb.py", "version": "v5",
        "tool": "ModelSim" if use_modelsim else "Icarus",
        "root": str(root), "output_dir": str(out_root),
        "rom": {"path": str(rom), "sha256": sha256(rom)},
        "dut": {"path": str(dut), "sha256": sha256(dut)},
        "tb": {"path": str(tb_src), "sha256": sha256(tb_src)},
        "inputs": {}, "steps": [],
    }

    for f in (dut, rtl_audio / "dds_oscillator.sv",
              rtl_mixer / "pcm_mixer_4voice.sv", tb_src, rom):
        if not f.exists():
            print("FAIL: missing source %s" % f)
            return 1
        shutil.copy(f, work)
    receipt["inputs"]["dds_oscillator.sv"] = sha256(rtl_audio / "dds_oscillator.sv")
    receipt["inputs"]["pcm_mixer_4voice.sv"] = sha256(rtl_mixer / "pcm_mixer_4voice.sv")

    tb = "tb_t052_polyphony"
    if use_modelsim:
        rc, so, se = run_step([vlog, "-version"], work, 60, receipt, "tool_version")
        (out_root / "tool_version.log").write_text(so + se, encoding="utf-8")
        if vlib:
            rc, so, se = run_step([vlib, "work"], work, 120, receipt, "vlib")
            (out_root / "vlib.log").write_text(so + se, encoding="utf-8")
            if rc != 0:
                print("FAIL: vlib failed exit=%s" % rc)
                return 1
        compile_cmd = [vlog, "-sv", "+incdir+.", "t052_polyphony_test_source.sv",
                       "dds_oscillator.sv", "pcm_mixer_4voice.sv",
                       "tb_t052_polyphony.sv"]
        run_cmd = [vsim, "-c", "-do", "run -all; quit -f", tb,
                   "+WAVETABLE_PATH=" + rom.name]
    else:
        compile_cmd = [iverilog, "-g2012", "-o", tb + ".vvp", "-I", ".",
                       "t052_polyphony_test_source.sv", "dds_oscillator.sv",
                       "pcm_mixer_4voice.sv", "tb_t052_polyphony.sv"]
        run_cmd = [vvp, tb + ".vvp", "+WAVETABLE_PATH=" + rom.name]

    print("root=%s" % root)
    print("out=%s" % out_root)
    print("tool=%s" % receipt["tool"])

    ce, cso, cse = run_step(compile_cmd, work, 300, receipt, "compile")
    (out_root / "compile.log").write_text(cso + cse, encoding="utf-8")
    if ce != 0:
        print("FAIL: compile exit %s" % ce)
        print((cso + cse)[-1500:])
        (out_root / "receipt.json").write_text(
            json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")
        return 1

    re_, rso, rse = run_step(run_cmd, work, 900, receipt, "simulate")
    (out_root / "sim.log").write_text(rso + rse, encoding="utf-8")

    cap = work / "tb_t052_polyphony.capture"
    req = work / "tb_t052_requests.log"
    ok = bool(re_ == 0 and "PASS:" in rso and cap.exists() and req.exists())
    if not cap.exists() or not req.exists():
        print("FAIL: this run produced no capture or request log")

    if ok:
        ke, kso, kse = run_step(
            [sys.executable, str(here / "check_t052_rtl.py"),
             str(req), str(cap), str(rom)],
            out_root, 600, receipt, "independent_check")
        (out_root / "check.log").write_text(kso + kse, encoding="utf-8")
        try:
            print((kso or "").strip())
        except UnicodeEncodeError:
            print((kso or "").encode("ascii", "replace").decode("ascii"))
        ok = ke == 0

    # 持久化本次产物（capture/requests 在 ASCII 暂存目录中）
    for name in ("tb_t052_polyphony.capture", "tb_t052_requests.log"):
        src = work / name
        if src.exists():
            shutil.copy(src, out_root / name)

    receipt["result"] = {
        "compile_exit": ce, "sim_exit": re_, "success": bool(ok),
        "capture_sha256": sha256(cap) if cap.exists() else None,
        "requests_sha256": sha256(req) if req.exists() else None}
    (out_root / "receipt.json").write_text(
        json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")

    print("compile_exit=%s sim_exit=%s success=%s" % (ce, re_, ok))
    print("receipt=%s" % (out_root / "receipt.json"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
