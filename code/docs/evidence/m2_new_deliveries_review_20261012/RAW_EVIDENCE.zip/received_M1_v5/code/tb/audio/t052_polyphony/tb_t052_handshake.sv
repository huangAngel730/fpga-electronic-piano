// T052 v4 handshake boundary TB: always-ready / early / late, held stability, cancel priority
`timescale 1ns/1ps

module tb_t052_handshake;

    logic clk, rst_n;
    logic frame_tick = 0;
    logic sample_req, calc_ready;
    logic [31:0] req_id;
    logic enable;
    logic [3:0] voice_enable_mask;
    logic [31:0] fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3;
    logic cancel;
    logic result_valid, result_ready;
    logic [31:0] result_req_id;
    logic [95:0] voices_left, voices_right;
    logic [31:0] active_voice_count;
    logic clip_any;

    t052_polyphony_test_source dut (
        .clk(clk), .rst_n(rst_n), .frame_tick(frame_tick),
        .sample_req(sample_req), .calc_ready(calc_ready), .req_id(req_id),
        .enable(enable), .voice_enable_mask(voice_enable_mask),
        .fcw_lane0(fcw_lane0), .fcw_lane1(fcw_lane1),
        .fcw_lane2(fcw_lane2), .fcw_lane3(fcw_lane3), .cancel(cancel),
        .result_valid(result_valid), .result_ready(result_ready),
        .result_req_id(result_req_id),
        .voices_left(voices_left), .voices_right(voices_right),
        .active_voice_count(active_voice_count), .clip_any(clip_any)
    );

    integer errors;
    integer i;

    initial begin clk = 0; forever #10 clk = ~clk; end

    task chk(input string name, input logic cond);
        if (!cond) begin $display("CHECK_FAIL: %s", name); errors = errors + 1; end
    endtask

    task run_case(input string name, input logic late_ready);
        integer v_edges, hs;
        logic [31:0] id_seen;
        logic id_locked;
        begin
            v_edges = 0; hs = 0; id_seen = 32'hdeadbeef; id_locked = 1'b0;
            @(negedge clk);
            req_id = 32'h1234_5678; voice_enable_mask = 4'b1111; enable = 1'b1;
            fcw_lane0 = 32'h04B17E4D; fcw_lane1 = 32'h0962FC9A;
            fcw_lane2 = 32'h12C5F935; fcw_lane3 = 32'h258BF26A;
            sample_req = 1'b1;
            result_ready = late_ready ? 1'b0 : 1'b1;
            @(negedge clk);
            sample_req = 1'b0;
            for (i = 0; i < 16; i = i + 1) begin
                @(negedge clk);
                if (late_ready && i == 4) result_ready = 1'b1;
                if (result_valid) begin
                    v_edges = v_edges + 1;
                    if (!id_locked) begin id_seen = result_req_id; id_locked = 1'b1; end
                    chk({name, ": held ID stable"}, result_req_id === id_seen);
                end
                if (result_valid && result_ready) hs = hs + 1;
                if (hs > 0) i = 16;
            end
            result_ready = 1'b0;
            chk({name, ": exactly one handshake"}, hs == 1);
            chk({name, ": result_req_id matches accepted id"}, id_seen === 32'h1234_5678);
            chk({name, ": valid seen at least one edge"}, v_edges >= 1);
            $display("  %s: valid_edges=%0d handshakes=%0d id=%08x", name, v_edges, hs, id_seen);
        end
    endtask

    initial begin
        errors = 0;
        rst_n = 0; sample_req = 0; req_id = 0; enable = 0; voice_enable_mask = 0;
        fcw_lane0 = 0; fcw_lane1 = 0; fcw_lane2 = 0; fcw_lane3 = 0;
        cancel = 0; result_ready = 0;
        repeat (8) @(negedge clk);
        rst_n = 1;
        repeat (3) @(negedge clk);

        $display("== ready always 1 ==");
        run_case("always_ready", 1'b0);
        $display("== ready late ==");
        run_case("late_ready", 1'b1);

        $display("== cancel priority ==");
        @(negedge clk);
        req_id = 32'hAAAA_0001; voice_enable_mask = 4'b1111; enable = 1;
        sample_req = 1;
        @(negedge clk);
        sample_req = 0;
        cancel = 1;
        @(negedge clk);
        cancel = 0;
        for (i = 0; i < 20; i = i + 1) begin
            @(negedge clk);
            if (result_valid && result_req_id === 32'hAAAA_0001) begin
                $display("CHECK_FAIL: cancelled request published");
                errors = errors + 1;
            end
        end

        // ==== 帧边界 case 1: IDLE 下 frame_tick 与 sample_req 同沿 ====
        // 帧沿不得接受新请求、不得推进 DDS 相位（M2: V4_FRAME_EDGE_ACCEPTED_OR_PHASE_ADVANCED）
        $display("== frame edge must not accept (IDLE + frame/sample same edge) ==");
        @(negedge clk);
        req_id = 32'hBBBB_0001; voice_enable_mask = 4'b1111; enable = 1;
        fcw_lane0 = 32'h40000000; fcw_lane1 = 32'h40000000;
        fcw_lane2 = 32'h40000000; fcw_lane3 = 32'h40000000;
        sample_req = 1; frame_tick = 1; result_ready = 1;
        @(negedge clk);
        sample_req = 0; frame_tick = 0;
        for (i = 0; i < 8; i = i + 1) begin
            @(negedge clk);
            if (result_valid && result_req_id === 32'hBBBB_0001) begin
                $display("CHECK_FAIL: frame edge accepted or advanced phase");
                errors = errors + 1;
            end
        end

        // ==== 帧边界 case 2: valid/HOLD 下 frame_tick 必须清旧 valid ====
        // （M2: V4_FRAME_EDGE_OLD_HELD_RESULT_NOT_CANCELLED）
        $display("== frame edge must cancel old held result ==");
        @(negedge clk);
        req_id = 32'hCCCC_0001; voice_enable_mask = 4'b1111; enable = 1;
        fcw_lane0 = 32'h04B17E4D; fcw_lane1 = 32'h0;
        fcw_lane2 = 32'h0; fcw_lane3 = 32'h0;
        sample_req = 1; frame_tick = 0; result_ready = 0;
        @(negedge clk);
        sample_req = 0;
        // 等到 HOLD 发布（valid=1 且未握手）
        for (i = 0; i < 8 && !result_valid; i = i + 1) @(negedge clk);
        if (!result_valid) begin
            $display("CHECK_FAIL: expected held result before frame");
            errors = errors + 1;
        end
        @(negedge clk);
        frame_tick = 1;      // 帧沿
        @(negedge clk);
        frame_tick = 0;
        @(negedge clk);
        if (result_valid) begin
            $display("CHECK_FAIL: frame edge did not cancel old held result");
            errors = errors + 1;
        end

        // ==== CALC 阶段帧取消（清 context） ====
        $display("== frame edge must cancel in CALC ==");
        @(negedge clk);
        req_id = 32'hDDDD_0001; voice_enable_mask = 4'b1111; enable = 1;
        sample_req = 1; frame_tick = 0;
        @(negedge clk);
        sample_req = 0;                  // 进入 CALC（本沿已接受）
        @(negedge clk);
        frame_tick = 1;                  // CALC 中帧沿
        @(negedge clk);
        frame_tick = 0;
        for (i = 0; i < 8; i = i + 1) begin
            @(negedge clk);
            if (result_valid && result_req_id === 32'hDDDD_0001) begin
                $display("CHECK_FAIL: CALC frame did not cancel context");
                errors = errors + 1;
            end
        end

        // ==== 帧后恢复：新代可再次被接受（ID 恢复） ====
        $display("== post-frame recovery ==");
        @(negedge clk);
        req_id = 32'hEEEE_0001; voice_enable_mask = 4'b1111; enable = 1;
        sample_req = 1; frame_tick = 0; result_ready = 1;
        @(negedge clk);
        sample_req = 0;
        for (i = 0; i < 12 && !(result_valid && result_req_id === 32'hEEEE_0001); i = i + 1) begin
            @(negedge clk);
        end
        if (!(result_req_id === 32'hEEEE_0001)) begin
            $display("CHECK_FAIL: recovery after frame failed (id not restored)");
            errors = errors + 1;
        end
        wait (result_valid == 1'b1);
        @(negedge clk);
        result_ready = 0;

        $display("----------------------------------------");
        if (errors == 0) begin
            $display("PASS: handshake checks OK");
            $finish(0);
        end else begin
            $display("FAIL: %0d check(s) failed", errors);
            $fatal(1, "handshake failed");
        end
    end

    initial begin
        #100ms;
        $display("FAIL: timeout");
        $fatal(1, "timeout");
    end

endmodule
