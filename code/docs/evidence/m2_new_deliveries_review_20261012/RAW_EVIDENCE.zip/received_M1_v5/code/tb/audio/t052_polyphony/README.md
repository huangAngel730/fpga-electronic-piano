# T052 四声部复音测试源 —— 使用说明（返修v3）

## 已删除的做法（勿回退）

- 内部 `sample_counter` / `10'd1042` 节拍：**已删除**。改为按原合同由外部 `frame_tick` / `sample_req` 驱动，不存在位宽截断。
- `automatic` 局部声明：已全部移除（Icarus 10.x 不支持）。
- 局部 `0x7F00` 削波阈值：已删除，改回复用 `pcm_mixer_4voice` 的宽位和 + 24bit 饱和。

## 接口（局部隔离合同，不改正式公共接口）

| 方向 | 信号 | 说明 |
|---|---|---|
| in | `clk` | 50 MHz |
| in | `rst_n` | 低有效异步拉低 |
| in | `frame_tick` | 帧边界，最高优先：丢弃旧结果 |
| in | `sample_req` | 逻辑采样请求 |
| out | `calc_ready` | 可接受一次请求 |
| in | `req_id[31:0]` | 请求 ID（32bit） |
| in | `enable` | 总使能 |
| in | `voice_enable_mask[3:0]` | 声部使能 mask |
| in | `fcw_lane0..3[31:0]` | 四路频率控制字 |
| in | `cancel` | 取消（与 frame_tick 同优先） |
| out | `result_valid` | 结果有效，held 至握手 |
| in | `result_ready` | 消费者背压 |
| out | `result_req_id[31:0]` | 结果对应请求 ID |
| out | `voices_left/right[95:0]` | 每 24bit 一声部（16bit 左移 8） |
| out | `active_voice_count[31:0]` | 已锁存 mask 的置位数 |
| out | `clip_any` | mixer 宽位和饱和结果 |

## 时序口径

- `accept = (state==IDLE) && sample_req && calc_ready && !abort`，`abort = cancel | frame_tick`。
- DDS 仅在 `accept` 沿推进一次；**取值 = 推进前相位**（先取样后推进）。
- 接受的请求其 ID/mask/enable/FCW 在 CALC 沿冻结；已发生的相位推进不回滚。
- 结果在 HOLD 保持稳定，直到 `result_ready`；背压不产生重复推进。
- 取消/帧边界在计算、提交、保持任一阶段都最高优先，且同沿不接受新请求。

## 文件

- DUT：`code/rtl/audio/t052_polyphony_test_source.sv`
- TB：`code/tb/audio/t052_polyphony/tb_t052_polyphony.sv`
- 运行器：`code/tb/audio/t052_polyphony/run_tb.py`
- 独立检查器：`code/tb/audio/t052_polyphony/check_t052_rtl.py`
- 参考模型/单测：`code/model/t052_polyphony_reference.py`、`test_t052_polyphony_reference.py`

## 运行

```bash
cd code/tb/audio/t052_polyphony
python run_tb.py          # 自动定位仓库根；ModelSim 或 Icarus
python ../../../model/test_t052_polyphony_reference.py
```

`run_tb.py` 判定同时要求：编译退出 0、仿真退出 0、捕获与请求记录完整、独立数学比较通过；任一不满足即非零退出。

## 未覆盖（未验证边界）

- 未实例化 `polyphonic_pcm_commit`，1041/1042 帧距与「按一次成功提交计 clip」未测。
- 未做 Gowin 综合 / PnR / STA；138K 40MHz 正式接入归 M2。
- 未做板级采集与现场 FFT；归 M3。
- 频率为 FCW 换算值，非板测实测。
