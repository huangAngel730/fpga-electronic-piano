`timescale 1ns/1ps
module m2_commit_observer;
  integer cycle=0, gap1041=0,gap1042=0,last_frame=0;
  logic [31:0] before_count,before_clip;
  logic accept_pcm,clip_pcm;
  always @(posedge tb_t052_commit_chain.clk) begin
    cycle=cycle+1;
    if(!tb_t052_commit_chain.rst_n) last_frame=0;
    else begin
      if(tb_t052_commit_chain.frame_tick) begin
        if(last_frame!=0) begin
          if(cycle-last_frame==1041) gap1041=gap1041+1;
          else if(cycle-last_frame==1042) gap1042=gap1042+1;
          else $fatal(1,"M2_ACTUAL_FRAME_GAP_BAD");
        end
        last_frame=cycle;
      end
      before_count=tb_t052_commit_chain.pcm_commit_count;
      before_clip=tb_t052_commit_chain.clip_count;
      accept_pcm=tb_t052_commit_chain.u_commit.pcm_valid && tb_t052_commit_chain.u_commit.pcm_ready;
      clip_pcm=tb_t052_commit_chain.u_commit.pcm_clip_any;
      if(accept_pcm) begin
        $display("M2_COMMIT %0d %0d %0d %0d %0d",cycle,
          tb_t052_commit_chain.u_commit.pcm_req_id,
          $signed(tb_t052_commit_chain.u_commit.pcm_left),
          $signed(tb_t052_commit_chain.u_commit.pcm_right),clip_pcm);
        if(tb_t052_commit_chain.frame_tick) $fatal(1,"M2_FRAME_ACCEPTED_OLD_PCM");
        if(tb_t052_commit_chain.u_commit.pcm_req_id!==tb_t052_commit_chain.sample_req_id)
          $fatal(1,"M2_COMMIT_WRONG_GENERATION");
      end
      #1;
      if(tb_t052_commit_chain.pcm_commit_count !== before_count+accept_pcm)
        $fatal(1,"M2_COMMIT_NOT_COUNTED_EXACTLY_ONCE");
      if(tb_t052_commit_chain.clip_count !== before_clip+(accept_pcm&&clip_pcm))
        $fatal(1,"M2_CLIP_NOT_SUCCESSFUL_COMMIT_ONCE");
    end
  end
  final $display("M2_FRAME_GAPS 1041=%0d 1042=%0d",gap1041,gap1042);
endmodule
