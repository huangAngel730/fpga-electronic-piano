"""New v4 capture mathematical replay and strict-schema refusal checks."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
PKG = OUT / "original/T052_v4_pkg"
ROM = OUT / "dependencies/sine_1024_8192.mem"
CHECKER = PKG / "code/tb/audio/t052_polyphony/check_t052_rtl.py"


def main():
    rp, cp = PKG / "logs/tb_t052_requests.log", PKG / "logs/tb_t052_polyphony.capture"
    req, cap = rp.read_text("ascii").splitlines(), cp.read_text("ascii").splitlines()
    assert req[-1] == "END requests=4137" and cap[-1] == "END results=4137"
    assert len(req) == len(cap) == 4138
    table = [int(x, 16) for x in ROM.read_text("ascii").split()]
    table = [x - 65536 if x & 32768 else x for x in table]
    assert len(table) == 1024
    phase, masks, clips = [0] * 4, set(), 0
    pattern = re.compile(r"ID=(\d+) v0=(-?\d+) v1=(-?\d+) v2=(-?\d+) v3=(-?\d+) ACT=(\d+) CLIP=([01])")
    for request, capture in zip(req[:-1], cap[:-1]):
        p = request.split()
        rid, fcws, mask = int(p[1]), [int(x, 16) for x in p[2:6]], int(p[6])
        assert len(p) == 7 and p[0] == "REQ" and 0 <= rid < 2**32 and 0 <= mask < 16
        match = pattern.fullmatch(capture)
        assert match
        lanes = [table[phase[i] >> 22] * 256 if mask & (1 << i) else 0 for i in range(4)]
        clip = int(not -8388608 <= sum(lanes) <= 8388607)
        assert [int(x) for x in match.groups()] == [rid, *lanes, mask.bit_count(), clip]
        for i in range(4): phase[i] = (phase[i] + fcws[i]) & 0xffffffff
        masks.add(mask)
        clips += clip
    probes = OUT / "strict_probes"
    probes.mkdir(exist_ok=False)
    cases = {
        "normal": (req, cap, 0),
        "unknown_request": (req + ["UNKNOWN record"], cap, 1),
        "paired_tail4096": (req[:4096], cap[:4096], 1),
        "mask17": ([req[0][:-1] + "17"] + req[1:], cap, 1),
        "pcm1lsb": (req, [cap[0].replace("v0=0", "v0=1")] + cap[1:], 1),
        "wrong_end": (req, cap[:-1] + ["END results=4136"], 1),
        "clip_flip": (req, [x[:-1] + str(1 - int(x[-1])) for x in cap[:-1]] + cap[-1:], 1),
        "duplicate_end": (req, cap + [cap[-1]], 1),
    }
    steps = []
    for label, (r, c, expected) in cases.items():
        rq, cq = probes / (label + ".req"), probes / (label + ".cap")
        rq.write_bytes(("\n".join(r) + "\n").encode("ascii"))
        cq.write_bytes(("\n".join(c) + "\n").encode("ascii"))
        cmd = [sys.executable, "-B", "-X", "utf8", str(CHECKER), str(rq), str(cq), str(ROM)]
        result = subprocess.run(cmd, capture_output=True, timeout=30)
        (OUT / (label + ".stdout.bin")).write_bytes(result.stdout)
        (OUT / (label + ".stderr.bin")).write_bytes(result.stderr)
        assert result.returncode == expected, (label, result.stdout, result.stderr)
        steps.append(dict(label=label, command=cmd, exit=result.returncode,
                          stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                          stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))
    raw_trace = (OUT / "commit_simulate.stdout.bin").read_text("utf-8", errors="replace")
    points = re.findall(r"M2_COMMIT (\d+) (\d+) (-?\d+) (-?\d+) ([01])", raw_trace)
    gaps = re.search(r"M2_FRAME_GAPS 1041=(\d+) 1042=(\d+)", raw_trace)
    assert gaps and int(gaps[1]) > 0 and int(gaps[2]) > 0
    assert all(l == r for _, _, l, r, _ in points)
    positives = sum(int(l) == 8388607 and clip == "1" for _, _, l, _, clip in points)
    negatives = sum(int(l) == -8388608 for _, _, l, _, _ in points)
    result = dict(rows=4137, lane_comparisons=16548, mask_coverage=sorted(masks),
                  lane_ID_ACT_CLIP_mismatches=0, original_clip_true_rows=clips,
                  checker_steps=steps, independent_commit_trace_rows=len(points),
                  frame_gaps={"1041": int(gaps[1]), "1042": int(gaps[2])},
                  real_positive_clamp_commits=positives, real_negative_boundary_commits=negatives,
                  fractional_frame_average_hz=48000,
                  wrong_47984_6_label_applies_only_to_fixed1042_TB=True,
                  actual_right_Golden_capture=False, actual_mixed_Golden_capture=False,
                  mutant_sources_and_full_captures_present=False,
                  frame_priority_RTL_failed=True, complete_T052=False)
    (OUT / "math_receipt.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "checker_steps"}, ensure_ascii=False))


if __name__ == "__main__": main()
