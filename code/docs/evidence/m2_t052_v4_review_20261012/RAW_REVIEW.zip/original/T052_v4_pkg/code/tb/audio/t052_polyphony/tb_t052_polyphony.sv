// T052 Testbench (返修v3)
// 负沿驱动、NBA后检查；consumer result_ready；独立数学比对由 check_t052_rtl.py 完成。
`timescale 1ns/1ps

module tb_t052_polyphony;

    logic        clk, rst_n;
    logic        frame_tick;
    logic        sample_req;
    logic        calc_ready;
    logic [31:0] req_id;
    logic        enable;
    logic [3:0]  voice_enable_mask;
    logic [31:0] fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3;
    logic        cancel;
    logic        result_valid;
    logic        result_ready;
    logic [31:0] result_req_id;
    logic [95:0] voices_left, voices_right;
    logic [31:0] active_voice_count;
    logic        clip_any;

    string wavetable_path;
    integer capture_file;
    integer req_file;
    integer success_count;
    integer test_count;
    integer timeout;
    integer i;

    t052_polyphony_test_source #(
        .ROM_FILE("model/generated/wavetables/sine_1024_8192.mem")
    ) dut (.*);

    initial begin
        clk = 0;
        forever #10 clk = ~clk;
    end

    // 帧节拍：50MHz / 1042 ≈ 47.99kHz
    logic [10:0] frame_cnt;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_cnt <= 11'd0;
            frame_tick <= 1'b0;
        end else begin
            if (frame_cnt == 11'd1041) begin
                frame_cnt <= 11'd0;
                frame_tick <= 1'b1;
            end else begin
                frame_cnt <= frame_cnt + 1'b1;
                frame_tick <= 1'b0;
            end
        end
    end

    initial begin
        if (!$value$plusargs("WAVETABLE_PATH=%s", wavetable_path)) begin
            $display("ERROR: Missing +WAVETABLE_PATH=<path>");
            $fatal(1, "ROM 路径未指定");
        end
        capture_file = $fopen("tb_t052_polyphony.capture", "w");
        if (capture_file == 0) $fatal(1, "无法打开捕获文件");
        req_file = $fopen("tb_t052_requests.log", "w");
        if (req_file == 0) $fatal(1, "无法打开请求记录文件");

        rst_n = 0;
        sample_req = 0; req_id = 0; enable = 0; voice_enable_mask = 0;
        fcw_lane0 = 0; fcw_lane1 = 0; fcw_lane2 = 0; fcw_lane3 = 0;
        cancel = 0; result_ready = 0;
        success_count = 0; test_count = 0;

        repeat (10) @(negedge clk);
        rst_n = 1;
        repeat (5) @(negedge clk);

        $display("INFO: T052 TB v3 开始; ROM=%s", wavetable_path);

        // 场景1: 单声部
        do_req(32'd1, 4'b0001, 32'h04B17E4D, 32'h0, 32'h0, 32'h0, 10);
        // 场景2: 四声部
        do_req(32'd2, 4'b1111, 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 10);
        // 场景3: mask 0101
        do_req(32'd3, 4'b0101, 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 5);
        // 场景4: 16 种 mask
        for (i = 0; i < 16; i = i + 1)
            do_req(32'd100 + i, i[3:0], 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 1);
        // 场景5: 大样本量（含 32bit ID 回绕）
        for (i = 0; i < 4096; i = i + 1) begin
            do_req(i[31:0], 4'b1111, $urandom(), $urandom(), $urandom(), $urandom(), 1);
            if (i % 1000 == 0) $display("  progress: %0d / 4096", i);
        end
        // 场景6: 计算阶段取消
        test_cancel_calc();
        // 场景7: COMMIT/HOLD 前取消
        test_cancel_hold();
        // 场景8: 满幅饱和
        test_saturation();

        // END 记录：供检查器检测截断/成对计数，不能只按最低数量放行
        $fwrite(capture_file, "END results=%0d\n", success_count);
        $fwrite(req_file, "END requests=%0d\n", success_count);
        $fclose(capture_file);
        $fclose(req_file);

        $display("========================================");
        $display("成功: %0d / %0d", success_count, test_count);
        $display("========================================");
        if (success_count >= 4096 && success_count == test_count) begin
            $display("PASS: 至少4096个成功结果");
            $finish(0);
        end else begin
            $display("FAIL: 成功结果 %0d / %0d", success_count, test_count);
            $fatal(1, "测试失败");
        end
    end

    task do_req(input logic [31:0] rid, input logic [3:0] vmask,
                input logic [31:0] f0, f1, f2, f3, input integer n);
        integer k;
        integer done;
        for (k = 0; k < n; k = k + 1) begin
            done = 0;
            // frame_tick/cancel 会取消在途请求，按合同重试
            while (!done) begin
                @(negedge clk);
                req_id = rid; voice_enable_mask = vmask; enable = 1'b1;
                fcw_lane0 = f0; fcw_lane1 = f1; fcw_lane2 = f2; fcw_lane3 = f3;
                sample_req = 1'b1;
                @(negedge clk);
                sample_req = 1'b0;
                timeout = 0;
                while (!result_valid && timeout < 8) begin
                    @(negedge clk);
                    timeout = timeout + 1;
                end
                if (result_valid) done = 1;
            end
            // held 稳定性：连续 3 个沿 ID 不变
            repeat (3) @(negedge clk);
            if (result_req_id !== rid) $fatal(1, "held 期间 result_req_id 不稳定");
            // 请求记录与成功结果配对写入（保证检查器重放一一对应）
            $fwrite(req_file, "REQ %0d %08x %08x %08x %08x %0d\n", rid, f0, f1, f2, f3, vmask);
            $fwrite(capture_file, "ID=%0d v0=%0d v1=%0d v2=%0d v3=%0d ACT=%0d CLIP=%b\n",
                    result_req_id,
                    $signed(voices_left[23:0]), $signed(voices_left[47:24]),
                    $signed(voices_left[71:48]), $signed(voices_left[95:72]),
                    active_voice_count, clip_any);
            result_ready = 1'b1;
            @(negedge clk);
            result_ready = 1'b0;
            success_count = success_count + 1;
            test_count = test_count + 1;
        end
    endtask

    task test_cancel_calc();
        @(negedge clk);
        req_id = 32'd900; voice_enable_mask = 4'b1111; enable = 1; sample_req = 1;
        @(negedge clk);
        sample_req = 0;
        @(negedge clk);
        cancel = 1;
        @(negedge clk);
        cancel = 0;
        for (i = 0; i < 20; i = i + 1) begin
            @(negedge clk);
            if (result_valid && result_req_id == 32'd900)
                $fatal(1, "T052_CANCELLED_REQUEST_PUBLISHED");
        end
        $display("  计算阶段取消: OK");
    endtask

    task test_cancel_hold();
        // 接受后到达 HOLD 前取消
        @(negedge clk);
        req_id = 32'd901; voice_enable_mask = 4'b1111; enable = 1; sample_req = 1; cancel = 0;
        @(negedge clk);
        sample_req = 0;
        @(negedge clk);
        cancel = 1;
        @(negedge clk);
        cancel = 0;
        for (i = 0; i < 20; i = i + 1) begin
            @(negedge clk);
            if (result_valid && result_req_id == 32'd901)
                $fatal(1, "T052_COMMIT_CANCEL_PUBLISHED");
        end
        $display("  HOLD前取消: OK");
    endtask

    task test_saturation();
        // 先复位使相位归零，保证取样地址确定。
        // 第一次接受取样 rom[0]=0，相位->0x40000000；
        // 第二次取样 addr=256 即 rom[256]=8192（正峰）。
        // 四次同相 8192 左移8 -> 和 8388608 > 8388607 -> 应夹并 clip=1。
        rst_n = 0;
        repeat (5) @(negedge clk);
        rst_n = 1;
        repeat (3) @(negedge clk);
        @(negedge clk);
        req_id = 32'd902; voice_enable_mask = 4'b1111; enable = 1;
        fcw_lane0 = 32'h40000000; fcw_lane1 = 32'h40000000;
        fcw_lane2 = 32'h40000000; fcw_lane3 = 32'h40000000;
        // 第一次：推进相位到峰值地址
        sample_req = 1;
        @(negedge clk);
        sample_req = 0;
        timeout = 0;
        while (!result_valid && timeout < 100) begin
            @(negedge clk);
            timeout = timeout + 1;
        end
        if (!result_valid) $fatal(1, "饱和测试首次结果超时");
        result_ready = 1; @(negedge clk); result_ready = 0;
        // 第二次：此时相位 = 0x40000000，取样 addr=256 → 8192
        @(negedge clk);
        sample_req = 1;
        @(negedge clk);
        sample_req = 0;
        timeout = 0;
        while (!result_valid && timeout < 100) begin
            @(negedge clk);
            timeout = timeout + 1;
        end
        if (!result_valid) $fatal(1, "饱和测试二次结果超时");
        // voices_left/right 为每路 24bit 独立总线（左移8定标）；混音和饱和结果
        // 在 mixer 内部，仅可由 clip_any 观察（每路 8192<<8 = 0x200000）。
        if (clip_any !== 1'b1) begin
            $display("DEBUG sat: v0=%0d clip=%b act=%0d",
                     $signed(voices_left[23:0]), clip_any, active_voice_count);
            $fatal(1, "T052_PCM24_POSITIVE_SATURATION_NOT_REPORTED");
        end
        if ($signed(voices_left[23:0]) !== 24'sh200000) $fatal(1, "每路定标不是 8192<<8");
        result_ready = 1; @(negedge clk); result_ready = 0;
        $display("  满幅饱和: OK");
    endtask

    initial begin
        #200ms;
        $display("ERROR: 仿真超时");
        $fatal(1, "超时");
    end

endmodule
