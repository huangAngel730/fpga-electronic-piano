#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 independent math checker (v4)

Strict schema/tag validation + independent recomputation of
32-bit phase wrap, ROM address/sample alignment, mask, PCM24 scaling,
wide sum with 24-bit saturation, active count and clip.

Required input format:
  requests.log: "REQ <id_dec> <f0_hex> <f1_hex> <f2_hex> <f3_hex> <mask_dec>"
  capture:      "ID=<id> v0=<..> v1=<..> v2=<..> v3=<..> ACT=<..> CLIP=<0|1>"

Usage: python check_t052_rtl.py <requests.log> <capture> <rom.mem> [--min N]
Exits non-zero on any schema error, count mismatch or value mismatch.
"""
import re
import sys
from pathlib import Path

PHASE_MOD = 1 << 32
PCM_MAX, PCM_MIN = 8388607, -8388608
ID_MAX = 0xFFFFFFFF

REQ_RE = re.compile(
    r"^REQ (\d+) ([0-9a-fA-F]{8}) ([0-9a-fA-F]{8}) ([0-9a-fA-F]{8}) "
    r"([0-9a-fA-F]{8}) (\d+)$")
CAP_RE = re.compile(
    r"^ID=(\d+) v0=(-?\d+) v1=(-?\d+) v2=(-?\d+) v3=(-?\d+) "
    r"ACT=(\d+) CLIP=([01])$")
REQ_END_RE = re.compile(r"^END requests=(\d+)$")
CAP_END_RE = re.compile(r"^END results=(\d+)$")


def load_rom(path):
    lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    rom = []
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("//"):
            continue
        if not re.fullmatch(r"[0-9a-fA-F]{1,4}", s):
            raise ValueError(f"ROM 非法十六进制行: {s!r}")
        v = int(s, 16)
        rom.append(v - 0x10000 if v >= 0x8000 else v)
    if len(rom) != 1024:
        raise ValueError(f"ROM 必须为 1024 点，实际 {len(rom)}")
    return rom


def parse_reqs(path):
    out = []
    end_count = None
    for n, ln in enumerate(Path(path).read_text(encoding="utf-8",
                                               errors="replace").splitlines(), 1):
        if not ln.strip():
            continue
        m = REQ_END_RE.match(ln)
        if m:
            if end_count is not None:
                raise ValueError(f"requests 第{n}行重复 END 记录")
            end_count = int(m.group(1))
            continue
        if end_count is not None:
            raise ValueError(f"requests 第{n}行出现 END 之后的记录: {ln!r}")
        m = REQ_RE.match(ln)
        if not m:
            raise ValueError(f"requests 第{n}行 schema 非法: {ln!r}")
        rid = int(m.group(1))
        if not 0 <= rid <= ID_MAX:
            raise ValueError(f"requests 第{n}行 id 越界: {rid}")
        mask = int(m.group(6))
        if not 0 <= mask <= 15:
            raise ValueError(f"requests 第{n}行 mask 越界: {mask}")
        out.append((rid, m.group(2), m.group(3), m.group(4), m.group(5), mask))
    if end_count is None:
        raise ValueError("requests 缺少 END 记录（截断或未完整写出）")
    if end_count != len(out):
        raise ValueError(f"requests END 计数 {end_count} != 实际记录数 {len(out)}")
    return out


def parse_caps(path):
    out = []
    end_count = None
    for n, ln in enumerate(Path(path).read_text(encoding="utf-8",
                                               errors="replace").splitlines(), 1):
        if not ln.strip():
            continue
        m = CAP_END_RE.match(ln)
        if m:
            if end_count is not None:
                raise ValueError(f"capture 第{n}行重复 END 记录")
            end_count = int(m.group(1))
            continue
        if end_count is not None:
            raise ValueError(f"capture 第{n}行出现 END 之后的记录: {ln!r}")
        m = CAP_RE.match(ln)
        if not m:
            raise ValueError(f"capture 第{n}行 schema 非法: {ln!r}")
        vals = [int(m.group(k)) for k in (2, 3, 4, 5)]
        for v in vals:
            if not PCM_MIN <= v <= PCM_MAX:
                raise ValueError(f"capture 第{n}行 PCM 越界: {v}")
        clip = int(m.group(7))
        if clip not in (0, 1):
            raise ValueError(f"capture 第{n}行 CLIP 非法: {clip}")
        act = int(m.group(6))
        if not 0 <= act <= 4:
            raise ValueError(f"capture 第{n}行 ACT 越界: {act}")
        out.append({'id': int(m.group(1)), 'v': vals,
                    'act': act, 'clip': clip})
    if end_count is None:
        raise ValueError("capture 缺少 END 记录（截断或未完整写出）")
    if end_count != len(out):
        raise ValueError(f"capture END 计数 {end_count} != 实际记录数 {len(out)}")
    return out


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    min_n = 4096
    for a in sys.argv[1:]:
        if a.startswith("--min="):
            min_n = int(a.split("=", 1)[1])
    if len(args) != 3:
        print("用法: python check_t052_rtl.py <requests.log> <capture> <rom.mem> [--min=N]")
        return 2
    req_p, cap_p, rom_p = args

    for p in (req_p, cap_p, rom_p):
        if not Path(p).exists():
            print(f"FAIL: 文件不存在: {p}")
            return 1

    try:
        rom = load_rom(rom_p)
        reqs = parse_reqs(req_p)
        caps = parse_caps(cap_p)
    except ValueError as e:
        print(f"FAIL: schema 错误: {e}")
        return 1

    if not reqs:
        print("FAIL: requests 为空")
        return 1
    if len(reqs) != len(caps):
        print(f"FAIL: 请求数({len(reqs)}) != 捕获数({len(caps)})")
        return 1

    phases = [0, 0, 0, 0]
    bad = 0
    for idx, (rid, h0, h1, h2, h3, vmask) in enumerate(reqs):
        fcws = [int(x, 16) for x in (h0, h1, h2, h3)]
        sample = [rom[(phases[j] >> 22) & 0x3FF] for j in range(4)]
        for j in range(4):
            phases[j] = (phases[j] + fcws[j]) % PHASE_MOD

        exp_v, act = [], 0
        for j in range(4):
            if (vmask >> j) & 1:
                exp_v.append(sample[j] << 8)
                act += 1
            else:
                exp_v.append(0)

        total = sum(exp_v)
        if total > PCM_MAX:
            exp_clip = 1
        elif total < PCM_MIN:
            exp_clip = 1
        else:
            exp_clip = 0

        c = caps[idx]
        if (c['id'] != rid or c['v'] != exp_v
                or c['act'] != act or c['clip'] != exp_clip):
            bad += 1
            if bad <= 5:
                print(f"  idx={idx} id={rid}: got {c} exp v={exp_v} act={act} clip={exp_clip}")

    n = len(reqs)
    print(f"逐样本比对: {n - bad}/{n} 一致（含 24bit 定标/宽位和/饱和/削波）")
    if bad == 0 and n >= min_n:
        print(f"PASS: {n} 个结果与独立模型一致")
        return 0
    if bad == 0:
        print(f"FAIL: 成功结果数 {n} < 要求的 {min_n}")
        return 1
    print(f"FAIL: {bad} 处不匹配")
    return 1


if __name__ == "__main__":
    sys.exit(main())
