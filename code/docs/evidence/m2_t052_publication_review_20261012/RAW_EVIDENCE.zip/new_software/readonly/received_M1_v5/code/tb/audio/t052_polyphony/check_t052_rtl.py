#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 independent math checker (v5)

Strict schema/tag validation plus independent recomputation of
32-bit phase wrap, ROM address/sample alignment, mask, PCM24 scaling,
wide sum with 24-bit saturation, active count and clip.

Input formats (v5):
  requests.log: "ACC <id_dec> <f0_hex> <f1_hex> <f2_hex> <f3_hex> <mask_dec>"
                ... then exactly one "END requests=N"
                ACC i.e. every REAL accept, including accepts later
                cancelled/aborted by a frame edge. Phase advances on accept.
  capture:      "ID=<id> v0=<..> v1=<..> v2=<..> v3=<..> ACT=<..> CLIP=<0|1>"
                ... then exactly one "END results=N"
                capture holds only PUBLISHED results, an ordered subsequence
                of ACC (accepted but aborted requests produce no capture line).

Usage: python check_t052_rtl.py <requests.log> <capture> <rom.mem> [--min=N]
Exits non-zero on any schema error, count mismatch or value mismatch.
"""
import re
import sys
from pathlib import Path

PHASE_MOD = 1 << 32
PCM_MAX, PCM_MIN = 8388607, -8388608
ID_MAX = 0xFFFFFFFF

ACC_RE = re.compile(
    r"^ACC (\d+) ([0-9a-fA-F]{8}) ([0-9a-fA-F]{8}) ([0-9a-fA-F]{8}) "
    r"([0-9a-fA-F]{8}) (\d+)$")
CAP_RE = re.compile(
    r"^ID=(\d+) v0=(-?\d+) v1=(-?\d+) v2=(-?\d+) v3=(-?\d+) "
    r"ACT=(\d+) CLIP=([01])$")
ACC_END_RE = re.compile(r"^END requests=(\d+)$")
CAP_END_RE = re.compile(r"^END results=(\d+)$")
RESET_RE = re.compile(r"^RESET$")


def load_rom(path):
    rom = []
    for ln in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        s = ln.strip()
        if not s or s.startswith("//"):
            continue
        if not re.fullmatch(r"[0-9a-fA-F]{1,4}", s):
            raise ValueError(f"ROM 非法十六进制行: {s!r}")
        v = int(s, 16)
        rom.append(v - 0x10000 if v >= 0x8000 else v)
    if len(rom) != 1024:
        raise ValueError(f"ROM 必须为 1024 点，实际 {len(rom)}")
    return rom


def parse_acc(path):
    out = []
    end_count = None
    for n, ln in enumerate(Path(path).read_text(encoding="utf-8",
                                                errors="replace").splitlines(), 1):
        if not ln.strip():
            continue
        if RESET_RE.match(ln):
            if end_count is not None:
                raise ValueError(f"requests 第{n}行出现 END 之后的 RESET")
            out.append(('RESET',))
            continue
        m = ACC_END_RE.match(ln)
        if m:
            if end_count is not None:
                raise ValueError(f"requests 第{n}行重复 END 记录")
            end_count = int(m.group(1))
            continue
        if end_count is not None:
            raise ValueError(f"requests 第{n}行出现 END 之后的记录: {ln!r}")
        m = ACC_RE.match(ln)
        if not m:
            raise ValueError(f"requests 第{n}行 schema 非法: {ln!r}")
        rid = int(m.group(1))
        if not 0 <= rid <= ID_MAX:
            raise ValueError(f"requests 第{n}行 id 越界: {rid}")
        mask = int(m.group(6))
        if not 0 <= mask <= 15:
            raise ValueError(f"requests 第{n}行 mask 越界: {mask}")
        out.append((rid, m.group(2), m.group(3), m.group(4), m.group(5), mask))
    if end_count is None:
        raise ValueError("requests 缺少 END 记录（截断或未完整写出）")
    n_acc = sum(1 for e in out if e[0] != 'RESET')
    if end_count != n_acc:
        raise ValueError(f"requests END 计数 {end_count} != 实际 ACC 记录数 {n_acc}")
    return out


def parse_caps(path):
    out = []
    end_count = None
    for n, ln in enumerate(Path(path).read_text(encoding="utf-8",
                                                errors="replace").splitlines(), 1):
        if not ln.strip():
            continue
        m = CAP_END_RE.match(ln)
        if m:
            if end_count is not None:
                raise ValueError(f"capture 第{n}行重复 END 记录")
            end_count = int(m.group(1))
            continue
        if end_count is not None:
            raise ValueError(f"capture 第{n}行出现 END 之后的记录: {ln!r}")
        m = CAP_RE.match(ln)
        if not m:
            raise ValueError(f"capture 第{n}行 schema 非法: {ln!r}")
        vals = [int(m.group(k)) for k in (2, 3, 4, 5)]
        for v in vals:
            if not PCM_MIN <= v <= PCM_MAX:
                raise ValueError(f"capture 第{n}行 PCM 越界: {v}")
        act = int(m.group(6))
        if not 0 <= act <= 4:
            raise ValueError(f"capture 第{n}行 ACT 越界: {act}")
        clip = int(m.group(7))
        if clip not in (0, 1):
            raise ValueError(f"capture 第{n}行 CLIP 非法: {clip}")
        out.append({'id': int(m.group(1)), 'v': vals, 'act': act, 'clip': clip})
    if end_count is None:
        raise ValueError("capture 缺少 END 记录（截断或未完整写出）")
    if end_count != len(out):
        raise ValueError(f"capture END 计数 {end_count} != 实际记录数 {len(out)}")
    return out


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    min_n = 4096
    for a in sys.argv[1:]:
        if a.startswith("--min="):
            min_n = int(a.split("=", 1)[1])
    if len(args) != 3:
        print("用法: python check_t052_rtl.py <requests.log> <capture> <rom.mem> [--min=N]")
        return 2
    req_p, cap_p, rom_p = args

    for p in (req_p, cap_p, rom_p):
        if not Path(p).exists():
            print(f"FAIL: 文件不存在: {p}")
            return 1

    try:
        rom = load_rom(rom_p)
        reqs = parse_acc(req_p)
        caps = parse_caps(cap_p)
    except ValueError as e:
        print(f"FAIL: schema 错误: {e}")
        return 1

    if not reqs:
        print("FAIL: 接受轨迹为空")
        return 1
    if len(caps) > len(reqs):
        print(f"FAIL: 发布数({len(caps)}) 多于接受数({len(reqs)})")
        return 1
    if not caps:
        print("FAIL: capture 无发布结果")
        return 1

    # 相位在接受沿推进（被帧/取消终止的接受也仍已推进）。
    # capture 只含被发布的结果，是 ACC 的有序子序列，按 ID 双指针配对。
    phases = [0, 0, 0, 0]
    bad = 0
    ci = 0
    matched = 0
    for idx, entry in enumerate(reqs):
        if entry[0] == 'RESET':
            # 复位把 DDS 相位清零（其余状态由后续 ACC 重建）
            phases = [0, 0, 0, 0]
            continue
        rid, h0, h1, h2, h3, vmask = entry
        fcws = [int(x, 16) for x in (h0, h1, h2, h3)]
        sample = [rom[(phases[j] >> 22) & 0x3FF] for j in range(4)]
        for j in range(4):
            phases[j] = (phases[j] + fcws[j]) % PHASE_MOD

        exp_v, act = [], 0
        for j in range(4):
            if (vmask >> j) & 1:
                exp_v.append(sample[j] << 8)
                act += 1
            else:
                exp_v.append(0)

        total = sum(exp_v)
        exp_clip = 1 if (total > PCM_MAX or total < PCM_MIN) else 0

        if ci < len(caps) and caps[ci]['id'] == rid:
            c = caps[ci]
            if (c['v'] != exp_v or c['act'] != act or c['clip'] != exp_clip):
                bad += 1
                if bad <= 5:
                    print(f"  idx={idx} id={rid}: got {c} "
                          f"exp v={exp_v} act={act} clip={exp_clip}")
            matched += 1
            ci += 1

    if ci != len(caps):
        print(f"FAIL: capture 有 {len(caps) - ci} 行未能与接受轨迹配对")
        bad += 1

    n = matched
    print(f"逐样本比对: {n - bad}/{n} 一致（含 24bit 定标/宽位和/饱和/削波）")
    print(f"接受轨迹 {sum(1 for e in reqs if e[0] != 'RESET')} 条，发布 {len(caps)} 条")
    if bad == 0 and n >= min_n:
        print(f"PASS: {n} 个发布结果与独立模型一致")
        return 0
    if bad == 0:
        print(f"FAIL: 发布结果数 {n} < 要求的 {min_n}")
        return 1
    print(f"FAIL: {bad} 处不匹配")
    return 1


if __name__ == "__main__":
    sys.exit(main())
