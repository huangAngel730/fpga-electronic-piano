// T052 v4 golden TB: accepts logged separately from published results.
// Every real accept is written to the request log (so the checker can replay
// phase exactly, including accepts later cancelled by a frame edge); only
// published results are written to the capture.
`timescale 1ns/1ps

module tb_t052_polyphony;

    logic clk, rst_n;
    logic frame_tick;
    logic sample_req, calc_ready;
    logic [31:0] req_id;
    logic enable;
    logic [3:0] voice_enable_mask;
    logic [31:0] fcw_lane0, fcw_lane1, fcw_lane2, fcw_lane3;
    logic cancel;
    logic result_valid, result_ready;
    logic [31:0] result_req_id;
    logic [95:0] voices_left, voices_right;
    logic [31:0] active_voice_count;
    logic clip_any;

    string wavetable_path;
    integer cap_file, req_file;
    integer success_count, accept_count, test_count;
    integer timeout, i, j;
    logic [31:0] acc_id;
    logic        cancel_seen;

    t052_polyphony_test_source #(
        .ROM_FILE("model/generated/wavetables/sine_1024_8192.mem")
    ) dut (.*);

    initial begin clk = 0; forever #10 clk = ~clk; end

    // 50MHz / 1042 帧节拍
    logic [10:0] frame_cnt;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_cnt <= 11'd0; frame_tick <= 1'b0;
        end else if (frame_cnt == 11'd1041) begin
            frame_cnt <= 11'd0; frame_tick <= 1'b1;
        end else begin
            frame_cnt <= frame_cnt + 11'd1; frame_tick <= 1'b0;
        end
    end

    initial begin
        if (!$value$plusargs("WAVETABLE_PATH=%s", wavetable_path)) begin
            $display("ERROR: Missing +WAVETABLE_PATH=<path>");
            $fatal(1, "ROM path not given");
        end
        cap_file = $fopen("tb_t052_polyphony.capture", "w");
        if (cap_file == 0) $fatal(1, "cannot open capture");
        req_file = $fopen("tb_t052_requests.log", "w");
        if (req_file == 0) $fatal(1, "cannot open request log");

        rst_n = 0; sample_req = 0; req_id = 0; enable = 0; voice_enable_mask = 0;
        fcw_lane0 = 0; fcw_lane1 = 0; fcw_lane2 = 0; fcw_lane3 = 0;
        cancel = 0; result_ready = 0;
        success_count = 0; accept_count = 0; test_count = 0; acc_id = 32'd1;

        repeat (8) @(negedge clk);
        rst_n = 1;
        repeat (3) @(negedge clk);

        // 场景1: 单声部
        drive_batch(4'b0001, 32'h04B17E4D, 32'h0, 32'h0, 32'h0, 8);
        // 场景2: 四声部
        drive_batch(4'b1111, 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 8);
        // 场景3: mask 0101
        drive_batch(4'b0101, 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 4);
        // 场景4: 16 种 mask
        for (i = 0; i < 16; i = i + 1)
            drive_batch(i[3:0], 32'h04B17E4D, 32'h0962FC9A, 32'h12C5F935, 32'h258BF26A, 1);
        // 场景5: 大样本量（32bit ID 递增，跨越 0x10000）
        for (i = 0; i < 4200; i = i + 1) begin
            drive_batch(4'b1111, $urandom(), $urandom(), $urandom(), $urandom(), 1);
            if (i % 1000 == 0) $display("  progress: %0d / 4200", i);
        end
        // 场景6: 计算阶段取消
        test_cancel_calc();
        // 场景7: 满幅饱和
        test_saturation();

        $fwrite(req_file, "END requests=%0d\n", accept_count);
        $fwrite(cap_file, "END results=%0d\n", success_count);
        $fclose(req_file);
        $fclose(cap_file);

        $display("========================================");
        $display("accepts=%0d published=%0d", accept_count, success_count);
        $display("========================================");
        if (success_count >= 4096 && accept_count >= success_count) begin
            $display("PASS: at least 4096 published results");
            $finish(0);
        end else begin
            $display("FAIL: published %0d accepts %0d", success_count, accept_count);
            $fatal(1, "test failed");
        end
    end

    // 发起一批请求；每个真正被接受的请求都记录 ACC
    // 注意：loop 变量必须私有，不能复用模块级 i（嵌套会互相破坏）
    task drive_batch(input logic [3:0] vmask,
                     input logic [31:0] f0, f1, f2, f3, input integer n);
        integer k;
        for (k = 0; k < n; k = k + 1) begin
            do_one(vmask, f0, f1, f2, f3);
        end
    endtask

    task do_one(input logic [3:0] vmask,
                input logic [31:0] f0, f1, f2, f3);
        logic [31:0] this_id;
        logic        accepted;
        begin
            accepted = 1'b0;
            // 等到本模块有能力接单（calc_ready），且当前沿不是帧/取消沿
            timeout = 0;
            while (!accepted && timeout < 2000) begin
                @(negedge clk);
                if (calc_ready && !frame_tick && !cancel) begin
                    this_id = acc_id;
                    req_id = acc_id; voice_enable_mask = vmask; enable = 1'b1;
                    fcw_lane0 = f0; fcw_lane1 = f1; fcw_lane2 = f2; fcw_lane3 = f3;
                    sample_req = 1'b1;
                    // 该沿必定被接受（state==IDLE、非帧非取消）
                    $fwrite(req_file, "ACC %0d %08x %08x %08x %08x %0d\n",
                            acc_id, f0, f1, f2, f3, vmask);
                    accept_count = accept_count + 1;
                    acc_id = acc_id + 32'd1;
                    accepted = 1'b1;
                end else begin
                    sample_req = 1'b0;
                end
            end
            if (!accepted) $fatal(1, "accept timeout");
            @(negedge clk);
            sample_req = 1'b0;

            // 等待发布；若被帧取消则本请求无发布，直接返回
            timeout = 0;
            while (!result_valid && timeout < 8) begin
                @(negedge clk);
                timeout = timeout + 1;
                if (frame_tick || cancel) begin
                    // 被取消：不产生发布，接受已记录
                    repeat (2) @(negedge clk);
                    return;
                end
            end
            if (!result_valid) return;

            if (result_req_id !== this_id) $fatal(1, "published id mismatch");

            // held 稳定：3 沿内 ID 不变；期间若来帧沿则视为取消
            for (j = 0; j < 3; j = j + 1) begin
                @(negedge clk);
                if (frame_tick || cancel) begin
                    repeat (2) @(negedge clk);
                    return;
                end
                if (result_valid && result_req_id !== this_id)
                    $fatal(1, "held id unstable");
            end

            $fwrite(cap_file, "ID=%0d v0=%0d v1=%0d v2=%0d v3=%0d ACT=%0d CLIP=%b\n",
                    result_req_id,
                    $signed(voices_left[23:0]), $signed(voices_left[47:24]),
                    $signed(voices_left[71:48]), $signed(voices_left[95:72]),
                    active_voice_count, clip_any);
            success_count = success_count + 1;
            result_ready = 1'b1;
            @(negedge clk);
            result_ready = 1'b0;
            test_count = test_count + 1;
        end
    endtask

    task test_cancel_calc();
        // 这次接受是真实的（非帧非取消沿），必须记录 ACC，否则检查器相位错位。
        // 先把 FCW 固定成已知值，再等到确有能力接单的沿才驱动并记录。
        logic ok;
        ok = 1'b0;
        timeout = 0;
        while (!ok && timeout < 2000) begin
            @(negedge clk);
            if (calc_ready && !frame_tick && !cancel) begin
                req_id = 32'h9000_0001; voice_enable_mask = 4'b1111; enable = 1;
                fcw_lane0 = 32'h04B17E4D; fcw_lane1 = 32'h0;
                fcw_lane2 = 32'h0; fcw_lane3 = 32'h0;
                sample_req = 1;
                $fwrite(req_file, "ACC %0d 04b17e4d 00000000 00000000 00000000 15\n",
                        acc_id);
                acc_id = acc_id + 32'd1;
                accept_count = accept_count + 1;
                ok = 1'b1;
            end else begin
                sample_req = 1'b0;
            end
        end
        if (!ok) $fatal(1, "cancel-case accept timeout");
        @(negedge clk);
        sample_req = 0;
        @(negedge clk);
        cancel = 1;
        @(negedge clk);
        cancel = 0;
        for (i = 0; i < 20; i = i + 1) begin
            @(negedge clk);
            if (result_valid && result_req_id === 32'h9000_0001)
                $fatal(1, "T052_CANCELLED_REQUEST_PUBLISHED");
        end
        $display("  cancel in CALC: OK");
    endtask

    task test_saturation();
        // 复位对齐相位后四路同相满幅，观察正饱和与 clip。
        // 复位把 DDS 相位清 0，必须让检查器可见，否则其相位模型会错位。
        rst_n = 0;
        repeat (5) @(negedge clk);
        rst_n = 1;
        $fwrite(req_file, "RESET\n");
        repeat (3) @(negedge clk);
        fcw_lane0 = 32'h40000000; fcw_lane1 = 32'h40000000;
        fcw_lane2 = 32'h40000000; fcw_lane3 = 32'h40000000;
        voice_enable_mask = 4'b1111; enable = 1'b1; cancel = 0;
        begin
            integer seen_max;
            seen_max = 0;
            for (i = 0; i < 24 && !seen_max; i = i + 1) begin
                do_one(4'b1111, 32'h40000000, 32'h40000000, 32'h40000000, 32'h40000000);
                // voices_left 为每路 24bit 独立总线（16bit<<8 = 0x200000）；
                // 四路同相满幅时宽位和在 mixer 内夹到 0x7FFFFF 并由 clip_any 报告。
                if (clip_any && $signed(voices_left[23:0]) === 24'sh200000)
                    seen_max = 1;
            end
            if (!seen_max) $fatal(1, "T052_PCM24_POSITIVE_SATURATION_NOT_REPORTED");
        end
        $display("  positive saturation: OK");
    endtask

    initial begin
        #500ms;
        $display("FAIL: timeout");
        $fatal(1, "timeout");
    end

endmodule
