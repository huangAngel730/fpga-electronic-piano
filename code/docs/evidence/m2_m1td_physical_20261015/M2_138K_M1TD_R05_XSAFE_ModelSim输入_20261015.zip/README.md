# M1 independent execution handoff; nothing was run during this preparation.

From this directory's `inputs` subfolder, on a host with a verified ModelSim 10.7:

    vlib work
    vlog -sv +incdir+include -f compile.f
    vsim -c work.tb_m2_m1td_real_chain -do "run -all; quit -f"

Before execution seal the exact ModelSim binaries and dependency hashes,
commands, cwd, bounded deadlines (each tool <=300s, entire run <=900s),
new output folder and fail-on-FATAL/PASS-marker contract. A ModelSim process
exit 0 alone is not PASS. Run once only after reviewer approves the exact
source/tool combination. No Gowin, PnR, STA or device calls.

The TB checks MIDI->shared FIFO->real M1 sound/score->PCM/frame/PT8211
and reset, but it does not independently recompute M1 arithmetic or prove
BSRAM resource inference. The old T056 .fs and STA never apply here.
