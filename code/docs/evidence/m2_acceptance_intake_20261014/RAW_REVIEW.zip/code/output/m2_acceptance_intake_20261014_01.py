"""Read delivered packages/logs only; no software tests or HDL execution."""
import base64
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'code/output/M2_acceptance_intake_20261014_02'
OUT.mkdir(exist_ok=False)
GROUPS={
 'oneshot':ROOT/'code/docs/test/t052_publication_acceptance_20261012/CONTROL_PREPARATION_20261012/ONESHOT_20261013_SEALED_07',
 'tail':ROOT/'code/docs/test/t052_runner_acceptance_20261012/SEALED_TAIL_20261013_05'}
records={};files=[]
for kind,directory in GROUPS.items():
    seal=json.loads((directory/'seal.json').read_bytes())
    raw=base64.b64decode((directory/'evidence.zip.b64').read_bytes(),validate=False)
    assert len(raw)==seal['zip_bytes'] and hashlib.sha256(raw).hexdigest()==seal['zip_sha256']
    archive=zipfile.ZipFile(io.BytesIO(raw));assert archive.testzip() is None
    member_map=seal['source'] if kind=='oneshot' else json.loads(archive.read('MEMBERS.json'))
    assert len(archive.namelist())==seal['members']
    assert set(archive.namelist())==set(member_map)|({'member_inventory.json'} if kind=='oneshot' else {'MEMBERS.json'})
    for name,item in member_map.items():
        data=archive.read(name)
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],name
    logs={}
    for name in archive.namelist():
        if name.endswith(('.stdout.bin','.stderr.bin')) and len(archive.read(name))<50000:
            logs[name]=archive.read(name).decode('utf-8',errors='replace')
    (OUT/(kind+'_raw.zip')).write_bytes(raw)
    records[kind]=dict(raw_bytes=len(raw),raw_sha=seal['zip_sha256'],members_verified=len(member_map),
                       actual_HDL=seal.get('HDL_calls'),complete=seal['T052_complete'],logs=logs)
    files+=[directory/'seal.json',OUT/(kind+'_raw.zip')]
    if kind=='oneshot':
        config=json.loads((directory/'config.json').read_bytes())
        assert hashlib.sha256((directory/'config.json').read_bytes()).hexdigest()==seal['config']['sha256']
        assert config['execution_authorized'] is False and config['machine']=='LAPTOP-KSS1MRR7'
        assert config['budgets_seconds']==dict(total=300,compile=90,run=90,check=90)
        assert config['calls']==dict(compile=1,run=1,check=1,version_queries=0)
        for path,item in config['software'].items():
            relative=path.split('fpga-electronic-piano/',1)[1]
            data=(ROOT/relative).read_bytes()
            assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],relative
        assert not any('actual_once/' in n for n in archive.namelist())
        records[kind].update(config_SHA=seal['config']['sha256'],software_sources_verified=len(config['software']),
            machine=config['machine'],inventory_scope=config['inventory_scope'],actual_capture='NOT_RUN',
            prepared_manifest=config['manifest'])
        files+=[directory/'config.json',directory/'manifest.json']
repermit=ROOT/'code/docs/hardware/audio_math_acceptance_v1/T060_MINCLOSURE_20261011/REPERMIT_PREPARATION_20261013_01'
receipt=json.loads((repermit/'PREPARATION_RECEIPT.json').read_bytes())
for name,item in receipt['artifacts'].items():
    data=(repermit/name).read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
assert receipt['execution_authorized'] is False and receipt['compile_diagnostic_completed'] is False
assert receipt['old_permission_consumed'] is True and receipt['actual_HDL_EDA_tool_calls']==0
records['T060']=receipt
files+=list(repermit.glob('*.json'))
result=dict(commit='0b5f45388f974ce4ae0a2081eac7add93181c32a',scope='Delivered evidence source/log static intake only',
    records=records,new_tool_calls=0,old_tests_replayed=False)
(OUT/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
DEST=ROOT/'code/docs/evidence/m2_acceptance_intake_20261014'
DEST.mkdir(exist_ok=False)
files+=[Path(__file__),OUT/'review.json']
archive=DEST/'RAW_REVIEW.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as package:
    for path in files:package.write(path,path.relative_to(ROOT).as_posix())
summary=dict(commit=result['commit'],scope=result['scope'],members={k:v.get('members_verified') for k,v in records.items()},
    archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),new_tool_calls=0)
(DEST/'MANIFEST.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary,indent=2))
print('T052 config:',records['oneshot']['config_SHA'])
