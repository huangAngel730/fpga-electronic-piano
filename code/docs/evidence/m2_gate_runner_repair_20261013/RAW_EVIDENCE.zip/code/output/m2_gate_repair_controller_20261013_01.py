import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'code/output/M2_gate_repair_publish_20261013_01'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('owned_runner', ROOT / 'code/scripts/run_t025_top_stat.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
started = time.monotonic()
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode('utf-8').split('\0')
paths += ['code/scripts/test_run_t025_top_stat.py']
paths = sorted({p for p in paths if p and (ROOT / p).is_file() and Path(p).suffix.lower() in {'.py', '.ps1', '.sv', '.v', '.svh', '.sdc', '.cst', '.mem', '.hex', '.gprj', '.tcl', '.yaml', '.yml'}})


def snapshot():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}


before = snapshot()
pwsh = r'C:\Users\Angel17\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
command = [pwsh, '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(ROOT / 'code/scripts/check_repo.ps1')]
receipt = {'command': command, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'total_bound': 600, 'passed': False, 'inputs_before': before}
try:
    rc, timeout = runner.run_bounded(command, OUT, 600 - (time.monotonic() - started))
    after = snapshot()
    log = (OUT / 'stdout.log').read_text(encoding='utf-8', errors='replace') + (OUT / 'stderr.log').read_text(encoding='utf-8', errors='replace')
    (OUT / 'run.log').write_text(log, encoding='utf-8')
    receipt.update(exit=rc, timeout=timeout, inputs_after=after, inputs_unchanged=before == after, seconds=time.monotonic() - started)
    receipt['passed'] = rc == 0 and not timeout and before == after and receipt['seconds'] <= 600 and log.count('[PASS]') == 9 and '[FAIL]' not in log
    print(log[-6000:])
except Exception as error:
    receipt.update(error=type(error).__name__ + ': ' + str(error), seconds=time.monotonic() - started)
finally:
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: receipt.get(k) for k in ['exit', 'timeout', 'seconds', 'passed', 'inputs_unchanged', 'error']}))
    print('Receipt:', OUT / 'receipt.json')
sys.exit(0 if receipt['passed'] else 1)
