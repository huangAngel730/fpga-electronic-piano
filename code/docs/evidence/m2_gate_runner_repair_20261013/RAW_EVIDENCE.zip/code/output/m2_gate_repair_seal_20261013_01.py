"""Seal only the new gate and runner evidence; no tool invocation."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
GATE = ROOT / 'code/output/M2_gate_repair_publish_20261013_01'
receipt = json.loads((GATE / 'receipt.json').read_text(encoding='utf-8'))
assert receipt['passed'] and receipt['exit'] == 0 and not receipt['timeout']
assert receipt['inputs_before'] == receipt['inputs_after']
for name, digest in receipt['inputs_after'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
DEST = ROOT / 'code/docs/evidence/m2_gate_runner_repair_20261013'
DEST.mkdir(exist_ok=False)
files = [GATE / name for name in ('receipt.json', 'run.log', 'stdout.log', 'stderr.log')]
files += [ROOT / 'code/output/m2_gate_repair_controller_20261013_01.py', Path(__file__),
          ROOT / 'code/scripts/run_t025_top_stat.py', ROOT / 'code/scripts/test_run_t025_top_stat.py',
          ROOT / 'code/software/t052_runner_acceptance_candidate_20261012/windows_job.py']
for top in ('tb_electronic_piano_top', 'tb_key_to_tone', 'tb_midi_top_integration'):
    stages = sorted((ROOT / 'code/output').glob(top + '_20261013T*'), key=lambda p: p.stat().st_mtime)
    selected = [stages[-1]]
    if top == 'tb_key_to_tone':
        selected += [ROOT / 'code/output/tb_key_to_tone_20261013T123916_cda229e0']
    for stage in selected:
        local = json.loads((stage / 'receipt.json').read_text(encoding='utf-8'))
        assert local['passed'] and local['inputs_before'] == local['inputs_after']
        files.extend(stage / n for n in ('receipt.json', 'run.log', 'stdout.log', 'stderr.log', 'lower.ys', 'run.bat', 'allocator.v'))
files = sorted(set(files))
manifest = {'scope': 'Runner software and existing T007 gate only; no new Gowin or specialist capture',
            'gate_seconds': receipt['seconds'], 'gate_exit': receipt['exit'], 'gate_passed': receipt['passed'],
            'inputs_count': len(receipt['inputs_before']), 'inputs_unchanged': True, 'files': []}
archive = DEST / 'RAW_EVIDENCE.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as package:
    for path in files:
        data = path.read_bytes()
        name = path.relative_to(ROOT).as_posix()
        manifest['files'].append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        package.writestr(name, data)
manifest['archive'] = {'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(DEST / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: manifest[k] for k in ('gate_passed', 'gate_seconds', 'inputs_count', 'archive')}, indent=2))
