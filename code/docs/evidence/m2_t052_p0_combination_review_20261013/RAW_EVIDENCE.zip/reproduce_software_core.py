"""Pure software core review with exact two TOOL IDENTITY FIXTURES only.

This is not an actual-machine preflight or RTL receipt. The unmodified original
preflight rejected the different M2 compiler and its failure is retained.
"""
import argparse
import importlib.util
import io
import json
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "code/software/t052_publication_acceptance_candidate_20261012/rtl_capture_precheck_20261012/successor_20261013"
cli = argparse.ArgumentParser()
cli.add_argument("--output", type=Path, required=True)
out = cli.parse_args().output.resolve()
if out.exists():
    raise ValueError("REFUSE_EXISTING_OUTPUT")
out.mkdir(parents=True)
spec = importlib.util.spec_from_file_location("m2_core_software_fixture_tests", SOURCE / "test_checker.py")
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
checker = tests.checker
manifest = json.loads(tests.MANIFEST.read_text())
original = checker.source_identity


def software_tool_identity(item):
    for fixed in manifest["tools"].values():
        if item == fixed:
            return {key: fixed[key] for key in ("bytes", "sha256")}
    return original(item)


stream = io.StringIO()
with patch.object(checker, "source_identity", side_effect=software_tool_identity):
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(tests.CheckerTests))
(out / "software_core_tests.log").write_text(stream.getvalue(), encoding="utf-8", newline="\n")
print(json.dumps(dict(tests=result.testsRun, software_checks_pass=result.wasSuccessful(),
                     tool_identity_is_stub=True, real_tool_calls=0,
                     actual_machine_preflight_pass=False, actual_RTL_run=False)))
raise SystemExit(0 if result.testsRun == 24 and result.wasSuccessful() else 1)
