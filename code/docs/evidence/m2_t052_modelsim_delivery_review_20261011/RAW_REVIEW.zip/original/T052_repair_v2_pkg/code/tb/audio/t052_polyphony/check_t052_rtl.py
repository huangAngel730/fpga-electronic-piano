#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T052 独立数学检查器：重放 TB 记录，逐样本比对 DUT 捕获

用法：python check_t052_rtl.py <requests.log> <capture> <rom.mem>
"""
import sys
from pathlib import Path

# 4 个 lane 的独立相位，先取样后推进（与 RTL dds_oscillator.sv 一致）
PHASE_MOD = 1 << 32


def load_rom(path):
    rom = []
    with open(path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('//'):
                v = int(line, 16) & 0xFFFF
                if v >= 0x8000:
                    v -= 0x10000
                rom.append(v)
    return rom


def main():
    if len(sys.argv) != 4:
        print("用法: python check_t052_rtl.py <requests.log> <capture> <rom.mem>")
        return 2

    req_path, cap_path, rom_path = sys.argv[1], sys.argv[2], sys.argv[3]

    if not Path(rom_path).exists():
        print(f"FAIL: ROM不存在: {rom_path}")
        return 1
    if not Path(req_path).exists():
        print(f"FAIL: 请求记录不存在: {req_path}")
        return 1
    if not Path(cap_path).exists():
        print(f"FAIL: 捕获不存在: {cap_path}")
        return 1

    rom = load_rom(rom_path)

    reqs = []
    for line in Path(req_path).read_text(encoding='utf-8', errors='replace').splitlines():
        p = line.split()
        if p and p[0] == 'REQ':
            reqs.append((int(p[1]), int(p[2], 16), int(p[3], 16),
                         int(p[4], 16), int(p[5], 16), int(p[6])))

    caps = []
    for line in Path(cap_path).read_text(encoding='utf-8', errors='replace').splitlines():
        if not line.strip():
            continue
        # ID=%d PCM v0=%d v1=%d v2=%d v3=%d ACT=%d CLIP=%b
        parts = line.replace('=', ' ').split()
        d = {}
        d['ID'] = int(parts[1])
        d['v0'] = int(parts[4])
        d['v1'] = int(parts[6])
        d['v2'] = int(parts[8])
        d['v3'] = int(parts[10])
        d['ACT'] = int(parts[12])
        d['CLIP'] = int(parts[14])
        caps.append(d)

    if len(reqs) != len(caps):
        print(f"FAIL: 请求数({len(reqs)}) != 捕获数({len(caps)})")
        return 1

    # 逐请求独立重放：4 路相位持续推进（与 DUT 相同，跨请求不回滚）
    phases = [0, 0, 0, 0]
    mismatch = 0
    for idx, (rid, f0, f1, f2, f3, vmask) in enumerate(reqs):
        fcws = [f0, f1, f2, f3]
        # 先取样后推进
        samples = [rom[(phases[j] >> 22) & 0x3FF] for j in range(4)]
        for j in range(4):
            phases[j] = (phases[j] + fcws[j]) % PHASE_MOD

        exp = []
        act = 0
        for j in range(4):
            if (vmask >> j) & 1:
                exp.append(samples[j])
                act += 1
            else:
                exp.append(0)

        c = caps[idx]
        got = [c['v0'], c['v1'], c['v2'], c['v3']]
        if got != exp or c['ACT'] != act or c['ID'] != rid:
            mismatch += 1
            if mismatch <= 5:
                print(f"  不匹配 idx={idx} id={rid}: got={got}/{c['ACT']} exp={exp}/{act}")

    total = len(reqs)
    print(f"逐样本比对: {total - mismatch}/{total} 一致")
    if mismatch == 0 and total >= 4096:
        print(f"PASS: {total} 个成功结果全部与独立模型一致")
        return 0
    print(f"FAIL: {mismatch} 处不匹配")
    return 1


if __name__ == "__main__":
    sys.exit(main())
