"""Independent new-package audit; no RTL execution, old DUT failures REUSED."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PKG = ROOT / "original/T052_repair_v2_pkg"
SOURCE = PKG / "code/tb/audio/t052_polyphony/check_t052_rtl.py"
ROM = ROOT / "readonly_dependencies/sine_1024_8192.mem"


def run(label, requests, capture, expected):
    command = [sys.executable, "-B", "-X", "utf8", str(SOURCE),
               str(requests), str(capture), str(ROM)]
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=30)
    (ROOT / (label + ".stdout.bin")).write_bytes(result.stdout)
    (ROOT / (label + ".stderr.bin")).write_bytes(result.stderr)
    if result.returncode != expected:
        raise ValueError(f"{label}: {result.returncode} != {expected}")
    return dict(label=label, command=command, exit_code=result.returncode,
                expected_exit=expected, elapsed_seconds=time.monotonic() - start,
                stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                stderr_sha256=hashlib.sha256(result.stderr).hexdigest())


def main():
    request_path = PKG / "logs/tb_t052_requests.log"
    capture_path = PKG / "logs/tb_t052_polyphony.capture"
    requests = request_path.read_text("ascii").splitlines()
    captures = capture_path.read_text("ascii").splitlines()
    assert len(requests) == len(captures) == 4137
    pattern = re.compile(r"ID=\s*(\d+) PCM v0=\s*(-?\d+) v1=\s*(-?\d+) "
                         r"v2=\s*(-?\d+) v3=\s*(-?\d+) ACT=(\d+) CLIP=([01])")
    table = [int(token, 16) for token in ROM.read_text("ascii").split()]
    assert len(table) == 1024
    table = [x - 65536 if x & 32768 else x for x in table]
    phases = [0] * 4
    masks = set()
    mismatches = []
    for index, (req, cap) in enumerate(zip(requests, captures)):
        fields = req.split()
        assert len(fields) == 7 and fields[0] == "REQ"
        rid, fcws, mask = int(fields[1]), [int(x, 16) for x in fields[2:6]], int(fields[6])
        match = pattern.fullmatch(cap)
        assert match and 0 <= rid < 256 and 0 <= mask < 16
        got = [int(x) for x in match.groups()]
        expected = [table[p // (1 << 22)] if mask & (1 << lane) else 0
                    for lane, p in enumerate(phases)]
        if got[0] != rid or got[1:5] != expected or got[5] != mask.bit_count():
            mismatches.append(index)
        for lane in range(4):
            phases[lane] = (phases[lane] + fcws[lane]) & 0xffffffff
        masks.add(mask)
    assert not mismatches and masks == set(range(16))
    steps = [run("original_golden_check", request_path, capture_path, 0)]
    probes = ROOT / "checker_probes"
    probes.mkdir(exist_ok=False)
    variants = {
        "all_clip_flipped": (requests, [x[:-1] + str(1 - int(x[-1])) for x in captures]),
        "extra_unknown_request_tag": (requests + ["UNKNOWN request event"], captures),
        "paired_tail_truncated_4096": (requests[:4096], captures[:4096]),
        "request_mask_out_of_range": ([requests[0][:-1] + "17"] + requests[1:], captures),
    }
    for label, (req, cap) in variants.items():
        rp, cp = probes / (label + ".requests"), probes / (label + ".capture")
        rp.write_bytes(("\n".join(req) + "\n").encode("ascii"))
        cp.write_bytes(("\n".join(cap) + "\n").encode("ascii"))
        steps.append(run(label, rp, cp, 0))
    bad = captures.copy()
    bad[0] = bad[0].replace("v0=     0", "v0=     1", 1)
    cp = probes / "pcm_1lsb.capture"
    cp.write_bytes(("\n".join(bad) + "\n").encode("ascii"))
    steps.append(run("pcm_1lsb_rejected", request_path, cp, 1))
    summary = dict(rows=4137, lanes=16548, active_masks=sorted(masks),
                   independently_recomputed_lane_ID_ACT_mismatches=0,
                   mathematical_input_ROM_source="M2 supplementary Git 3eac8f1",
                   ROM_sha256=hashlib.sha256(ROM.read_bytes()).hexdigest(),
                   checker_false_acceptances=list(variants), steps=steps,
                   CLIP_not_mathematically_checked_by_original_checker=True,
                   accepted_request_handshakes_not_proven_by_request_log=True,
                   mutant_source_compile_run_capture_missing=True,
                   same_old_DUT_failures_reused_not_rerun=True,
                   new_RTL_Gowin_device=False, task_complete=False,
                   fcw_04b17e4d_at_48000=0x04b17e4d * 48000 / (1 << 32),
                   fixed_TB_sample_rate=50_000_000 / 1042)
    (ROOT / "capture_review.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
