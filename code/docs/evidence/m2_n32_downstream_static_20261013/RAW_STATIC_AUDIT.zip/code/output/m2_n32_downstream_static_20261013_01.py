"""Exact downstream audit/validation preparation; never runs HDL or EDA."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'code/build/138k_night_cache_combo/staged_20261010_01'
OUT = ROOT / 'code/output/M2_N32_downstream_static_20261013_01'
OUT.mkdir(exist_ok=False)


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


receipt_path = BASE / 'frozen_receipt.json'
frozen = json.loads(receipt_path.read_bytes())
assert frozen['version'] == 'night_cache_parser_hold_20261010_v1'
assert frozen['input_count'] == 62 and frozen['project_file_count'] == 53
assert frozen['new_RAM_reference_commit'] == '5e1d13c398fd1cf749c613a30b9238d1a46319b4'
protected = [receipt_path]
for name, expected in frozen['inputs'].items():
    path = BASE / 'inputs' / name
    assert identity(path)['sha256'] == expected['adapted_sha256'], name
    protected.append(path)
top_path = BASE / 'inputs/sources/audio_visual_coexistence_top.sv'
sdc_path = BASE / 'inputs/constraints/audio_visual_hold055.sdc'
core_path = BASE / 'inputs/sources/polyphonic_audio_core.sv'
candidate_path = ROOT / 'code/rtl/common/m2_n32_prom_candidate_20261013/m2_b2d_event_audio_prom.sv'
adapter_path = ROOT / 'code/rtl/audio_out/m2_polyphony_frame_candidate_20261012/premixed_frame_adapter.sv'
resource_path = ROOT / 'code/build/138k_polyphony_resource/prom_candidate_20261013_01/resource_receipt.json'
resource = json.loads(resource_path.read_bytes())
for path, digest in resource['input_SHA'].items():
    source = Path(path)
    assert identity(source)['sha256'] == digest, path
    protected.append(source)
assert identity(resource_path)['sha256'] == 'f77a526318cd213b164e9bed5d0d1d0f2ca19aad89a61813f082d7d5971151bf'
assert identity(candidate_path)['sha256'] == '4339784901857cab00ce856dc23ce993a59783398d37aca02648c3123b533e84'
assert identity(adapter_path)['sha256'] == 'd7952a5f986eb8b609cbe657907e418cfe751c6492d6e49469b5e37c390bb56c'
protected += [resource_path, candidate_path, adapter_path, Path(__file__)]
protected = sorted(set(protected))
before = {p.relative_to(ROOT).as_posix(): identity(p) for p in protected}


def anchors(path, tokens):
    rows = []
    lines = path.read_text(encoding='utf-8').splitlines()
    for token in tokens:
        found = [{'line': i, 'text': text.strip()} for i, text in enumerate(lines, 1) if token in text and not text.lstrip().startswith('//')]
        assert found, str(path) + ':' + token
        rows.append(dict(token=token, positions=found))
    return dict(path=path.relative_to(ROOT).as_posix(), identity=identity(path), anchors=rows)


top = top_path.read_text(encoding='utf-8')
assert '.wave_frame_load(i2s_frame_tick)' in top
assert '.wave_play_left(buffered_left), .wave_play_right(buffered_right)' in top
assert 'wire [31:0] status_active_voice_count, status_clip_count;' in top
aliases = [{'line': i, 'text': line.strip()} for i, line in enumerate(top.splitlines(), 1)
           if 'u_audio_core.u_' in line and not line.lstrip().startswith('//')]
assert len(aliases) == 6
hierarchy_rules = [{'line': i, 'text': line.strip()} for i, line in enumerate(sdc_path.read_text(encoding='utf-8').splitlines(), 1)
                   if 'g_polyphonic.u_audio_core/u_bank' in line and not line.lstrip().startswith('#')]
assert len(hierarchy_rules) == 8
required = [
    anchors(top_path, ['.frame_tick(i2s_frame_tick)', '.accepted_valid(shared_event_valid && shared_event_ready)', '.wave_frame_load(i2s_frame_tick)']),
    anchors(adapter_path, ['assign candidate_cancel=frame_tick', 'assign candidate_sample_valid=rst_n && !frame_tick', 'wire valid_current_result=candidate_result_valid && dispatched', '.clip_any(pcm_clip)']),
    anchors(BASE / 'inputs/sources/pcm_frame_observer.sv', ['observed_left <= play_left', 'observed_right <= play_right']),
    anchors(BASE / 'inputs/sources/i2s_tx.sv', ['assign frame_tick = frame_start', 'sample_left  <= next_left', 'sample_right <= next_right']),
    anchors(candidate_path, ['sample_ready = rst_n && idle && !cancel && !read_valid', 'assign publish=state==HOLD', 'clipped<=be_clipped']),
]
cases = [
    ('FRAME_EXPIRE', 'result arrives on frame_tick', 'No old-generation result handshake or commit; next ID credit survives'),
    ('READ_STALL', 'READ blocks initial sample_ready', 'Credit and ID retained; dispatch counted only on actual valid&&ready'),
    ('DRAIN_RECOVERY', 'Frame cancels busy backend', 'No new acceptance until old drain finishes; no stale output commit'),
    ('DUPLICATE_ID', 'Second valid for consumed current ID', 'At most one commit and one clip count'),
    ('WRONG_ID', 'Old or noncurrent result_id under valid', 'No successful buffer commit'),
    ('STEREO_SWAP', 'Distinct left/right signed samples; mutant swaps them', 'Public result to committed PCM unchanged; swap diagnostic rejects'),
    ('CLIP_TRANSPORT', 'Positive/negative saturation and exact full scale', 'Metadata copied from candidate, not inferred from PCM; clear/flip mutant rejects'),
    ('RESULT_HOLD', 'Backpressure on candidate output', 'ID/left/right/clipped stable until qualified handshake or explicit cancel'),
    ('RESET_FIRST_FRAME', 'Reset during queue, compute or HOLD', 'No old lifetime commit; silent initial frame and valid restart identity'),
    ('UNDERRUN_REPEAT', 'No completed sample for several full frames after first commit', 'Repeat last actual play PCM; count per full frame, observer captures repeats'),
    ('OBSERVATION_OVERLOAD', 'Display queue full or pixel clock stopped', 'Only observation dropped; audio dispatch/PCM/I2S unaffected'),
    ('STATUS_N32', '32 occupied including Release; repeated or cancelled request', '32-bit STAT unchanged; occupied population not 5-bit wrapping; latency contract explicit'),
]
result = dict(scope='New downstream source audit only, not new combination RTL or STA',
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    baseline_receipt=identity(receipt_path), baseline_inputs_verified=62,
    candidate_resource_receipt=identity(resource_path), protected_inputs=before,
    source_anchors=required, old_private_aliases_to_replace=aliases,
    old_audio_constraint_commands_to_remap=hierarchy_rules,
    status_protocol_bits=32, internal_occupancy_population_required_bits=6,
    open_status_choice='Keep frame-credit-to-commit latency meaning; do not silently redefine as actual-dispatch-to-result. Cancelled frames excluded.',
    preserve=['newRAM5e1d13c','40MHz_audio/25MHz_pixel/125MHz_serial', 'PLL/CST/ROM originals',
              'pre-NBA actual play PCM observation including silence/repeats', '4-voice and 60K fallback'],
    general_event_read_service_deadline='UNKNOWN', actual_new_combination_test='NOT_RUN',
    directed_cases=[dict(id=n, trigger=t, oracle=o, status='PREPARED_NOT_EXECUTED') for n,t,o in cases],
    new_RTL=0, new_EDA=0, new_approval=False, board_release_allowed=False)
after = {p.relative_to(ROOT).as_posix(): identity(p) for p in protected}
assert before == after
result['inputs_unchanged'] = True
(OUT / 'downstream_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
DEST = ROOT / 'code/docs/evidence/m2_n32_downstream_static_20261013'
DEST.mkdir(exist_ok=False)
with zipfile.ZipFile(DEST / 'RAW_STATIC_AUDIT.zip', 'x', compression=zipfile.ZIP_DEFLATED) as package:
    for path in [Path(__file__), OUT/'downstream_audit.json', receipt_path, resource_path, top_path, sdc_path, core_path, adapter_path,
                 BASE/'inputs/sources/pcm_frame_observer.sv', BASE/'inputs/sources/pcm_waveform_observer_bridge.sv']:
        package.write(path, path.relative_to(ROOT).as_posix())
archive = DEST/'RAW_STATIC_AUDIT.zip'
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
(DEST/'MANIFEST.json').write_text(json.dumps(dict(scope=result['scope'], protected_inputs=before,
    baseline_inputs=62, aliases=6, old_constraint_commands=8, directed_cases_prepared=len(cases),
    raw_output=identity(OUT/'downstream_audit.json'), archive=identity(archive)), ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(baseline_inputs=62, protected_inputs=len(before), aliases=6, old_constraints=8,
    cases_prepared=len(cases), new_RTL=0, new_EDA=0, status='STATIC_PREPARATION_COMPLETE_NOT_CONNECTED'), indent=2))
print('Evidence:', DEST)
