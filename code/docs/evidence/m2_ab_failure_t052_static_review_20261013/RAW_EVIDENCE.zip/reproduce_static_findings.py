"""New complete software counterexamples; NEVER invokes HDL/EDA tools."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "code/software/t052_publication_acceptance_candidate_20261012/rtl_capture_precheck_20261012"))
import precheck
import test_precheck

cli = argparse.ArgumentParser()
cli.add_argument("--output", type=Path, required=True)
out = cli.parse_args().output.resolve()
if out.exists():
    raise ValueError("REFUSE_EXISTING_OUTPUT")
out.mkdir(parents=True)

baseline = out / "baseline"
baseline.mkdir()
paths = test_precheck.synthetic_tracks(baseline)
normal = precheck.validate_capture(test_precheck.MANIFEST, test_precheck.PLAN, *paths)
assert normal["ledger"] == dict(type="END", accepted=6, published=3, cancelled=3, open=0)

zero = out / "all_observed_accepts_erased"
zero.mkdir()
paths = test_precheck.synthetic_tracks(zero)
observations = precheck.read_jsonl(paths[1])
for row in observations[1:-1]:
    row.update(calc_ready=0, result_valid=0, result_req_id=0)
test_precheck.write_jsonl(paths[1], observations)
events = precheck.read_jsonl(paths[2])
test_precheck.write_jsonl(paths[2], [events[0], dict(type="END", accepted=0, published=0, cancelled=0, open=0)])
lost = precheck.validate_capture(test_precheck.MANIFEST, test_precheck.PLAN, *paths)
assert lost["exit_code"] == 0 and lost["ledger"]["accepted"] == 0

forged = out / "forged_source_sha"
forged.mkdir()
paths = test_precheck.synthetic_tracks(forged)
controls = precheck.read_jsonl(paths[0])
controls[0].update(rom_sha256="0" * 64, tb_sha256="0" * 64, observer_sha256="0" * 64, tool_sha256="0" * 64)
test_precheck.write_jsonl(paths[0], controls)
wrong_source = precheck.validate_capture(test_precheck.MANIFEST, test_precheck.PLAN, *paths)
assert wrong_source["exit_code"] == 0

print(json.dumps(dict(baseline=normal["ledger"], all_accepts_erased_exit=lost["exit_code"], forged_source_exit=wrong_source["exit_code"], real_RTL_runs=0)))
