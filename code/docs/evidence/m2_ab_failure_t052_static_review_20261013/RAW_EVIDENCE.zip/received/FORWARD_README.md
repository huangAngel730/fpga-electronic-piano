# M3 T060/T052 增量交接（2026-10-13）

## Git 身份

- 功能提交：`9998438740b6a5dabf631c8f5936d3341b8eb347`
- 编号登记提交：`83244ce27adad511965d31aaeec6f5d952940b28`
- 已核远端：`origin/develop = 83244ce27adad511965d31aaeec6f5d952940b28`
- 登记：`V0308`、`V0309`

## T060 精确 A/B 唯一执行

- 授权机器：`LAPTOP-KSS1MRR7`
- config SHA-256：`deef8bc73b6f8f2789149f3c1558bf05954919dbe05cda1d03dd2e97fefce637`
- approval SHA-256：`78c251492a8003db9a573ea3c0e4b6df0ce44bc59fa01444ba49426314627131`
- 默认锁闭预检：退出 0。
- 唯一执行：总退出 1，状态 `FAIL_PARTIAL`。
- `A_lower`：退出 0；`A_compile`：Windows `0xC0000005`；无 A.vvp、无 A capture，B 未启动。
- 许可已消费；未重试、未换工具、未提高超时。

## T052 128 沿静态准备

- 六项软件测试和静态预检通过，资格器退出 0。
- 薄 TB、170-bit 控制 memory、仅公开端口 pre-NBA observer、真实 accept/publish 资格与 UNKNOWN 开放窗口合同已封存。
- `execution_authorized=false`；未执行 lower、compile、VVP、Gowin 或设备操作。
- 计划的 6 接受／3 发布／3 取消仍为软件预测，不冒充真实 RTL 结果。

完整 T052/T060/T061 均保持 `PARTIAL`。请 M2 只复核本次增量，并决定 T060 失败后继范围及 T052 唯一小窗口采集是否放行。
