cd {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/build/138k_polyphony_resource/m3_n32_allocator_candidate_20261013/prepared/N32_R1_20261014_R01}
open_project {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/build/138k_polyphony_resource/m3_n32_allocator_candidate_20261013/prepared/N32_R1_20261014_R01/n32_resource.gprj}
set_option -top_module m3_n32_resource
set_option -verilog_std sysv2017
set_option -include_path {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/build/138k_polyphony_resource/m3_n32_allocator_candidate_20261013/prepared/N32_R1_20261014_R01/include}
run syn
