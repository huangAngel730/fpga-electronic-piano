"""Bounded owned-job supervision with nonblocking dual-pipe polling.

No process or Win32 call at import. Production adapter selects the native
factory; directed fake tests inject a separate factory into this low layer.
"""

import hashlib
import json
from pathlib import Path
import re
import time


BAD_DIAGNOSTIC = re.compile(
    rb"(?:^|\n)\s*(?:#\s*)?\*\*\s*(?:Error|Fatal)\b|Errors:\s*[1-9][0-9]*", re.I)


def _write_new(path, value):
    body = (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=True, allow_nan=False) + "\n").encode("ascii")
    with Path(path).open("xb") as handle:
        if handle.write(body) != len(body):
            raise OSError("RECEIPT_SHORT_WRITE")


def run_owned(argv, cwd, output_dir, *, factory, environment, deadline,
              timeout_seconds, memory_bytes, active_limit=16, log_limit=64 << 20,
              cleanup_seconds=10.0, clock=time.monotonic, sleep=time.sleep,
              on_created=None, resource_guard=None, scan_modelsim_errors=True):
    """One command only; total includes cleanup, stdout/stderr to real EOF.

    factory protocol: launch -> poll/accounting/read_available/terminate/close.
    This function is not an arbitrary-command authorization or actual GO.
    """
    if not (0 < cleanup_seconds < timeout_seconds <= 3600
            and type(log_limit) is int and 0 < log_limit <= 64 << 20
            and type(memory_bytes) is int and 0 < memory_bytes <= 2 << 30
            and type(active_limit) is int and 1 <= active_limit <= 16):
        raise ValueError("SUPERVISOR_EXPLICIT_LIMITS")
    started = clock()
    end = min(deadline, started + timeout_seconds)
    if end - started <= cleanup_seconds:
        raise TimeoutError("NO_COMPLETE_CALL_AND_CLEANUP_RESERVE")
    execution_end = end - cleanup_seconds
    output = Path(output_dir)
    output.mkdir(parents=False, exist_ok=False)
    handles, paths = [], [output / "stdout.bin", output / "stderr.bin"]
    count, read_count, eof = [0, 0], [0, 0], [False, False]
    hashes = [hashlib.sha256(), hashlib.sha256()]
    overlap = [b"", b""]
    first, cleanup_errors = None, []
    job = None
    created_pid = None
    terminated = timeout = job_zero = False
    exit_code = None
    samples = []
    offending_samples, seen_pids = [], []
    saturated_pid_samples = []
    closed = {"root_handle_closed": False, "job_handle_closed": False,
              "pipe_handles_closed": False, "cleanup_errors": []}
    launch_evidence = None
    root_exit_first = None
    # Windows console/loader helpers may reap just after the root. A bounded
    # natural-drain grace prevents a millisecond race from becoming a false
    # leak. It remains inside the original cleanup/whole-call reservation.
    root_exit_grace = min(0.25, cleanup_seconds / 2)

    def fail(code, error=None):
        nonlocal first
        if first is None:
            message = None
            if error is not None:
                try:
                    message = str(error)[:512]
                except BaseException:
                    message = "EXCEPTION_MESSAGE_UNAVAILABLE"
            first = {"code": code, "error_type": type(error).__name__ if error else None,
                     "message": message,
                     "cause_code": getattr(error, "code", None),
                     "winerror": getattr(error, "winerror", None)}

    def created(pid):
        nonlocal created_pid
        created_pid = pid
        if on_created is not None:
            on_created(pid)

    def pump():
        for index in range(2):
            if eof[index]:
                continue
            body = job.read_available(index, 65536)
            if body is None:
                continue
            if type(body) is not bytes or len(body) > 65536:
                raise ValueError("DRAIN_READ_CONTRACT")
            if body == b"":
                eof[index] = True
                continue
            read_count[index] += len(body)
            allowed = max(0, log_limit - sum(count))
            kept = body[:allowed]
            if kept:
                written = handles[index].write(kept)
                if written != len(kept):
                    raise OSError("RAW_STREAM_SHORT_WRITE")
                hashes[index].update(kept)
                count[index] += len(kept)
            if len(kept) != len(body):
                fail("COMBINED_OUTPUT_LIMIT")
            if scan_modelsim_errors and BAD_DIAGNOSTIC.search(overlap[index] + body):
                fail("MODELSIM_ERROR_DIAGNOSTIC")
            overlap[index] = body[-256:]

    def observe_job():
        nonlocal exit_code, job_zero
        exit_code = job.poll()
        stats = job.accounting()
        if not (type(stats) is dict and type(stats.get("active")) is int
                and type(stats.get("total")) is int and 0 <= stats["active"] <= stats["total"]):
            raise ValueError("JOB_ACCOUNTING_CONTRACT")
        sample = {"at_seconds": clock() - started, **stats}
        samples.append(sample)
        del samples[:-16]
        ids = stats.get("process_ids", [])
        if not (type(ids) is list and len(ids) <= 64 and all(type(x) is int and x > 0 for x in ids)):
            raise ValueError("JOB_PID_SNAPSHOT_CONTRACT")
        for pid in ids:
            if pid not in seen_pids and len(seen_pids) < 64:
                seen_pids.append(pid)
        installed_cap = (launch_evidence or {}).get("job_limits", {}).get("active_process_limit", active_limit)
        if len(ids) == installed_cap and stats["active"] >= installed_cap and len(saturated_pid_samples) < 8:
            saturated_pid_samples.append(sample)
        if stats["active"] > active_limit:
            if len(offending_samples) < 8:
                offending_samples.append(sample)
            # Production still fails immediately at its configured guard.
            # A qualification-only factory can install a LOWER kernel limit
            # while requesting a larger diagnostic accounting guard.
            raise ValueError("JOB_ACCOUNTING_CONTRACT")
        job_zero = stats["active"] == 0
        return stats

    try:
        for path in paths:
            handles.append(path.open("xb", buffering=0))
        if resource_guard is not None:
            resource_guard()
        job = factory.launch(list(argv), str(cwd), dict(environment),
                             memory_bytes=memory_bytes, active_limit=active_limit,
                             on_created=created, cleanup_seconds=cleanup_seconds)
        launch_evidence = dict(job.evidence)
        while True:
            pump()
            stats = observe_job()
            if exit_code is not None and exit_code != 0:
                fail("NATURAL_NONZERO_EXIT")
            if exit_code is not None:
                if root_exit_first is None:
                    root_exit_first = clock()
                if stats["active"] > 0 and clock() - root_exit_first >= root_exit_grace:
                    fail("DESCENDANTS_REMAIN_AFTER_ROOT_EXIT")
            if resource_guard is not None:
                resource_guard()
            now = clock()
            if now >= execution_end and first is None:
                timeout = True
                fail("EXECUTION_TIMEOUT")
            if exit_code is not None and job_zero and all(eof):
                break
            if first is not None and not terminated:
                job.terminate()
                terminated = True
            if now >= end:
                fail("CLEANUP_DEADLINE_OR_EOF_INCOMPLETE")
                break
            sleep(min(0.01, max(0, end - clock())))
    except BaseException as error:
        fail("LAUNCH_OR_SUPERVISION_ERROR", error)
        launch_evidence = getattr(error, "launch_evidence", launch_evidence)
    finally:
        if job is not None:
            if not (job_zero and exit_code is not None and all(eof)):
                try:
                    if not terminated:
                        job.terminate()
                        terminated = True
                    while clock() < end:
                        pump()
                        observe_job()
                        if job_zero and exit_code is not None and all(eof):
                            break
                        sleep(min(0.01, max(0, end - clock())))
                except BaseException as error:
                    cleanup_errors.append(type(error).__name__)
            try:
                closed = job.close()
                cleanup_errors += closed.get("cleanup_errors", [])
            except BaseException as error:
                cleanup_errors.append(type(error).__name__)
        for handle in handles:
            try:
                handle.close()
            except BaseException as error:
                cleanup_errors.append(type(error).__name__)
    streams = []
    for index, path in enumerate(paths):
        exists = path.is_file()
        stored_size = path.stat().st_size if exists else None
        streams.append({"path": str(path), "bytes": count[index], "sha256": hashes[index].hexdigest(),
                        "read_bytes": read_count[index], "eof": eof[index],
                        "closed": len(handles) > index and handles[index].closed,
                        "identity_complete": exists and stored_size == count[index],
                        "truncated_by_limit": read_count[index] > count[index]})
    clean = (job is not None and job_zero and all(eof) and not cleanup_errors
             and launch_evidence is not None
             and launch_evidence.get("assigned_before_resume") is True
             and launch_evidence.get("resumed") is True
             and all(closed.get(key) is True for key in (
                 "root_handle_closed", "job_handle_closed", "pipe_handles_closed"))
             and all(s["identity_complete"] and s["closed"] for s in streams))
    if not clean:
        fail("CLEANUP_NOT_PROVEN")
    if clock() > end:
        fail("TOTAL_CALL_DEADLINE_EXCEEDED")
    success = first is None and exit_code == 0 and clean
    result = {"schema": "M3_C9_R06_OWNED_CALL_V1", "status": "NATURAL_EXIT_CLEAN" if success else "FAILED_PARTIAL",
              "argv": list(argv), "cwd": str(cwd), "factory_kind": factory.kind,
              "started_monotonic": started, "ended_monotonic": clock(), "elapsed_seconds": clock() - started,
              "execution_deadline": execution_end, "total_deadline": end,
              "timeout": timeout, "exit_code": exit_code, "created_pid": created_pid,
              "root_exit_first_monotonic": root_exit_first,
              "bounded_natural_reap_grace_seconds": root_exit_grace,
              "launch": launch_evidence, "termination_requested": terminated,
              "job_zero_observed_before_close": job_zero, "job_accounting_last16": samples,
              "job_accounting_offending_first8": offending_samples, "job_process_ids_seen_first64": seen_pids,
              "job_at_hard_cap_pid_samples_first8": saturated_pid_samples,
              **closed, "stdout": streams[0], "stderr": streams[1],
              "first_error": first, "cleanup_errors": cleanup_errors,
              "combined_log_limit": log_limit, "memory_hard_limit_bytes": memory_bytes,
              "active_process_hard_limit": (launch_evidence or {}).get("job_limits", {}).get("active_process_limit", active_limit),
              "accounting_active_guard_limit": active_limit,
              "environment_names_only": sorted(environment),
              "raw_failure_prefixes_preserved": True, "real_C9_verified": False}
    _write_new(output / "RESULT.json", result)
    return result
