"""Explicit runtime Windows Job backend; import performs no Win32 calls.

Reuses the SHA-pinned existing WindowsJob definitions/attach-and-resume.
No process is created until the returned factory.launch is explicitly called.
"""

import hashlib
from pathlib import Path
from types import ModuleType


HELPER = "code/software/t052_runner_acceptance_candidate_20261012/windows_job.py"
HELPER_BYTES = 3481
HELPER_SHA = "5450b8943b0616cc0f8ad7147c1c6a4b20eb4f04d8a7cc3fb515825941c0df1b"
# Win32 CreateProcess flags; Python subprocess does not export every flag.
CREATE_SUSPENDED = 0x00000004
CREATE_NO_WINDOW = 0x08000000
CREATE_PROCESS_FLAGS = CREATE_SUSPENDED | CREATE_NO_WINDOW


def available_ram_bytes():
    """Runtime-only local OS metadata, never a tool/license probe."""
    import ctypes as C
    from ctypes import wintypes as W

    class Memory(C.Structure):
        _fields_ = [("length", W.DWORD), ("load", W.DWORD)] + [
            (name, C.c_uint64) for name in ("total", "available", "page_total", "page_available",
                                           "virtual_total", "virtual_available", "extended")]
    value = Memory()
    value.length = C.sizeof(value)
    fn = C.WinDLL("kernel32", use_last_error=True).GlobalMemoryStatusEx
    fn.argtypes, fn.restype = [C.POINTER(Memory)], W.BOOL
    if not fn(C.byref(value)):
        raise C.WinError(C.get_last_error())
    return int(value.available)


def allocation_reader():
    """Explicit-runtime on-disk file allocation metadata (sparse/compressed aware)."""
    import ctypes as C
    from ctypes import wintypes as W

    fn = C.WinDLL("kernel32", use_last_error=True).GetCompressedFileSizeW
    fn.argtypes, fn.restype = [W.LPCWSTR, C.POINTER(W.DWORD)], W.DWORD

    def read(path):
        high = W.DWORD()
        C.set_last_error(0)
        low = fn(str(path), C.byref(high))
        error = C.get_last_error()
        if low == 0xFFFFFFFF and error:
            raise C.WinError(error)
        return (int(high.value) << 32) | int(low)
    return read


def load_factory(repo_root):
    """Finite pinned source load only when the admitted caller asks for it."""
    path = Path(repo_root) / HELPER
    with path.open("rb") as source:
        body = source.read(HELPER_BYTES + 1)
    if len(body) != HELPER_BYTES or hashlib.sha256(body).hexdigest() != HELPER_SHA:
        raise ValueError("WINDOWS_JOB_SOURCE_CHANGED")
    module = ModuleType("_c9_r06_exact_windows_job")
    module.__file__ = str(path)
    exec(compile(body, str(path), "exec"), module.__dict__)
    return WindowsFactory(module)


class WindowsFactory:
    source_sha256 = HELPER_SHA
    kind = "WINDOWS_SUSPENDED_OWNED_JOB_R06"

    def __init__(self, helper):
        self.helper = helper

    def launch(self, argv, cwd, environment, *, memory_bytes, active_limit,
               on_created, cleanup_seconds):
        # Imports and every native call are behind explicit launch, never a
        # tool/version probe and never part of writer-side source preparation.
        import ctypes as C
        from ctypes import wintypes as W
        import os
        import subprocess
        import time

        if os.name != "nt":
            raise OSError("WINDOWS_REQUIRED")
        if not (type(memory_bytes) is int and 0 < memory_bytes <= 2 << 30
                and type(active_limit) is int and 1 <= active_limit <= 16
                and 0 < cleanup_seconds <= 30):
            raise ValueError("JOB_RESOURCE_LIMITS")
        job = self.helper.WindowsJob()
        process = None
        evidence = {"create_process_attempted": False, "process_created": False,
                    "assigned_before_resume": False, "resumed": False,
                    "created_pid": None, "launch_stage": "SET_JOB_LIMITS"}
        try:
            limits = self.helper._ExtendedLimit()
            limits.basic.flags = 0x2000 | 0x0200 | 0x0008 | 0x0001
            limits.basic.min_working_set = 2 << 20
            limits.basic.max_working_set = 512 << 20
            limits.basic.active_process_limit = active_limit
            limits.job_memory = memory_bytes
            if not job.kernel.SetInformationJobObject(job.handle, 9, C.byref(limits), C.sizeof(limits)):
                raise C.WinError(C.get_last_error())
            query = job.kernel.QueryInformationJobObject
            query.argtypes, query.restype = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.c_void_p], W.BOOL
            readback = self.helper._ExtendedLimit()
            if not query(job.handle, 9, C.byref(readback), C.sizeof(readback), None):
                raise C.WinError(C.get_last_error())
            if (readback.basic.flags != limits.basic.flags
                    or readback.basic.active_process_limit != active_limit
                    or readback.job_memory != memory_bytes
                    or readback.basic.min_working_set != 2 << 20
                    or readback.basic.max_working_set != 512 << 20):
                raise ValueError("JOB_HARD_LIMIT_READBACK_MISMATCH")
            evidence["job_limits"] = {"readback_verified": True, "flags": int(readback.basic.flags),
                                      "active_process_limit": active_limit, "job_memory_bytes": memory_bytes, "min_process_working_set": 2 << 20, "max_process_working_set": 512 << 20}
            evidence["launch_stage"] = "CREATE_SUSPENDED"
            evidence["create_process_attempted"] = True
            process = subprocess.Popen(
                list(argv), cwd=str(cwd), env=dict(environment), shell=False,
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                close_fds=True, bufsize=0,
                creationflags=CREATE_PROCESS_FLAGS)
            evidence.update(process_created=True, created_pid=process.pid)
            evidence["job_identity"] = {"controller_pid": os.getpid(), "root_pid": process.pid,
                                        "owned_handle_value": int(job.handle)}
            # Durable unit consumption callback occurs before any child code.
            on_created(process.pid)
            evidence["launch_stage"] = "ASSIGN_AND_RESUME"
            job.attach_and_resume(process)
            evidence.update(assigned_before_resume=True, resumed=True, launch_stage="RUNNING")
            return OwnedWindowsProcess(job, process, evidence, C, W)
        except BaseException as primary:
            evidence["launch_stage_failed"] = evidence["launch_stage"]
            failures = []
            end = time.monotonic() + cleanup_seconds
            if process is not None:
                try:
                    # If attach failed, the old helper already kills the
                    # suspended root. No arbitrary PID/process-tree fallback.
                    if process.poll() is None:
                        if evidence["resumed"]:
                            job.terminate()
                        else:
                            process.kill()
                    process.wait(timeout=max(0.001, end - time.monotonic()))
                except BaseException as secondary:
                    failures.append(type(secondary).__name__)
                for stream in (process.stdout, process.stderr):
                    try:
                        stream.close()
                    except BaseException as secondary:
                        failures.append(type(secondary).__name__)
                try:
                    if process._handle is not None:
                        process._handle.Close()
                        process._handle = None
                except BaseException as secondary:
                    failures.append(type(secondary).__name__)
            try:
                if job.handle:
                    if not job.kernel.CloseHandle(job.handle):
                        raise C.WinError(C.get_last_error())
                    job.handle = None
            except BaseException as secondary:
                failures.append(type(secondary).__name__)
            evidence["cleanup_errors"] = failures
            primary.launch_evidence = evidence
            raise


class OwnedWindowsProcess:
    def __init__(self, job, process, evidence, C, W):
        self.job, self.process, self.evidence = job, process, dict(evidence)
        self.C, self.W = C, W
        self.streams = (process.stdout, process.stderr)
        self.pid = process.pid
        self.root_closed = self.job_closed = False
        self.terminated = False
        self.exit_code = None

        class Accounting(C.Structure):
            _fields_ = [(name, C.c_int64) for name in ("user", "kernel", "period_user", "period_kernel")] + [
                (name, W.DWORD) for name in ("faults", "total", "active", "terminated")]
        self.accounting_type = Accounting

        class ProcessIds(C.Structure):
            _fields_ = [("assigned", W.DWORD), ("count", W.DWORD), ("ids", C.c_size_t * 64)]
        self.process_ids_type = ProcessIds
        job.kernel.PeekNamedPipe.argtypes = [W.HANDLE, C.c_void_p, W.DWORD, C.c_void_p,
                                             C.POINTER(W.DWORD), C.c_void_p]
        job.kernel.PeekNamedPipe.restype = W.BOOL

    def poll(self):
        if not self.root_closed:
            self.exit_code = self.process.poll()
        return self.exit_code

    def accounting(self):
        C, W = self.C, self.W

        value = self.accounting_type()
        fn = self.job.kernel.QueryInformationJobObject
        fn.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.c_void_p]
        fn.restype = W.BOOL
        if not fn(self.job.handle, 1, C.byref(value), C.sizeof(value), None):
            raise C.WinError(C.get_last_error())
        ids = self.process_ids_type()
        if not fn(self.job.handle, 3, C.byref(ids), C.sizeof(ids), None):
            raise C.WinError(C.get_last_error())
        if not 0 <= ids.count <= ids.assigned <= 64:
            raise ValueError("JOB_PID_SNAPSHOT_BOUND")
        return {"active": int(value.active), "total": int(value.total), "terminated": int(value.terminated),
                "pid_snapshot_assigned": int(ids.assigned),
                "process_ids": [int(ids.ids[i]) for i in range(ids.count)]}

    def read_available(self, index, maximum=65536):
        """No blocking read when empty; no drain threads or unlimited queue."""
        import msvcrt
        C, W = self.C, self.W
        available = W.DWORD()
        handle = W.HANDLE(msvcrt.get_osfhandle(self.streams[index].fileno()))
        if not self.job.kernel.PeekNamedPipe(handle, None, 0, None, C.byref(available), None):
            error = C.get_last_error()
            if error == 109:  # ERROR_BROKEN_PIPE after every inherited writer closes
                return b""
            raise C.WinError(error)
        if available.value == 0:
            return None
        # This is the only reader; request <= bytes Peek proved present.
        return self.streams[index].read(min(maximum, available.value))

    def terminate(self):
        self.job.terminate()
        self.terminated = True

    def close(self):
        failures = []
        for stream in self.streams:
            try:
                stream.close()
            except BaseException as error:
                failures.append(type(error).__name__)
        try:
            if self.process._handle is not None:
                self.process._handle.Close()
                self.process._handle = None
            self.root_closed = self.process._handle is None
        except BaseException as error:
            failures.append(type(error).__name__)
        try:
            if self.job.handle:
                if not self.job.kernel.CloseHandle(self.job.handle):
                    raise self.C.WinError(self.C.get_last_error())
                self.job.handle = None
            self.job_closed = self.job.handle is None
        except BaseException as error:
            failures.append(type(error).__name__)
        return {"root_handle_closed": self.root_closed, "job_handle_closed": self.job_closed,
                "pipe_handles_closed": all(stream.closed for stream in self.streams),
                "cleanup_errors": failures}
