"""Read actual implementation reports; never infer STA pass from tool exit 0."""
import hashlib
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

REPO = Path(__file__).resolve().parents[4]
BASE = REPO / "code/output/m3_pro_audio_r10_20261021"


def pin(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def review(ident):
    attempt = BASE / ident
    native = json.loads((attempt / "native/RESULT.json").read_text(encoding="utf-8"))
    root = json.loads((attempt / "ROOT_RETURN.json").read_text(encoding="utf-8"))
    pnr = attempt / "pro_audio/impl/pnr"
    text = (pnr / "pro_audio.tr").read_text(encoding="utf-8")
    report = (pnr / "pro_audio.rpt.txt").read_text(encoding="utf-8")
    stdout = (attempt / "native/stdout.bin").read_text(encoding="utf-8", errors="replace")
    body = text[text.index("Note:Core Timing Report"):]

    def counter(name):
        matches = re.findall(r"<" + re.escape(name) + r">:(\d+)", body)
        if len(matches) != 1:
            raise ValueError("Missing or ambiguous STA counter: " + name)
        return int(matches[0])

    def worst(section):
        start = body.index(section)
        match = re.search(r"^\s*1\s+(-?\d+\.\d+)\s+", body[start:], re.M)
        if not match:
            raise ValueError("Missing timing path: " + section)
        return float(match[1])

    counts = {name: counter("Numbers of " + name) for name in [
        "Paths Analyzed", "Endpoints Analyzed", "Setup Violated Endpoints", "Hold Violated Endpoints"]}
    slacks = {name: worst(section) for name, section in [
        ("setup", "3.1.1 Setup Paths Table"), ("hold", "3.1.2 Hold Paths Table"),
        ("recovery", "3.1.3 Recovery Paths Table"), ("removal", "3.1.4 Removal Paths Table")]}
    clocks = {"ref_50MHz": bool(re.search(r"ref_clk\s+Base\s+20\.000\s+50\.000MHz", body)),
              "generated_core_40MHz": bool(re.search(r"core_clk\s+Generated\s+25\.000\s+40\.000MHz", body)),
              "exact_PLL_pin": "u_audio/u_audio_pll/u_pll/PLL_inst/CLKOUT2" in body}
    target = ("<Part Number>: GW5AST-LV138FPG676AC1/I0" in body and
              "<Device Version>: C" in body and "<Tool Version>: V1.9.12.04 (64-bit)" in body)
    errors = [line for line in stdout.splitlines() if re.search(r"\b(?:ERROR|FATAL)\s*\(", line)]
    pnr_pass = (native["status"] == "NATURAL_EXIT_CLEAN" and native["exit_code"] == 0 and
                not root["input_drift"] and "Placement and routing completed" in stdout and
                "Bitstream generation completed" in stdout and not errors and target)
    sta_pass = (pnr_pass and counts["Paths Analyzed"] > 0 and counts["Endpoints Analyzed"] > 0 and
                counts["Setup Violated Endpoints"] == 0 and counts["Hold Violated Endpoints"] == 0 and
                all(value >= 0 for value in slacks.values()) and all(clocks.values()))
    peak = max(s.get("peak_job_memory_bytes", 0) for s in native["job_accounting_last16"])
    result = {"schema": "M3_PRO_AUDIO_R10_REPORT_SELF_REVIEW", "at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "attempt": ident, "status": "SYNTHESIS_PNR_BASIC_STA_PASS" if sta_pass else "PNR_PASS_STA_PARTIAL",
        "synthesis_pass": "GowinSynthesis finish" in stdout, "PnR_pass": pnr_pass,
        "basic_STA_pass": sta_pass, "STA_counters": counts, "reported_worst_slack_ns": slacks,
        "clock_checks": clocks, "correct_target_and_commercial_version": target,
        "native_exit": native["exit_code"], "native_elapsed_seconds": native["elapsed_seconds"],
        "actual_job_peak_commit_bytes": peak if peak else None,
        "job_hard_memory_bytes": native["memory_hard_limit_bytes"],
        "Job_zero_and_handles_closed": native["job_zero_observed_before_close"] and all(native[k] for k in ["root_handle_closed", "job_handle_closed", "pipe_handles_closed"]),
        "warnings_preserved": [line for line in stdout.splitlines() if re.search(r"\bWARN\s*\(", line)],
        "ordinary_reference_clock_routing_PR1014": "PR1014" in stdout,
        "reports": [pin(pnr / name) for name in ["pro_audio.tr", "pro_audio.rpt.txt", "pro_audio.pin.html"]],
        "bitstream": pin(pnr / "pro_audio.fs"), "raw_native_receipt": pin(attempt / "native/RESULT.json"),
        "input_manifest": pin(attempt / "INPUT_MANIFEST.json"),
        "boundary": {"N_and_tail": "验证后补", "full_C9_pass": False, "full_RTL_simulation_pass": False,
            "downloaded": False, "field_audio_measured": False,
            "scope": "Current constrained physical design: 50 MHz reference, 40 MHz audio core and declared audio output constraints. No independent external PT8211 timing or board-voltage measurement is inferred.",
            "pending_board": ["Current Bank straps and external MIDI isolation", "Exact .fs technical/physical release", "Actual audio and reset behavior"]}}
    with (attempt / "REPORT_SELF_REVIEW.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({k: result[k] for k in ["attempt", "status", "STA_counters", "reported_worst_slack_ns", "bitstream"]}, ensure_ascii=False))
    return 0 if sta_pass else 1


if __name__ == "__main__":
    raise SystemExit(review(sys.argv[1]))
