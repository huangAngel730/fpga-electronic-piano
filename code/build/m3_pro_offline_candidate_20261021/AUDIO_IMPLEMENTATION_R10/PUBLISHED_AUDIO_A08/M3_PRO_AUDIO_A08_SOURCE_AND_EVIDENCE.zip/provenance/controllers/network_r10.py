"""Reuse the qualified 30-second transport; isolate this delivery's ledger."""
import hashlib
import json
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
SOURCE = ROOT / (
    "code/software/m3_pro_fourvoice_trace_20261016/pro_basis_r08_20261017/"
    "coordinator/night_r10_20261017/night_drill_r01/network.py"
)
OUTPUT = ROOT / "code/output/m3_pro_audio_r10_20261021/NETWORK"


def main():
    raw = SOURCE.read_bytes()
    old = '"http.proxy=http://127.0.0.1:7892", "-c", "http.version=HTTP/1.1"'
    new = '"http.proxy=", "-c", "https.proxy=", "-c", "http.version=HTTP/1.1"'
    source = raw.decode("utf-8")
    if source.count(old) != 1:
        raise ValueError("TRANSPORT_SOURCE_SHAPE_CHANGED")
    module = types.ModuleType("r10_qualified_transport")
    module.__file__ = str(SOURCE)
    exec(compile(source.replace(old, new), str(SOURCE), "exec"), module.__dict__)
    module.ROOT = ROOT
    module.OUTPUT = OUTPUT
    module.COMMANDS["fetch"] = ["fetch", "origin", "develop"]
    OUTPUT.mkdir(exist_ok=True)
    derivation = OUTPUT / "DERIVATION.json"
    if not derivation.exists():
        derivation.write_text(json.dumps({
            "source": str(SOURCE),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "changes": ["Use command-local direct HTTPS, as previously verified on this host",
                        "Private R10 output and persistent network ledger",
                        "Fetch only origin/develop"],
            "deadline_and_owned_job": "UNCHANGED_30_SECONDS",
            "authority": "Standing user instruction to upload each completed task",
            "retry": "No automatic retry; preserve old attempts and require new basis"
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return module.run(sys.argv[1], sys.argv[2])


if __name__ == "__main__":
    raise SystemExit(main())
