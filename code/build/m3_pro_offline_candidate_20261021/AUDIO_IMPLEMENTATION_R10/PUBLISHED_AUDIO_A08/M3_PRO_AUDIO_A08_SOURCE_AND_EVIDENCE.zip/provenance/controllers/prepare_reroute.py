"""Retain A02 failure; reuse only its successful synthesis in a fresh project."""
import hashlib
import json
import shutil
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
BASE = REPO / "code/output/m3_pro_audio_r10_20261021"
ident = sys.argv[1] if len(sys.argv) > 1 else "A03"
if ident not in {"A03", "A04", "A05", "A06", "A07", "A08"}:
    raise ValueError("An evidenced repair definition is required")
old, new = BASE / {"A03": "A02", "A04": "A03", "A05": "A04", "A06": "A05", "A07": "A06", "A08": "A06"}[ident], BASE / ident
new.mkdir(exist_ok=False)


def pin(path):
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


project = new / "pro_audio"
project.mkdir()
shutil.copy2(old / "pro_audio/pro_audio.gprj", project / "pro_audio.gprj")
shutil.copytree(old / "pro_audio/rom", project / "rom")
for name in ["sine_wavetable.hex", "triangle_wavetable.hex"]:
    shutil.copy2(old / "pro_audio" / name, project / name)
(project / "impl").mkdir()
shutil.copy2(old / "pro_audio/impl/pro_audio_process_config.json", project / "impl/pro_audio_process_config.json")
shutil.copytree(old / "pro_audio/impl/gwsynthesis", project / "impl/gwsynthesis")
assert (old / "pro_audio/impl/gwsynthesis/pro_audio.vg").read_bytes() == (project / "impl/gwsynthesis/pro_audio.vg").read_bytes()
text = ("if {[catch {\n    open_project {" + (project / "pro_audio.gprj").as_posix() +
        "}\n    run pnr\n} detail]} {\n    puts stderr $detail\n    exit 1\n}\nexit 0\n")
if ident == "A04":
    text = text.replace("    run pnr", "    set_option -route_option 1\n    run pnr")
if ident == "A05":
    original_sdc = BASE / "A02/inputs/pro_audio.sdc"
    sdc = original_sdc.read_text(encoding="utf-8").replace("-hold 0.650", "-hold 0.750")
    sdc += ("# PLL_INIT lock crosses to asynchronous-assert/synchronous-release reset.\n"
            "# Exempt only the two synchronizer asynchronous CLEAR pins; retain D/CLK\n"
            "# timing and all downstream synchronized reset recovery/removal checks.\n"
            "set_false_path -to [get_pins {u_audio/u_reset_sync/sync_chain_0_s0/CLEAR u_audio/u_reset_sync/sync_chain_1_s0/CLEAR}]\n")
    new_sdc = new / "pro_audio.sdc"
    new_sdc.write_text(sdc, encoding="utf-8", newline="\n")
    gp = project / "pro_audio.gprj"
    gp.write_text(gp.read_text(encoding="utf-8").replace(original_sdc.as_posix(), new_sdc.as_posix()), encoding="utf-8", newline="\n")
    text = text.replace("    run pnr", "    set_option -route_option 2\n    run pnr")
(new / "run_build.tcl").write_text(text, encoding="utf-8", newline="\n")
manifest = json.loads((old / "INPUT_MANIFEST.json").read_text(encoding="utf-8"))
manifest["entry"] = pin(new / "run_build.tcl")
manifest["reused_synthesis"] = {"source": pin(old / "pro_audio/impl/gwsynthesis/pro_audio.vg"), "copy": pin(project / "impl/gwsynthesis/pro_audio.vg"), "byte_equal": True}
manifest["reroute_reason"] = {"previous_native": pin(old / "native/RESULT.json"), "previous_log": pin(old / "native/stdout.bin"),
    "observed": "Placement reached 50 percent and routing started; tool then returned 1 without diagnostic or final PnR report.",
    "hypothesis_not_yet_proven": "The approximately 1 GiB Job commit cap may be insufficient at routing.",
    "change": "Retain successful same-source netlist; allow up to 2 GiB Job commit within available RAM minus 512 MiB reserve; capture actual Job peak memory.",
    "RTL_constraints_PLL_same": True, "old_attempts_preserved": True}
if ident == "A04":
    manifest["reroute_reason"] = {
        "previous_native": pin(old / "native/RESULT.json"),
        "timing_report": pin(old / "pro_audio/impl/pnr/pro_audio.tr"),
        "previous_state": "SYNTHESIS_AND_PNR_PASS_STA_HOLD_2_VIOLATED_ENDPOINTS",
        "setup_worst_ns": 4.077, "hold_violated_endpoints": 2,
        "change": "Change only physical route strategy from supported option 2 to option 1, seeking hold closure; retain all clock, uncertainty, IO delay and asynchronous-input exceptions.",
        "no_relaxed_timing_constraints": True, "RTL_constraints_PLL_same": True,
        "automatic_synthesis_rerun_possible": True, "old_attempts_preserved": True}
if ident == "A05":
    manifest["constraints"] = [x for x in manifest["constraints"] if not x["path"].endswith(".sdc")] + [pin(new_sdc)]
    manifest["reroute_reason"] = {
        "previous_native": pin(old / "native/RESULT.json"),
        "timing_report": pin(old / "pro_audio/impl/pnr/pro_audio.tr"),
        "observed": "Two rounded-zero hold violations remain; removal -0.508/-0.252 ns ends only on the two reset synchronizer asynchronous CLEAR pins.",
        "changes": ["Tighten global hold uncertainty from 0.650 to 0.750 ns, retaining setup 1.000 ns and 40 MHz clock.",
            "Declare only the two observed reset-sync asynchronous CLEAR pins false paths. No D/CLK pins, downstream reset or entire clock-domain exceptions added.",
            "Use physical route option 2."],
        "reset_structure_proof": "Original unchanged reset_sync: two async_reg stages; asynchronous assertion and local two-edge synchronous release. PLL lock drives the asynchronous input, while sync_chain[1] drives downstream reset.",
        "original_sdc": pin(original_sdc), "successor_sdc": pin(new_sdc),
        "RTL_PLL_CST_unchanged": True, "old_attempts_preserved": True}
if ident == "A06":
    manifest["reroute_reason"] = {
        "previous_native": pin(old / "native/RESULT.json"),
        "observed_job_memory_cap_bytes": 992722944,
        "observed_peak_commit_bytes": 992862208,
        "observed": "A05 returned 1 at placement phase 2 without tool diagnostic; the kernel-reported peak reached its dynamically shrunken approximately 993 MB Job cap.",
        "change": "Use a fixed 2 GiB aggregate Job commit ceiling, retaining the 256 MiB available-physical-RAM emergency guard and 2 GiB free disk guard. Commit cap is not physical RAM preallocation.",
        "RTL_PLL_CST_SDC_and_route_unchanged": True,
        "old_attempts_preserved": True}
if ident == "A07":
    manifest["reroute_reason"] = {
        "previous_native": pin(old / "native/RESULT.json"),
        "observed": "A06 hit the 256 MiB available physical RAM emergency guard at routing; owned Job was terminated and reached zero cleanly.",
        "change": "Use 2 GiB Job aggregate commit cap and 512 MiB per-process working-set cap (min 2 MiB). Read back the kernel limits, qualify one bounded natural fake child, retain all emergency guards.",
        "scope": "Only the owned Gowin Job. No system settings, pagefile configuration or unrelated processes changed.",
        "RTL_PLL_CST_SDC_and_route_unchanged": True, "old_attempts_preserved": True}
if ident == "A08":
    manifest["reroute_reason"] = {
        "previous_native": pin(BASE / "A06/native/RESULT.json"),
        "failed_optional_working_set_qualification": pin(BASE / "A07/working_set_qualification/RESULT.json"),
        "working_set_qualification_boundary": "WinError 1314 at SET_JOB_LIMITS before any child creation; no Gowin call and no privilege/security-setting change. Do not reuse that backend.",
        "new_recovery_evidence": "Available physical RAM subsequently recovered: 4474789888 bytes, then 3134136320 bytes at the latest host read.",
        "change": "Return to original qualified backend, fixed 2 GiB aggregate commit cap, require at least 3000000000 bytes available physical RAM before launch; keep 256 MiB emergency guard and 2 GiB disk reserve.",
        "RTL_PLL_CST_SDC_and_route_unchanged": True,
        "old_attempts_preserved": True}
(new / "INPUT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"attempt": str(new), "manifest": pin(new / "INPUT_MANIFEST.json"), "netlist": manifest["reused_synthesis"]["copy"]}))
