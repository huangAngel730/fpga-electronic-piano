"""Collect only this audio implementation; preserve original evidence bytes."""
import hashlib
import json
import re
import shutil
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[4]
CONTROL = Path(__file__).resolve().parent
OUTPUT = ROOT / "code/output/m3_pro_audio_r10_20261021"
FINAL = OUTPUT / "A08"
STAGE = OUTPUT / "DELIVERY_CONTENTS"
PUBLISH = CONTROL / "PUBLISHED_AUDIO_A08"


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(data.encode("utf-8") if isinstance(data, str) else data)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main():
    review = json.loads((FINAL / "REPORT_SELF_REVIEW.json").read_text(encoding="utf-8"))
    assert review["status"] == "SYNTHESIS_PNR_BASIC_STA_PASS"
    STAGE.mkdir(exist_ok=False)
    PUBLISH.mkdir(exist_ok=False)
    manifest = json.loads((FINAL / "INPUT_MANIFEST.json").read_text(encoding="utf-8"))
    mappings = {}
    closure = []

    def copy(source, relative, expected=None):
        source = Path(source)
        data = source.read_bytes()
        if expected:
            assert identity(data) == {k: expected[k] for k in ["bytes", "sha256"]}
        dest = STAGE / relative
        write(dest, data)
        return {"path": relative, **identity(data)}

    for entry in manifest["copies"]:
        frozen = entry["frozen"]
        source = Path(frozen["path"])
        inputs = OUTPUT / "A02/inputs"
        project = OUTPUT / "A02/pro_audio"
        if source.is_relative_to(inputs):
            relative = "project/" + source.relative_to(inputs).as_posix()
        else:
            relative = "project/" + source.relative_to(project).as_posix()
        closure.append(copy(source, relative, frozen))
        mappings[str(source)] = relative
    for entry in manifest["constraints"]:
        source = Path(entry["path"])
        relative = "project/" + source.name
        closure.append(copy(source, relative, entry))
        mappings[str(source)] = relative
    assert len(manifest["sources"]) == 62
    assert all(str(Path(x["path"])) in mappings for x in manifest["sources"])
    write(STAGE / "SOURCE_CLOSURE.json", json_bytes({
        "frozen_original_inputs": closure,
        "hdl_compilation_order": [mappings[str(Path(x["path"]))] for x in manifest["sources"]],
        "source_bytes_unchanged": True,
        "whole_C9_archive": False
    }))

    options = (OUTPUT / "A02/frozen_options.tcl").read_text(encoding="utf-8")
    option_lines = [line for line in options.splitlines() if line.startswith("set_option ")]
    assert "set_option -use_cpu_as_gpio 1" in option_lines
    assert "set_option -route_option 2" in option_lines
    option_lines = [
        "set_option -include_path [list [file join $package_root project include]]"
        if line.startswith("set_option -include_path ") else line for line in option_lines
    ]
    write(STAGE / "options.tcl", "\n".join(option_lines) + "\n")
    tcl = [
        "# Relocation entry, statically checked; not an additional executed build.",
        "set package_root [file dirname [file normalize [info script]]]",
        "set work [file join $package_root REBUILD]",
        "if {[file exists $work]} { error {REBUILD already exists; preserve it and select a fresh extraction} }",
        "if {[catch {",
        "    create_project -name pro_audio -dir $work -pn GW5AST-LV138FPG676AC1/I0 -device_version C",
        "    file copy [file join $package_root project rom] [file join $work pro_audio rom]",
        "    foreach name {sine_wavetable.hex triangle_wavetable.hex} {",
        "        file copy [file join $package_root project $name] [file join $work pro_audio $name]",
        "    }",
        "    cd [file join $work pro_audio]",
    ]
    for source in manifest["sources"]:
        relative = mappings[str(Path(source["path"]))]
        tcl.append("    add_file -type verilog [file join $package_root " + relative + "]")
    for extension in ["cst", "sdc"]:
        tcl.append("    add_file -type " + extension + " [file join $package_root project pro_audio." + extension + "]")
    tcl += ["    source [file join $package_root options.tcl]", "    run all",
            "} detail]} {", "    puts stderr $detail", "    exit 1", "}", "exit 0"]
    write(STAGE / "rebuild.tcl", "\n".join(tcl) + "\n")

    report = (FINAL / "pro_audio/impl/pnr/pro_audio.tr").read_text(encoding="utf-8")
    body = report[report.index("Note:Core Timing Report"):]
    pulse_section = body[body.index("3.2 Minimum Pulse Width Table"):body.index("3.3 Timing Report By Analysis Type")]
    pulse_slacks = [float(x) for x in re.findall(r"^\s*\d+\s+(-?\d+\.\d+)\s+", pulse_section, re.M)]
    assert pulse_slacks and min(pulse_slacks) >= 0
    exception = "set_false_path -to [get_pins {u_audio/u_reset_sync/sync_chain_0_s0/CLEAR u_audio/u_reset_sync/sync_chain_1_s0/CLEAR}]"
    assert exception in body[body.index("3.8 Timing Constraints Report"):]
    assert "TC_FALSE_PATH          Actived   " + exception in body
    downstream_removal = body[body.index("3.1.4 Removal Paths Table"):body.index("3.2 Minimum Pulse Width Table")]
    assert "u_audio/u_reset_sync/sync_chain_1_s0/Q" in downstream_removal
    copy(FINAL / "pro_audio/impl/pnr/pro_audio.fs", "bitstream/pro_audio.fs", review["bitstream"])
    for name in ["pro_audio.tr", "pro_audio.rpt.txt", "pro_audio.pin.html"]:
        copy(FINAL / "pro_audio/impl/pnr" / name, "reports/" + name)
    copy(FINAL / "pro_audio/pro_audio.gprj", "provenance/ORIGINAL_ABSOLUTE_PATH_PROJECT.gprj")
    copy(FINAL / "pro_audio/impl/pro_audio_process_config.json", "provenance/ORIGINAL_PROCESS_CONFIG.json")
    for source in sorted(CONTROL.glob("*.py")):
        copy(source, "provenance/controllers/" + source.name)
    for source in sorted((CONTROL / "integration").iterdir()):
        if source.is_file():
            copy(source, "provenance/integration/" + source.name)
    native_base = ROOT / "code/software/m3_c9_streaming_evidence_candidate_20261020_r01/CONTINUATION_TO1600_R03/C9_NATIVE_RUNNER_R06"
    for name in ["backend.py", "supervisor.py"]:
        copy(native_base / name, "provenance/qualified_native_runner/" + name)

    attempts = []
    total = 0.0
    for number in range(1, 9):
        attempt = OUTPUT / f"A{number:02}"
        for source in sorted(attempt.iterdir()):
            if source.is_file():
                copy(source, "history/" + attempt.name + "/" + source.name)
        native = attempt / "native/RESULT.json"
        if native.exists():
            n = json.loads(native.read_text(encoding="utf-8"))
            total += n["elapsed_seconds"]
            attempts.append({"attempt": attempt.name, "kind": "REAL_GOWIN",
                             "status": n["status"], "exit_code": n["exit_code"],
                             "elapsed_seconds": n["elapsed_seconds"],
                             "first_error": n.get("first_error")})
            for name in ["RESULT.json", "stdout.bin", "stderr.bin"]:
                copy(attempt / "native" / name, "history/" + attempt.name + "/native/" + name)
        else:
            qualification = attempt / "working_set_qualification/RESULT.json"
            n = json.loads(qualification.read_text(encoding="utf-8"))
            assert not n["launch"]["create_process_attempted"]
            attempts.append({"attempt": attempt.name, "kind": "QUALIFICATION_ONLY_NO_CHILD",
                             "status": n["status"], "Gowin_calls": 0,
                             "elapsed_seconds": n["elapsed_seconds"], "first_error": n["first_error"]})
            for source in qualification.parent.iterdir():
                if source.is_file():
                    copy(source, "history/" + attempt.name + "/qualification/" + source.name)
        if number in [3, 4]:
            for name in ["pro_audio.tr", "pro_audio.rpt.txt"]:
                copy(attempt / "pro_audio/impl/pnr" / name, "history/" + attempt.name + "/reports/" + name)
    completion = {
        "schema": "M3_PRO_AUDIO_R10_COMPLETION",
        "at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "original_main_START": "2026-10-21T11:26:15.802019+08:00",
        "current_task": "Real Pro C audio-only integration, synthesis, placement/routing and basic STA",
        "status": "COMPLETED_LIMITED_L5_OFFLINE_IMPLEMENTATION",
        "source_author_and_self_review": "Night 3 integration; M3 root integration and actual report self-review",
        "M2_final_review": "NOT_RECEIVED_NOT_ACCEPTED",
        "actual_result": review,
        "additional_report_checks": {"minimum_pulse_width_slack_ns": min(pulse_slacks),
                                     "only_two_async_CLEAR_endpoints_exempted": True,
                                     "downstream_reset_removal_still_analyzed": True},
        "consumption": {"real_Gowin_invocations": 7, "Gowin_elapsed_seconds": round(total, 3),
                        "attempt_slots_preserved": 8, "qualification_without_child": 1,
                        "current_A08_job_peak_commit_bytes": review["actual_job_peak_commit_bytes"],
                        "model_token_quota": "No per-call billing/usage counter available; not inferred from runtime",
                        "device_operations": 0},
        "attempt_history": attempts,
        "repair_explanation": [
            "A01 R17 dedicated CPU/SSPI pin conflict: enable the actual supported CPU GPIO option, retain pin R17.",
            "A03/A04 PnR passed; actual negative paths were removal checks on PLL_INIT lock to the two reset synchronizer async CLEAR pins. The hold summary counted these; displayed hold slack 0.000 alone was not proof of a hidden negative hold path.",
            "Preserve async assertion/synchronous release RTL; except only two asynchronous CLEAR pins. Keep all downstream reset, D/CLK and ordinary data-path timing. Strengthen hold uncertainty from 0.650 to 0.750 ns.",
            "A05 hit its small Job commit cap; A06 stopped on the existing available-RAM guard. A07 working-set qualification lacked a privilege before creating any child; no privilege or system-setting workaround was used.",
            "A08 restored the original qualified backend, retained a 2 GiB Job commit cap, and admitted only after two stable RAM samples. Actual synthesis reran; historical copied-synthesis metadata is not claimed as skipped synthesis."
        ],
        "remaining": {"minimum_N_and_all_tail_proofs": "验证后补_USER_WAIVER",
                      "full_C9": "PARTIAL_NOT_SIGNED", "full_RTL_simulation": "NOT_RUN",
                      "new_top_functional_board_test": "NOT_RUN", "SRAM_or_Flash": "NOT_RUN",
                      "PT8211_external_timing_and_board_voltages": "NOT_MEASURED"},
        "warnings": "PR1014 reference clock generic routing and existing width/unused-observation warnings retained in raw logs; passing constrained STA does not certify board audio behavior.",
        "M2_R09_email": "NOT_SENT_AS_USER_REQUESTED",
        "old_main_C9_archive_hold": "PRESERVED; this is only the new completed audio implementation delivery",
        "relocation_entry": "Static path/options check only; not executed as another EDA run"
    }
    write(STAGE / "COMPLETION.json", json_bytes(completion))
    readme = f"""# Pro C 音频工程 A08 本地完成交付

本包仅覆盖本轮新完成的音频工程接合与离线实现，验证等级限定 L5。使用 Gowin 商业版 V1.9.12.04、GW5AST-LV138FPG676AC1/I0、C 步进，物理顶层 pro_audio_minimal_top。A08 原始工具退出 0，综合、布局布线、码流生成和当前约束下基本 STA 通过。

分析 122807 条路径、32060 个端点；Setup/Hold 违规端点均为 0。报告最差 Setup +2.823 ns、Hold 0.000 ns、Recovery +14.701 ns、Removal +0.351 ns；最小脉宽裕量 +6.961 ns。参考时钟 50 MHz，真实 PLL CLKOUT2 音频时钟 40 MHz。Hold 的 0.000 是工具报告精度下数值，不宣称额外正裕量。

当前码流：bitstream/pro_audio.fs，37262764 字节，SHA-256 55f102b1972deaff774844e125693648ceac1b982ac0d5567d223c3b9c2c21e5。

主要修复：R17 使用芯片复用 CPU/SSPI GPIO 的已支持选项；保持异步置位、同步释放的复位结构，只对两级同步器的 CLEAR 输入设置时序例外，下游复位和数据路径继续分析；保留更严格的 0.750 ns hold 不确定度。资源受限失败后恢复原受控执行器，在足够 RAM 准入后完成。八个尝试槽原始记录均保留，其中 A07 未创建子进程，实际 Gowin 调用 7 次，累计 {total:.3f} 秒。

主要入口：COMPLETION.json 为自审、消费和未验项；SOURCE_CLOSURE.json 为 62 份 HDL、头文件、ROM、IP 与约束的身份；reports/ 为未改字节的实际报告；history/ 保留每次原始双流、退出码和失败；project/ 为实际采用的源码与 ROM。MANIFEST.json 覆盖除它自身以外的全部包内文件。ZIP 中保留原件字节，未对厂商文件或日志换行归一化。

需要重新构建时，在独立新目录解压，先核 MANIFEST；用同一商业版 gw_sh.exe 执行 rebuild.tcl。该入口用包内文件生成 REBUILD/pro_audio 工程；路径和选项已静态核对，此次没有再执行一轮迁移构建。不得覆盖旧 REBUILD 或旧失败。实际本次输入的绝对路径项目和配置另保存在 provenance/。

引脚：P16=50 MHz；K16=Dock S0 低有效复位；F15/G15=两枚演奏键；R17=MIDI RX；E22/F24/G24=PT8211 BCLK/LRCK/DIN；H17=高有效功放使能；P15=UART TX。当前 CST 声明相应 I/O 为 LVCMOS33/3.3 V。K16 与历史 U4 高有效 1.5 V 复位不可混用。上板前仍核 Bank 实际配置、R17 外部隔离/电平和精确码流放行，本包没有进行 SRAM/Flash 操作。

保留 PR1014 参考时钟普通布线及既有位宽等警告；详细原文在 history/A08/native/stdout.bin。STA 仅对声明的时钟与输出约束负责，未测 PT8211 外部时序、板卡电压、实际音频、复位/按键/MIDI 功能。本轮未运行新顶层完整 RTL 仿真；旧 C9 整体仍 PARTIAL。用户暂缓的精确最小 N 和全部尾窗证明记录为“验证后补”。没有把本轮结果写成完整 C9、上板或整机通过。原主任务 START、旧失败/消费和主 C9 原件包暂不封存要求保留。

本轮由夜间任务3提供私有集成源码，总控完成受控构建和自审；未启用审核员制度。交 M2 最终限定复核，当前未代签收件/验收。按用户“暂不发送”决定，没有发送 R09 邮件。
"""
    write(STAGE / "README_FIRST.md", readme)
    members = [{"path": p.relative_to(STAGE).as_posix(), **identity(p.read_bytes())}
               for p in sorted(STAGE.rglob("*")) if p.is_file()]
    write(STAGE / "MANIFEST.json", json_bytes({"schema": "M3_PRO_AUDIO_A08_MANIFEST", "files": members}))
    archive = PUBLISH / "M3_PRO_AUDIO_A08_SOURCE_AND_EVIDENCE.zip"
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(STAGE.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(STAGE).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(members) + 1
        for entry in members:
            assert identity(z.read(entry["path"])) == {k: entry[k] for k in ["bytes", "sha256"]}
    assert archive.stat().st_size < 32 * 1024 * 1024
    write(PUBLISH / "README.md", readme)
    write(PUBLISH / "HANDOFF.json", json_bytes({
        "handoff_id": "M3_PRO_AUDIO_A08_L5_20261022",
        "consumer": "M2", "status": "LOCAL_SELF_REVIEWED_PENDING_PUBLICATION",
        "result_commit": "Bind to the commit containing this handoff, not a self-referential field",
        "verification_level": "LIMITED_L5_OFFLINE_AUDIO_IMPLEMENTATION",
        "archive": {"path": archive.name, **identity(archive.read_bytes())},
        "archive_payloads_SHA_size_CRC_verified": len(members),
        "raw_reports_and_sources_accessible": True,
        "full_C9_pass": False, "board_release_allowed": False,
        "M2_acceptance": "PENDING", "R09_email": "NOT_SENT_AS_USER_REQUESTED"
    }))
    print(json.dumps({"archive": str(archive), **identity(archive.read_bytes()),
                      "payloads_verified": len(members), "Gowin_seconds": round(total, 3)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
