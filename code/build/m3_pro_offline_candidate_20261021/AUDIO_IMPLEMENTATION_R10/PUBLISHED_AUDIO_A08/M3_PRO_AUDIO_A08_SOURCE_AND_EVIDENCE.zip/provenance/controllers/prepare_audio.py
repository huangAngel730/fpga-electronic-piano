"""Create a new immutable source snapshot for a real Pro C audio build."""
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

REPO = Path(__file__).resolve().parents[4]
CONTROL = Path(__file__).resolve().parent
BASE = REPO / "code/tb/board/m3_c9_continuation_20261021"
OUTPUT = REPO / "code/output/m3_pro_audio_r10_20261021"


def pin(path):
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body),
            "sha256": hashlib.sha256(body).hexdigest()}


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(text.encode("utf-8"))


def main():
    ident = sys.argv[1] if len(sys.argv) > 1 else "A01"
    if ident not in {"A01", "A02"}:
        raise ValueError("An evidenced repair definition is required for this attempt")
    attempt = OUTPUT / ident
    attempt.mkdir(parents=True, exist_ok=False)
    inputs = attempt / "inputs"
    project = attempt / "pro_audio"
    project.mkdir()
    copies = []

    def copy(source, dest):
        body = source.read_bytes()
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open("xb") as handle:
            handle.write(body)
        copies.append({"source": pin(source), "frozen": pin(dest)})
        return dest

    sources = []
    visual = {"visual_event_bridge.sv", "video_scan_timing.sv",
              "visual_mailbox_cdc.sv", "visual_control_bridge.sv",
              "visual_live_state.sv", "visual_score_tracker.sv",
              "visual_scene_renderer.sv", "visual_hit_flash.sv",
              "m3_visualizer.sv", "audio_visual_display_probe.sv"}
    exclusions = []
    filelist = BASE / "ROOT_LAYOUT_R04/runtime/compile_c9_decl_order_r07.f"
    for line in filelist.read_text(encoding="utf-8-sig").splitlines():
        if not line or line.startswith("+"):
            continue
        source = Path(line)
        allowed = (source.parent == BASE / "sources" and
                   source.name not in visual and source.suffix == ".sv")
        allowed |= (source.parent == BASE / "selected" and source.name in {
            "m2_fourvoice_timbre_delay_frame_core_r06c9.sv",
            "m2_r06_tx_identity_sidecar.sv", "dds_oscillator_leaf.sv",
            "m2_r06_raw_cancel_reason.sv"})
        if allowed:
            sources.append(copy(source, inputs / "src" / source.name))
        else:
            exclusions.append(pin(source))
    for name in ["m3_pro_audio_core_r10.sv", "pro_audio_minimal_top.sv"]:
        sources.append(copy(CONTROL / "integration" / name, inputs / "src" / name))
    ipbase = REPO / "code/output/m3_pro_c_production_ip_20261021_r02"
    for source in [ipbase / "TMDS_PLL/TMDS_PLL/TMDS_PLL.v",
                   ipbase / "TMDS_PLL/TMDS_PLL/TMDS_PLL_mod.v",
                   ipbase / "PRECHECK/project/pro_c_ip_r02/src/pll_init.v"]:
        sources.append(copy(source, inputs / "ip" / source.name))
    for source in sorted((BASE / "include").iterdir()):
        if source.is_file():
            copy(source, inputs / "include" / source.name)
    for source in sorted((BASE / "rom").iterdir()):
        if source.is_file():
            copy(source, project / "rom" / source.name)
    for name in ["sine_wavetable.hex", "triangle_wavetable.hex"]:
        copy(BASE / "ROOT_LAYOUT_R04/runtime" / name, project / name)
    copy(ipbase / "TMDS_PLL/TMDS_PLL/TMDS_PLL.ipc", inputs / "metadata/TMDS_PLL.ipc")
    copy(CONTROL / "integration/SOURCE_BINDING.json", inputs / "metadata/INTEGRATION_SOURCE_BINDING.json")

    mapping = [
        ("sys_clk_50m", "P16", "NONE", "OFF"),
        ("sys_rst_n", "K16", "UP", "OFF"),
        ("key_n[0]", "F15", "UP", "OFF"),
        ("key_n[1]", "G15", "UP", "OFF"),
        ("midi_rx", "R17", "UP", "OFF"),
        ("i2s_bclk", "E22", "NONE", "8"),
        ("i2s_lrck", "F24", "NONE", "8"),
        ("i2s_din", "G24", "NONE", "8"),
        ("pa_en", "H17", "DOWN", "8"),
        ("uart_tx", "P15", "NONE", "8")]
    cst = "// Pro C audio-only successor. Reset is Dock S0/K16 active low.\n"
    for name, ball, pull, drive in mapping:
        cst += (f'IO_LOC "{name}" {ball};\n'
                f'IO_PORT "{name}" IO_TYPE=LVCMOS33 PULL_MODE={pull} '
                f'DRIVE={drive} BANK_VCCIO=3.3;\n')
    write(inputs / "pro_audio.cst", cst)
    sdc = '''# Pro C: 50 MHz reference and real PLL output 2 at 40 MHz.
create_clock -name ref_clk -period 20.000 [get_ports {sys_clk_50m}]
create_generated_clock -name core_clk -source [get_ports {sys_clk_50m}] -master_clock ref_clk -multiply_by 4 -divide_by 5 [get_pins {u_audio/u_audio_pll/u_pll/PLL_inst/CLKOUT2}]
set_clock_uncertainty -setup 1.000 -from [get_clocks {core_clk}] -to [get_clocks {core_clk}]
set_clock_uncertainty -hold 0.650 -from [get_clocks {core_clk}] -to [get_clocks {core_clk}]
# External inputs are asynchronous; RTL retains its two-stage synchronizers.
set_false_path -from [get_ports {sys_rst_n}]
set_false_path -from [get_ports {key_n[0]}]
set_false_path -from [get_ports {key_n[1]}]
set_false_path -from [get_ports {midi_rx}]
# Retained conservative candidate output constraints, not board measurements.
set_output_delay -clock core_clk -max 5.000 [get_ports {i2s_bclk i2s_lrck i2s_din}]
set_output_delay -clock core_clk -min 0.000 [get_ports {i2s_bclk i2s_lrck i2s_din}]
'''
    write(inputs / "pro_audio.sdc", sdc)
    tcl = ["if {[catch {",
           f"    create_project -name pro_audio -dir {{{attempt.as_posix()}}} -pn GW5AST-LV138FPG676AC1/I0 -device_version C"]
    for source in sources:
        tcl.append(f"    add_file -type verilog {{{source.as_posix()}}}")
    for ext in ["cst", "sdc"]:
        tcl.append(f"    add_file -type {ext} {{{(inputs / ('pro_audio.' + ext)).as_posix()}}}")
    tcl += ["    set_option -synthesis_tool gowinsynthesis",
            "    set_option -top_module pro_audio_minimal_top",
            "    set_option -verilog_std sysv2017",
            f"    set_option -include_path {{{(inputs / 'include').as_posix()}}}",
            "    set_option -output_base_name pro_audio",
            "    set_option -unused_pin default",
            "    set_option -use_jtag_as_gpio 0",
            "    set_option -use_sspi_as_gpio 1",
            "    set_option -use_mspi_as_gpio 0",
            "    set_option -use_done_as_gpio 0",
            "    set_option -use_ready_as_gpio 0",
            f"    saveto -all_options {{{(attempt / 'frozen_options.tcl').as_posix()}}}",
            "    run all", "} detail]} {", "    puts stderr $detail", "    exit 1", "}", "exit 0"]
    if ident == "A02":
        index = tcl.index("    set_option -use_sspi_as_gpio 1") + 1
        tcl.insert(index, "    set_option -use_cpu_as_gpio 1")
        write(attempt / "REPAIR_REASON.json", json.dumps({
            "previous_attempt": "A01", "preserved": True,
            "observed": "GowinSynthesis finish; PR2017 midi_rx dedicated CPU/SSPI pin R17; PR2028",
            "evidence": pin(OUTPUT / "A01/native/stdout.bin"),
            "supported_option_evidence": pin(OUTPUT / "A01/frozen_options.tcl"),
            "change": "Enable existing use_cpu_as_gpio option in addition to use_sspi_as_gpio; pin/RTL/clock/electrical constraints unchanged."
        }, ensure_ascii=False, indent=2) + "\n")
    write(attempt / "run_build.tcl", "\n".join(tcl) + "\n")
    manifest = {"schema": "M3_PRO_AUDIO_R10_FROZEN_INPUTS", "created_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
                "authority": "USER_DIRECT_JOIN_SYNTHESIS_PNR_STA_20261021", "target": "GW5AST-LV138FPG676AC1/I0", "device_version": "C",
                "top": "pro_audio_minimal_top", "sources": [pin(p) for p in sources], "copies": copies,
                "excluded_simulation_and_visual_files": exclusions, "constraints": [pin(inputs / "pro_audio.cst"), pin(inputs / "pro_audio.sdc")],
                "entry": pin(attempt / "run_build.tcl"), "device_operations": 0, "N_and_tail_status": "验证后补",
                "physical_checks_pending": "Current board Bank straps/external MIDI isolation and exact bitstream admission before download; no download in this task."}
    write(attempt / "INPUT_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"attempt": str(attempt), "sources": len(sources), "manifest": pin(attempt / "INPUT_MANIFEST.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
