// R10 private Pro audio-only physical wrapper. Build candidate; not board tested.
// Input is the board 50 MHz clock. sys_rst_n and key_n are active low.
// No display or observation ports are exposed as physical IO.
`ifndef M3_PRO_AUDIO_MINIMAL_TOP_R10_SV
`define M3_PRO_AUDIO_MINIMAL_TOP_R10_SV
`timescale 1ns / 1ps
module pro_audio_minimal_top (
    input  wire       sys_clk_50m,
    input  wire       sys_rst_n,
    input  wire [1:0] key_n,
    input  wire       midi_rx,
    output wire       i2s_bclk,
    output wire       i2s_lrck,
    output wire       i2s_din,
    output wire       pa_en,
    output wire       uart_tx
);
    wire legacy_pa_disable;
    m3_pro_audio_core_r10 #(.SOURCE_MODE(0)) u_audio (
        .sys_clk(sys_clk_50m),
        .sys_rst_n(sys_rst_n),
        .key_n(key_n),
        .midi_rx(midi_rx),
        .i2s_bclk(i2s_bclk),
        .i2s_lrck(i2s_lrck),
        .i2s_din(i2s_din),
        .pa_en(legacy_pa_disable),
        .uart_tx(uart_tx),
        .tmds_clk_p(),
        .tmds_clk_n(),
        .tmds_data_p(),
        .tmds_data_n()
    );
    // Same existing conversion, exactly once: Pro XPT4809 high = enabled.
    // Core retains asynchronous reset/PLL-lock shutdown and sync release.
    assign pa_en = sys_rst_n && !legacy_pa_disable;
endmodule
`endif  // M3_PRO_AUDIO_MINIMAL_TOP_R10_SV
