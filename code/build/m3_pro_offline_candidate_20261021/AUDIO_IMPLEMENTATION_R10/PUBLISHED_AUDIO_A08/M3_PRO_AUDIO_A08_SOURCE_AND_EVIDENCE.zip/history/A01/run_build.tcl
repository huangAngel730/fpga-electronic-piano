if {[catch {
    create_project -name pro_audio -dir {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01} -pn GW5AST-LV138FPG676AC1/I0 -device_version C
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/audio_defs_pkg.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/sustain_control_contract_pkg.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/reset_sync.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/button_debouncer.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/button_event_converter.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/performance_event_fifo.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/system_status_counters.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/uart_status_reporter.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/uart_tx.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/uart_rx.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/midi_event_parser.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/midi_input.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/note_pitch.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/simple_voice.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/i2s_tx.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_frame_buffer.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/voice_allocator_4.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/piano_dds_oscillator.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/adsr_piano_envelope.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/sustain_controller.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_event_router.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_envelope_bank.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/voice_gain_q15_candidate.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_pcm_commit.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_audio_core.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_mixer_4voice.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_clip_counter.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_result_hold.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/performance_control_snapshot.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pitch_mod_fcw_pipeline.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pitch_mod_snapshot_pipeline.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_adsr_piano_envelope.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_audio_candidate.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_dds_oscillator.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_delay_effect.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_note_pitch.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pcm_clip_counter.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pcm_frame_buffer.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pcm_mixer_4voice.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_performance_control_snapshot.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_piano_dds_oscillator.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_piano_triangle_voice.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pitch_mod_fcw_pipeline.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pitch_mod_snapshot_pipeline.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_polyphonic_envelope_bank.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_polyphonic_event_router.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_stereo_delay.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_sustain_controller.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_timbre_delay_chain.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_timbre_oscillator.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_voice_allocator_4.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_voice_gain_q15_candidate.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/premixed_frame_adapter.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m2_fourvoice_timbre_delay_frame_core_r06c9.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m2_r06_tx_identity_sidecar.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/dds_oscillator_leaf.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m2_r06_raw_cancel_reason.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m3_pro_audio_core_r10.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pro_audio_minimal_top.sv}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/ip/TMDS_PLL.v}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/ip/TMDS_PLL_mod.v}
    add_file -type verilog {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/ip/pll_init.v}
    add_file -type cst {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/pro_audio.cst}
    add_file -type sdc {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/pro_audio.sdc}
    set_option -synthesis_tool gowinsynthesis
    set_option -top_module pro_audio_minimal_top
    set_option -verilog_std sysv2017
    set_option -include_path {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/include}
    set_option -output_base_name pro_audio
    set_option -unused_pin default
    set_option -use_jtag_as_gpio 0
    set_option -use_sspi_as_gpio 1
    set_option -use_mspi_as_gpio 0
    set_option -use_done_as_gpio 0
    set_option -use_ready_as_gpio 0
    saveto -all_options {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/frozen_options.tcl}
    run all
} detail]} {
    puts stderr $detail
    exit 1
}
exit 0
