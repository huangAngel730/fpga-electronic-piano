add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/ip/TMDS_PLL.v"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/ip/TMDS_PLL_mod.v"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/ip/pll_init.v"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/adsr_piano_envelope.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/audio_defs_pkg.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/button_debouncer.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/button_event_converter.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/dds_oscillator_leaf.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/i2s_tx.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_adsr_piano_envelope.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_audio_candidate.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_dds_oscillator.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_delay_effect.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_note_pitch.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pcm_clip_counter.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pcm_frame_buffer.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pcm_mixer_4voice.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_performance_control_snapshot.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_piano_dds_oscillator.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_piano_triangle_voice.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pitch_mod_fcw_pipeline.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_pitch_mod_snapshot_pipeline.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_polyphonic_envelope_bank.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_polyphonic_event_router.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_stereo_delay.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_sustain_controller.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_timbre_delay_chain.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_timbre_oscillator.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_voice_allocator_4.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m1td_voice_gain_q15_candidate.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m2_fourvoice_timbre_delay_frame_core_r06c9.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m2_r06_raw_cancel_reason.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m2_r06_tx_identity_sidecar.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/m3_pro_audio_core_r10.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/midi_event_parser.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/midi_input.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/note_pitch.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_clip_counter.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_frame_buffer.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_mixer_4voice.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pcm_result_hold.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/performance_control_snapshot.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/performance_event_fifo.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/piano_dds_oscillator.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pitch_mod_fcw_pipeline.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pitch_mod_snapshot_pipeline.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_audio_core.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_envelope_bank.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_event_router.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/polyphonic_pcm_commit.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/premixed_frame_adapter.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/pro_audio_minimal_top.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/reset_sync.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/simple_voice.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/sustain_control_contract_pkg.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/sustain_controller.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/system_status_counters.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/uart_rx.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/uart_status_reporter.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/uart_tx.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/voice_allocator_4.sv"
add_file -type verilog "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/src/voice_gain_q15_candidate.sv"
add_file -type cst "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/pro_audio.cst"
add_file -type sdc "E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/pro_audio.sdc"
set_device GW5AST-LV138FPG676AC1/I0 -device_version C
set_csr NA
set_option -synthesis_tool gowinsynthesis
set_option -output_base_name pro_audio
set_option -global_freq default
set_option -top_module pro_audio_minimal_top
set_option -include_path {"E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A01/inputs/include"}
set_option -verilog_std sysv2017
set_option -vhdl_std vhd1993
set_option -print_all_synthesis_warning 0
set_option -disable_io_insertion 0
set_option -looplimit 2000
set_option -rw_check_on_ram 0
set_option -gen_sdf 0
set_option -gen_io_cst 0
set_option -gen_ibis 0
set_option -gen_posp 0
set_option -gen_verilog_sim_netlist 0
set_option -gen_vhdl_sim_netlist 0
set_option -show_init_in_vo 0
set_option -show_all_warn 0
set_option -timing_driven 1
set_option -ireg_in_iob 0
set_option -oreg_in_iob 0
set_option -ioreg_in_iob 0
set_option -replicate_resources 0
set_option -cst_warn_to_error 1
set_option -rpt_auto_place_io_info 0
set_option -convert_sdp32_36_to_sdp16_18 1
set_option -correct_hold_violation 1
set_option -set_route_vcc 1
set_option -place_option 3
set_option -route_option 2
set_option -retiming_resource None
set_option -clock_route_order 0
set_option -route_maxfan 23
set_option -use_jtag_as_gpio 0
set_option -use_sspi_as_gpio 1
set_option -use_mspi_as_gpio 0
set_option -use_ready_as_gpio 0
set_option -use_done_as_gpio 0
set_option -use_mode_as_gpio 0
set_option -use_i2c_as_gpio 0
set_option -use_cpu_as_gpio 0
set_option -power_on_reset_monitor 1
set_option -bit_format bin
set_option -bit_crc_check 1
set_option -bit_compress 0
set_option -bit_encrypt 0
set_option -bit_encrypt_key 00000000000000000000000000000000
set_option -bit_security 1
set_option -bit_incl_bsram_init 1
set_option -hotboot 0
set_option -i2c_slave_addr 00
set_option -secure_mode 0
set_option -loading_rate default
set_option -program_done_bypass 0
set_option -wakeup_mode 0
set_option -user_code default
set_option -unused_pin default
set_option -multi_boot 0
set_option -mspi_jump 0
set_option -turn_off_bg 0
set_option -vccx 1.8
set_option -vcc 0.9
set_option -seu_handler 0
set_option -seu_handler_checksum 0
set_option -seu_handler_mode auto
set_option -error_detection false
set_option -error_detection_correction false
set_option -stop_seu_handler false
set_option -error_injection false
set_option -ext_cclk false
set_option -ext_cclk_div 1
set_option -inc_place 0
set_option -inc_pnr 0
set_option -serdesRetiming 0
set_option -co-place_io_registers 0