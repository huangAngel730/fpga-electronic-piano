# Pro C: 50 MHz reference and real PLL output 2 at 40 MHz.
create_clock -name ref_clk -period 20.000 [get_ports {sys_clk_50m}]
create_generated_clock -name core_clk -source [get_ports {sys_clk_50m}] -master_clock ref_clk -multiply_by 4 -divide_by 5 [get_pins {u_audio/u_audio_pll/u_pll/PLL_inst/CLKOUT2}]
set_clock_uncertainty -setup 1.000 -from [get_clocks {core_clk}] -to [get_clocks {core_clk}]
set_clock_uncertainty -hold 0.750 -from [get_clocks {core_clk}] -to [get_clocks {core_clk}]
# External inputs are asynchronous; RTL retains its two-stage synchronizers.
set_false_path -from [get_ports {sys_rst_n}]
set_false_path -from [get_ports {key_n[0]}]
set_false_path -from [get_ports {key_n[1]}]
set_false_path -from [get_ports {midi_rx}]
# Retained conservative candidate output constraints, not board measurements.
set_output_delay -clock core_clk -max 5.000 [get_ports {i2s_bclk i2s_lrck i2s_din}]
set_output_delay -clock core_clk -min 0.000 [get_ports {i2s_bclk i2s_lrck i2s_din}]
# PLL_INIT lock crosses to asynchronous-assert/synchronous-release reset.
# Exempt only the two synchronizer asynchronous CLEAR pins; retain D/CLK
# timing and all downstream synchronized reset recovery/removal checks.
set_false_path -to [get_pins {u_audio/u_reset_sync/sync_chain_0_s0/CLEAR u_audio/u_reset_sync/sync_chain_1_s0/CLEAR}]
