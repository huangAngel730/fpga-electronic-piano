if {[catch {
    open_project {E:/FPGA/GAOYUNFPGA/team/fpga-electronic-piano/code/output/m3_pro_audio_r10_20261021/A03/pro_audio/pro_audio.gprj}
    run pnr
} detail]} {
    puts stderr $detail
    exit 1
}
exit 0
