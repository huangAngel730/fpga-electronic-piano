"""Retain A02 failure; reuse only its successful synthesis in a fresh project."""
import hashlib
import json
import shutil
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
BASE = REPO / "code/output/m3_pro_audio_r10_20261021"
old, new = BASE / "A02", BASE / "A03"
new.mkdir(exist_ok=False)


def pin(path):
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


project = new / "pro_audio"
project.mkdir()
shutil.copy2(old / "pro_audio/pro_audio.gprj", project / "pro_audio.gprj")
shutil.copytree(old / "pro_audio/rom", project / "rom")
for name in ["sine_wavetable.hex", "triangle_wavetable.hex"]:
    shutil.copy2(old / "pro_audio" / name, project / name)
(project / "impl").mkdir()
shutil.copy2(old / "pro_audio/impl/pro_audio_process_config.json", project / "impl/pro_audio_process_config.json")
shutil.copytree(old / "pro_audio/impl/gwsynthesis", project / "impl/gwsynthesis")
assert (old / "pro_audio/impl/gwsynthesis/pro_audio.vg").read_bytes() == (project / "impl/gwsynthesis/pro_audio.vg").read_bytes()
text = ("if {[catch {\n    open_project {" + (project / "pro_audio.gprj").as_posix() +
        "}\n    run pnr\n} detail]} {\n    puts stderr $detail\n    exit 1\n}\nexit 0\n")
(new / "run_build.tcl").write_text(text, encoding="utf-8", newline="\n")
manifest = json.loads((old / "INPUT_MANIFEST.json").read_text(encoding="utf-8"))
manifest["entry"] = pin(new / "run_build.tcl")
manifest["reused_synthesis"] = {"source": pin(old / "pro_audio/impl/gwsynthesis/pro_audio.vg"), "copy": pin(project / "impl/gwsynthesis/pro_audio.vg"), "byte_equal": True}
manifest["reroute_reason"] = {"previous_native": pin(old / "native/RESULT.json"), "previous_log": pin(old / "native/stdout.bin"),
    "observed": "Placement reached 50 percent and routing started; tool then returned 1 without diagnostic or final PnR report.",
    "hypothesis_not_yet_proven": "The approximately 1 GiB Job commit cap may be insufficient at routing.",
    "change": "Retain successful same-source netlist; allow up to 2 GiB Job commit within available RAM minus 512 MiB reserve; capture actual Job peak memory.",
    "RTL_constraints_PLL_same": True, "old_attempts_preserved": True}
(new / "INPUT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"attempt": str(new), "manifest": pin(new / "INPUT_MANIFEST.json"), "netlist": manifest["reused_synthesis"]["copy"]}))
