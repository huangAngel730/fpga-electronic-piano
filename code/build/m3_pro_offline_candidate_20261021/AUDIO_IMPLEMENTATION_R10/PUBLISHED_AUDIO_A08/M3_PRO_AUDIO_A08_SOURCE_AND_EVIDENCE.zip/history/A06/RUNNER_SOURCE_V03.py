"""One explicitly authorized, bounded Gowin build; no device operations."""
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

REPO = Path(__file__).resolve().parents[4]
CONTROL = Path(__file__).resolve().parent
RUNNERS = REPO / "code/software/m3_c9_streaming_evidence_candidate_20261020_r01/CONTINUATION_TO1600_R03/C9_NATIVE_RUNNER_R06"
TOOL_ROOT = Path("D:/program/Gowin_work/Gowin/Gowin_V1.9.12.04_x64")


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def pin(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def write(path, data):
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def main():
    ident = sys.argv[1]
    if ident not in {f"A{i:02d}" for i in range(1, 9)}:
        raise ValueError("Only eight separately evidenced attempts are allowed")
    attempt = REPO / "code/output/m3_pro_audio_r10_20261021" / ident
    logdir = attempt / "native"
    if logdir.exists() or (attempt / "ATTEMPT.json").exists():
        raise ValueError("Existing attempt cannot be restarted or overwritten")
    manifest = json.loads((attempt / "INPUT_MANIFEST.json").read_text(encoding="utf-8"))
    held = [x["frozen"] for x in manifest["copies"]] + manifest["constraints"] + [manifest["entry"]]
    for item in held:
        assert pin(Path(item["path"])) == item
    backend = module("audio_build_backend", RUNNERS / "backend.py")
    supervisor = module("audio_build_supervisor", RUNNERS / "supervisor.py")
    available = backend.available_ram_bytes()
    if available < 1024 << 20:
        raise RuntimeError("Not enough currently available RAM for guarded build")
    job_memory = min((2 if ident >= "A03" else 1) << 30, available - (512 << 20))
    if ident >= "A06":
        # A Job memory limit is a commit ceiling, not an upfront physical-RAM
        # reservation. Keep the real physical-RAM emergency guard below.
        job_memory = 2 << 30
    tool = TOOL_ROOT / "IDE/bin/gw_sh.exe"
    public_names = ("SystemRoot", "WINDIR", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "COMSPEC", "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE")
    environment = {k: os.environ[k] for k in public_names if k in os.environ}
    environment["PATH"] = str(TOOL_ROOT / "IDE/bin") + ";C:/Windows/System32;C:/Windows"
    environment["GOWIN_HOME"] = str(TOOL_ROOT)
    environment["GOWIN_PROGRAMMER_HOME"] = str(TOOL_ROOT / "Programmer")
    for key in ("LM_LICENSE_FILE", "MGLS_LICENSE_FILE"):
        if key in os.environ:
            environment[key] = os.environ[key]
    record = {"schema": "M3_PRO_AUDIO_BUILD_ATTEMPT_R10", "started_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
              "authority": "USER_DIRECT", "verbatim": "你现在已经有了约束文件和PLL 请你完成接合并通过综合、布局布线和时序检查",
              "attempt": ident, "tool": pin(tool), "manifest": pin(attempt / "INPUT_MANIFEST.json"),
              "supervisor": pin(RUNNERS / "supervisor.py"), "backend": pin(RUNNERS / "backend.py"),
              "argv": [str(tool), str(attempt / "run_build.tcl")], "cwd": str(attempt / "pro_audio"),
              "timeout_seconds": 3600, "job_memory_bytes": job_memory, "available_ram_before": available,
              "disk_free_before": shutil.disk_usage(attempt).free, "environment_names_only": sorted(environment),
              "memory_limit_kind": "Job aggregate committed bytes; not physical RAM preallocation",
              "device_operations": 0, "N_and_tail": "验证后补", "old_consumption_reset": False}
    write(attempt / "ATTEMPT.json", record)
    guard_last = [0.0]

    def guard():
        now = time.monotonic()
        if now - guard_last[0] < 1:
            return
        guard_last[0] = now
        if shutil.disk_usage(attempt).free < 2 << 30:
            raise RuntimeError("DISK_RESERVE_2GIB")
        if backend.available_ram_bytes() < 256 << 20:
            raise RuntimeError("AVAILABLE_RAM_256MIB_STOP")
        total, count = 0, 0
        for path in attempt.rglob("*"):
            if path.is_symlink():
                raise RuntimeError("Unexpected symlink in build outputs")
            if path.is_file():
                total += path.stat().st_size
                count += 1
                if total > 24 << 30 or count > 200000:
                    raise RuntimeError("BUILD_OUTPUT_BOUND")

    base_factory = backend.load_factory(REPO)

    class MemoryObservedFactory:
        kind = base_factory.kind

        def launch(self, *args, **kwargs):
            owned = base_factory.launch(*args, **kwargs)
            previous = owned.accounting

            def accounting():
                stats = previous()
                value = base_factory.helper._ExtendedLimit()
                fn = owned.job.kernel.QueryInformationJobObject
                if not fn(owned.job.handle, 9, owned.C.byref(value), owned.C.sizeof(value), None):
                    raise owned.C.WinError(owned.C.get_last_error())
                stats["peak_job_memory_bytes"] = int(value.peak_job_memory)
                stats["peak_process_memory_bytes"] = int(value.peak_process_memory)
                return stats

            owned.accounting = accounting
            return owned

    started = time.monotonic()
    result = supervisor.run_owned(record["argv"], record["cwd"], logdir,
        factory=MemoryObservedFactory(), environment=environment,
        deadline=started + 3600, timeout_seconds=3600, memory_bytes=job_memory,
        active_limit=16, log_limit=64 << 20, cleanup_seconds=30,
        resource_guard=guard, scan_modelsim_errors=False)
    drift = [x for x in held if pin(Path(x["path"])) != x]
    write(attempt / "ROOT_RETURN.json", {"native_result": result, "input_drift": drift,
        "ended_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "elapsed_seconds": time.monotonic() - started,
        "engineering_verdict": "REPORT_REVIEW_REQUIRED", "device_operations": 0})
    print(json.dumps({"attempt": ident, "status": result["status"], "exit_code": result["exit_code"],
        "first_error": result["first_error"], "elapsed_seconds": result["elapsed_seconds"],
        "input_drift_count": len(drift)}, ensure_ascii=False))
    return 0 if result.get("status") == "NATURAL_EXIT_CLEAN" and not drift else 1


if __name__ == "__main__":
    raise SystemExit(main())
