"""Retain A02 failure; reuse only its successful synthesis in a fresh project."""
import hashlib
import json
import shutil
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
BASE = REPO / "code/output/m3_pro_audio_r10_20261021"
ident = sys.argv[1] if len(sys.argv) > 1 else "A03"
if ident not in {"A03", "A04"}:
    raise ValueError("An evidenced repair definition is required")
old, new = BASE / ("A02" if ident == "A03" else "A03"), BASE / ident
new.mkdir(exist_ok=False)


def pin(path):
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


project = new / "pro_audio"
project.mkdir()
shutil.copy2(old / "pro_audio/pro_audio.gprj", project / "pro_audio.gprj")
shutil.copytree(old / "pro_audio/rom", project / "rom")
for name in ["sine_wavetable.hex", "triangle_wavetable.hex"]:
    shutil.copy2(old / "pro_audio" / name, project / name)
(project / "impl").mkdir()
shutil.copy2(old / "pro_audio/impl/pro_audio_process_config.json", project / "impl/pro_audio_process_config.json")
shutil.copytree(old / "pro_audio/impl/gwsynthesis", project / "impl/gwsynthesis")
assert (old / "pro_audio/impl/gwsynthesis/pro_audio.vg").read_bytes() == (project / "impl/gwsynthesis/pro_audio.vg").read_bytes()
text = ("if {[catch {\n    open_project {" + (project / "pro_audio.gprj").as_posix() +
        "}\n    run pnr\n} detail]} {\n    puts stderr $detail\n    exit 1\n}\nexit 0\n")
if ident == "A04":
    text = text.replace("    run pnr", "    set_option -route_option 1\n    run pnr")
(new / "run_build.tcl").write_text(text, encoding="utf-8", newline="\n")
manifest = json.loads((old / "INPUT_MANIFEST.json").read_text(encoding="utf-8"))
manifest["entry"] = pin(new / "run_build.tcl")
manifest["reused_synthesis"] = {"source": pin(old / "pro_audio/impl/gwsynthesis/pro_audio.vg"), "copy": pin(project / "impl/gwsynthesis/pro_audio.vg"), "byte_equal": True}
manifest["reroute_reason"] = {"previous_native": pin(old / "native/RESULT.json"), "previous_log": pin(old / "native/stdout.bin"),
    "observed": "Placement reached 50 percent and routing started; tool then returned 1 without diagnostic or final PnR report.",
    "hypothesis_not_yet_proven": "The approximately 1 GiB Job commit cap may be insufficient at routing.",
    "change": "Retain successful same-source netlist; allow up to 2 GiB Job commit within available RAM minus 512 MiB reserve; capture actual Job peak memory.",
    "RTL_constraints_PLL_same": True, "old_attempts_preserved": True}
if ident == "A04":
    manifest["reroute_reason"] = {
        "previous_native": pin(old / "native/RESULT.json"),
        "timing_report": pin(old / "pro_audio/impl/pnr/pro_audio.tr"),
        "previous_state": "SYNTHESIS_AND_PNR_PASS_STA_HOLD_2_VIOLATED_ENDPOINTS",
        "setup_worst_ns": 4.077, "hold_violated_endpoints": 2,
        "change": "Change only physical route strategy from supported option 2 to option 1, seeking hold closure; retain all clock, uncertainty, IO delay and asynchronous-input exceptions.",
        "no_relaxed_timing_constraints": True, "RTL_constraints_PLL_same": True,
        "automatic_synthesis_rerun_possible": True, "old_attempts_preserved": True}
(new / "INPUT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"attempt": str(new), "manifest": pin(new / "INPUT_MANIFEST.json"), "netlist": manifest["reused_synthesis"]["copy"]}))
