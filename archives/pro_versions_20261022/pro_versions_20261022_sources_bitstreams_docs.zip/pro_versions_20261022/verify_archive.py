"""Read-only byte verification; no devices or build tools."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'ARCHIVE_MANIFEST.json').read_text(encoding='utf-8'))
errors = []
for relative, item in manifest['files'].items():
    path = root / relative
    if not path.is_file() or path.stat().st_size != item['bytes']:
        errors.append(relative + ': missing/size')
    elif hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        errors.append(relative + ': SHA256')
if errors:
    raise SystemExit('FAIL\n' + '\n'.join(errors))
print('PASS', len(manifest['files']), 'files; three FPGA bitstreams and frozen source identities verified')
