# Pro 电子钢琴三版本归档 · 2026-10-22

按用户要求保存当日已交付的三个历史版本。源码和码流按原交付 SHA-256 核对；当前主工程和正在进行的修复不在本归档中。

| 版本 | 源码 | 码流 | 原报告最差 Setup |
| --- | --- | --- | --- |
| 基础四声部 A08 | [versions/01_basic_A08](versions/01_basic_A08) | [01_pro_audio_basic_A08.fs](bitstreams/01_pro_audio_basic_A08.fs) | +2.823 ns |
| 传谱、回读、播放、双滑块 R10 | [versions/02_score_slider_R10](versions/02_score_slider_R10) | [02_pro_audio_score_slider_R10.fs](bitstreams/02_pro_audio_score_slider_R10.fs) | +1.812 ns |
| 波形与键盘切页 R01 | [versions/03_waveform_R01](versions/03_waveform_R01) | [03_pro_audio_score_slider_waveform_R01.fs](bitstreams/03_pro_audio_score_slider_waveform_R01.fs) | +2.697 ns |

## 工具与工程

固定 Gowin 商业版 V1.9.12.04，目标 `GW5AST-LV138FPG676AC1/I0`、C 步进，参考时钟 50 MHz、音频核心 40 MHz；显示版本为 25 MHz pixel / 125 MHz serial。顶层 `pro_audio_minimal_top`。每版含 RTL、真实 IP HDL、ROM、CST、SDC、原始构建入口和报告。

在相应版本根目录运行原 `rebuild.tcl` 可生成新的完整工程，先确认脚本中的工具环境；已存在的输出目录不会被覆盖。原 GUI 工程和执行日志保留历史本机绝对路径；跨机器优先使用相对路径 Tcl 重建工程。本次上传没有重新执行 EDA，也不保证布局布线重跑会得到逐字节相同码流。

波形版 HANDOFF 已明确：三个旧 `.pr/.p` 物理数据库属于失败的增量尝试，最终普通完整流程不使用；本归档省略它们，SHA 和理由见 [provenance/EXCLUSIONS.json](provenance/EXCLUSIONS.json)。没有省略该版本实际 HDL、IP HDL、头文件、ROM 或约束。

## 软件和接线

- [ESP32 BLE 固件、PC 工具及测试](shared/ble_pc_software/README.md)，包括 C3 固件源码及最终 4 MB 镜像。
- [安卓传谱程序](shared/android_score_transfer/README.md)，含源码、APK、示例 JSON 与离线测试证据。APK 为开发签名版本；私钥、签名库、个人 SDK 路径未上传，重新构建需配置本机 SDK 并自行生成开发签名。
- [归档使用与接线](docs/USE_AND_STATUS.md)、[原始工具与引脚说明](docs/TOOLCHAIN_AND_PINOUT_ORIGINAL.md)、[Pro 原理图](docs/hardware)。

## 实际状态与已知问题

这些是历史备份，不能标为“全部实物功能已验收”。R10 曾完成 SRAM 下载，用户实测发现双键松开后约 15 秒异常拖尾、HDMI 后续显示异常；根因与修复仍在主任务排查，本归档 R10 **不包含后续修复**。波形版有源码仿真及原生时序证据，尚未上板，不能推定它已解决 R10 的现场问题。完整 C9、精确最小 N/尾窗及完整实机验收未签通过。

## 校验

在仓库根运行 `python -B -X utf8 verify_archive.py`；它只读取文件，不调用 FPGA、串口、编译器或 EDA。
完整文件身份见 [ARCHIVE_MANIFEST.json](ARCHIVE_MANIFEST.json)，原件来源见 [provenance/COPY_RECEIPT.json](provenance/COPY_RECEIPT.json)。
