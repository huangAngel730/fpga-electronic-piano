# Pro 两版本 FPGA 码流

本交付从已经实际完成的商业版构建中提取，未重新运行综合／布局布线，也未修改原件。两个文件逐字节回读与来源SHA核同。完整身份和原始来源见MANIFEST.json，构建及STA证据见reports/。

| 文件 | 用途 |
| --- | --- |
| 01_pro_audio_basic_A08.fs | 原稳定音频基础版，用于先验证原有四声部音频功能；不包含传谱或DVI双滑块 |
| 02_pro_audio_score_slider_R10.fs | 音频＋传谱／回读／播放＋曲谱下降和实弹上升双滑块，显示接J11 DVI_TX_A |

两个文件是互相替换的完整FPGA配置，一次选择其中一个。建议实物验证顺序为基础版音频，再拓展版音频／传谱／显示。

工具：Gowin商业版V1.9.12.04；目标GW5AST-LV138FPG676AC1/I0，C步进；50MHz参考，40MHz音频。保留K16低有效复位、H17高有效功放。基础A08和拓展R10均已实际生成并通过各自报告的STA；这不是新构建回执，也不是板上通过回执。PR1014等既有告警保留，完整C9及精确最小N／尾窗证明没有因此升级。

拓展版还需要ESP32-C3运行桥接固件和电脑客户端，单独下载FPGA码流不会自动完成蓝牙连接。桥接固件在../../project/software/firmware/release/，按实际flasher_args.json处理三份镜像；FPGA.fs不能烧给ESP32。接线：ESP GPIO4 TX→J26第11脚，GPIO5 RX←J26第9脚，GND→J26第3或4脚。接口为3.3V逻辑，ESP32由USB供电、FPGA沿用已验证适配器供电，不并接两板电源输出。实际Bank及接线仍须核对。

本轮仅交付文件，没有扫描或烧录设备。实物验证未开始，board_release_allowed=false；设备操作前继续遵循当轮技术准入和精确候选核验。详细接线／电脑运行环境以../../project/hardware_bringup_r01/README.md为准。
