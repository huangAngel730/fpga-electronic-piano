# Pro 码流归档：新增波形拓展版

01、02 的原码流、原 README.md 和 MANIFEST.json 均原样保留。
本次新增 03；三个文件均为完整 FPGA 配置，一次选择其中一个。

| 版本 | 文件 | 功能 |
| --- | --- | --- |
| 基础版 | 01_pro_audio_basic_A08.fs | 原四声部音频 |
| 传谱双滑块版 | 02_pro_audio_score_slider_R10.fs | 音频＋传谱、回读、播放＋双滑块 |
| 波形拓展版（最新） | 03_pro_audio_score_slider_waveform_R01.fs | 前述功能＋左声道波形＋键盘控制切页 |

03 使用 Gowin 商业版 V1.9.12.04，GW5AST-LV138FPG676AC1/I0、C步进。
Setup 最小余量 2.697 ns；Hold 0.000 ns，Setup/Hold 违规端点均为0。
Recovery 2.498 ns、Removal 0.009 ns、最小脉宽余量6.970 ns。
参考50MHz、核心40MHz、像素25MHz、串行125MHz，未改频率或分频。
精确源码模块/系统回归、综合、布局布线及当前约束下STA通过；尚未上板实测。

K1 CC7音量；B1 CC25切换后续新音符音色；B2 CC26返回双滑块；
B3 CC27进入波形；B4 CC28预留频谱，B5/B6暂空；两条触控条和踏板保持原功能。
频谱尚未实现。完整工程及证据仍在：
../../project/pro_waveform_integration_20261022_r01/delivery/Pro_Waveform_R01.zip

本次仅复制并逐字节/SHA核验归档，没有改设计、重新构建或操作设备。
新增清单为 MANIFEST_WAVEFORM_R01.json，新增报告为 reports/waveform_R01/。
旧低余量/失败构建及码流保留在原工程 evidence/GOWIN_WAVE_*/ 中。
