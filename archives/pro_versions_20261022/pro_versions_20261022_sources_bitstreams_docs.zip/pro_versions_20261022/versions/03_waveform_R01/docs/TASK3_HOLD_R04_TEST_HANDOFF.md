# Task3 Hold R04 第五版后备模块测试交接

RUN_01五组全PASS，无本轮失败。仅新写hold_r04测试/runner/evidence/docs，未编辑生产RTL。收口当前四源及95文件SV/include/ROM闭包与实际冻结输入逐字节一致，所有ROM实际副本和根别名已核。旧R01/R02/R03三套TB、runner与最终receipt对照已过快照未变。

精确四源SHA、原始stdout/stderr、完整命令/exit/时长、W05原件同字节证明、W13前参考与改名派生身份见 `evidence/task3_hold_r04_tests_r01/RECEIPT.json`。ModelSim SE-64 2020.4；vlib/vlog/5个vsim均退出0，正向PASS+Error/Fatal门禁齐全，原有relaxed-input-port警告保留。

## 精确恢复与新增bit8

真实当前bank逐字节等于 `evidence/GOWIN_WAVE_05/inputs/project/src/m1td_polyphonic_envelope_bank.sv` 和父封存BASELINE_W05副本，SHA `31c25b7e6eb22714d01c7d0f0ceb7131b3fb301d1aab54bebd041dace2fb4502`。scheduler W05 baseline也已核为a03c156…e60645，当前是新增bit8链后的c47ee456…df2ccf5。生产中没有R03 read_word_buffered/full64链和capture_generations/512 LUT代际链；不把这些带回后备版本。

`tb_hold_r04_identity` 没有时钟，对真实raw_mem_write_word完整64位做0/1/X192次、walking-one/zero128、混合4、随机2048，总2372次，覆盖原bit24与新bit8链，并检查完整其它字段保持；score14另3次。强迫任意读词只用于组合同值，不冒充合法score。

`tb_hold_r04_consumer` 真实READ捕获tick1和257，等READ_COMMIT后仅force末级 `read_word8_hold_chain[4]` 为1/0；两方向各检查出口和真实RAM采用，共4次。RAM写词仅bit8翻转，原read_word、prepared_key、previous_tick和div_shift仍取原W05含义；不误用本轮缓冲改变算法输入。另四条实际合法score tick1/256/257/512完整准备，逐行核存储/QR及两对ON/OFF端点，bit8=0/1均覆盖。

## 适用模块回归

scheduler新top/marker适用组通过56完成回执、18负例、8新态STOP/CLEAR、4复位、22identity变化、512 QR、5632ceil及满512准备16928core周期，READ后poison/边界/配对/120frame/96768tick/背压保持。没有重复无关gain48000组。

恢复的真实bank对精确BEFORE_W13 bank逐拍miter153674周期；两者均使用真实router/sustain/allocator/control/pitch/四DDS+ADSR及冻结ROM，没有bank stub。4955捕获、4950非零waves/envelopes结果、4952推进，10次实际多源channel分配含LRU抢占与代际递增，真实NoteOff按原4800样本Release经4900完整请求出现retire，再复用该slot。七状态frame_tick取消和DRAIN后新请求、逐req至多一次advance/result、WAIT_CONTROL异步复位与完整304位背压保持通过。当前bank fixture已删除R03 generation-buffer恒等/反事实段，不引用已移除信号；只核实际公开代际值捕获与事务行为。

显示对BEFORE_W13精确源逐拍miter1276726像素/2042722core周期，真实40/25/125MHz、H800/V525，含420000 active-live像素、760096真实fatal像素、页切换/复位和3次fault链0/1/X；DVI是明确RGB/control输入边界替身。

预计本hold特征组LUT24（score8、read24原2、新read8四级、live2、gain8），实际保留数和物理Hold/strict min1/Setup>0.5ns由总控EDA核。bank请求加速、scheduler每32core tick、display500kHz观察load都是软件fixture，不代签真实48k或完整2.016秒系统。#1只让delta收敛，无周期或物理时延结论。没有EDA、实物、Git或生产源写入。

复现需全新输出名：`C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_setup_hold_r04_tests_run.py NEW_RUN_NAME`。
