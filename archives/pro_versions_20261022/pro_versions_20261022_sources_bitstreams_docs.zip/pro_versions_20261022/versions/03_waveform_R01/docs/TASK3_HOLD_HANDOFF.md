# Task3 WAVE04 Hold 恒等缓冲修订

本轮按 TASK_AND_INTERFACE.md physical refinement，只修改 scheduler、display、m1td_voice_gain_q15_candidate 三文件及本次检查/交接。WAVE04 Setup+1.529ns已达严格>0.500ns，但Hold四端点失败，不能放行。旧FS、报告、SETUP_SOURCE_READY和对应冻结源码保留。修改前后精确SHA及diff在 evidence/task3_hold_r01/；本轮就绪入口为 TASK3_HOLD_SOURCE_READY.json。

## 精确端点与新增实例

| 模块/端点 | 恒等链 | 新LUT1数 |
| --- | --- | --- |
| scheduler held_payload[14]→score_payload[14]→mailbox，严格min1ns当前-0.369ns | g_score_payload_hold[0..7].u_identity | 8 |
| scheduler read_word[24]→raw_mem写端DI8，当前-0.008ns | g_read_word_hold[0..1].u_identity | 2 |
| display fatal_live_pixel→u_live.video_desync，当前-0.069ns | g_live_fault_hold[0..1].u_identity | 2 |
| gain envelope[4]→positive_gain→DSP B4，lane2当前-0.013ns | 每个g_gain[i].u_gain/g_envelope_hold[0..1].u_identity | 2×4=8 |

预期总新增20个LUT1，scheduler10、display2、四个gain lane8。沿用现有 `LUT1 #(.INIT(2'h2))`，中间chain wire和各instance均加 `syn_keep=1,syn_dont_touch=1`；这里只记录RTL数量，总控须在完整综合网表核验20个新增实例确实保留、没有被折叠或绕过。所用8/2/2/2级为本轮明确指定方案，物理效果只能由新PnR/STA验证，不将逻辑恒等仿真视作已满足hold。

拼接维持score98位、READ64位、envelope16位，仅替换各目标单bit。READ只在raw_mem写端用缓冲，不改变read_word字段/格式/lifetime/divider；live只在u_live.video_desync输入使用缓冲，其余fault扇出保持。gain的符号扩展、33位乘法、算术右移及PCM拼接保持。没有新FF、时钟/复位/约束变更，没有周期/数值变更。原精确音频min1与score严格min1均由总控继续保留，未放宽。

## 验证与后续门槛

新测试在 project/tb/setup_pipeline/hold_refinement、tools/task3_setup_hold_test*、evidence/task3_hold_tests*，不覆盖旧runner/测试证据。检查组合0/1/X输入的恒等传播、gain正负/端点/独立黄金与四实例、实际display对冻结修改前实例的逐周期miter以及当前scheduler的新准备阶段完整回归。RUN_02三组全PASS：gain黄金48000次、显式0/1/X恒等13条；scheduler 56回执/18负例/8抢占/4复位/22identity/512QR/5632ceil；display 1276726像素、2042722核心周期逐拍对照，live有效420000像素、真实fatal有效760096像素。RUN_01只有新fixture过早要求frame_start发布状态而失败，修正自然帧等待后通过，RTL和门槛未改。所有失败原件和一次进程创建前审查超时事件保留于测试交接。最终当前源和依赖闭包与RUN_02冻结输入逐字节一致。

总控/Task4以本轮3源精确SHA做新的真实top/PCM/MIDI/score/wave/page、原光栅与自然2.016s lead回归。总控执行商业版Gowin V1.9.12.04综合/PnR/STA，验证新增LUT实例、strict score min1及原audio min1命中与生效，所有Setup严格>0.500ns以及Hold/Recovery/Removal/Pulse通过后才能提供新码流并停止修改。本岗不执行EDA/设备、不声称物理Hold修复完成。
