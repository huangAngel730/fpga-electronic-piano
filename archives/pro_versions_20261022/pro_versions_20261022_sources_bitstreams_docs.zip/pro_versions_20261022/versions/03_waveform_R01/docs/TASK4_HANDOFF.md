# Task4 Pro波形系统接缝最终交接

**PASS：新ModelSim系统仿真及精确源码范围只读自审完成。没有执行EDA、设备扫描/下载或Git；不代签物理CDC、STA、TMDS串行器、板卡或完整C9。**

任务范围为本根docs/TASK_AND_INTERFACE.md的Task4。只新增project/tb/wave_system/**、tools/task4_*、evidence/task4_*/**及docs/TASK4_*；Task2/3/总控生产源码只读。未调用旧已消费runner，未改Android成品、原R10、baseline或仓库共享状态。旧源完整性由最终seal对SOURCE_INPUTS逐件核验。

## 新实现与验证

- tb_wave_top_seam.sv：实际pro_audio_minimal_top加独立同版真实core reference。真实31250 MIDI、115200 UART v2装载/COMMIT/逐条READ/START/STOP；默认combined、B3选wave/B2返回、重复高值/松开重臂/预留控制；自然frame_start切页、隐藏live/score持续；CC7实际DAC输入mute/unity；实际PRE_NBA PCM与observer/ordinal；显示像素暂停造成真实队列满，音频逐周期/I2S仍与无显示reference一致。
- tb_wave_audio_seam.sv：两份真实四声部core、source14公共score端口和MIDI真人并发、原波形observer/CDC/window。独立longint Q1.12黄金核volume正负/unity/mute/mid，按采用ordinal排队独立解码外部PT8211 BCK上升沿/WS/末16bit；CC25未来NoteOn确实采用轮换音色且不改已held source14，source14 scoped STOP保留真人；观察堵塞、显示支路复位和全音频复位恢复。
- task4_sim_primitives.sv：只为PLL频率/锁定、LUT1逻辑及DVI串行器边界提供明确fixture；未替换MIDI、真实音频算法、scheduler、observer、CDC、waveform或renderer。pixel暂停是注入的仿真故障，不是板上门控策略。

ModelSim SE-64 2020.4，新执行记录evidence/task4_system/RUN_004：

| 场景 | 实际正向结果 | 退出/用时 |
|---|---|---|
| audio端口接缝 | 2531个真实采用PCM/observer逐点、2467个pixel交付、5059个串行半帧、2431个真人/score共存帧；堵塞96帧/63丢弃/1gap；scoped STOP保留2真人；reset恢复 | vlib/vlog/vsim均0，audio实耗9.750s，虚拟55.335050ms |
| full实际top | 自然2.016s lead，四条raw事件按原始tick/顺序接受；两源并发7999998核心周期；90443100周期miter、108531实际发送帧、6次帧界页切换、11次真实UART协议核验；显示暂停仍发送144帧且观察丢111帧 | vsim0，实耗248.031s，虚拟2261.077926ms |

full未强制global_tick/t0/anchor/score状态，未缩短lead、采样周期或H800/V525光栅。按独立core miter、真实采用口和score精确到期检查判断，未把两个失效score输入相等当作完整播放通过。自然结尾lease保留，显式STOP后真人held/live仍在。

RUN_002另有实际top短测通过：5148帧、4290501周期、4次页切换；它是早期限定lead/preview证据，不单独冒称全曲。RUN_004 full包含完整自然链路，作为最终系统身份基准。完成标志TASK4_AUDIO_SEAM_COMPLETE、TASK4_TOP_SEAM_COMPLETE及PASS TASK4_NATURAL_FULL_LEAD_SCORE均在原日志；未只靠进程exit0放行。编译/仿真警告原样保留，不宣称零警告。

## 自审、身份与失败

控制/音量完整diff及新增模块全文自审见TASK4_CONTROL_REVIEW.md；显示/波形与实际top只读辅助见TASK4_VISUAL_REVIEW.md、evidence/task4_review/READ_001/REVIEW.json（21份精确来源、原字节、读取范围和findings=[]）。这不是启用外部审核员制度。Task2/3自己的单元结果仅作上下文，本窗没有重跑或合并它们的计数。

RUN_001编译失败：误选PATH旧10.1d不支持既有SV cast，另新TB误用sequence保留字；读工程实际工具路径后改用2020.4并仅修自有TB。RUN_003音频失败：新串行oracle过早把下一帧PCM用于旧左半帧末LSB；改为按采用序号排队、外部WS1→0后才取新黄金。两个失败的输入源码、命令、退出码、stdout/stderr与修正版新RUN全部保留，详见TASK4_FAILURE_HISTORY.md。没有为过测试修改生产代码或降低门槛。

交接勘误：RUN_003的audio进程实际exit_code=0、timed_out=false；日志有Fatal且completion_marker_seen=false，因此PASS=false、整包status=FAIL。TASK4_FAILURE_HISTORY.md已纠正原“退出非0”表述，原始失败回执与日志不变。

最终身份/证据收据：evidence/task4_final/SEAL_002/receipt.json（文档勘误后新封存，保留SEAL_001历史原件）。seal仅核RUN_004所有当前输入与执行快照相等、只读review来源相等、SOURCE_INPUTS原件全部未变，以及工具/测试/日志/产物SHA；不再重跑已通过组。RUN_004/inputs是实际执行源、include与ROM原件快照，receipt包含完整命令、每步耗时/退出码、工具SHA和产物SHA。后续生产源改变时不能沿用本收据代签新版本。

## 复现与接手

从任意cwd，以本根绝对路径运行（执行器创建新RUN，不覆盖旧原件）：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/pro_waveform_integration_20261022_r01/tools/task4_run_system.py' audio full
```

top短测可单独用参数top。full关闭不必要的全局+acc，TB静态层次引用和force注入仍由编译器保留；audio用+acc。两者算法、时钟、golden和断言相同，未记录全设计WLF。full上限1500s、短组600s；这些是新runner超时保护，不恢复旧额度。

总控接手真实Pro PLL/DVI和source注册、商业版Gowin V1.9.12.04综合/PnR/STA及CDC例外/80位bundle约束核验，尤其新音量组合路径。内部engine checksum仍是pre-volume，Task4另核实际post-volume发送PCM；没有把其metadata借作post-volume校验。无实机音量、耳机/功放、显示器、UART/BLE或整体C9结论，不产生设备放行。
