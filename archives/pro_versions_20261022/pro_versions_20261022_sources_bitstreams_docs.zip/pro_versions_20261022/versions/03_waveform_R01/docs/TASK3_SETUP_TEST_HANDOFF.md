# Task3 Setup pipeline 新RTL测试交接

RUN_02 PASS。只编写本新测试、runner、证据和本文档，未修改scheduler或其他RTL；无EDA、设备或Git操作。任务入口为docs/TASK_AND_INTERFACE.md的Setup置顶addendum。

测试源：project/tb/setup_pipeline/tb_setup_pipeline.sv；新runner tools/task3_setup_tests_run.py。ModelSim SE-64 2020.4，core真实40MHz。sample_tick软件fixture每32核心拍一次（1.25MHz加速），不能代替真实48k／整机自然2.016秒lead。仿真结束77.886425ms。vlib/vlog/vsim均退出0、Errors/Fatal为0，并强制正向PASS marker。原始双流、完整命令、时长和输入快照均在evidence/task3_setup_tests_r01/RUN_02。

最终scheduler源码SHA256：271a4117f883db70fd8b18f7d9d24d876e26c40de07d88c3fe11acac4c7c0e59。收口时当前源码与RUN_02冻结输入逐字节相同。

实际PASS：56完成回执、18负例、8新阶段STOP/CLEAR、4新阶段异步reset、22身份变更、512QR行、5632精确ceil、满512准备16928核心拍；runtime音频2事件/visual1载荷。

- READ响应只脉冲一拍，下一沿及以后总线持续poison；raw_mem、QR、endpoint必须仍来自捕获word。
- READ_FORMAT/LIFE_LOOKUP/LIFE_CHECK/READ_COMMIT四状态各执行STOP和CLEAR；同沿active_write必须0，raw_mem sentinel、previous_tick、active_count不变；后续ALL_NOTES_OFF/flush清理与lease释放完整完成。
- 四状态逐一异步复位，确认event/score/read/lease低、active清零、flush和global tick复位；四状态逐一改变valid/count/id/generation/bank，共20例，并在CHECK/ANCHOR改变generation，两例均不能成功START。
- 18负例覆盖未回读、513条、kind2、channel16/255、note35/85/255、velocity128/零on、高tick字节、降序、孤立off、重复on、未闭合on、READ超时、anchor phase4032、anchor frame溢出。
- 512行正例包括256同时on后逐一off，跨channel同note配对；逐行与独立64位整除模型对比5*tick/4032及余数，匹配on的off端点，再按11种phase逐一计算ceil共5632次；另测channel15/note84、最大tick16777215。
- runtime独立检查120frame绝对ceil payload、velocity映射、96768tick音频lead及短背压valid/data稳定。

RUN_01编译失败原件保留：新TB在显式global_tick声明之前引用它；仅移动测试声明顺序后通过RUN_02，RTL未改、门槛未降。没有RTL数据不一致或行为失败。精确源SHA、命令、计数、失败史与条件见evidence/task3_setup_tests_r01/RECEIPT.json。

复现请使用新目录名：

```powershell
C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_setup_tests_run.py NEW_RUN_NAME
```

这里只签新scheduler模块软件回归。严格Setup>0.500ns、其他时序门禁和真实top/MIDI/score/wave/page回归由总控/Task4执行，本测试不能代签EDA或实物。
