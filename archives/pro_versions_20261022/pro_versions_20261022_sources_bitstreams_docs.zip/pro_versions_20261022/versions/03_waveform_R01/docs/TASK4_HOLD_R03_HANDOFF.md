# Task4 HOLD R03 四源真实系统最终交接

**PASS：新directed/audio/full全部完成；current_inputs_unchanged=true、frozen_inputs_unchanged=true。当前四源与实际执行快照、Task3 READY和模块输入一致，精确静态自审无阻断。仅签RTL仿真和只读自审，明确非上板；本窗未执行EDA、设备或Git，不代签物理时序、码流或LUT数量。**

本轮按总控WAVE11后继授权，仅写自己的新project/tb/hold_r03_system/**、tools/task4_hold_r03_*、docs/TASK4_HOLD_R03_*和evidence/task4_hold_r03_*。未改生产RTL、SDC、options或旧证据，没有向Task3/其他窗口发送消息。旧波形/Setup/HOLD R01/R02封存分别483/254/167/166个文件逐件SHA核验未变，未重跑旧runner或不相关旧组。

## 真实依赖与输入身份

文件事件监听于2026-10-22 16:17:05.413835（Asia/Shanghai）收到真实docs/TASK3_HOLD_R03_SOURCE_READY.json；其SHA256为735199c3d0f981e04f868840c3309644628b05e93912dbd1622fc4cdd0496da8。没有频繁轮询。启动前实际核验SOURCE_READY、模块status=PASS、5组模块命令全部exit0/passed、14份raw日志SHA及全部PASS marker、无Fatal/Error，四源当前/冻结READY/实际模块输入均核同。依赖证据为evidence/task4_hold_r03_dependency/CHECK_001/receipt.json。

| 关键源 | 本轮精确SHA256 |
| --- | --- |
| project/src/extension_visual/scheduler/pro_score_scheduler.sv | 9cefca054bbf9a0ad799ef2951331fc5a99ba173d250dc5dc16ea74c1476f613 |
| project/src/m1td_polyphonic_envelope_bank.sv | 16d6662d02ad6d0c0ac9744e6e7f011dad28efe63dfd54cd79dc05a8f79d2bb6 |
| project/src/extension_visual/display/pro_score_display.sv | e32c346f96b79412bf67c99b8177278e7bcdbcc9f2e011aab33d26153da549a0 |
| project/src/m1td_voice_gain_q15_candidate.sv | 21256acd78106a8825e4c452499582736fc369d062c3b8dc6ec887ce55677697 |

R03 scheduler将64位READ所有真实消费者引到两级LUT恒等出口；bank仅在slot_generations到frozen_generations捕获支路增加128位、每位四级恒等链。新字段解析、状态、算术、周期、时钟/复位不变。display/gain与R02字节一致。静态自审见TASK4_HOLD_R03_STATIC_REVIEW.md和evidence/task4_hold_r03_review/READ_001/REVIEW.json：27项来源/快照核同，完整增量和必要上下文保留，findings=[]。Task3模块加速证明及counterfactual只作上游上下文，不混作本窗真实48k/系统计数。

## 冻结pre-Hold真实核参考

新参考含旧Setup RUN002/inputs的六模块：core、frame core、chain、audio_candidate、旧gain、旧bank。只重命名module/type和独立guard，逐源逆变换与旧原件字节完全相同；最终seal从六份旧冻结字节重建整文件核同。没有把R03缓冲同步写进参考逻辑。73个共同生产依赖均与旧Setup冻结字节相同。

新DUT与独立旧bank/旧gain参考接相同真实MIDI/score/reset/keys；逐40MHz周期核event/ready、post-volume实际TX PCM、I2S、commit/identity及underrun。bank另逐拍比较slot/frozen/control/math generation、phase、CAPTURE握手、frame_tick优先级、lane_tick和完整result，记录分配/释放/退休/复位后分配。音量有独立signed64 Q1.12黄金，PT8211 LSBJ半帧独立译码，observer/CDC按真实采用序号核同。

保持真实50MHz参考、40/25/125MHz、原48k NCO、H800/V525光栅和96768采样tick即2.016s lead。没有改变/分频时钟、缩短lead或强制scheduler tick/anchor。PLL/LUT沿已签fixture，DVI明确止于RGB/control边界，不代签物理PLL相位/TMDS串行器。

## 实际入口、时间、退出与cases

真实执行命令（新runner，默认同为directed/audio/full；复现会创建新RUN）：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/pro_waveform_integration_20261022_r01/tools/task4_hold_r03_run.py' directed audio full
```

ModelSim SE-64 2020.4，E:/FPGA/Bpan/modelsim/modelsim1/win64。实际目录evidence/task4_hold_r03_system/RUN_001。2026-10-22 16:24:46.352335启动，16:32:34.539309结束（Asia/Shanghai，UTC原值同在receipt）。外层命令exit0；version/vlib/vlog及三组vsim均exit0/PASS、未超时、所有完成marker齐全且无Error/Fatal。131项输入与执行快照封存，结束时及最终seal核当前未变。

| 新组 | 实际cases/结果 | vsim实耗／虚拟时间 |
| --- | --- | --- |
| directed | 准备4状态STOP/CLEAR8例、generation故障4例、非法READ/超时5例、准备全top reset4例；72捕获检查/92poison，64位消费者等值92次；50真实UART核验、11747979周期/14095发送帧/5次切页；tick8零9次/一2次；live故障仍发送486帧/5120故障条像素 | 180.594s／293.701601ms |
| audio | 2109167周期真实PCM/I2S miter，2531采用帧、2467pixel样本、5059独立串行半帧、2431共存帧；volume full646/mute80/mid80；观察堵塞96帧/drop63/gap1；source14 STOP保留2真人；显示/全音频reset恢复，新epoch100采用/99交付；envelope4零6045098/一2808246 | 9.968s／55.335050ms |
| full | 原自然2.016s lead四曲谱事件按due tick/type/note/channel/order接受；人/score并发15999998周期；101141046周期/121368发送帧/7次切页、23真实UART核验；36捕获/poison/64位消费者检查；tick8零6次/一2次；payload14零1次/一2次；另READ_COMMIT全top reset、真实重新上传全READ与START/STOP/CLEAR，live故障音频继续486帧/5120故障条像素 | 277.063s／2528.526976ms |

新增bank独立旧参考实测：

| 组 | 比较周期 | 真实CAPTURE握手／result | generation变化 | phase mask | 分配／释放／真实退休 | reset／reset后分配 |
| --- | --- | --- | --- | --- | --- | --- |
| directed | 11747974 | 14095／14095 | 5 | 0x01ff | 5／0／0 | 4／4 |
| audio | 2213334 | 2654／2654 | 5 | 0x01ff | 5／1／0 | 1／2 |
| full | 101141044 | 121368／121368 | 4 | 0x01ff | 4／2／1 | 1／1 |

三组覆盖全部9个bank phase；frame ticks为14095/2656/121368，WAIT_CONTROL周期183235/34502/1577784，ADVANCE周期14095/2654/121368。复用generation计数三组均0，未夸称该项实测；directed/audio退休0也保持如实记录。full确实观察1次原真实退休。

曲谱raw ticks为0 ON72、14400 OFF72/ON75、19200 OFF75，保持原lead，仅沿既有新向量覆盖payload14和合法tick8。真实UART完成BEGIN/DATA/COMMIT/逐条全READ/READ_END/START/STOP/CLEAR，严格核ACK identity/形状/CRC/READ字节。MIDI CC7静音/unity、CC25、Pitch/Mod/Sustain、波形B3/B2切页、隐藏跟踪均继续核验。短状态command/READ/generation及live故障注入均明确为仿真反例，不冒称UART正常提交非法数据，不作为板上操作方案。

## 所有失败与限制

本轮新ModelSim只有RUN_001，三模式均PASS，没有编译/RTL失败或超时。准备阶段有两条非零环境/诊断命令：WindowsApps python alias exit1、Get-Command/未生成目录检查exit1，原记录与更正见TASK4_HOLD_R03_FAILURE_HISTORY.md及PREPARATION_RECEIPT.json。原工具只给合并output，旧准备收据将双流分别写空的说法精度不足；原收据不回写，新失败史明确更正，不能独立断言stderr为空。随后已发现的bundled Python准备/AST/静态门禁exit0，本窗实际系统入口使用上述Miniconda。

编译Warnings12；directed/full各Warnings139，audioWarnings147，原日志保留，三组Errors0。没有声称零warning。所有新RUN的首失败保留规则不变，seal汇总全部非PASS RUN和准备非零事件，不能把进程exit0单独当PASS。

## 最终封存与总控接手

机读就绪docs/TASK4_HOLD_R03_SOURCE_READY.json；最终evidence/task4_hold_r03_final/SEAL_001/receipt.json。包含真实入口/时间、四源、模块PASS依赖、三模式退出与全部PASS行/cases、全部失败、当前/执行快照原件/参考/日志/工具及交接产物SHA。最终seal只核身份、语法和证据，不重跑测试；源、prepared TB或共同依赖改变时必须另绑新版本。

总控接手精确四源做商业版Gowin标准replication1完整构建和STA；实际658个相关hold LUT保留数、所有Setup严格>0.500ns、原min约束及Hold/Recovery/Removal/Pulse结果由总控原件验收。WAVE11及其它失败日志/FS继续保留。本窗不改SDC/options，不生成或放行码流，明确未上板。
