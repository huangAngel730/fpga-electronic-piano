# Task4 HOLD R04 定版静态自审

固定四源相对真实 WAVE05 执行输入、旧 Setup 冻结输入的完整 diff 范围内未发现具体阻断，`findings: []`。当前四源、R04 READY 冻结副本、模块测试实际输入及 SOURCE_READY 声明 SHA 均已核同。

| 当前文件 | SHA256 |
|---|---|
| project/src/extension_visual/scheduler/pro_score_scheduler.sv | c47ee45641b76ea4d964c8367a51cf65f496efc6502f5ad03b73a78ebdf2ccf5 |
| project/src/m1td_polyphonic_envelope_bank.sv | 31c25b7e6eb22714d01c7d0f0ceb7131b3fb301d1aab54bebd041dace2fb4502 |
| project/src/extension_visual/display/pro_score_display.sv | e32c346f96b79412bf67c99b8177278e7bcdbcc9f2e011aab33d26153da549a0 |
| project/src/m1td_voice_gain_q15_candidate.sv | 21256acd78106a8825e4c452499582736fc369d062c3b8dc6ec887ce55677697 |

相对真实 `evidence/GOWIN_WAVE_05/inputs/`，仅 scheduler 新增 read_word[8] 到 raw RAM 写数据的四级 `LUT1 INIT=2'h2` 链。原 bit24 两级、score14 八级保持。64 位写字拼接为 39+1+15+1+8 位，两个出口分别落在 bit24、bit8；格式、prepared_key、除法输入与 previous_tick 继续使用 WAVE05 原 READ 路径。删除新增 bit8 链、恢复原拼接后，完整 scheduler 文本等于 WAVE05。

bank、display、gain 均与真实 WAVE05 字节相同。bank 也与旧 Setup 原字节相同，已无 R03 generation 捕获缓冲；scheduler 已无 R03 全 64 位消费者缓冲。四个绑定源对旧 Setup 的实际差集只有 scheduler/display/gain，绑定四源不表示四源都修改。没有新增时序级或改变周期、数学、控制、接口、时钟、复位；组合传播与仿真 delta 收敛不构成新增寄存周期。

SOURCE_READY SHA256：`ed6cfc8f5c6d7b5998f4d9921fcedac24d6581abf88e65b9d5ad87e85afad921`。模块回执 SHA256：`f4a46e707821c19c56d3b5feffd4466e67e7a9484b177959e671f6ab1d7ddfb4`。本窗核同其命令退出与 passed 字段、14 份 raw 日志 SHA 及五组 PASS 标记，未见 Fatal/Error 标记；没有重新执行模块或系统测试。

上游回执报告：raw 写字恒等检查 2372 次、bit8 最终出口消费者检查 4 次、合法 tick 1/256/257/512 的 QR 行 4 条、scheduler 56 例、bank 153674 周期比较与一次真实退休、display 1276726 像素比较。合法 tick 256/257 的 bit8 为 1，1/512 为 0；强制 bit8 最终出口或任意 64 位输入只证明写端消费和恒等拼接，不能当成合法谱接纳。非法高 tick 仍由原 WAVE05 格式检查拒绝。

模块边界：scheduler sample_tick 每 32 个 40 MHz core 周期一次，waveform load 为 500 kHz 夹具；bank 使用加速请求握手节奏，真实 4800 样本 release 未改。bank 模块参考是 BEFORE_W13 的 R03 缓冲版本，不是独立 prehold bank；不变 gain 的 48000 黄金组未重复。DVI 为 RGB/control 边界。以上仅是上游模块证据，不能代签父窗新 audio/directed/full 自然 2.016 秒整机回归、独立旧 bank/gain 参考或 serializer/PLL/实物。

封存入口为 `evidence/task4_hold_r04_review/READ_001/REVIEW.json`。28 项 `sources` 每项包含绝对 path、sha256、read_scope、snapshot；保存完整 WAVE05/Setup 两份 diff、精确源/基线/READY/模块输入及 14 份模块日志。Task3 的 BASELINE_W05 仅含 scheduler/bank；其余两源直接绑定真实 WAVE05 输入。首次封存脚本错误假定目录含四源，在写证据前失败，已修正并保留 `PREPARATION_FAILURE_001` 说明及错误输出，不是产品失败。

相关恒等链预期 24 LUT（score8、read24 两级、read8 四级、live2、gain8）仅为 RTL 估计，比 WAVE05 增四级；不等于工程总 LUT 或真实保留数量。实际保留和全部 STA（含 Setup 严格大于 0.500 ns）由总控拓展任务1验收；本结论不提供设备放行。

本窗仅静态审查与指定新证据写入，未测试、编译、仿真、EDA、Git 或操作设备，未修改生产源、父窗代码及旧证据，未向外部聊天或 peer 通信。
