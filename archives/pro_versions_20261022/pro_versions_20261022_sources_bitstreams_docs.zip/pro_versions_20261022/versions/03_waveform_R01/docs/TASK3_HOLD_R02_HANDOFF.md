# Task3 Hold R02 tick域恒等缓冲

按TASK_AND_INTERFACE.md WAVE05 R02授权，仅修改 scheduler，display/gain保持R01精确SHA。WAVE05 Setup+1.478ns、原四个Hold cone及两条严格min1已通过，新增20个LUT均保留；仍有read_word8到raw_mem DI8的同类native Hold -0.057ns，故旧FS不放行。原WAVE05报告/FS、R01源码/ready/tests全部保持原位。

## 最小修改

`read_word[31:0]` 每bit通过2个 `LUT1 INIT2`，使用 `g_read_word_hold[bit].g_stage[stage].u_identity`；每条链和instance继续syn_keep/syn_dont_touch。上32位 `read_word[63:32]` 不变；仅raw_mem写数据拼接为 `{read_word[63:32],read_word_hold_ticks}`，字段验证、lifetime、QR、运行时算术和周期均保持。不添加寄存器，不改时钟/复位/约束。

read-word链预期64 LUT；含原score8、display2、gain2×4共82个，较R01净增加62个。总控须核完整综合网表实际计数/保留与生效，不能凭RTL数量代签。

精确前后三源SHA见 evidence/task3_hold_r02/IMPLEMENTATION_IDENTITIES.json；修改前冻结在BEFORE，精确diff及SELF_REVIEW与WAVE05_DIAGNOSIS同目录。旧SETUP/R01 ready哈希见PRIOR_RECEIPTS_SHA256，最终封存时再核其未变。

## 新验证与交接

新hold_r02专属测试/runner冻结实际三源与全部依赖；逐bit0/1/X、walking1/0及随机字检查32位tick拼接、上32事件字段不变和无周期恒等。重验原scheduler正负/异常/新态abort/复位/identity/512QR/ceil/lead/背压，并在本轮实际源闭包重验gain/display。样本加速fixture、DVI显式输入边界、force语义与失败历史由TASK3_HOLD_R02_TEST*及新test receipt明示。

RUN_01全PASS且无本轮失败，当前3源及依赖闭包与冻结输入逐字节一致。tick低32位恒等/拼接2212次、gain48000次；scheduler 56回执/18负/8abort/4reset/22identity/512QR/5632ceil；display1276726像素/2042722core周期一致。已经生成本轮就绪入口 TASK3_HOLD_R02_SOURCE_READY.json。R01旧TB/runner/receipt由测试方核未变；旧SETUP/HOLD ready由最终封存再次核哈希未变。Task4继续精确新源audio/directed/full自然2.016s lead回归；总控做商业版Gowin完整综合/PnR/STA，仍要求Setup严格>0.500ns、全部其他时序通过，原两条严格min1不放宽。通过后交付新码流并停止修改。本岗无EDA/实物/Git，不声称当前物理Hold已经通过。
