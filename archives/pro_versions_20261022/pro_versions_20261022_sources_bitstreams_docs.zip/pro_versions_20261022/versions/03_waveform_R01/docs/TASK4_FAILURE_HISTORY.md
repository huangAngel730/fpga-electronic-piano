# Task4新系统测试失败史

所有目录位于本候选evidence/task4_system；失败不删除、不回写为通过。

| 原件 | 实际结果 | 定位与最小修正 | 产品判断 |
|---|---|---|---|
| RUN_001 | vlog退出非0，未启动仿真；完整stdout/stderr及每步RESULT保留 | PATH指向ModelSim ALTERA STARTER10.1d，不接受原候选的部分SV sized casts；读现有工程实际runner后选择E:/FPGA/Bpan/modelsim/modelsim1/win64的ModelSim SE-642020.4。另修自有TB保留字参数sequence→request_seq，watchdog使用64位时间常量。未改生产RTL或运行旧runner | 工具选择及自有TB问题，不是新功能失败；新RUN_002编译通过 |
| RUN_003 | 编译0；audio仿真进程exit_code=0、timed_out=false，但日志含Fatal physical LSBJ word mismatch，1021637500ps，got0000/expected0004；completion_marker_seen=false、PASS=false，runner正确拒收，整包status=FAIL | 新译码器在真实frame adoption后立刻拿新PCM比较尚未结束的旧左半帧。改为按采用ordinal排队，在外部WS1→0边界先比较旧左字再取下一帧黄金，并检查每半帧32个BCK上升沿；不读DUT移位寄存器作黄金 | 自有serial oracle提前一BCK，不是产品数据修改；RUN_004音频seam独立5059半帧通过 |

RUN_002实际top短测通过，但不能代替自然2.016秒lead；该完整场景使用新RUN_004的full模式，不改global_tick、t0、anchor、raster或采样率。首失败原件含当时完整源码与测试输入SHA，修正版只进入新RUN。

2026-10-22交接勘误：原文“RUN_003 audio仿真退出非0”不准确；以RUN_003/receipt.json的tests.audio原始字段为准，实际进程退出0，因Fatal且缺完成标记而拒收。此次只修正文档及新最终封存回执；RUN_003原始失败回执、日志和SEAL_001均保持原样，没有重跑测试或修改生产源码。

ModelSim warning来源须按各原日志区分：类型化input端口默认var提示及测试未接诊断输出，均原样保留，不能写成零警告；有错误/Fatal或缺完成标记不会被exit0放行。没有设备、权限或门禁故障重试，也没有复制生产源来绕过拒绝。
