# Task4 Setup 流水线真实系统回归交接

**PASS：Task3新scheduler的真实top directed/full回归与精确diff只读自审已完成。Task4没有运行EDA、设备或Git；Setup严格大于0.500ns及全部其他时序项由总控拓展任务1按商业版Gowin原件验收，本交接不签时序、码流或实物通过。**

范围来自本候选docs/TASK_AND_INTERFACE.md置顶Setup addendum。只新增/编辑project/tb/setup_system/**、tools/task4_setup_*、evidence/task4_setup_*/**及docs/TASK4_SETUP_*。旧RUN002/RUN004、旧Task4工具/TB/交接、SEAL_001/002原件均未改写；封存前逐件核验旧SEAL_002覆盖的483个文件SHA未变。相对旧RUN004，生产RTL只有已授权scheduler变化；本窗未改生产源。

## 精确接收版本与自审

Task3_SOURCE_READY实际入口：docs/TASK3_SETUP_SOURCE_READY.json，状态SOURCE_READY。当前源码、Task3冻结副本、Task3模块RUN_02执行输入及本窗新系统执行输入，scheduler SHA256一致：

```text
271a4117f883db70fd8b18f7d9d24d876e26c40de07d88c3fe11acac4c7c0e59
```

旧scheduler SHA为16790e2d4f63d35ec1f0bff9ca9e3db4e2770dd95f406626148a24e99cf780d6。只读增量审查见TASK4_SETUP_STATIC_REVIEW.md及evidence/task4_setup_review/READ_001/REVIEW.json：9项来源逐件封存，保留完整diff、读取范围和Task3原始模块日志，findings=[]。确认READ_CAPTURE/格式/寿命查询/寿命判断/提交的寄存边界、STOP/CLEAR优先级、每级identity门禁；runtime offer和RUN/STOP段与旧基线相同，lead常量和数学不变。Task3加速模块测试只作上下文，未并入本窗计数。

## 新实现与运行结果

新tb_setup_top_regression.sv复用本窗旧自检的协议/音频黄金结构，另新增流水线特有场景；旧测试文件未改。实际pro_audio_minimal_top加同版真实audio core reference，真实31250 MIDI、115200 UART、50MHz参考/40MHz core/25MHz pixel/125MHz serial、48kHz NCO及H800/V525光栅。没有修改或强制scheduler tick、t0、anchor、lead、采样周期或raster。

在每个新READ准备状态，捕获后rd_event持续poison为全1，read_word须逐字节等于已上传曲谱。真实传输链路BEGIN/DATA/COMMIT/逐条全READ/READ_END/START/STOP/CLEAR均核ACK identity、形状、CRC及READ bytes。音频逐核心周期、I2S、ready、事件采用和post-volume PCM同独立无显示core对照；observer采用口及ordinal核同。自然frame_start切页、隐藏人/score跟踪、音量mute/unity、原Pitch/Mod/Sustain保留。

新ModelSim SE-64 2020.4执行原件：evidence/task4_setup_system/RUN_002；整包status=PASS、current_inputs_unchanged=true。

| 场景 | 实际结果 | 进程退出与用时 |
| --- | --- | --- |
| directed真实top | 新READ_FORMAT/LIFE_LOOKUP/LIFE_CHECK/READ_COMMIT各STOP和CLEAR，共8例；各generation故障共4例；非法READ/超时5例；各准备状态异步全top复位并重新真实上传全READ，共4例；50次真实UART协议核验、11343125周期miter、13609发送帧、5次切页；捕获72次状态检查、92次poison、真实UART CLEAR1次 | vlib/vlog/vsim均exit0；vsim166.375s，虚拟283.580251ms |
| full自然时基 | 原始96768个48k采样tick即2.016s lead；四条事件按原tick/type/note/channel/顺序接受，人/score并发7999998核心周期；92736193周期miter、111282发送帧、7次切页、23次真实UART协议核验；捕获36次状态检查/36次poison，另READ_COMMIT全top复位、重新上传全READ及成功START/STOP/CLEAR | vsim exit0；实耗224.562s，虚拟2318.405651ms |

两个场景均实际通过显示像素暂停：发送144帧继续、观察队列满丢111帧，音频与reference保持一致。directed完成marker要求精确aborts=8、identity=4、negative=5、prepare_resets=4；full额外要求PASS TASK4_NATURAL_FULL_LEAD_SCORE。两组均要求TASK4_SETUP_SYSTEM_COMPLETE、捕获稳定性正marker、exit0、无Error/Fatal。当前日志Errors0；编译Warnings11、每组仿真Warnings139，类型化input/default var和未接诊断输出等原样保留，不声称零warning。

## 故障注入边界与失败史

新状态只有25ns，115200 UART无法在观察到状态后再完成STOP包。8个精确中止用实际top公开command接口注入STOP/CLEAR；身份故障注入visual_generation；非法READ只替换实际scheduler公开READ响应，分别为无配对OFF、重复ON、note35、降序tick及rd_valid超时。这些是独立防御性反例，不冒称由真实UART提交出非法曲谱。原UART正向链与STOP/CLEAR另行实际执行。中止后都要求音频排空/显示flush/lease清理完成且真人音符保留；四个reset均清除传输/页/lease后重新真实装载。

RUN_001失败完整保留：vlog0，vsim进程exit0但Fatal且无完成marker，正确拒收；新TB在命中状态后又多等一拍，使READ_COMMIT的中止实际晚至PREP_DIV。只修本新TB及其生成准备脚本，STOP/CLEAR在目标状态当前negedge呈现，reset也不再额外等拍；生产源不变，门槛不降。详见TASK4_SETUP_FAILURE_HISTORY.md，RUN_002执行输入包含修正版原字节。

PLL fixture只验证频率/锁定接口，LUT1为精确逻辑，DVI fixture止于并行RGB边界；没有代签PLL物理相位、TMDS编码串行器或板上行为。pixel暂停为仿真故障，不是板上门控方案。

## 原件、复现与接手

最终封存入口：evidence/task4_setup_final/SEAL_001/receipt.json。新seal只核源码/执行快照/review身份、旧483原件及新工具语法并记录SHA，不重跑测试。RUN_002/inputs含实际生产RTL/include/ROM、TB、runner和Task3 ready元数据，回执保存完整命令、工具SHA、时长/退出和产物SHA。新runner独立执行，没有调用旧runner；tools/task4_setup_prepare.py只生成本新测试，不重复执行其已存在目录的初始化。

复现（创建新RUN，保留现有原件；不需要重复准备脚本）：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/pro_waveform_integration_20261022_r01/tools/task4_setup_run.py' directed full
```

本次命令退出0；directed限600s、full限1500s，均未超时。当前源后续改变时须重新绑定证据，不能用本回执代签另一SHA。总控接手该精确版本综合/PnR/STA，保留旧低余量FS/报告；不改频率/分频或放宽约束，全部时序满足且Setup严格大于0.500ns后交码流并停止修改。本窗不作设备放行。
