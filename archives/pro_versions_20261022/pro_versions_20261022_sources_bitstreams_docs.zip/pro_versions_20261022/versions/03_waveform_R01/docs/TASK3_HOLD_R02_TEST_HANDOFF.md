# Task3 Hold R02 模块测试交接

RUN_01全PASS，无本轮失败。仅新增hold_r02专属测试/runner/docs/evidence，没有修改任何生产源或R01文件。收口核当前源与冻结输入逐字节一致。精确三源SHA、完整闭包、命令/exit/时长、原始双流和R01不变核验见 `evidence/task3_hold_r02_tests_r01/RECEIPT.json`。

新fixture在 `project/tb/setup_pipeline/hold_r02/`，runner为 `tools/task3_setup_hold_r02_tests_run.py`；top与PASS marker均为新R02。ModelSim SE-64 2020.4，vlib/vlog/三个vsim全部退出0，正向PASS和Error/Fatal门禁齐套。原有relaxed-input-port警告原样保留。

组合测试无时钟：READ低32位每bit独立0/1/X共96次，walking-one/zero64次，混合高32事件字段与低32tick四组，随机拼接2048组，共2212次全64位case-equality，既证明tick逐bit同值，也检查upper32直接保持。score14另3次0/1/X，四lane gain的envelope4 X另4次，总2219。force任意tick只证明组合恒等，含非法tick，不冒充合法score格式。#1仅让仿真delta收敛，不是RTL增加周期或物理延迟。

四个实际gain模块48000次独立signed64乘积/算术右移floor-Q15黄金比较，覆盖正负端点、±1、零、随机和envelope4变化。没有时钟而输入改变后必须输出跟随。

对新scheduler精确字节重跑：56完成回执、18负例、8新阶段STOP/CLEAR、4复位、22identity变更、512 QR、5632 ceil；满512准备16928core拍；READ后poison稳定捕获、lifetime配对、120frame/96768tick和RUN背压保持通过。仅软件sample_tick每32core拍，非名义48k。

自然完整H800/V525、640×480显示前后miter：参考是R02前已做R01 hold的精确显示源，改名冻结；1276726像素、2042722core周期一致。正常note60形成active slot/keys并等真实帧界发布后，再用实际非法note35触发fatal_live_pixel和u_live清理，对live_end/valid/held/key及DVI RGB/DE/HS/VS/reset逐拍比较；active420000像素，fault760096像素。页切换、全局复位与另3次fault链0/1/X通过。真实40/25/125MHz，waveframe-load500kHz为加速观察fixture。DVI仅RGB/control边界替身，不签TMDS。

预计综合新增82 LUT1（read tick64、score8、live2、gain8），实际保留数/位置/物理Hold及严格min1、Setup>0.5ns仍由总控EDA核验。Task4另做实际音频与完整2.016秒lead，不由本模块测试代签。

复现使用新目录：`C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_setup_hold_r02_tests_run.py NEW_RUN_NAME`。原R01三份TB、runner与最终receipt逐字节对照R01已过快照未变。
