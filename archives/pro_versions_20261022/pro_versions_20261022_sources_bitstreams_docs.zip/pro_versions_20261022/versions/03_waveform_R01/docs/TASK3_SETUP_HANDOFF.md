# Task3 Setup 准备流水线 R01

范围按 TASK_AND_INTERFACE.md 置顶 addendum：只改 scheduler 及新 setup 专属 TB/tools/docs/evidence。总控负责真实系统回归、商业版Gowin构建和 STA。最终接受条件是 Setup **严格大于0.500ns**且其他时序检查全通过；本文件与RTL仿真不签时序通过。不修改/分频时钟，不改约束、显示或音频core，无设备操作。

## 根据与实现

只读 GOWIN_WAVE_03 原件：Setup+0.011ns、Hold-0.002ns。timing_paths首路径从transport byte_lanes[6]存储输出，经 scheduler 动态active判断，到active CE；后续同源到divider CE。旧报告与FS保持原位。

`project/src/extension_visual/scheduler/pro_score_scheduler.sv` 在原0..11状态外增加4个准备状态，原件和精确diff位于 `evidence/task3_setup_r01/`：

| 状态 | 动作 | 此时不提交的内容 |
| --- | --- | --- |
| READ_WAIT=3 | 只在identity有效且rd_valid时锁存64位read_word | active/raw_mem/previous_tick/divider |
| READ_FORMAT=12 | 只用捕获word检查格式/顺序，寄存key/is_on及5*tick | active及动态lifetime判断 |
| LIFE_LOOKUP=13 | 2048位active与9位on-index查表结果进独立寄存器 | active/raw_mem/divider |
| LIFE_CHECK=14 | 用寄存结果拒绝重复ON/无配对OFF | 所有提交副作用 |
| READ_COMMIT=15 | 捕获word写缓存，更新active/count/previous_tick，初始化divider | 只有此态可做本条提交 |
| PREP_DIV=11 | 原27步整数除法与QR/end配对 | 算法/位宽/120frame lead保持 |

由此RAM数据只到read_word；格式检查、动态lifetime mux与全局提交CE有寄存边界。保持静态逐bit CE写active的实现，避免恢复bit hold-Q mux。每条READ在进入原divider前增加4个core周期（40MHz下100ns），仅增加START准备时间，不改运行时整数时基、96768音频lead ticks或120frame视觉lead。

STOP/CLEAR在全部新态command_ready，同沿command_fire先于状态机；active_write也显式被!command_fire抑制。每级均先identity_ok再修改；PREP_DIV全部更新移至identity成功分支，CHECK和ANCHOR新增identity优先检查，避免最后一条准备后identity变化仍给START成功。STOP音频释放、flush/lease、RUN下背压保持和epoch逻辑保留。

read_word仅READ_WAIT可重写，后续rd_event变化不会污染格式或提交。内部RAM仍不清零，以有效状态和新load覆盖保护。准备中止后通过原STOP清理，再次START从index0重建。

## 验证与交接

新RTL自检范围、正负结果、冻结输入、命令/exit和失败历史见 `docs/TASK3_SETUP_TEST*` 与 `evidence/task3_setup_tests*/`。RUN_02全PASS，当前源码与冻结输入逐字节一致，已生成 `docs/TASK3_SETUP_SOURCE_READY.json`。实际计数：56完成回执、18负例、8新阶段STOP/CLEAR、4复位、22身份变化、512QR和5632ceil；512条准备16928core周期。RUN_01只有新TB声明顺序编译失败，保留原件；修正TB后通过，生产RTL未返改。

静态自审本次精确diff未发现具体阻断，确认新态抢占/identity优先、READ稳定锁存、lifetime寄存边界和QR/on-index配对；没有运行EDA，不凭RTL结构推定Setup余量。独立子智能体仅完成同范围静态复查与新RTL自检，不启用项目审核员/预审员制度。

总控下一步：以SOURCE_READY精确SHA冻结源，Task4做真实top/48k/完整光栅与2.016s lead回归；新商业版Gowin综合/PnR/STA核实际最长路径及全部Setup/Hold/Recovery/Removal/Pulse和原CDC约束。达标后提供新FS并停止修改；若仍不达标保留报告/FS，依据新瓶颈再授权最小优化。本岗未生成或放行码流。
