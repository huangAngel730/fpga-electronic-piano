# Payload61 最小内部布局修复

WAVE12原生完整构建exit0，Setup+1.014ns，Hold仅剩1个端点-0.043ns。
实际路径为scheduler held_payload_61_s0→score_mailbox payload_hold_61_s0，
同为core_clk上升沿；数据C2Q0.130ns、net0.615ns、clock skew+0.026ns。
原0.750ns uncertainty和库hold0.012ns保留。

仅新增两个内部FF的INS_LOC：源保持WAVE12实际站点R67C165[2][B]，
捕获FF从自动布局的R41C149[1][A]移到R49C55[3][A]。
目标站点合法性来自WAVE12实际pcm_right_19_s0的Q/CLK路径；这不宣称
该站点原先空闲。未固定对象由新一轮布局器重新分配，必须通过新全局STA。
原DVI释放FF位置、所有外部IO、RTL、时钟及频率均保持。

SDC只追加该精确路径的setup/hold诊断报告，命令依据本机官方
SUG940-2.0.5E Example5.38。所有create/set约束和原全局报告原字义保留。
不是改变uncertainty、false path、max/min要求，也不是接线修改。

新review_payload_placement.py须核同对WAVE12仅两项编译输入变更，
精确两条INS_LOC、所有旧CST命令、SDC全部要求及原报告保持，并检查实际
两站点、非空精确路径和新完整Setup>0.500ns及其它全部STA通过。
功能回归仍绑定完全相同R03四份RTL，布局约束不是功能仿真的输入。
