# Task4：真实 top／音频／波形系统接缝只读核查

初始授权为只读辅助；随后总控追加只写独立 tb_wave_audio_seam.sv 的实现授权。未运行 ModelSim、EDA、旧测试或设备。本文是新系统测试设计依据和未执行 TB 的交接，不是新测试通过记录。候选 Task2/Task3 并发实现，最终执行前须冻结交接后的源码 SHA。

## 结论与当前接口门槛

采用“真实 pro_audio_minimal_top + 独立同版真实 m3_pro_audio_core_r10”双实例 miter 可验证显示观察／页切换／观察队列满不会反向改变音频；两核心必须使用相同 MIDI、keys、reset 和 top 实际产生的 score_event_valid/data。reference 的 score ready 应独立输出并逐周期对照 top ready，不能反过来驱动生产 top。

自然完整2.016秒 lead 可以承受：只读旧原件 PHYSICAL_FULL_R10_01/receipt.json，vsim 实际121.656秒，R09为122.797秒，R04为124.812秒；最早 FULL_01 为76.485秒。新双真实核心加 PCM 波形支路耗时可能增加，以上只用于预算，不是新候选已通过或可靠 ETA。建议保留一次新物理 top 全链自然 lead；短 seam 用真实 core + display 端口注入曲谱事件，分别声明覆盖边界，不伪造 scheduler tick/T0。

最初读取的 core 快照没有 extension_page_select 输出，obs_tx_left/right 及 i2s_tx.pcm_left/right 还是 buffered_left/right。追加 TB 授权后的最新只读核查已确认 Task2 加入 extension_page_select/extension_pixel_clk/extension_serial_clk；obs_tx 与实际 I2S 均接 volume_left/right，Q1.12 音量路径已落地。下面来源 SHA 表保留最初独立快照身份；主窗执行时须重新冻结最终树，不能将旧 SHA 当最新候选。

## 编译源闭包和测试边界

当前目录 P 指候选根下 project。推荐新 runner 的源收集顺序：

```python
src = P / 'src'
packages = [src/'audio_defs_pkg.sv', src/'sustain_control_contract_pkg.sv']
sources = packages + sorted(p for p in src.rglob('*.sv') if p not in packages)
sources += [P/'tb/extension_integration/clock_model.sv',
            P/'tb/extension_integration/gw5a_lut1_model.sv',
            P/'tb/extension_visual/display/dvi_sim_boundary.sv',
            NEW_SYSTEM_TB]
# vlog -sv -mfcu +incdir+<P/include> <sources ...>
```

这是候选全部生产 SV 闭包，包含未展开旧分支，避免遗漏真实 m1td 音频/控制/adapter/sidecar。已读取快照共有76个 SV；数量不是最终门禁，新 extension_controls 文件发布后应重新收集。具体新增关键组为 extension_transfer/**、extension_visual/**、extension_waveform/{pcm_frame_observer,pcm_waveform_observer_bridge,pcm_waveform_candidate,m3_pro_fixed_left_waveform}.sv 及 Task2 extension_controls/**。packages 必须先于引用它们的模块。

仿真只用频率正确的 TMDS_PLL clock_model（125/25/40MHz），不要同时编译 project/ip/TMDS_PLL*.v 与 fixture；它证明逻辑时钟关系，不签物理 PLL 相位。gw5a_lut1_model 提供真实 top 中 R09 identity LUT1 的精确逻辑，包含其 MUX2/mux2 依赖。dvi_sim_boundary 定义 Pro_DVI_TX_Top，仅替代加密 TMDS PHY，RGB/raster/page/CDC/PCM 支路保持真实；不要再编译真实 DVI_TX_Top/rgb2dvi 引入同名模块。观察点应在 u_dvi 的 RGB/hs/vs/de 输入之前，不能用 stub 的 TMDS 高位映射当完整画面或真实序列器验证。

运行目录保留 project/rom 的完整副本，并将 project/sine_wavetable.hex、triangle_wavetable.hex 复制到运行目录同名位置。m1td_timbre_oscillator 使用根别名；pitch/mod 使用 rom/oct_ratio_q16.mem、sub_ratio_q16.mem、lfo_sine_q15.mem；ADSR 使用 rom/velocity_gain_rom.mem。不要改成假 ROM 或生成正弦替代，输入原件也要逐件 SHA。copy ROM 是新 run 准备，不需执行旧 runner。

旧 basic/project/extension_tools/run_checks.py 可只读参考源排序、ROM 布局和 stderr/exit 捕获，不能直接在候选运行：它的 ROOT/输出准入/旧 baseline 路径属于 basic 原工程，且旧 physical 分支尚未收集 extension_waveform。它的 PASS token 也不覆盖 CC7/25/26/27。新 runner 必须使用候选根，新增独立 TB/断言/完成 token，并检查 Error/Fatal + token + exit，而非只看 exit0。候选 tools/register_candidate.py 会写 gprj/rebuild，tools/build_candidate.py 会启动 EDA；本轮只读辅助没有运行它们。

## 真实 PCM 采用点和 PRE_NBA 采样

层次以 physical top 实例名 dut 为准：

| 边界 | 真实观测点 | 用途 |
| --- | --- | --- |
| core 时轴/复位 | dut.core_clk；dut.core_rst_n；dut.u_audio.obs_rst_n | audio 域正沿；不要用像素帧当音频采用 |
| 最终事件接受 | dut.accepted_event_valid && dut.accepted_event_ready；dut.accepted_event_data | source0 MIDI、source1 keys、source14 自动；不是源请求 valid |
| 采用资格 | dut.u_audio.obs_tx_sample_valid，与 dut.u_audio.u_i2s_tx.frame_tick 同拍 | 真实发送器 valid=1 的完整 stereo frame 采用点 |
| 被采用 PCM24 | dut.u_audio.u_i2s_tx.pcm_left/right；修订后的 dut.adopted_left/right | 音量之后、24→16 量化之前；必须逐点相等 |
| waveform core 入参 | dut.u_score_visual.u_display.u_waveform.u_bridge.u_observer.frame_load/play_left/play_right | 应等于上两行，同域直连 |
| 已寄存观察值 | 上述 u_observer.observed_valid/seq/left/right | 比采用边沿晚一拍可见，序号连续 |
| pixel 接收样点 | dut.u_score_visual.u_display.u_waveform.u_bridge.sample_valid/seq/left/right | 与 core 日志按 seq 比对；允许有明确 drop/gap，不允许改值 |
| 计算/commit（辅助） | dut.u_audio.obs_req_*、obs_result_*、obs_commit_* | 不可冒充 TX 采用样本 |
| 标签/错误 | dut.u_audio.obs_tx_frame_id/req_id/hold/startup_zero、obs_metadata_error、audio_underrun | 排除错标签、漏帧、假连续静音 |

`i2s_tx` 在 core 上升沿 frame_start && valid 时以旧 PCM 输入计算 sample_left/right 的 NBA 更新；frame buffer 也会在同沿移动 pending/held。因此系统 scoreboard 必须在该正沿 PRE_NBA 保存 PCM24 与 frame/seq，不能先 #1 再读 buffered/volume/data 当作本次采用值。pcm_frame_observer 也是同沿寄存，正沿 E 采用的数据在 E 的 NBA 后成为 observed_*，E+1 PRE_NBA 才由 bridge 入队。对照时保存 expected(E)，再对 E 后的 observed(E) 或 E+1 pre 值，不把两次不同边沿误配。

应新增独立 PT8211 LSBJ 解码器，在外部 i2s_bclk 上升沿、每个32-bit半帧的最后16个采样沿重建字；WS低=右、高=左。对照发送器真实采用 PCM24 经 `(signed25(pcm)+128) >>> 8` 后限幅至[-32768,32767]，避免把 sample/shift DUT 寄存器直接当黄金。波形显示应保留 PCM24，不能拿量化后的 PCM16 反推。

## MIDI／曲谱注入

1. 新 physical top TB 把 midi_rx 从旧 TB 的常量1改成驱动变量；8N1、LSB first，40MHz core 下31250 baud 每 bit1280个 core 周期。示例 MIDI 通道0：NoteOn `90 45 64`；NoteOff `80 45 00`；CC7 `B0 07 vv`；CC25 `B0 19 7F` 后 `19 00` rearm；CC26/27 分别为 `1A/1B`。不要把十进制25/26/27误写成0x25/0x26/0x27。CC1=`01`，sustain=`40`，Program Change=`C0 00/01`，pitch=`E0 lsb msb`。
2. 必须计数真实 parser/MIDI FIFO 出口、human common FIFO 和最终 accepted handshakes；旁路直接 force parsed_event/shared_event 不覆盖 MIDI 解析。running status 场景可在同一 B0 下连续发 control/value，穿插 F8；pressed127保持再次127不能重复触发，低于64 rearm 后再127应触发；另用通道15检查每通道按钮状态。实际 Task2 侧带/accepted control 输出层次以交接后的源为准，当前快照尚无该实现，不捏造名称。
3. physical top 曲谱输入应走 ble_uart_rx 的原 v2 BEGIN/DATA/COMMIT→READ_BEGIN→逐条 READ→READ_END→START。旧 tb_pro_extension 的 framing/CRC/response monitor 和 demo byte 布局可以作为新 TB 实现依据，但新用例必须自己断言 CC/page/PCM 共存。COMMIT 后不得自动 START；完整回读和同一 generation 校验后才 START。默认transport115200 baud，原 TB 用347 core周期/bit；保持真实值时 ACK monitor 同参数。
4. 较短 core+display seam 可在 m3_pro_audio_core_r10 已有 score_event_valid/data 端口驱动真实 source14 performance_event_t，持有至 score_event_ready，然后把最终 accepted_valid && ready 送真实 display，并把同一个发送器采用 PCM 输入送 observer。这样保留 audio adapter→arbiter→router→四声部/ADSR/DDS/mix/delay/frame buffer→I2S 全链；但必须标成端口 seam，不冒充 raw RAM/scheduler/真实2.016秒 lead 验证。
5. source14 ALL_NOTES_OFF 经过 u_score_audio_adapter 转成各通道的 scoped NoteOff；最终 shared router 不能收到 source14 的 GLOBAL panic。记录 occupied/releasing/source/channel/note，STOP 后真人 held voice 必须仍存在。演奏共存用不同 note/source 身份并控制总复音<=4，避免正常抢占被误判为页切换影响音频。

## 可加速和不可加速的内容

| 调整 | 是否建议 | 边界 |
| --- | --- | --- |
| u_audio.DEBOUNCE_CNT=2、DEBOUNCE_CLK_HZ=1000 | 可，用 testbench defparam 或直接 core 参数 | 只缩短机械按键去抖；保留同步器、converter/FIFO和真实音频 |
| u_audio.u_midi_input.MIDI_BAUD=1_000_000（bit40core周期） | 可，独立快速 seam fixture | 保留UART/同步器/parser；TB sender同步改速率；仍需一组31250真实速率，不改parser CLK_HZ或1kHz CC1策略 |
| u_score_transport.BAUD=1_000_000，response monitor 同值 | 可，上传/read握手加速 fixture | 保留原 framing/CRC/RAM/control，不能当115200物理链验证 |
| SOURCE_MODE=1／假PCM／替换音频core | 不可 | 会绕过实际4voice、控制/score共存与TX观察 |
| 改 CLK_HZ／BCLK_PHASE_STEP／sample_tick 或强制 t0/global_tick/anchor | 不可用于本系统证据 | 破坏真实48k、5/4032、120frame lead 和采用口径 |
| 缩小 H800/V525／pixel clock／120frame lead | 不可用于自然 full lead | 会改变 real anchor 及实际页窗口；短 seam 分开声明 |
| 改波形窗口／喂人工sample_valid | 不可用于真实观察共存证明 | 当前 waveform无窗口参数，固定2048样本=512列×4；应自然等待 |
| 不记录全层次 WLF、只记关键日志 | 建议 | 保留必需正负证据；run -all 不 dump 全design可减I/O，不能因无WLF省略断言 |

固定2048采用样本约42.667ms，下一自然frame_start发布，初次 trace 通常需约43..60ms外加复位启动；不能在几毫秒后因 trace_valid=0就判错。短测试至少等完整窗口及发布边界。PCM min/max 每4个左声道 PCM24先比较，再取有符号高8位；右声道不平均进左波形。

## 新 miter 与共存断言建议

首先建立两真实音频核心同输入 miter：比较最终 event_valid/ready/data、I2S引脚、PRE_NBA TX PCM及 frame-id 连续性、request/commit/underrun。在 top vs reference 模式，reference 接 top 的原始 score offer（adapter之前），自行输出 ready 并比较两者，不要接已 merge 的最终 event 再重复经过adapter。两实例 reset/PLL fixture锁定时刻必须一致。页控制的完整 MIDI 流应同时送两core；这证明“显示观察支路”没有反馈音频，不单独证明 CC7/CC25 算法正确。

测试序列可先按 CC7=127 建立真人MIDI held note 与独立 source14 音符同时 nonzero；切 B3→自然帧界 page1→B2→page0，并在像素中线再次切页。期间连续记录波形输入每个采用样本、原human/score事件顺序和slot身份，不只比较少数非零值。页0默认 combined，B3幂等选wave，B2幂等返回combined，不能自动toggle。

CC7/CC25 本来要改变声音，不能把所有控制阶段都断言 PCM不变：CC7=0 应在其规定采用边沿后全 stereo为0，CC7=127应恢复 unity，signed正负都应出现且符合Task2实际 gain公式；负满幅等边界算法属于Task2单元证明，系统从真实采用值核绑定。CC25/PC=0/1 的原 router `program_timbre[{source,channel}]` 表按 source/channel 保存，slot_timbre 和 oscillator timbre 在新 NoteOn 锁存；不要要求已 held 的旧voice立即换音色，也不要不经定义就要求source0控制改变source14已有voice。切换后安排新 NoteOn并核实际slot_timbre、再确认非零PCM/频谱或时域变化。CC26/27不得误改gain、timbre、sustain、pitch/mod或释放slot。

暂停 top 的像素时钟作为观察堵塞压力时，必须只动 test clock fixture 的 pixel输出，不动共享lock/core/serial或PCM/frame tick；它是注入的观察时钟故障，非正常板上时钟策略。32深队列加1个mailbox约33个样本后开始积压，停像素1..2ms足以出现 observation_drop_count。比较 top/reference真实音频逐周期不变，采用frame持续、human声部仍held。暂停期间 pixel reset不下降，不能假定window/gap计数即时更新；恢复后按seq检查drop/gap和继续发布。

暂停要放在已完成 START/anchor锁定且现有score预览已入队之后，或单独core+display seam；若恰好暂停于未绑定anchor/未来score admission被堵时，scheduler可能按既有可见deadline/anchor条件报错并清理source14，不能把这种受控曲谱中止当作“波形observer回压音频”或声称曲谱仍全程不中断。完整共存测试需另核source14实际ON/OFF计数和PCM，不只依赖两core都接同一失效score输入而相等。

隐藏页时 observer、score/live tracker都必须继续运行；返回页0后 frame/current_frame、falling ID与held human key不重启。system层至少记录 u_display.u_waveform.u_bridge 的 drop/queue/seq；u_display.u_waveform.u_waveform 的 sample_index/front_bank/pending/trace_valid；u_display 的 page_latched/render_page/page_d2 与 de/hs/vs/RGB tokens。对 raw pixel边沿N，wave RGB/mask和scene/control/page在N+2 NBA后对应同一个N坐标，DVI在下一edge采用；blank黑优先，desync在active像素最后覆盖。页CDC frame_start附近一拍分歧不要用未同步core page直接判错，应以page_sync/page_for_pixel和最终token对齐。

## 本轮边界与来源

实际仅执行文件读取、rg检索、Python只读列源/哈希/旧receipt提取（均退出0；若末尾目录尚未建立，PowerShell只读探测退出1已明确是并行文件缺件，不是仿真失败）。未运行任何ModelSim或EDA命令。生产源码仍由Task2/Task3/总控修改，本文不代签其交付。最终主窗新runner须记录实际命令/时间/exit、输入快照SHA、预期PASS marker及所有失败原件，不把本文或旧FULL结果当作本次通过。

### 文档收口时只读来源 SHA-256

以下是各文件独立读取的当前字节身份；并行实现未冻结，不表示同一已签测试树。

| 候选相对路径 | SHA-256 |
| --- | --- |
| docs/TASK_AND_INTERFACE.md | `ae64732861095088a7b9ac3a0382a2eeb082aebec2eabcdc89b9668d603b3a59` |
| project/src/pro_audio_minimal_top.sv | `e018dbbde4b0a52b2ab9c83381234178863542abe52d0525f0c1b40b2ada2346` |
| project/src/m3_pro_audio_core_r10.sv | `3138b2787118e61b5c4ac9f86be774458c515923eed90c7c822b34b06430129e` |
| project/src/midi_input.sv | `458a7932de69ed8bb4b74c53555373194b9532c6975565907fa44c70e99ec3a6` |
| project/src/midi_event_parser.sv | `ec867a526424895752b4da70c29dc7b29c5182c23f85afaecba22706a866d6d9` |
| project/src/i2s_tx.sv | `6c703e31064e5943df4e310b3baddd8935362a1c028828d8e11f8f3c016267ad` |
| project/src/m2_r06_tx_identity_sidecar.sv | `40fd5145a9d80bae36ead96b8e1144be84acdf3669aa5c47a26fcef305a54d1e` |
| project/src/pro_score_audio_adapter.sv | `8b3df181d0bad65df5e2028bcae22ad16b74cf0739fa3cdce5f00b62f62649e0` |
| project/src/extension_visual/pro_score_visual.sv | `b6b299cc1a35d9ec7c213e956a75280cd8406cad1606fdb333b4938e7d57a8d0` |
| project/src/extension_visual/display/pro_score_display.sv | `d8a47eda46aa74d5bab56c7b26ed24335df882dbcc2d4c31ff5d47da70050263` |
| project/src/extension_waveform/pcm_frame_observer.sv | `f0f755558fbd40a103c1d7d6c73c102eb4f83bf54cc41b09a78fd65609fe13a8` |
| project/src/extension_waveform/pcm_waveform_observer_bridge.sv | `0b937e2d23dc090b5094d789edba5216c34a96eb84eb96d002cdab8aa0c45cfb` |
| project/src/extension_waveform/pcm_waveform_candidate.sv | `052c4e79095152410bdd42e4d5c3cd47a00b91ad7bdf848a3c0914ab9aec0160` |
| project/src/extension_waveform/m3_pro_fixed_left_waveform.sv | `6034d06fa255f1f4f84c13e632fe0d070a9850aa5e49a8cd9c48aa611c6069ca` |
| project/tb/extension_integration/tb_pro_extension.sv | `caab78bfd9d9b34e0826326b7a7d1c87715f5d58271974b26192bff907d89c13` |
| project/tb/extension_integration/tb_audio_extension.sv | `cea3d137dee05ca8d37f78de4f28d5e50fc211d64e81cb17d3595b176e4d659d` |
| project/tb/extension_integration/clock_model.sv | `3c02dc4f688ab8bc73855a69db90f19c2aa81ed4acf4eb2dcbd5bf405474c1c8` |
| project/tb/extension_integration/gw5a_lut1_model.sv | `baee0e96fb715e08ba9f20907b8911d0268a3df72bf63058789720a7d3278ded` |
| project/tb/extension_visual/display/dvi_sim_boundary.sv | `e9a2737ef0414d6db33d2a8c036ef20c5636904cd0b9d17c09c54e2230ecfa46` |

## 追加独占 TB 交接（尚未编译／运行）

新增 `project/tb/wave_system/tb_wave_audio_seam.sv`，顶层 `tb_wave_audio_seam`。仅实例化两份当前实际 `m3_pro_audio_core_r10` 及实际 `m3_pro_fixed_left_waveform`；使用主窗提供的 `TMDS_PLL` 40/25/125MHz 仿真 fixture。两 core 共享物理50MHz输入、复位、keys、真实31250baud MIDI 8N1和同一source14公共端口offer，各自输出ready并逐周期比较。无历史baseline、无PCM替身、无内部audio/PCM/score force。波形分支只接dut，reference无display反馈。只停独立fixture像素支路2ms，不停任何实际音频时钟。

TB 采用下列新断言：

- PRE_NBA逐采用帧保存实际TX PCM24、0起始ordinal；同沿NBA后对实际pcm_frame_observer，pixel接收再按ordinal对golden；跨队列丢弃允许显式gap，拒绝重复/逆序/改值。
- 每次采用对实际buffered PCM和独立longint signed量化oracle核Q1.12音量；CC7=127/0/64/127的实际接受值分别4095/0/2064/4095。PT8211外部BCK上升沿独立重建32bit半帧最后16位，与实际采用PCM24舍入/限幅值逐字比较。
- 全程比较两core event/ready/page/采用PCM、I2S引脚/PA、commit/id/PCM/underrun；要求无underrun/metadata/overflow/MIDI framing/parser/FIFO错误。
- 真人source0 MIDI69与曲谱source14/channel3/note60持续真实并发；CC25重复高不重触发、低释放后重按，再以新MIDI72核实际slot_timbre=1且held source14仍为0。CC26/27页面幂等切换且不产生volume/timbre/note事件。
- 停像素2ms必须32项queue满、实际drop增加、至少90个音频采用继续、pixel接收停住；恢复须有gap并继续真实2048样本窗口自然发布。waveform_enable固定1，以覆盖隐藏页仍收样；实际display页面CDC/RGB复用仍由主窗physical TB覆盖。
- scoped source14 ALL_OFF后两真人held声部保持；display-only reset不重置音频ordinal；全audio reset清ordinal/恢复unity和page0，再真实MIDI/score发声并观察恢复。

99ms虚拟时间watchdog；未加速48k、window、raster或调度器。自然完整raw/scheduler/120frame lead不在此TB覆盖范围。编译源与ROM闭包沿上文；仅TB加本文件，无runner改动。

成功必须出现以下新标志并无 Error/Fatal：`PASS TASK4_OBSERVER_STALL`、`PASS TASK4_REAL_MIDI_MASTER_VOLUME`、`PASS TASK4_REAL_CORE_PCM_I2S_MITER`、`PASS TASK4_SCOPED_SCORE_STOP`、`PASS TASK4_AUDIO_DISPLAY_RESET_RECOVERY`、最终 `TASK4_AUDIO_SEAM_COMPLETE`。这些是待主窗实际执行的期望输出，当前不宣称PASS。

TB SHA-256：`fd423efd10ee5d8049e87c99711c754f471ebeafc89da97c4dcdebe6f5caedc5`。实际仅文件读取/rg/hash与apply_patch；未执行编译。一次只读命令遇自动审批超时，按工具允许重试一次后成功；另两次只读探测不存在的历史猜测路径退出1，已改为真实源码层次，未触发仿真或EDA。所有写入仅此文档与获追加授权的TB。
