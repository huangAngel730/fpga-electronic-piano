# Pro waveform integration R01 — active user instruction 2026-10-22

## Effective addendum: user's Setup margin requirement

### Effective physical refinement after GOWIN_WAVE_04

#### WAVE05 follow-up R02

WAVE05 Setup+1.478ns, all original four short cones and both strict min1 now
pass; only remaining native Hold is read_word_8_s0 -> raw_mem DI8, -0.057ns.
This is the same raw tick write-data class as previous bit24. Task3 may extend
the two-stage read-word identity buffer across all32 tick bits, preserving
upper32 event fields, cycles, arithmetic and all other buffers/constraints.
Expected read-word LUT count64 instead2, total added82 instead20. Use fresh
TASK3_HOLD_R02_SOURCE_READY.json, fresh hold_r02/test evidence, retaining R01
ready/source/tests and WAVE05 reports/FS. Task4 must use new hold_r02 tools,
TB/evidence/docs on exact new SHA with audio/directed/full natural lead; old
hold R01 groups stay immutable. No clock/constraint changes or peer EDA/device.

WAVE04 pipeline passed Setup +1.529ns (unchanged clocks), but four Hold
endpoints fail. Preserve WAVE04 reports/FS and all previous tests. Root now
authorizes Task3 a minimal combinational LUT1 identity-buffer refinement in
these candidate-only files: scheduler/pro_score_scheduler.sv,
display/pro_score_display.sv, and project/src/m1td_voice_gain_q15_candidate.sv.
No cycle/latency, numerical, frequency, clock/reset or constraint change.
Use existing preserved LUT1 INIT2 convention on demonstrated exact short cones:
score payload bit14 to mailbox (strict min1 currently -0.369ns); raw READ
bit24 to raw_mem DI8 (-0.008ns); fatal_live_pixel to live state (-0.069ns);
envelope bit4 to gain DSP B4 (-0.013ns). Keep successful exact audio min1.
Produce separate TASK3_HOLD_SOURCE_READY.json and hold evidence; retain all
SETUP_SOURCE_READY and prior snapshots unchanged. Add relevant module checks
and no-cycle identity proof; actual preserved LUT count checked by root EDA.
Task4 owns fresh tools/task4_hold_*, tb/hold_system, evidence/task4_hold_* and
docs/TASK4_HOLD_* for exact final sources, with full natural lead regression
and real PCM reference. Prior setup groups are immutable. No EDA/device by peers.

After GOWIN_WAVE_03 the user explicitly requires final Setup margin **>0.500ns**,
not equal, while all other timing checks must pass. Preserve all previous
below-threshold reports/bitstreams. Optimize using registers/pipelines/resources;
do not change/divide clocks. Once passing and final evidence is sealed, provide
the bitstream path and stop further edits. This supersedes the prior nonnegative
Setup acceptance. Root still coordinates and no device operations are authorized.

New exclusive refinement work after original peer closure:
- Task3 owns only `project/src/extension_visual/scheduler/pro_score_scheduler.sv`,
  `project/tb/setup_pipeline/**`, `tools/task3_setup_*`,
  `evidence/task3_setup_*/**`, `docs/TASK3_SETUP_*`.
  Pipeline raw READ capture/format/order/lifetime validation and commit so the
  RAM→dynamic2048-bit active lookup→malformed→global active/quotient CE path is
  split. Preserve event/READ/lease/score-epoch/START-lead semantics; allow STOP
  and CLEAR in every new prepare state, identity-check before any mutation,
  reject malformed and duplicate/unpaired note lifetime. Provide new actual RTL
  tests for positive/negative/abort/reset paths and packet-stable capture. No
  EDA or edits to other owners. Do not lower verification/clock requirements.
- Task4 owns additional `project/tb/setup_system/**`, `tools/task4_setup_*`,
  `evidence/task4_setup_*/**`, `docs/TASK4_SETUP_*`; read-only source review.
  After Task3 source-ready, run meaningful full real-top/MIDI/score/wave/page
  regression against its exact bytes (original clock/raster/2.016sec lead).
  Old failures and all original passing evidence remain immutable.
- Root owns SD C physical fixes, project/Tcl, implementation and STA. No root
  frequency/uncertainty relaxation, broad false paths, or ungrounded repeat.

Actual GOWIN_WAVE_02/03 Setup critical path: transport byte_lanes[6] BSRAM
DOB[4] -> scheduler active_* / div_quotient CE, +0.011ns at25ns/core. Original
score payload bit14 hold repaired in03 with stricter min1ns, actual+0.147ns.
03 remaining natural hold-0.002ns is separate slot_velocity38→lane3 piano
attack_samples_left6. Root preserves both failing FS and handles exact min rule.

Coordinator 拓展任务1. User authorizes implementation, self/subagent review,
ModelSim and commercial Gowin V1.9.12.04 synthesis/PnR/STA. No device operation.
Candidate root is this folder; baseline and sealed original R10 are read-only.
No Git publishing: this is an independent backup project outside the team repo.

## Actual image and latest requested mapping

K1 CC7 master volume; B1 CC25 next implemented timbre; B2 CC26 live rising
notes page; B3 CC27 waveform page. B4 CC28 reserved for spectrum; B5 CC29 and
B6 CC30 unused. Pitch bend retained; modulation CC1 retained; sustain CC64
retained. No FFT here. Incoming MIDI channel follows existing parser policy
(all channels); button action on first value >=64, rearm on value <64 per
channel/button. Recommend momentary 127/0 assignment in keyboard configuration.
Existing Program Change 0/1 remains operational. Preserve 64-bit event ABI.
Default page is existing combined score/live page (page 0); waveform is page 1.
B2 returns to that page; no B3 toggle. Hidden score/live tracking and score
playback continue. Display faults and pause must never gate audio.

## Exclusive write sets

Task2: project/src/midi_event_parser.sv, midi_input.sv,
m3_pro_audio_core_r10.sv; project/src/extension_controls/**;
project/tb/wave_controls/**; tools/task2_*; evidence/task2_*/**; docs/TASK2_*.
Implement controls and expose on core:
`output wire [1:0] extension_page_select` (core domain stable state 0/1).
Implement CC7 on actual audio PCM path (unity reset/full-scale, mute at zero,
signed symmetric arithmetic; accepted controls preserve voice/score behavior).
CC25 rotates the implemented 0/1 timbres on button press; retain existing PC.
Keep PCM observation exactly equal to transmitter-adopted samples after volume.
Task2 must supply complete self-checking RTL tests including MIDI framing,
running status, realtime, repeated presses, volume negative/full-scale/mute,
existing pitch/mod/sustain/PC preservation. No edits outside this set.

Task3: project/src/extension_waveform/**; existing candidate-only
project/src/extension_visual/pro_score_visual.sv and
project/src/extension_visual/display/pro_score_display.sv;
project/tb/wave_display/**; tools/task3_*; evidence/task3_*/**; docs/TASK3_*.
Add pro_score_visual inputs and forward to display:
`input wire [1:0] page_select` (core domain),
`input wire audio_frame_load`,
`input wire signed [23:0] play_left, play_right` (core-domain pre-NBA adopted).
Reuse verified repository PCM observer, waveform bridge/core/Pro wrapper;
copy them into extension_waveform, preserve source SHA notes and semantics.
Use local existing reset_sync/visual_mailbox_cdc if byte/semantic equivalent;
do not introduce module-name collisions. No upstream audio ready/gating.
Page CDC must be coherent, latched only at frame boundary; source stable page
state may use proper handshake/single-bit synchronization (only pages 0/1).
Preserve current negedge-pixel DVI reset, real Pro IP, scan, anchor and trackers.
Pixel pipeline must align waveform N+2 with RGB/de/hs/vs/page/desync tokens,
blank black, desync final override. Output uses existing DVI instance.
Tests cover real raster boundaries, page changes midline, reset, left-only
PCM minmax/axis, window publication and existing combined default page.

Task4: project/tb/wave_system/**; tools/task4_*; evidence/task4_*/**;
docs/TASK4_*. Read-only review of source changes outside your set. Establish
independent new system seam tests using candidate actual top/audio/PCM tap,
MIDI CC control and page switching with human sound/score chain active.
Coordinate only necessary API with coordinator, do not message peers.
No EDA/device. Report exact failures, commands, times, exits and source SHA.

Coordinator owns physical top wiring, gprj, root rebuild/options Tcl, constraints,
source registration, full build and STA, integration tests/hand-off.
Peers may use child agents inside their exclusive sets. Messages only when
blocked or one consolidated result; user explicitly authorizes root dispatch.
Old budget/START restrictions are not reused; no old consumed runner replay.
All failures preserved under fresh evidence directories. Do not modify original
R10, Android deliverables, basic/baseline, repository sources or shared status.
