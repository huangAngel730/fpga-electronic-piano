# Task3 Hold R04：用户第五版后备

本轮按总控转达的用户明确后备授权执行：WAVE05准确两源为基线，bank逐字节恢复；scheduler仅修W05唯一read_word8→raw_mem DI8负Hold，其余沿W05结构。生产写集仅scheduler和m1td_polyphonic_envelope_bank。显示/gain不动，另外冻结为完整四源清单。before按W13输入四源逐字节核对后保存BEFORE_W13，W05实际两源保存BASELINE_W05，R03及旧原件绝不改写。

## 有据最小改动

原WAVE05 JSON Setup+1.478ns/Hold-0.057ns，原.tr唯一负路径为read_word8/Q→raw_mem_raw_mem_0_0_s/DI8；原.vg低32 RAM实际DI={read_word[31:25],bit24_chain[2],read_word[23:0]}，证明bit8原本直入DI8。W12仅payload61 Hold仍负；W13只CST拆FF实验Setup余量不足且三端点Hold失败。旧报告/FS及精确SHA索引见BASELINE_TIMING_AND_NETLIST.json。

R04新 `read_word8_hold_chain[0..4]` 以4个syn_keep/syn_dont_touch LUT1 INIT2串联，末级进入真正RAM写字bit8；拼接 `{read_word[63:25],read_word_hold_chain[2],read_word[23:9],read_word8_hold_chain[4],read_word[7:0]}`，39+1+15+1+8=64bit。原bit24两级和score14八级保持。较W05只多4个LUT，本岗相关Hold组共24（score8+bit24两级+bit8四级+display2+gain8），不声称全工程LUT总量。

去除新增块并还原原一行RAM拼接后，scheduler文本与W05原件完全相同；bank字节与W05完全相同。没有R03全64字段缓冲或bank512链；所有START/STOP/CLEAR/identity、时基/QR/120frame/96768tick、观察、音频数学/显示、周期/复位沿W05原义。不添加寄存器或周期。

本岗不改CST/SDC/options/GUI。总控负责恢复W05相应准确字节、原频率/0.75uncertainty/两条min1，并移除后期实验项；本两源复原不等于整棵工程/约束已恢复为W05，最终闭包按本轮实际源冻结。

## 新软件验证及交接

新hold_r04测试、runner、run和证据独立，覆盖64bit真实RAM写字0/1/X及bit24/bit8、反事实真实末级RAM消费、合法tick bit8翻转/QR与端点配对；调度器适用56等回归；bank恢复SHA精确核同与真实W13-before事务miter；显示适用回归和四源实际SV/include/ROM闭包。失败全保留，首次缺陷定位后再修。不重复无关已签gain组。

RUN_01五组全PASS、无本轮失败，当前四源及95文件SV/include/ROM闭包与冻结字节一致，已生成 TASK3_HOLD_R04_SOURCE_READY.json。64位RAM写词2372恒等检查、bit8末级4次实际消费者及4合法tick QR；scheduler56等全部适用回归、真实bank153674周期miter/4955捕获/4950结果/7取消/真实retire和复用、display1276726像素miter通过。旧R01–R03测试17份原件及旧ready收据哈希再次核未变。其内列W13 before/after、W05基线SHA、READY、receipt/命令/退出码/时间/病例/失败和未签项。这里只签模块软件仿真，不跑EDA/设备/Git。Setup仍必须严格>0.500ns，全部其它时序/两条原min1必须通过；尚未新PnR不得交付放行FS。最终通过后由总控给码流并停止修改。
