# Task4 HOLD R04 全部失败与实际边界

本记录仅覆盖本轮 R04，不复用或掩盖 R01/R02/R03 的失败史。

## 准备阶段非零命令

1. 父窗依赖脚本首执行 exit1（原工具 chunk `64e8b7`）：直接比较模块回执与 READY 的路径键，因反斜杠/正斜杠差异触发 AssertionError。四份 SHA 实际完全相同。保存修前脚本和退出/原因于 `evidence/task4_hold_r04_dependency/PREPARATION_FAILURE_001/`；工具当时仅返回合并 output，未独立捕获 stdout/stderr，所存输出为明确标注的转录，不冒称原始双流。修正仅做 Path.as_posix 归一化，后续 CHECK_001 全部通过。没有执行仿真或修改生产源。

2. 子代理只读审查的证据生成首次 exit1：错误假定 Task3 BASELINE_W05 含 display/gain，实际仅含 scheduler/bank，FileNotFoundError。改用真实 GOWIN_WAVE_05/inputs 绑定全部四源；`evidence/task4_hold_r04_review/READ_001/PREPARATION_FAILURE_001.json` 与 `.stderr.raw` 保留原因及错误原件。未修改生产源，非产品失败。

初始新测试准备 PREPARATION_RECEIPT.json 内六条静态命令均 exit0；后续追加测试修正静态检查记录。上述父窗/审查事件另列，不因该收据全零而漏记。

## 新增测试首失败及修正

3. 新系统 RUN_001 directed 实际失败（318817513500ps，198.563s）：新增合法边界 START 已完成、previous_tick 正确保留512，测试误从 RUN 调用准备短状态 abort helper，触发 previous_tick==0 断言。vsim exit0 但 fatal_or_error_seen=true、完成标记缺失，runner 正确拒绝并外层 exit1。保留 RUN_001 完整源码快照、RESULT/stdout/stderr/transcript 与首失败。TEST_REVISION_001 只把新增边界清理换成真实 UART STOP，旧 prepare abort 断言完全保留，生产 RTL 未动；准备清单与脚本同步更新，修前原件及 SHA 在 `evidence/task4_hold_r04_dependency/TEST_REVISION_001/`。从新 RUN 重跑全部三模式，未复用中止组作为通过。

该 helper 的现有适用条件是 setup_directed 在首记录、首次 raw commit 前的状态12/13/14/15注入 STOP/CLEAR：此时 previous_tick/active_count/active 均为零，命令同拍不应修改它们。它不是 RUN 状态通用 STOP 断言。新增边界已完成4条合法记录并处于 RUN；STOP 进入 STOP_PENDING=10 时 previous_tick 仍为512符合原 RTL，不能要求清零。修正选择实际 UART STOP（exchange8），保留严格 ACK命令/identity/长度/CRC/error检查；随后重新 BEGIN/DATA/COMMIT/完整READ 成功，旧8项准备中止断言继续执行通过。未删断言或改 RTL 迎合测试。

## 新 ModelSim 执行

- `evidence/task4_hold_r04_system/RUN_001/receipt.json`：FAIL；首失败和所有原件保留。

各组 warning 原样保留；通过判据包含进程退出、日志错误及全部必需 marker，未以 exit0 单独判断。Task4 未执行 EDA、Git、设备或实物操作，不签物理时序或码流。
