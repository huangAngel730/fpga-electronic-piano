# Task4 三源 HOLD 修复真实系统回归交接

**R01执行快照PASS／已由R02接续：新audio/directed/full三组全部通过，精确diff静态自审未发现阻断。测试结束时输入未变，但最终seal前总控更新R02任务约定，因此本包仅按R01执行快照封存，不冒称当前树未变，也不作为R02准入。Task4仅签RTL仿真和只读自审；未运行EDA、设备或Git，不代签物理Hold、Setup、LUT数量或码流。**

本轮依据TASK_AND_INTERFACE.md的WAVE04 physical refinement，只写新project/tb/hold_system/**、tools/task4_hold_*、evidence/task4_hold_*/**及docs/TASK4_HOLD_*。生产源只读。旧波形RUN002/RUN004、旧Setup RUN002、原失败及SEAL均保留；封存逐件核验旧波形SEAL_002的483个文件、旧Setup SEAL_001的254个文件SHA未变。

## 精确接收与静态范围

本轮上游为docs/TASK3_HOLD_SOURCE_READY.json的SOURCE_READY，三份当前源、Task3 READY和模块执行输入、本窗新RUN_001输入均绑定下列SHA256：

| 文件 | SHA256 |
| --- | --- |
| project/src/extension_visual/scheduler/pro_score_scheduler.sv | a03c156037e83c72942289b68c5ca874c686a2c5afe873675c7d65a069e60645 |
| project/src/extension_visual/display/pro_score_display.sv | e32c346f96b79412bf67c99b8177278e7bcdbcc9f2e011aab33d26153da549a0 |
| project/src/m1td_voice_gain_q15_candidate.sv | 21256acd78106a8825e4c452499582736fc369d062c3b8dc6ec887ce55677697 |

相对旧Setup RUN002，生产RTL仅上述三源变化。独立静态自审详见TASK4_HOLD_STATIC_REVIEW.md、evidence/task4_hold_review/READ_001/REVIEW.json：18项来源及快照逐件核同，完整三源diff封存，findings=[]。确认LUT1 INIT2恒等、score98位/READ64位/envelope16位拼接、增益符号扩展与floor-Q15算术不变；没有新增时序过程、端口、时钟、复位、约束或周期延迟。Task3模块加速测试只是已读取上下文，不混入本窗真实系统计数。

## 独立旧增益真实core参考

新的task4_hold_reference_modules.sv来自旧Setup RUN002/inputs的五份真实生产源：m3_pro_audio_core_r10→m2_fourvoice_timbre_delay_frame_core_r06c9→m1td_timbre_delay_chain→m1td_audio_candidate→m1td_voice_gain_q15_candidate。只替换上述module/type符号并改独立include guard，未改行为；准备脚本反向替换后必须逐字等于旧冻结文本，最终seal重建整份参考文件核同。reference_provenance.json保存旧原件SHA、映射及生成物SHA。

新DUT采用当前真实core和新增LUT gain；参考实例采用旧冻结gain的完整真实core路径。其余共用模块相对旧Setup未变，已核源闭包。两路收到相同真实MIDI/score/reset/keys，逐核心周期比较event/ready、实际post-master-volume PCM、I2S、commit/identity及underrun；参考不接显示/observer。此方式避免两路共用新gain形成共同盲点。主音量另有独立signed64 Q1.12黄金，外部LSBJ串行半帧独立译码，observer/CDC按采用序号比较。

PLL与LUT1沿用原已验证fixture：50MHz参考、40MHz core、25MHz pixel、125MHz serial，LUT INIT真值精确；DVI止于并行RGB/control边界，不模拟加密串行器。没有降频/分频、改采样tick、改光栅或强制scheduler时基/锚点。

## 新执行与结果

ModelSim SE-64 2020.4，新runner tools/task4_hold_run.py，新证据evidence/task4_hold_system/RUN_001。vlib/vlog及audio/directed/full各vsim均exit0，整包status=PASS、current_inputs_unchanged=true，全部正marker存在且无Error/Fatal。没有本轮Task4失败或超时；没有重跑旧runner。

| 新组 | 实际通过内容 | 实耗／虚拟时间 |
| --- | --- | --- |
| audio | 2109167核心周期旧gain真实core miter；主场景2531采用PCM/observer、2467pixel样本、5059独立串行半帧、人/score共存2431帧；主音量full646/mute80/mid80；观察堵塞96帧/63drop/1gap；scoped STOP保留2真人；显示/全音频reset恢复，后者新epoch100 adopted/99 received；实际envelope4零6045098次/一2808246次 | 9.157s／55.335050ms |
| directed实际top | 四新准备状态各STOP/CLEAR共8例、generation故障4例、非法READ/超时5例、准备状态全top reset并真实重新上传全READ4例；READ捕获72次状态检查/92次poison；真实UART协议50次；11747979周期/14095发送帧/5次帧界切页；live故障下继续486音频帧、5120故障条像素 | 172.984s／293.701601ms |
| full自然时基 | 96768个真实48k tick即2.016s lead，四条曲谱事件按原due tick/type/note/channel/order接受，与真人并发15999998核心周期；101141046周期旧gain core miter、121368发送帧、7次帧界切页、23次真实UART协议核验；另READ_COMMIT全top reset、重新上传全READ/START/STOP/CLEAR；36捕获检查/36poison；live故障仍发送486帧、5120故障条像素 | 246.719s／2528.526976ms |

full的新曲谱raw ticks为0 ON72、14400 OFF72/ON75、19200 OFF75。改变的是测试音符长度，不是lead或时基；第一视觉duration超过16帧，实际payload[14]一出现2次、零出现1次（含复位后重START预览），两值均真实经过mailbox。四条自动音频事件完成后显式STOP，真人held继续。两组top都通过像素暂停：观察队列满/drop111时音频继续144帧且与旧gain reference一致。音量mute/unity、原Pitch/Mod/Sustain/CC25、B3波形/B2返回与隐藏跟踪沿原自检继续核验。

live故障在实际top中定点force fatal_live_pixel：同拍组合链跟随、下一像素拍内部valid清零，等原自然frame_start公布key/live清空及desync；最终fault条保持最高active优先级、blank黑。故障期间音频持续与旧gain参考一致。精确短态中止通过实际top公开command接口注入，非法READ和generation为明确故障反例；真实UART BEGIN/DATA/COMMIT/全READ/START/STOP/CLEAR另外完整执行并核identity/形状/CRC/字节。这些定点反例不冒称由UART提交了非法曲谱，也不是板上时钟/信号操作方案。

编译Warnings12；audio仿真Warnings147、两组top各Warnings139，类型化input默认var及未接诊断输出等原样保留，不能写零warning。当前三组Errors0。上游Task3及历史Task4首次失败保持各自原件和说明，本轮没有将历史失败改写为通过。

## 封存、复现和接手

R01机读封存：docs/TASK4_HOLD_SOURCE_READY.json；最终seal：evidence/task4_hold_final/SEAL_001/receipt.json，状态PASS_R01_EXECUTED_SNAPSHOT_SUPERSEDED_BY_R02、archive_only=true。两者绑定R01三源SHA、上游ready、audio/directed/full全部命令/exit/用时/正marker及静态回执；seal核执行/读取快照与参考闭包，单独列出当前树与R01快照变化，核旧483+254原件与新工具语法，不重跑测试。首次严格seal正确拒绝任务约定漂移，见TASK4_HOLD_SEAL_HISTORY.md。R02须用新目录另跑，不沿用本PASS。

RUN_001/inputs保存实际执行RTL、include/ROM、TB、参考闭包、runner及ready元数据。复现仅运行新runner（新建RUN，不覆盖旧原件；已存在测试目录不再运行初始化prepare）：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/pro_waveform_integration_20261022_r01/tools/task4_hold_run.py' audio directed full
```

本次命令退出0。audio/directed限600s、full限1500s，均未超时。后续改变任何输入源时不能沿用此证据代签新树。总控接手本精确三源，核实际新增20个LUT1保留、strict score min1及原audio min1的命中和效果；商业版Gowin V1.9.12.04全部Setup严格>0.500ns且Hold/Recovery/Removal/Pulse等全通过后交新FS并停止修改。WAVE04等低余量/失败报告FS继续保留。本回执不放行设备。
