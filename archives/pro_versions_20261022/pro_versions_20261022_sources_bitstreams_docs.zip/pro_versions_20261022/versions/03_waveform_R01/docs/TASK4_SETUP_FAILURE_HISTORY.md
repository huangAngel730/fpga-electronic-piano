# Task4 Setup 新系统回归失败史

旧Task4 RUN_001..004及SEAL_001/002保持原位、未改写。本节仅覆盖新evidence/task4_setup_system。

| 原件 | 实际结果 | 定位与最小修法 |
| --- | --- | --- |
| RUN_001 | 编译exit0；directed vsim进程exit0但日志有Fatal `SETUP abort same-edge mutation`，虚拟107276313500ps；缺完成marker，被runner拒收为FAIL；full未运行 | 自有setup_command在wait_state命中后的negedge又等待了一拍，在READ_COMMIT测试将中止延后到PREP_DIV，因此正常提交已经发生。仅修新TB及其准备脚本，使STOP/CLEAR在当前目标状态的negedge即呈现；reset注入同样去除额外等待。生产源不变，失败输入/日志/回执保留。 |

通过标准仍要求exit0、无Error/Fatal以及全部正向完成marker；进程退出0不代表测试通过。未运行EDA、设备或Git。

后续RUN_002：directed/full均PASS，当前输入与执行快照不变。directed实际8中止/4身份/5负例/4准备复位，full自然2.016s lead四事件、人/score并发、重新上传全READ和START/STOP/CLEAR通过；所有失败与修正版输入均保留在各自新RUN，没有重写RUN_001。
