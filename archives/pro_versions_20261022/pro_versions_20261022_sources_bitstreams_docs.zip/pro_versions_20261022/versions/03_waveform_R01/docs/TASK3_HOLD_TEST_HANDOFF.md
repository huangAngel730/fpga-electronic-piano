# Task3 Hold identity模块测试交接

RUN_02全PASS，3份生产RTL未由测试子智能体修改。精确SHA、依赖闭包、完整命令/exit/时长、raw双流、失败史见 `evidence/task3_hold_tests_r01/RECEIPT.json`。收口确认当前源与RUN_02冻结输入逐字节一致。ModelSim SE-64 2020.4。

新测试写于 `project/tb/setup_pipeline/hold_refinement/`，新runner为 `tools/task3_setup_hold_tests_run.py`，旧测试和收据均只读。vlib/vlog/3个vsim全部退出0，强制正向PASS并拒绝Error/Fatal，防止vsim Fatal返回0的假通过。原有relaxed-input-port警告完整保留。

- `tb_hold_identity`：四个真实gain模块共48000次独立signed64乘积/floor-Q15黄金比较，正负满幅、±1、零和随机envelope、bit4变化；没有时钟，输入改变后必须组合跟随。四lane envelope4 X传播检查。scheduler held_payload14和read_word24链逐个0/1/X检查，完整输出其余位保持。总10条显式恒等检查。
- `tb_setup_hold_regression`：复制原新setup用例到新的hold目录、改top和PASS marker；对本次实际最终源重跑READ稳定锁存、18负例、8个新态STOP/CLEAR、4复位、22identity变化、512QR、5632精确ceil、512准备16928core拍、120frame载荷、96768tick音频lead与RUN背压。56完成回执。
- `tb_hold_display`：本次candidate和封存的before-LUT display逐拍miter；真实40/25/125MHz、H800/V525、640×480，DVI仅在RGB/DE/HS/VS输入边界明确仿真替身。1276726像素和2042722core周期对照，420000像素live有效、760096像素真实fatal_live故障有效。先正常accepted note60并等自然帧界发布slot/key，再送实际非法范围note35触发fatal_live_pixel和u_live清理，逐拍对照live_end_y/live_valid/keys/held与DVI输入，无周期差。覆盖页切换和全局复位。另3次fatal→u_live 0/1/X无周期恒等检查。

预计实际顶层新增LUT1为20：score8、read2、live2、gain2×4=8；仅逻辑展开，是否保持与布局延迟由总控EDA核。LUT1模型使用候选现有同版GW5A模型，INIT2与原器件模型一致。#1为等待delta收敛，不是加入RTL周期或物理延迟。read_word24=1本就非法，force只证明组合恒等，不宣称合法分数。

RUN_01失败原件保留：gain/identity/setup均已PASS，display TB在30us过早要求已公布live状态而coverage前提失败；查实际live_state得知仅frame_start公布，改为等待第一个自然frame后再检查，生产RTL未改，门槛未降低，RUN_02全通过。RUN_02首次启动在进程创建前遇自动审查超时，按工具允许重试一次后启动，未发生双进程或覆盖。

测试条件边界：scheduler sample_tick每32core周期(1.25MHz)；display waveform frame-load500kHz，均为软件加速fixture，不能当真实48k/整机2.016秒lead证明。组合/周期恒等不签物理Hold，严格min1ns、Setup>0.5ns及全部其它时序由总控Gowin确认；Task4负责最终源真实全链回归。没有EDA、实物、Git或旧runner操作。

复现使用全新输出名：`C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_setup_hold_tests_run.py NEW_RUN_NAME`。
