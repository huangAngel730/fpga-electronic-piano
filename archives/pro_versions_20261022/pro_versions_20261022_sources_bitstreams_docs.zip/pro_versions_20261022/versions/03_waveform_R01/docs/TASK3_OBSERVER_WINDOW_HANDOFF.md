# Task3 observer/window 新自检交接

完成：RUN_03 PASS。未修改任何RTL。

入口 tools/task3_observer_run.py NEW_RUN_NAME；Python C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B。ModelSim SE-64 2020.4。输出目录必须未存在，冻结输入、原始双流、命令、时长和退出码。vlib/vlog/vsim均0，另强制检查正向PASS，避免vsim Fatal回0造成假绿。

测试真实40MHz/25MHz及640x480/H800/V525扫描，fixture每160核心拍加载，即250kHz加速样本，并非48kHz名义采样验证。运行411.234650ms，共24个真实frame_start；初始audio/display复位后另在行中间异步显示支路复位，音频持续，观察序号不重置。

参考使用独立源序号函数生成五类图案：四样本满负/满正混合、左0右满幅、纯负满幅、纯正满幅、随列变化且含负一量化边界的minmax。2048样本/窗、每4样本/bin、512列。只按公开样本与帧边界建逻辑front/pending参考，不读取DUT私有RAM/bank生成期望。

实际PASS计数：pre-NBA采用观察102808、CDC交付102808、N+2 mask/RGB逐像素10280866、blank2747200、ROI关键交叉492、零左声道轴2769/轴外5538、满跨幅像素528896、负端点y319为2346、正端点y64为2558；完整窗口49、帧发布24、pending替换24、stream_restart2。

源在frame_load采样同一沿通过NBA更新下一样本，因此错读post-NBA会失败。左零右满幅组确保右声道未混入波形。所有前台窗口在后台写入及pending替换期间逐像素保持正确，覆盖三银行所有权行为但不窥私有bank编号。trace_valid只允许真实frame_start发布。

RUN_01/02失败原件保留；均是覆盖不足，没有像素或数据不一致。第一次延长帧数，第二次根据窗口/帧相位比改fixture周期128->160，不改RTL、不降门槛；RUN_03全通过。vsim失败时实际退出0但runner退出1，见各轮日志和收据。

精确源码SHA、命令、时长、条件见evidence/task3_observer_r01/RECEIPT.json，全部原件在RUN_01/02/03。源文件在封存时仍与RUN_03冻结输入逐字节一致。未验证物理CDC、BSRAM推断、STA、完整真实音频核心或设备；pixel暂停和显示页/原combined/整机接缝由父窗口相应组覆盖，本组不代签。
