# Task4 HOLD R02 精确三源真实系统交接

**PASS：R02新audio/directed/full三组全部完成，当前输入与执行快照一致，三源精确diff只读自审未发现阻断。仅签RTL仿真及静态自审；Task4未运行EDA、设备或Git，不代签物理Hold/Setup、LUT保留数量、FS或板卡通过。**

本轮依据TASK_AND_INTERFACE.md的WAVE05 follow-up R02。只写新project/tb/hold_r02_system/**、tools/task4_hold_r02_*、evidence/task4_hold_r02_*/**及docs/TASK4_HOLD_R02_*。R01按原执行快照封存并已被R02接续，本轮没有改写它的源码快照、ready、测试、工具、失败或交接。封存逐包核验旧波形483、Setup254、HOLD R01共167个文件SHA未变。

## 精确版本与静态结论

上游docs/TASK3_HOLD_R02_SOURCE_READY.json为SOURCE_READY；当前源、Task3 READY及模块执行输入、本窗新RUN_001执行输入三源SHA256一致：

| 文件 | SHA256 |
| --- | --- |
| project/src/extension_visual/scheduler/pro_score_scheduler.sv | 3e52cc5057834a0b94428e0673f5b30beed58b46027953a7e7ea6c40576c674d |
| project/src/extension_visual/display/pro_score_display.sv | e32c346f96b79412bf67c99b8177278e7bcdbcc9f2e011aab33d26153da549a0 |
| project/src/m1td_voice_gain_q15_candidate.sv | 21256acd78106a8825e4c452499582736fc369d062c3b8dc6ec887ce55677697 |

相对R01只扩scheduler READ写数据tick[31:0]每bit两级INIT2恒等LUT；upper32事件字段、格式/lifetime/QR/runtime算术、状态/周期/时钟/复位/约束及display/gain不变。静态原件见TASK4_HOLD_R02_STATIC_REVIEW.md与evidence/task4_hold_r02_review/READ_001/REVIEW.json，18项来源/快照核同，完整本次diff及必要上下文已封存，findings=[]。Task3模块0/1/X、walking/random与加速scheduler/display计数只作为已读取上游上下文，不混入本窗计数。

## 新参考与系统验证

新的hold_r02 TB/runner是原已签R01自检的独立副本，未执行旧runner。实际DUT使用R02生产源；参考保留旧Setup RUN002真实core→framecore→chain→audio_candidate→旧gain五模块，只重命名module/type与独立guard。参考代码字节保持R01同一纯符号闭包；reference_provenance.json绑定旧原件、映射及生成SHA。seal重新从旧冻结字节生成整份参考文本并比对，未改变逻辑。其余生产模块相对Setup未变，源闭包已核。

因此逐核心周期PCM/I2S/event/ready/commit miter的另一侧使用未加新LUT的旧gain，避免两侧共用新gain形成共同盲点。音量另用独立signed64 Q1.12黄金，PT8211 LSBJ半帧独立译码，observer/CDC按实际采用序号逐样本比较。PLL/LUT/DVI边界沿原已签fixture：真实50MHz参考、40MHz core、25MHz pixel、125MHz serial、原48kHz NCO、H800/V525；DVI只到RGB/control边界，不代签加密TMDS或PLL物理相位。没有降频/分频、改tick/anchor/lead或光栅。

本轮新增实际READ_COMMIT写入检查：仅active_write有效才计数，完整raw_mem_write_word须等于read_word；合法曲谱0/14400/19200 ticks覆盖native Hold端点bit8两值。高tick[31:24]非法样本仍只用于上游组合恒等/格式拒绝，不能当合法播放。本窗不伪造高tick准入。

## 实际运行结果

ModelSim SE-64 2020.4；实际新目录为evidence/task4_hold_r02_r02_system/RUN_001。vlib/vlog及三组vsim均exit0；整包status=PASS、current_inputs_unchanged=true，正向完成marker齐全、无Error/Fatal、无超时。该目录是实际执行器生成的R02新目录，封存与复现沿用其原名称，不移动或覆盖原件。

| 新组 | 实际PASS | 实耗／虚拟时间 |
| --- | --- | --- |
| audio | 2109167核心周期旧gain参考；主场景2531采用PCM/observer、2467pixel样本、5059独立串行半帧、人/score共存2431帧；full646/mute80/mid80；观察堵塞96帧/63drop/1gap；scoped STOP保留2真人；显示/全音频reset恢复，后者新epoch100 adopted/99 received；envelope4零6045098次、一2808246次 | 8.954s／55.335050ms |
| directed实际top | 四新准备状态STOP/CLEAR共8例、generation故障4例、非法READ/超时5例、准备全top reset并真实重上传/全READ4例；72捕获状态检查/92poison；50次真实UART协议核验、11747979周期/14095发送帧/5次切页；live故障仍发送486帧，5120故障条像素；实际tick8零9次、一2次，共11条提交 | 171.562s／293.701601ms |
| full自然时基 | 原96768个真实48k tick即2.016s lead；四曲谱事件按due tick/type/note/channel/order接受、人/score并发15999998周期；101141046周期旧gain miter、121368发送帧、7次帧界切页、23次真实UART协议；另READ_COMMIT全top reset、真实重上传全READ及START/STOP/CLEAR；36捕获检查/36poison；live故障仍发送486帧、5120故障条像素；tick8零6次、一2次，共8条提交 | 252.188s／2528.526976ms |

曲谱向量为0 ON72、14400 OFF72/ON75、19200 OFF75；保持R01测试音符长度，lead固定不变。实际payload14零1次、一2次，覆盖原score缓冲两值和复位后START预览。自动四事件后显式STOP，真人held保留。两组top的观察队列满/drop111时仍发送144帧，I2S/PCM与旧gain参考不变。B3波形/B2返回、隐藏live/score、CC25和原Pitch/Mod/Sustain、CC7 mute/unity继续核验。

live故障注入实际fatal_live_pixel后组合链无新增周期，下一像素拍清内部valid，原自然frame_start公布key/live清空及desync；最终active故障条覆盖优先级和blank黑均检查。短态STOP/CLEAR从实际top公开command接口定点注入，generation及READ替换是明确故障反例；真实115200 UART BEGIN/DATA/COMMIT/逐条完整READ/START/STOP/CLEAR另行执行并核ACK identity/形状/CRC/字节。故障注入不冒称真实UART提交非法曲谱，不作为板上门控/信号操作方案。

编译Warnings12；audio仿真Warnings147、两组top各Warnings139，类型化input默认var及未接诊断输出等原样保留，三组Errors0。本轮新Task4没有失败或超时，旧R01严格seal因新任务约定漂移而拒绝的历史仍原位保留，未改成当前通过。

## 最终封存与接手

机读就绪docs/TASK4_HOLD_R02_SOURCE_READY.json，最终seal evidence/task4_hold_r02_final/SEAL_001/receipt.json。严格seal要求R02当前三源和全部输入等于执行快照、static来源等于读取快照、三组exit0/PASS齐全，核参考纯符号变换及旧483/254/167原件，记录新工具语法和所有产物SHA；不重跑测试、不接受当前漂移的归档模式。

RUN_001/inputs保存实际生产RTL、include/ROM、新TB/参考、runner/prepare和Task3 ready。复现使用新runner，创建后续新RUN；不重复已存在目录的prepare初始化：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/pro_waveform_integration_20261022_r01/tools/task4_hold_r02_run.py' audio directed full
```

本次命令exit0。audio/directed限600s、full限1500s，均未超时。新source-ready绑定三源及audio/directed/full全部命令/退出/耗时/完成marker、实际输入和静态回执SHA。任何后续源改变须另绑新版本，不能沿用此包。总控接手精确R02源，在商业版Gowin V1.9.12.04核read64个/总82个新增LUT实际保留、原两条strict min1不放宽，全部Setup严格>0.500ns且Hold/Recovery/Removal/Pulse等全通过后交新FS并停止修改；WAVE05等旧报告FS保留。本包无设备放行。
