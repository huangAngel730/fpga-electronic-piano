# Task2 MIDI controls — 软件交接

状态：PASS_MIDI_SUBTASK / 自审完成。生产源码稳定，最终仿真为 RUN_02。
本交接只覆盖 MIDI 解析和输入转接，不代表整机、EDA 或实物通过。

## 范围与接口

仅修改候选 project/src/midi_event_parser.sv 和 midi_input.sv。
新增测试位于 project/tb/wave_controls/midi_controls/，新执行器为
tools/task2_midi_run.py，所有证据在 evidence/task2_midi_r01/。
原工程输入只读；未修改公共事件包、uart_rx、core、volume、引脚、
时钟、工程注册文件或原仓库；无 Git 和设备操作。

新增 extension_page_select[1:0]：parser 为 output logic，midi_input
为 output wire 转接；与 core 同域，同步低有效 rst_n。
状态默认 0，仅 0/1；父任务负责 core/top/page CDC 连接和整合验证。
所有原有 64 位事件字段和 control_id 编号保留。

- CC7：离散 FIFO 中的 EVENT_CONTROL_CHANGE / CTRL_VOLUME=2，
  control_value 为既有 midi_cc_to_12bit(raw7)，0→0、64→2064、127→4095。
- CC25：每通道首次 raw7>=64，发 CTRL_VOICE_SELECT=5 的 0/1 轮换；
  raw7<64 重新武装。影子仅随成功入本地 FIFO 的 PC0/1 或 CC25 更新。
  PC>1 仍原值发出且不改变影子；FIFO 满的按下计原溢出，不改变影子，
  按下仍消耗，松开后才能再试。FIFO 同拍出队可正常接纳新按下。
- CC26/27：独立逐通道逐按钮首次按下分别设置页面 0/1；
  不进入公共事件 FIFO，也不受该 FIFO 背压/溢出影响。
- CC28/29/30 忽略；原 Note/velocity0、Pitch、Mod CC1、
  Sustain CC64、PC 语义保留。坏帧清解析上下文，不伪造页面或按钮边沿。

## 验证与证据

命令（在候选根运行，每次使用不存在的新目录名）：

    C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task2_midi_run.py RUN_02

ModelSim SE-64 2020.4；vlib、vlog、两个 vsim 均退出 0。
vlog 零错误、零警告。最终 PASS 标记：

    PASS MIDI_PARSER checks=162 ABI=64
    PASS MIDI_UART checks=29 frames=109 CLK_HZ=40000000 BAUD=31250

字节级测试使用 LOCAL_FIFO_DEPTH=2、CLK_HZ=1000 加速原控制限速计数；
串行测试使用实际 40MHz 时钟和 31250 baud 8N1、1280 clock/bit，
经实际 uart_rx + midi_input，不注入已解码字节。串行模拟总时长
34.952825 ms，包含真实停止位错误。

覆盖：Running Status、实时字节夹入半消息、System Common/SysEx、
坏帧恢复、阈值63/64、重复高值与有效/损坏松开、全部16通道独立、
PC>1、PC0/1、背压输出稳定、FIFO溢出与影子一致性、满FIFO同拍出入队、
页面在音频背压时独立变化，以及原音符/延音/弯音/调制事件逐字段比较。

RUN_01 亦通过（parser56项、UART29项/109帧），原件保留；RUN_02
仅扩展有意义边界，生产源未改。ModelSim 未出现失败。
曾有一次工具代码解析失败（JavaScript 模板中的 SV 反引号未转义）；
未启动进程、未写文件，纠正后正常执行。记录见 SELF_REVIEW.json。

RUN_02/inputs/ 冻结源和执行器；SOURCE_SHA256.json 记录输入SHA；
COMMANDS.json 记录完整命令、起止UTC和退出码；
00..03.stdout.raw / stderr.raw 保存原始输出；
RESULT.json、SELF_REVIEW.json、PRODUCTION_DIFF.patch 和
BASELINE_INPUTS/ 提供结果、自审、最小diff与原生产输入。

## 最终生产 SHA256

midi_event_parser.sv: ec867a526424895752b4da70c29dc7b29c5182c23f85afaecba22706a866d6d9
midi_input.sv: 458a7932de69ed8bb4b74c53555373194b9532c6975565907fa44c70e99ec3a6

原输入已按 SOURCE_INPUTS.json 核SHA，公共事件包及 uart_rx 与原输入一致。
当前两份生产源与 RUN_02/inputs 副本逐字节一致。

## 交接边界

本子任务必做项已完成，未发现阻断；交父任务汇总。
尚待父任务的实际 core/PCM/显示整合、商业 Gowin 综合/PnR/STA及总控验收。
真实键盘的 CC 瞬时模式设置和物理 MIDI 接收/音频/画面均未验证，
本任务未操作任何设备。未写父任务拥有的 TASK2_SOURCE_READY.json。
