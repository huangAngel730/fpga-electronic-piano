# Task3 Pro 波形显示集成交接 R01

适用范围：`pro_waveform_integration_20261022_r01/docs/TASK_AND_INTERFACE.md` 的 Task3 独占写集。总控为拓展任务1。当前交付只涉及软件实现、ModelSim 和自审；没有 EDA、设备扫描、串口实物通信、下载、上板或 Git 发布。最终结果与源码身份见 `evidence/task3_wave_r01/FINAL_RECEIPT.json`。

## 实现与接线

- 新增 `project/src/extension_waveform/{pcm_frame_observer,pcm_waveform_observer_bridge,pcm_waveform_candidate,m3_pro_fixed_left_waveform}.sv`，均逐字节复用仓库验证源。原始绝对路径、SHA 与复用关系封存在 `evidence/task3_wave_r01/REUSE_IDENTITIES.json`。
- 只修改现有 `project/src/extension_visual/pro_score_visual.sv` 与 `project/src/extension_visual/display/pro_score_display.sv`。前者新增并直通 `page_select[1:0]`、`audio_frame_load`、signed PCM24 `play_left/right`，总控在真实顶层连接稳定 core 页状态以及发送器本次采用的 PRE_NBA 音量后 PCM。
- 复用原 `project/src/reset_sync.sv` 和 `project/src/extension_visual/display/visual_mailbox_cdc.sv`，二者也与仓库源逐字节相同，没有引入重复 module。
- page 0 默认保持原 combined score/live，page 1 为固定左声道波形。`page_select==1` 在 core 编成单比特后双同步到 pixel，仅帧开始提交；首像素与该帧新页相同。无 FFT。
- 波形始终观察，隐藏页不停止 observer、live/score tracker、frame counter 或 anchor。新增支路没有音频 ready 或反馈控制。
- 波形采用原始 raster N，RGB 在 N+2 输出；原场景 snapshot 之后增加两级，同时延迟 DE/HS/VS/page/desync/坐标。最终 active 故障条覆盖两页，消隐最后强制黑。原 negedge pixel DVI 复位和真实 Pro IP 文件保留，未改 scan、current_frame/anchor、score/human epoch 语义。
- 左声道固定 2048 样本窗口、每列4样本 min/max、512列；ROI x64..575/y64..319，零轴 y191。该定义直接复用原波形实现。

## 新增 CDC 层级（以实际 top 的 u_score_visual 为前缀）

| 功能 | RTL 精确对象 | 集成约束关注点 |
| --- | --- | --- |
| 页状态 core→pixel | `u_score_visual/u_display/wave_page_core` → `page_meta` → `page_sync` → `page_latched` | 仅单比特；首级 `page_meta` D，随后在 pixel frame_start 提交 |
| PCM 观察采用点 | `u_score_visual/u_display/u_waveform/u_bridge/u_observer` 的 `frame_load/play_left/play_right` | core 同域 PRE_NBA 采用；与真实 I2S 发送器采用接口逐样本对照由总控执行 |
| 稳定80位 bundle | `u_score_visual/u_display/u_waveform/u_bridge/u_mailbox/payload_hold[79:0]` → 同层 `dst_data[79:0]` | 请求返回确认前 payload 保持；max40ns/min0ns；不能整域 false-path |
| bundle 请求 core→pixel | 同 mailbox `request_toggle` → `req_meta` → `req_sync` | 首级 `req_meta` D |
| bundle 确认 pixel→core | 同 mailbox `acknowledge_toggle` → `ack_meta` → `ack_sync` | 首级 `ack_meta` D |
| 源域上线 core→pixel | `u_score_visual/u_display/u_waveform/u_bridge/source_reset_done` → `source_up_meta` → `source_up_sync` | 首级 `source_up_meta` D；目的域启动后才消费 |
| 观察支路本地复位 | 同 mailbox `u_src_reset/sync_chain`、`u_dst_reset/sync_chain` | branch reset=`core_rst_n && pixel_rst_n`，异步置位/本地同步释放；不反馈音频/曲谱复位 |
| DVI 既有释放级 | `u_score_visual/u_display/dvi_rst_n` | 全局异步断言；pixel_rst_n 后下一个 pixel 下降沿释放；未新增125MHz织构复位 |

源代码中的实例名为 `u_waveform/u_bridge/u_mailbox`。表格为 RTL 对象而非综合 cell 签收；总控必须在新网表检查集合非空、位数和精确首级 D/CLEAR 例外及 bundle 约束实际生效，完成相关时钟 STA。仿真不能证明物理 CDC。

## 已完成的新测试与边界

使用 ModelSim SE-64 2020.4，新 runner `tools/task3_run_display.py` 将输入复制到独立 run，保留源 SHA、完整命令/退出码和 stdout/stderr。原件目录不覆盖、不执行旧 runner。以下各 run 的 vlib/vlog/vsim 均退出0且检查 PASS marker 和 Error/Fatal。

1. `evidence/task3_wave_r01/RUN_01`：40/25/125MHz，H800/V525真实光栅，640×480 active，H_RESET_OFFSET50，pixel 相位偏移7ns。采用冻结改前原 display 独立实例与独立 raster 对照，检查 N+2 控制、page0 RGB、隐藏页 tracker/anchor 连续、三次中线页请求且只帧界切换、首像素、wave axis/ROI、active desync 条、blank 黑及全局复位。结果 `PASS DISPLAY_RASTER checks=1697892 combined=841194 wave=856698 axis=1024 blank=454618 fault=11520 boundaries=14851 first=4 audio=33957`。PCM frame-load 为500kHz加速fixture（80个40MHz周期），左零/右变化，缩短窗口等待；不是实机48k链路证明。
2. `evidence/task3_wave_r01/RUN_RESET_01`：独立 PRE_NBA observer scoreboard；pixel 暂停150us（6000 core周期），core/串行时钟仍运行，队列满可见丢弃，恢复后序号 gap 可见，故障不门控样本；异步复位和两次 DVI 下降沿释放均检查。结果 `PASS DISPLAY_RESET_PAUSE observations=107 releases=2`。同为500kHz frame-load压力fixture。
3. `evidence/task3_observer_r01/RUN_03`：独立 observer/window 模型通过102808组采用/CDC数据和10280866个N+2 mask/RGB像素；真实40/25MHz、H800/V525，250kHz加速采样（160 core周期），运行411.234650ms。覆盖左零右满幅、正负端点、min/max、ROI/轴、49窗口/24发布/24 pending替换和中线显示支路复位。独立模型只用公开样本和帧边界，不读取DUT私有bank生成期望。具体见 `docs/TASK3_OBSERVER_WINDOW_HANDOFF.md`。前两轮 RUN_01/02分别缺负端点和满跨幅覆盖；延长帧数及改变fixture采样相位比后通过，门槛未降低、RTL未改；失败原件均保留。

显示测试只在真实 DVI IP RGB/DE/HS/VS 输入边界放置显式仿真替身，生产 DVI/PLL 未被替换或改动。覆盖逻辑像素输入，未签 TMDS 编码/串行器、PLL物理相位或板上显示。vlog 原有 relaxed input port kind 警告保留于原始日志，未视作新错误。

## 自审与未签范围

只读复查实际增量未发现具体阻断：同龄像素 token、frame-boundary page、blank/fault 优先级、hidden tracking 和 negedge DVI reset 保持。未启用项目审核员/预审员制度。复用四份源身份与已通过 run 的当前源码身份由最终封存脚本再核；不因后续总控修改自动延续此结论。

总控继续负责真实 top 接线、GPRJ/源注册、受控约束、真实音频/score/MIDI共存的新系统验证、Gowin商业版V1.9.12.04综合/PnR/STA。接口采样必须与真实发送器采用音量后PCM相等，不用 #1 后移动的buffer当本次采用值。Task3模块测试通过不代替上述集成、硬件或完整C9验收。原R10/baseline/仓库源、Android成品和共享状态均不在本任务写集。

复现显示用例（使用全新 run 名，既有原件保留）：

```powershell
C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_run_display.py NEW_RASTER_NAME
C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_run_display.py NEW_RESET_NAME tb_wave_display_reset
```
