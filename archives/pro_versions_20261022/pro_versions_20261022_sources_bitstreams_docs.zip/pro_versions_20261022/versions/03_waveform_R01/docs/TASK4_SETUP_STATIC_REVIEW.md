# Task4 Setup 流水线定版静态审查

本次精确源码及指定 diff 范围内未发现具体阻断，机读结论为 `findings: []`。仅进行静态阅读、身份核对与证据封存，未运行编译、仿真、EDA、设备操作或 Git，未修改生产源码、测试或父窗 runner。

当前 `project/src/extension_visual/scheduler/pro_score_scheduler.sv`（完整读取 1–360 行）SHA256：

```text
271a4117f883db70fd8b18f7d9d24d876e26c40de07d88c3fe11acac4c7c0e59
```

对比 RUN_004 原 scheduler，SHA256 为 `16790e2d4f63d35ec1f0bff9ca9e3db4e2770dd95f406626148a24e99cf780d6`。当前源码与 Task3 SOURCE_READY 的冻结副本、模块 RUN_02 实际输入逐字节身份一致。

本次核查结果：

- READ_WAIT 单次捕获 `read_word`，后续格式、顺序、键值和寿命检查使用稳定快照；READ_FORMAT、LIFE_LOOKUP、LIFE_CHECK 与 READ_COMMIT 分离，active 位图只在允许的提交拍更新（75–110、216–265 行）。
- 新增状态及 PREP_DIV、CHECK、ANCHOR 在执行受保护写入前重新检查 valid/count/id/generation/bank；身份不符禁止提交，进入错误清理（83–100、216–302 行）。
- 新增状态接受 STOP/CLEAR，顶层命令分支优先于状态执行；`active_write` 同时排除 `command_fire`，覆盖 READ_COMMIT 同拍中止（135–138、189–211、250–263 行）。
- runtime offer 生成以及 RUN/STOP 清理段与 RUN_004 基线逐字节一致，保留已呈现 offer 的握手行为。绝对帧/ceil 数学及锚定后的 96768 个真实 sample tick、120 帧 lead 未改；每条 raw 事件新增四个准备 core 周期发生在取得运行锚点之前（37、118–161、287–354 行）。

已阅读并核同 Task3 模块测试回执与原始日志身份：RUN_02 报告 56 例 PASS，包含 18 个负例、8 个中止、4 个复位及 22 个身份变化场景。其 sample_tick 夹具为每 32 个 40 MHz core 周期一次，即 1.25 MHz 加速条件；这不是本次新执行结果，也不代替整机自然时基回归。模块 RUN_01 的测试声明顺序编译失败原件仍保留，回执说明只修测试声明、RTL 未变。

完整源码快照、本次 diff、Task3 SOURCE_READY/模块回执与六份模块原始日志已封存于 `evidence/task4_setup_review/READ_001/`。其中 `REVIEW.json` 的 `sources` 数组逐项记录当前绝对路径、SHA256、read_scope 和 snapshot；`findings` 为空。

Task4父窗自行负责新 real-top directed/full 回归及其夹具失败原件，本审查不评判父窗测试实现或代签运行结果。最终 Setup 严格大于 0.500 ns 及其他时序门槛仍须总控拓展任务1真实 EDA 验收；Task4不运行EDA，本静态结论不构成综合、布局布线、时序或实物通过。
