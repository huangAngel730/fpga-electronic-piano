# Task3 Hold R03：READ字段与代际捕获零周期缓冲

本轮按总控拓展任务1的R03独占调度，只修改scheduler及m1td_polyphonic_envelope_bank两源，另冻结display/gain为四源身份清单。禁止改SDC/options/GUI、时钟、其余生产源及旧证据，无EDA/设备/Git。WAVE11标准复制1构建exit0，Setup+1.568ns，但Hold-0.334ns/5端点；六条新增min0.200约束非空。已通过的OSER D8/D5和frozen85→held85路径不改。

## 真实连接与修法

WAVE11原.tr表格显示slot_generation[0]_14到frozen_generations14为-0.334ns，read_word51到prepared_key副本为-0.078/-0.070ns，read_word48到另一副本-0.022ns（另一个端点原始表格近零负值）。现有低32位buffer只进入raw_mem_write_word，单纯扩宽RAM写口不会修prepared_key，因此本轮接通真实后续消费端。

scheduler保留READ_WAIT的原read_word寄存器与LUT链首。64个bit各两级保留LUT1 INIT2，输出read_word_buffered；captured_is_on、全部格式/序检查、prepared_key、prepared_div_shift、previous_tick与raw_mem_write_word都从该出口读取。直接read_word[bit]只剩链首一处，无组合回环，不加拍，原STOP/CLEAR、identity、120frame/96768tick、整数QR、lease与READ捕获语义保持。

bank新增capture_generations128位，每bit四级保留LUT1 INIT2，仅CAPTURE把该出口写frozen_generations。保留slot_generations→observer、control snapshot、live_identity_matches的原始连接，reset/math identity/观测接口及其他捕获字段不变。四级用来覆盖WAVE11 -0.334ns缺口并留实际布局余量，是否足够只能由新PnR证明。

新增层级：scheduler `u_score_visual/u_scheduler/g_read_word_hold[0..63].g_stage[0..1].u_identity`共128；bank `u_audio/g_polyphonic.u_audio_core/u_chain/u_audio/u_bank/g_generation_capture_hold[0..127].g_stage[0..3].u_identity`共512。较R02新增64+512=576；本岗Hold缓冲组总658（read128+bank512+score8+display2+gain8），这不是整个工程全部LUT总数。链wire及instance均syn_keep/syn_dont_touch；真实综合网表数量/连接由总控核验。

## 新验证与交接门槛

新hold_r03测试/runner以实际四源和依赖闭包冻结，覆盖完整64bit/128bit 0/1/X、walking/随机恒等与prepared_key真实出口消费，原scheduler适用正负/abort/reset/identity/QR/lead/背压，真实bank前后miter含router/四voice/ROM/代际捕获/取消/复位和显示适用回归。不重复无关旧已签组。force仅证明组合连接，不冒充合法上传、自然采样率或实际板级身份安全。失败原件全部保留并按具体缺陷定位修正。

RUN_01五组全PASS、无本轮失败，当前四源及95文件实际SV/include/ROM闭包与冻结字节一致，已生成 TASK3_HOLD_R03_SOURCE_READY.json。READ64恒等2372次/真实消费者反事实5次；scheduler全部适用56回执/18负/8abort/4reset/22identity/512QR/5632ceil；真实bank153670周期miter、4955捕获、4950结果、7取消、真实4800样本release/retire及复用、128位恒等1668次；display1276726像素miter通过。详见新TASK3_HOLD_R03_TEST*与测试receipt。所有before/READY/diff/原WAVE11身份/旧ready身份封存在 evidence/task3_hold_r03；保留R01/R02/Setup及WAVE11旧成果。第一次读取使用简称evidence/WAVE11未找到，已改为实际GOWIN_WAVE_11并读原.tr；该只读路径诊断不属于RTL失败。

这里只能签模块软件仿真级。新完整PnR、Setup严格>0.500ns和全部Hold/Recovery/Removal/Pulse、保留六条min0.200与其它原严格min1由总控继续确认；未新PnR不能放行FS。达到最终全部门槛后交付码流并停止修改。
