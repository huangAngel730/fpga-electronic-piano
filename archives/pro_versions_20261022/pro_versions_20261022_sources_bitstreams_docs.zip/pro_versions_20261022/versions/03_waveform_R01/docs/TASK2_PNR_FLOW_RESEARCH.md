# Task2：本机商业版 PnR / STA 只读流程研究

日期：2026-10-22（Asia/Shanghai）。范围：仅本机官方 PDF、安装目录文本资料、
冻结候选 rebuild.tcl / options.tcl / SDC 及历史 .p/.pr 文件清单。
未启动 gw_sh / gw_ide / gw_sta / PnR，也未执行任何 EDA help 探测；
未运行仿真、未操作设备、未联网、未改 RTL/SDC/options/rebuild/工程。
本研究不是新增执行许可，也不将任何命令标记为实测可运行。

## 直接结论

| 问题 | 文档能支持的结论 | 不能据此声称 |
| --- | --- | --- |
| 更严格 hold uncertainty 做实现余量 | 支持 -hold 独立时钟不确定度；现有 PnR 还可启用自动 hold 修复。将原0.750提高到0.750+delta作为额外目标有合法约束语法 | 不保证收敛，不保证 setup不回退，也不是已验证的两阶段实现/STA流程 |
| 已布线设计换回原SDC，只重跑STA | 本次资料未找到正式加载已布线数据库、替换SDC且只做STA的入口 | 不能确认 run sta、恢复原SDC后 run pnr 可保持同一布线 |
| 复用上一版好布局/布局布线 | 支持 inc_place、inc_pnr；需历史 .p 或 .pr，且目标属于支持的 Arora V/III | 增量不等于完全锁死布局，不等于 routing-only，不保证旧布局逐对象保留 |
| 高扇出复制 | replicate_resources=1 正是 PnR 复制高扇出资源以减扇出/改善时序；Arora V/III支持 | 未保证特定FSM寄存器必复制、复制次数或特定关键路径改善 |
| syn_maxfan | GowinSynthesis 明确支持，可能复制寄存器或其他逻辑；支持RTL或GSC | 明确不适用于时钟、control enable、reset/set；不能仅凭终点D推定源信号适用 |

对当前需求，文档依据最直接、无需修改功能周期的候选是
set_option -replicate_resources 1；本轮只报告该正式入口，没有改动或执行。
独立 STA 复评流程目前证据不足，不应作为已掌握的可靠收敛方案。
原频率/分频、原 setup/hold 要求均保留；提高实现目标不允许替代原要求验收。

## 资料、版本和页码口径

以下均来自用户指定商业安装根：
D:/program/Gowin_work/Gowin/Gowin_V1.9.12.04_x64/IDE/doc/EN/

- SUG1220-2.1E，Gowin Software Tcl Commands User Guide，2026-09-22；
  PDF 80页，正文页数72；“PDF第N页”减7通常为正文印刷页。
- SUG100-4.4.7E，Gowin Software User Guide，2026-09-22；
  PDF 100页，正文页数87；本文引用部分 PDF页减12为印刷页。
- SUG940-2.0.5E，Gowin Design Timing Constraints User Guide，2026-09-22；
  PDF95页，正文84；引用部分 PDF页减10为印刷页。
- SUG550-2.4E，GowinSynthesis User Guide，2026-06-17；
  PDF98页，正文90；引用部分 PDF页减8为印刷页。

文档版本不冒充实际新执行器版本。本轮没有启动执行器读版本。
各原始 PDF 的绝对路径、SHA256及页数在 evidence/task2_pnr_flow_research/SOURCES.json。
全文本、关键页独立文本和争议页 PNG 均在同一证据目录。已目视核对
SUG1220 PDF51、SUG100 PDF55、SUG550 PDF65，确认后缀冲突/排除项不是提取错误。

## A. Hold guardband 与同一路由重做 STA

SUG940 §5.2.4，PDF72–73 / 印刷62–63(84)，正式语法：

    set_clock_uncertainty
    <uncertainty>
    -setup | -hold
    [-from <from_clock> | -rise_from <rise_from_clock> | -fall_from <fall_from_clock>]
    [-to <to_clock> | -rise_to <rise_to_clock> | -fall_to <fall_to_clock>]

数值单位ns。-hold作用于hold和removal，-setup作用于setup和recovery；
省略二者会影响四类分析，因此不能为hold guardband误用无类型的全局修改。
至少需要一个 from/to 类时钟选择。原SDC已有的合法具体语句是：

    set_clock_uncertainty -hold 0.750 -from [get_clocks {core_clk}] -to [get_clocks {core_clk}]

若将“这条同一时钟对的值”提高到0.750+delta，语法可表达更严格hold目标。
这是约束含义推论，非官方给出的专用guardband两阶段操作流程；
不能假设多条不同值会按期望叠加/覆盖，不能在未核优先级时简单追加。
其他时钟域及跨域约束仍需完整保留，不能只改core后宣称全部hold有余量。
当前原SDC还包含pixel 0.750ns和serial 0.100ns hold不确定度。

SUG1220 PDF49–50 / 印刷42–43(72)给出：

    set_option -correct_hold_violation 1

其含义是布线期间自动修复hold违规，默认1；不是独立修复/仅STA命令。
当前 options.tcl 已为1，timing_driven也为1。

SUG1220 §3.3.13，PDF23–24 / 印刷16–17(72)只列出：

    run [-h/--help] <syn/pnr/all>
    run pnr
    run all

正式 flow 枚举为 syn、pnr、all，没有列 sta、route 或 routing。
SUG940 §5.5.1，PDF83–85 / 印刷73–75(84)正式支持报告约束，例如：

    report_timing -setup -max_paths 25 -max_common_paths 1
    report_timing -hold -max_paths 25 -max_common_paths 1

这些是时序报告约束，能决定报告的分析/路径范围；
它们本身没有提供加载已布线设计、替换SDC或启动独立STA进程的完整方法。
SUG100 PDF68 / 印刷56(87)还明确说明打开尚未生成的报告可触发PnR，
不能将GUI“打开Timing Report”当作无重布线STA的保证。

因此，本轮无法给出有官方依据的 run sta / read_pnr / read_sdc / write_checkpoint
组合来完成“同一已布线数据库用原0.750ns重新STA”。这些命令未执行，也不作为建议脚本。
这里只能说在四份PDF、指定本地文本格式内未找到，不能证明二进制绝对不支持。
同一路由前提下可从额外不确定度推导slack差异，但这种算术推导不是工具重新STA报告，
不能冒称原SDC验收通过。

## B. 增量入口、所需输入及边界

SUG1220 PDF50–51 / 印刷43–44(72)，set_option 选项语法：

    -inc_place <0|auto|file>
    -inc_pnr <0|auto|file>

手册的可直接引用正式示例：

    set_option -inc_place auto
    set_option -inc_pnr auto

两个选项默认均0。file表示所指定的历史文件，而不是参数字面值“file”。
SUG100 PDF54–55 / 印刷42–43(87)明确：
增量布局复用 .p；增量布局布线复用 .pr。
auto从工程目录自动选择已有对应文件；缺文件会提示；也可手动指定历史文件。
启用“Incremental Placement and Routing”时，“Incremental Placement Only”不可用。
SUG100 PDF98 / 印刷86(87)，Table8-2再次定义：
.p = Incremental placement file；.pr = Incremental placement and routing file。

必须保留的官方文档差异：
SUG1220 PDF51 的 inc_pnr 参数表也写“*.p”，与SUG100两处“*.pr”冲突。
本次没有试运行来裁定该Tcl参数实际接受行为。
可确认官方有auto入口；精确文件形式应在获准的未来非破坏性执行/官方澄清后确认，
不能把未经执行的 .pr Tcl调用冒充验证过的命令，也不能将 .p 改后缀伪装 .pr。

本候选 evidence 中实际已有 WAVE02..06 各一对 .p/.pr；
WAVE04/05分别存在6.8MB左右布局文件和151MB左右布局布线文件。
绝对/相对位置、真实大小及SHA见 HISTORICAL_INCREMENTAL_INPUTS.json。
只做了只读清单/哈希，没有载入或复制这些大型数据库，也未宣称可跨修订直接复用。
其中 WAVE04/05的准确路径为：

    evidence/GOWIN_WAVE_04/gowin/pro_audio/impl/pnr/pro_audio.p
    evidence/GOWIN_WAVE_04/gowin/pro_audio/impl/pnr/pro_audio.pr
    evidence/GOWIN_WAVE_05/gowin/pro_audio/impl/pnr/pro_audio.p
    evidence/GOWIN_WAVE_05/gowin/pro_audio/impl/pnr/pro_audio.pr

Arora V/III支持增量（SUG100 PDF55）。当前Pro目标为Arora V系列；
文档没有给出针对该具体网表、改动后映射匹配率或固定所有对象的保证。
PnR前仍需综合结果和完整器件/约束/工程输入（SUG100 PDF68）。
不能把旧bitstream、.tr.html或saveto导出的Tcl当作 .p/.pr 物理数据库替代品。
SUG1220 PDF24–25 / 印刷17–18的 saveto仅保存工程设计数据/选项到Tcl。
其open_project（PDF21 / 印刷14）打开工程，也不构成恢复物理检查点的承诺。

当前 rebuild.tcl 每次创建新目录、配置源并 run all，options中
inc_place=0、inc_pnr=0；因此现有自动流程不会自动继承WAVE04/05布局。
即使将来使用增量，也需要明确历史输入、来源SHA和匹配性，不能假设新目录auto能发现旧文件。
run pnr是正式PnR流程，不等于routing-only；route_option是算法选择，也不是只运行route的开关。
在所读资料没有找到正式的“只重布线/完全固定旧布局”入口或数据库加载命令。

## C. Replicate Resources、syn_maxfan 与 routing fanout 的区别

SUG1220 PDF46 / 印刷39(72)，官方描述的作用正是减少高扇出并改善时序：

    set_option -replicate_resources 1

0禁用，1启用，默认0。SUG100 PDF51 / 印刷39(87)将其列在Place配置，
并明确只支持Arora V和Arora III；当前Pro系列属于支持范围。
因此它是可在不改RTL功能周期情况下由PnR尝试物理复制的正式选项。
官方措辞是“resources”，没有枚举一定复制哪些FF/LUT/控制网络、复制数量/阈值、
是否绕过preserve/dont_touch，或保证state_2_s0关键路径得到改善。
不能把启用等同于已成功复制、setup/hold均通过；需将来的实际映射/资源/STA报告判定。
这不同于 retiming_resource：复制入口不要求启用retiming，本轮不建议混改功能级流水。

SUG550 §5.11，PDF65–66 / 印刷57–58(90)，明确支持 syn_maxfan，
可能复制 registers 或其他 logic resources 达到最大扇出。正式语法包括：

    object /* synthesis syn_maxfan = value */ ;
    NET "object" syn_maxfan=value;
    INS "object" syn_maxfan=value;
    GLOBAL syn_maxfan=value;

支持模块/entity、port、wire/reg/signal；GSC形式不支持module对象；
port默认指顶层，子模块输入要约束其driver。每个属性仅约束一个对象。
关键排除项（PDF65原文已目视确认）：不适用于clock signals、control enable signals、
reset/set signals。因此不能直接保证对clear/commit控制有效；
需要区分普通D数据逻辑网与专用CE/RESET/SET类网络。
终点为active bitmap D并不足以单独证明其上游FSM控制符合 syn_maxfan 适用范围。
SUG550 PDF39–42 / 印刷31–34还说明GSC/RTL/IDE属性范围与优先级；
同一对象同一属性通常GSC高于RTL、高于IDE配置，不能忽略已有更具体属性。

另有两个名字相近但不能混为一谈的正式选项：
- SUG1220 PDF34 / 印刷27(72)：set_option -max_fanout <value>，
  用于input ports、nets或register output ports，默认1000，属综合配置范围。
- SUG1220 PDF48–49 / 印刷41–42(72)：set_option -route_maxfan <value>，
  是routing优化参数，合法整数1..100，当前Pro默认23。
  SUG100 PDF52 / 印刷40补充：过小可造成route失败，不控制long wire和clock route。
  不能把当前route_maxfan=23解释为已将2048扇出控制复制到每组最多23个消费者。

本轮没有设任何上述参数，也未新增GSC属性。若后续由总控选择实验，
replicate_resources是与现有高扇出症状直接对应的单一PnR选项；
是否使用增量、沿用哪个历史数据库仍需单独保留输入/原始结果，不能凭文档预判成功。

## 证据与核查等级

- SOURCES.json：四份官方PDF绝对路径、版次和文件SHA。
- 各PDF全文提取文本；关键单页txt/PNG保留完整页及页码。
- READONLY_INPUT_SHA256.json：当前91份源码/IP/工程/约束/流程输入SHA。
- frozen_options.tcl.txt / frozen_rebuild.tcl.txt：只读时的原文副本。
- HISTORICAL_INCREMENTAL_INPUTS.json：已有10份.p/.pr路径/大小/SHA；原件只读。
- official_text_search.json及stdout/stderr：对官方安装目录的.tcl/.xml/.ini/.cfg/
  .txt/.json/.html/.md搜索，rg退出1且无匹配；排除license文件。
  未对二进制strings作命令推断，也未执行任何help/EDA。
- FINAL_READONLY_CHECK.json：结束时输入无漂移核对与研究文件清单。

实际等级：官方文档只读研究 + 原始页目视核对 + 文件身份静态核验。
没有命令执行验证、没有新增综合/PnR/STA结果，生产源码继续冻结。
