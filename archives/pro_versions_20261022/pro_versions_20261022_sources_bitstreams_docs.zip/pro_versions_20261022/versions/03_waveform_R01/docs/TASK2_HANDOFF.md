# Task2 — Pro MIDI 控制与主音量软件交接

状态：PASS_TASK2_SOFTWARE。实现、必要软件仿真及自审完成，生产源冻结。
源码安全点见 TASK2_SOURCE_READY.json；该状态供总控统一注册和商业版 EDA 使用，
不代表整机、布局布线、时序或实测通过。未执行设备扫描、烧录、下载或 Git 操作。

## 实现与写集

只修改本候选的 project/src/midi_event_parser.sv、midi_input.sv、
m3_pro_audio_core_r10.sv；新增 extension_controls/pro_master_volume.sv。
测试只写 project/tb/wave_controls/，工具只写 tools/task2_*，
证据只写 evidence/task2_*，文档只写 docs/TASK2_*。
Android、旧 R10、baseline、原仓库及总控拥有的顶层/工程/约束未修改。
既有音频 engine、R06 身份 sidecar、I2S、PLL 和公共事件包保持输入 SHA 一致。

CC7 是全局主音量，作用于 human+score 混合后的实际 PCM，最后成功接受的值生效；
CC25 每通道有效按下轮换音色 0/1，并保留 PC0/1；PC>1 原值送出且不污染有效影子。
CC26 回 page0 现有综合/上飘页面，CC27 选 page1 波形，不切换翻转。
三个按钮分别按通道独立重臂：首次值>=64 生效，<64 重新武装。
CC28 为频谱预留，CC29/30 空；Pitch、CC1、CC64、Note 和 PC 原有语义保留。
MIDI 细节、背压及溢出语义见 TASK2_MIDI_HANDOFF.md。

core 新增 output wire [1:0] extension_page_select，同 40MHz 音频域，
只输出 0/1，复位为0。页面控制不入音频 FIFO，无 display ready/audio gating；
显示端的 CDC 和整帧采纳由 Task3/总控实现。实际底层 MIDI 输入继续使用 uart_rx。

## 数值、复位与采样口径

pro_master_volume 使用低有效异步复位，恢复 12'hFFF 精确单位增益。
仅在最终共享事件 valid && ready 且 type=CONTROL_CHANGE、id=CTRL_VOLUME
时更新寄存器，不改变任何事件 ready/valid。
raw MIDI 7bit 依冻结转换扩展成 12bit：0→0、64→2064、127→4095。
实际 gain 为 Q1.12：4095 特判为4096，其余值原值除4096。
因此127精确单位增益，0精确静音，64约0.50390625。
此处是已明确的定点量化，不是浮点 CC/127 的逐值精确等价。

PCM 是 signed24，乘正 signed14 增益，signed38 乘积覆盖最负样本乘4096；
取绝对值后加2048、右移12，再恢复符号，最近舍入、恰半远离零。
25bit 恢复符号可正确表达绝对值8388608；gain<=unity 不产生新增削波。
无流水拍，缩放在既有 play 寄存器与 I2S 输入之间组合完成。
全 STA 应由总控确认新乘法/舍入路径在实际 Pro 40MHz 下收敛。

obs_tx_left/right 与 u_i2s_tx.pcm_left/right 取同一缩放样本。
在 obs_frame_tick 的 PRE-NBA 边沿，观察器与发送器采用完全相同的一对 PCM；
若接受音量控制与帧边界同沿，该帧沿用旧寄存值，下帧使用新值。
I2S 既有24→16舍入/饱和及 PT8211 LSBJ 时序保持原样。

重要边界：R06 engine 内部身份 sidecar、checksum、commit/result PCM 和相关
metadata 仍描述 pre-volume 引擎输出；只对外 obs_tx_left/right 改为 post-volume
实际 TX。音量变化不改变 engine 帧身份，不把内部 checksum 冒称 post-volume 校验。

## 软件验证

ModelSim SE-64 2020.4。最终有效 vlib/vlog/vsim 命令退出码均0。
命令原文、UTC/耗时、完整 stdout/stderr、输入及依赖 SHA 均在对应 RUN 目录。

| 测试 | 最终原件 | 实际结果 |
| --- | --- | --- |
| 全4096增益值，signed24边界、独立随机双声道、握手、复位 | evidence/task2_volume_r01/RUN_VOLUME_01 | 49152黄金向量 / 49162检查 PASS |
| 实际核心、双音源、串行MIDI音量/页面、外部BCLK/WS/DIN独立解码 | evidence/task2_volume_r01/RUN_CORE_04 | 1266帧 / 2529半帧 / 9192检查 PASS |
| MIDI字节解析、16通道、Running Status/实时/SysEx/坏帧、FIFO溢出/同拍出入队/影子 | evidence/task2_midi_r01/RUN_02 | 162检查 PASS |
| 实际40MHz/31250 baud 8N1 UART 输入链 | evidence/task2_midi_r01/RUN_02 | 109串行帧 / 29检查 PASS |

核心测试使用实际四声部/乐谱适配器/事件 FIFO/音频处理/I2S，未替换音频算法。
为避免把物理 PLL 当作逻辑仿真条件，TB 中只用40MHz直通测试模型替代 TMDS_PLL。
用于真实 engine 保留 LUT1 的模型从用户指定商业版 GW5A prim_sim.v 中原样
抽取 LUT1、MUX2、mux2；源路径、全库 SHA 和抽取 SHA 见 VENDOR_MODEL.json。
核心测试没有验证 Pro PLL 倍频/锁定、DVI 或实际管脚。
独立解码 PT8211 的 BCLK 上升沿、WS0右/WS1左及每半帧末16bit，逐样本比较。
记录正500帧、负437帧、静音但底层DSP非零328帧；页面切换时两源仍占用，
实际核心 audio_underrun=0。没有用层次强制或改状态来伪造声音/控制结果。

音量测试独立 Python 整数黄金模型生成49152行，覆盖全部12bit值；
不调用 RTL 内函数产生预期。核心的采样采用口和串行译码双重核对。
core 的72条警告为6条类型化端口默认 var 提示及66条测试未连接诊断输出提示；
无功能、ROM载入或算术警告。MIDI 编译零错误/警告。

重现入口（从候选根执行，用全新目录名，旧 RUN 不覆写）：

    C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task2_run_controls.py volume NEW_VOLUME_RUN
    C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task2_run_controls.py core NEW_CORE_RUN
    C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task2_midi_run.py NEW_MIDI_RUN

封存/自审入口为 tools/task2_seal_controls.py；只核当前文件与已有 PASS 快照，
不运行 EDA、不操作设备。evidence/task2_volume_r01/ARTIFACT_SHA256.json
覆盖交付、输入快照、原始结果和工具身份；HANDOFF_RECEIPT.json 汇总可机读状态。

## 失败史与自审

所有旧 RUN 保留，不覆盖、不把修复后的成功写回失败目录：
1. 首个核心修改脚本匹配实例文字失败，退出1；生产源未写入，只保存 intake。
   核对实际声明后完成最小变更，记录 attempt01_write_failed.txt。
2. RUN_CORE_01：编译成功，装载退出12，未找到真实 engine 的 LUT1。
3. RUN_CORE_02：官方模型抽取脚本的换行转义导致 Python ValueError，退出1，
   未启动 ModelSim；输入快照及 PRE_RUN_FAILURE.txt 保留。
4. RUN_CORE_03：编译成功，装载退出12；补入 LUT1 后仍缺直接依赖 MUX2。
5. 核对官方原文依赖 MUX2→mux2，一并原样抽取后 RUN_CORE_04 全 PASS。
   此过程没有改 engine 或用自写 identity 替代原语。
6. 一次自动权限审批等待超时，没有启动进程；按返回规则仅重试一次后成功。
   另一次只读核对使用斜杠键读取 Windows SHA 表遇 KeyError，改为规范化路径后
   成功核对；未写源。MIDI 子任务的工具模板解析失败另见其自审记录。

源码自审无阻断。当前四份生产文件与 RUN_CORE_04 冻结输入逐字节同 SHA，
MIDI 两源也与其 RUN_02 一致；模块端口、24/38/25bit数值范围、ready链、
逐通道按钮、溢出影子及原控制回归均已核验。自审不是总控最终签收。

## 待总控接手

新增综合源只需注册 project/src/extension_controls/pro_master_volume.sv。
core 现有文件路径不变；连接 extension_page_select 到可视化 page_select，
obs_frame_tick 到 audio_frame_load，post-volume obs_tx_left/right 到 play_left/right。
总控负责真实顶层、全部源注册、实际 Pro IP 综合/PnR/STA、系统接缝和最终验收。
硬件键盘 CC 瞬时127/0配置、物理 MIDI/音频/显示均未实测。
本独立候选不做 Git 发布；本交付为本地文件交接，尚不宣称总控已接收或验收。
