# Task4 HOLD R04 四源真实系统最终交接

**PASS：全新 directed/audio/full 完成；当前输入和执行快照未变，四源与实际 Task3 READY/模块测试输入一致。只签 RTL 仿真和静态自审，未上板。**

本轮仅写新 `project/tb/hold_r04_system/**`、`tools/task4_hold_r04_*`、`docs/TASK4_HOLD_R04_*` 和 `evidence/task4_hold_r04_*`。未改生产 RTL、SDC、options 或历史证据，未运行旧 runner、EDA、Git、设备；未向 Task3/其他聊天发送消息。

## 当前精确源码和真实依赖

文件事件在 2026-10-22T17:10:40.401008+08:00 接到真实 READY（SHA256 `ed6cfc8f5c6d7b5998f4d9921fcedac24d6581abf88e65b9d5ad87e85afad921`），未频繁轮询文件。启动前验证模块 PASS、全部命令 exit0/passed、14 份 raw 日志 SHA、5 组 PASS marker、无 Fatal/Error；四源当前/冻结 READY/实际模块输入一致。依赖原件：`evidence/task4_hold_r04_dependency/CHECK_001/receipt.json`。

| 关键源 | SHA256 |
| --- | --- |
| project/src/extension_visual/scheduler/pro_score_scheduler.sv | c47ee45641b76ea4d964c8367a51cf65f496efc6502f5ad03b73a78ebdf2ccf5 |
| project/src/m1td_polyphonic_envelope_bank.sv | 31c25b7e6eb22714d01c7d0f0ceb7131b3fb301d1aab54bebd041dace2fb4502 |
| project/src/extension_visual/display/pro_score_display.sv | e32c346f96b79412bf67c99b8177278e7bcdbcc9f2e011aab33d26153da549a0 |
| project/src/m1td_voice_gain_q15_candidate.sv | 21256acd78106a8825e4c452499582736fc369d062c3b8dc6ec887ce55677697 |

相对实际 WAVE05，仅 scheduler 新增 read_word[8]→raw_mem 写端四级 LUT1 INIT2 恒等链；保留 bit24 两级、score14 八级。其他 READ 消费路径保持 WAVE05；没有 R03 全64位消费缓冲。bank 恢复 pre-Hold 原字节，无 generation 捕获缓冲；display/gain 与 WAVE05 一致。对旧 Setup 的实际变更集合恰为 scheduler/display/gain 三份，四源绑定包括未变的 bank。

静态自审 `TASK4_HOLD_R04_STATIC_REVIEW.md` / `evidence/task4_hold_r04_review/READ_001/REVIEW.json`：28 项来源与快照核同，findings=[]。上游模块的加速夹具和 counterfactual 只作依赖背景，不混入本窗自然48k系统计数。

## 独立参考、接口和时钟

参考使用旧 Setup RUN_002/inputs 的六模块：core/frame core/chain/audio_candidate/旧 gain/旧 bank。仅 module/type/guard 重命名，逆变换及最终 seal 重建核同旧冻结原件；未把新缓冲复制到参考。74 个共同生产依赖（含恢复的 bank）一致。

新 DUT 与独立旧核同接真实 MIDI/score/reset/keys，逐40MHz周期比较事件/ready、post-volume TX PCM、I2S、commit/identity/underrun；bank 逐拍比较 phase、slot/frozen/control/math generation、CAPTURE握手、frame_tick优先级和完整 result，并记录分配/释放/退休/复位后分配。音量另用 signed64 Q1.12 黄金，PT8211 LSBJ 独立串行译码，PCM observer 核采用序号。

保持50MHz参考、40/25/125MHz、原48k NCO、H800/V525光栅与96768 tick即2.016s自然lead。PLL/LUT为仿真夹具，DVI明确止于RGB/control边界；不代签物理PLL/串行器/CDC/STA。

## 实际命令与结果

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/pro_waveform_integration_20261022_r01/tools/task4_hold_r04_run.py' directed audio full
```

ModelSim SE-64 2020.4：`E:/FPGA/Bpan/modelsim/modelsim1/win64`。新执行 `evidence/task4_hold_r04_system/RUN_002`；2026-10-22T17:23:43.990515+08:00 至 2026-10-22T17:32:34.053746+08:00。version/vlib/vlog 与三组 vsim 全部 exit0/PASS、未超时、必需标记齐全。131 项输入及实际执行快照封存。UTC原值、完整命令/退出/日志SHA均在 receipt 与各 RESULT。

| 组 | exit | 实耗秒 | 虚拟结束时间 | Errors / Warnings |
| --- | --- | --- | --- | --- |
| directed | 0 | 232.937 | 377703001 ns  Iteration: 0  Instance: /tb_hold_r04_top_regression | 0 / 139 |
| audio | 0 | 9.625 | 55335050 ns  Iteration: 1  Instance: /tb_hold_r04_audio_regression | 0 / 147 |
| full | 0 | 286.859 | 2612528326 ns  Iteration: 0  Instance: /tb_hold_r04_top_regression | 0 / 139 |

真实 UART 完成 BEGIN/DATA/COMMIT/逐条 READ/READ_END/START/STOP/CLEAR，严格核 ACK identity、形状、CRC和READ字节。新增合法边界 ON72@255→OFF72@256→ON75@511→OFF75@512，tick单调且配对完整；写端同时覆盖 bit8 双向翻转、非法高 tick/bit24 拒绝。主体自然lead曲谱仍为 0 ON72、14400 OFF72/ON75、19200 OFF75。

MIDI CC7静音/中量/unity、CC25、Pitch/Mod/Sustain、B3/B2切页、隐藏跟踪继续核验；显示堵塞/故障不得反压音频。短状态command/READ/generation/live故障明确为仿真注入，另有独立真实UART正向链路。以下列出本轮实际输出的全部PASS计数，不拿旧组代签：

### directed

```text
PASS TASK4_HOLD_R04_TOP_PAUSED_DISPLAY_AUDIO_ISOLATION frames=144 drops=111
PASS TASK4_HOLD_R04_BIT24_READ_REJECT captured_one=1 commits_unchanged=7
PASS TASK4_HOLD_R04_DIRECTED aborts=8 identity=4 negative=5 prepare_resets=4
PASS TASK4_HOLD_R04_LEGAL_TICK8_BOUNDARIES commits=4 ff_to_100=1 oneff_to_200=1
PASS TASK4_HOLD_R04_CAPTURE_STABILITY checks=88 poison_cycles=109 resets=4 UART_clear=1
PASS TASK4_HOLD_R04_LIVE_FAULT audio_frames=637 overlay_pixels=5120
PASS TASK4_HOLD_R04_OLD_GAIN_CORE_REFERENCE cycles=15108035 payload14_zero=0 one=2
PASS TASK4_HOLD_R04_TOP_PROTOCOL_PAGE_PCM checks=69 cycles=15108035 frames=18127 human=13 pages=5 mute=24 full=13692
PASS TASK4_HOLD_R04_TICK_WRITE bit8_zero=11 one=4 writes=15
PASS TASK4_HOLD_R04_READ_WRITE_ENDPOINTS identity=109 commits=15 bit8_zero=11 one=4 bit24_zero=108 one=1
PASS TASK4_HOLD_R04_BANK_OLD_REFERENCE cycles=15108030 capture=18127 result=18127 gen_changes=5 frozen_nonzero=14916310 phases=01ff
PASS TASK4_HOLD_R04_BANK_CAPTURE_PRIORITY hs=18127 wait_control=235651 advance=18127 ticks=18127 allocations=5 release=0 retire=0 resets=4 postreset_alloc=4 reused_gen=0
```

### audio

```text
PASS TASK4_HOLD_R04_OBSERVER_STALL frames=96 drops=63 gap=1
PASS TASK4_HOLD_R04_REAL_MIDI_MASTER_VOLUME full=646 mute=80 mid=80
PASS TASK4_HOLD_R04_REAL_CORE_PCM_I2S_MITER cycles=2109167 tx=2531 observed=2531 pixel=2467 words=5059 coexist=2431
PASS TASK4_HOLD_R04_SCOPED_SCORE_STOP human=2 score_off=1
PASS TASK4_HOLD_R04_AUDIO_DISPLAY_RESET_RECOVERY adopted=100 received=99
PASS TASK4_HOLD_R04_AUDIO_OLD_GAIN_REFERENCE envelope4_zero=6045098 one=2808246
PASS TASK4_HOLD_R04_BANK_OLD_REFERENCE cycles=2213334 capture=2654 result=2654 gen_changes=5 frozen_nonzero=2133314 phases=01ff
PASS TASK4_HOLD_R04_BANK_CAPTURE_PRIORITY hs=2654 wait_control=34502 advance=2654 ticks=2656 allocations=5 release=1 retire=0 resets=1 postreset_alloc=2 reused_gen=0
```

### full

```text
PASS TASK4_HOLD_R04_TOP_PAUSED_DISPLAY_AUDIO_ISOLATION frames=144 drops=111
PASS TASK4_HOLD_R04_NATURAL_FULL_LEAD_SCORE events=4 concurrent_cycles=15999998
PASS TASK4_HOLD_R04_BIT24_READ_REJECT captured_one=1 commits_unchanged=4
PASS TASK4_HOLD_R04_LEGAL_TICK8_BOUNDARIES commits=4 ff_to_100=1 oneff_to_200=1
PASS TASK4_HOLD_R04_CAPTURE_STABILITY checks=52 poison_cycles=53 resets=1 UART_clear=1
PASS TASK4_HOLD_R04_LIVE_FAULT audio_frames=637 overlay_pixels=5120
PASS TASK4_HOLD_R04_OLD_GAIN_CORE_REFERENCE cycles=104501099 payload14_zero=1 one=2
PASS TASK4_HOLD_R04_TOP_PROTOCOL_PAGE_PCM checks=42 cycles=104501099 frames=125400 human=10 pages=7 mute=24 full=120965
PASS TASK4_HOLD_R04_TICK_WRITE bit8_zero=8 one=4 writes=12
PASS TASK4_HOLD_R04_READ_WRITE_ENDPOINTS identity=53 commits=12 bit8_zero=8 one=4 bit24_zero=52 one=1
PASS TASK4_HOLD_R04_BANK_OLD_REFERENCE cycles=104501097 capture=125400 result=125400 gen_changes=4 frozen_nonzero=104424409 phases=01ff
PASS TASK4_HOLD_R04_BANK_CAPTURE_PRIORITY hs=125400 wait_control=1630200 advance=125400 ticks=125400 allocations=4 release=2 retire=1 resets=1 postreset_alloc=1 reused_gen=0
```

## 失败、封存及接手边界

准备阶段两次非零（路径键比较、审查基线缺文件）和 RUN_001 新增测试用法错误均保留，见 TASK4_HOLD_R04_FAILURE_HISTORY.md；修正仅涉及新测试，旧 prepare abort 断言与生产源未改。所有新非PASS RUN均由最终seal枚举。warning没有抹除；最终三组无 Fatal/Error。gen复用计数若为0不宣称已覆盖，directed/audio退休0也按实际计数保留。

机读就绪 `docs/TASK4_HOLD_R04_SOURCE_READY.json`，最终 `evidence/task4_hold_r04_final/SEAL_001/receipt.json`。seal核当前/执行快照/六模块参考/依赖日志/静态审查/旧五份封存全部身份，不重新执行测试；历史失败和原件不改写。任一源码、TB或共同依赖变化须绑定新版本。

总控拓展任务1接手该精确四源，按商业版 Gowin V1.9.12.04 标准设置完成构建和 STA，核实际恒等链保留及所有 Setup 严格 >0.500ns、Hold/Recovery/Removal/Pulse 全通过。24个相关恒等LUT只是RTL估计，不等于真实保留数。本窗不签物理时序、FS放行或设备/板卡结果。
