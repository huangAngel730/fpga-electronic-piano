# 本轮受控变更说明

用户在拓展任务1明确授权将既有波形接入 Pro，并于 2026-10-22 提供
控制映射图片与替换要求。适用范围仅本独立候选副本，非团队仓库共享
生产顶层。原 R10、baseline 和原失败证据保留。

新增核心只读 PCM/页面接口，按真实 I2S frame-load 取样；显示分支
增加 FIFO/mailbox、左声道窗口、页面单比特同步和帧边界提交，以及
RGB/DE/HS/VS 等龄流水线。MIDI 新增 CC7、CC25/26/27；其余控制保持。
不改变顶层端口或引脚、50/40/25/125 MHz 时钟、音频复位和功放极性。
GPRJ 与根 rebuild.tcl 同步注册新增源文件，沿用真实 Pro PLL/DVI IP。

新增 CDC 只豁免明确首级捕获 D 和本地同步器异步 CLEAR；80 位稳定
payload 源寄存器至目的寄存器 max=40 ns、min=0 ns，逐项检查实际
报告非空及生效情况。所有时钟仍相关分析，不添加整域 false path。
新增音量路径、显示流水线与原音频输出仍按原时钟/不确定度约束验证。
旧码流不能代替新候选综合、布局布线和时序结果。

观察边界说明：`obs_tx_left/right` 在本候选为 master-volume 后、实际
TX pre-NBA 输入；原引擎内部 R06 sidecar 的 checksum/identity/clip
继续表示 master-volume 前的引擎 PCM。其 metadata PASS 不等于
volume 后 PCM 校验。新波形观察器只借用相同 frame-load valid 时序，
自行捕获 post-volume 的左右声道并生成独立连续 ordinal。

首轮 GOWIN_WAVE_01 综合成功，但 SDC 原 payload_hold FF 集合为空，
TA2003 阻断布局布线；失败原件保留。实际综合网表
visual_mailbox_cdc_0 把 payload_hold 作为 [79:24] 输入；桥中
queue_queue_* BSRAM 的 DO 直接驱动该输入，CLKB=core_clk、CEB=pop。
右声道因左波形不使用被优化。后继约束保留 max40/min0 数值和精确
dst_data 目的集合，以 core_clk 启动集合纳入实际 BSRAM clock-to-out
弧；不更改RTL、时钟或首级同步例外，待新 PnR 报告逐位核验。

GOWIN_WAVE_02 完整实现退出0，但真实STA不通过：Setup +0.011 ns，
Hold -0.030 ns/1端点，Recovery +2.856 ns、Removal +0.023 ns、
最小脉宽 +6.841 ns；50约束全部active且两组新增bundle非空通过。
唯一违规为 scheduler/held_payload_14_s0 到
display/u_score_mailbox/payload_hold_14_s0，同core域原score短路径。
后继只对这两个精确寄存器增加更严格min1.000ns布线下限；大于原
0.750ns hold uncertainty，其他数据/时钟/复位要求均保留。未改RTL，
新仿真源码继续与现有已通过输入逐字节同SHA。失败报告/码流留原地，
不作为可用新版交付；后继必须重新核全部STA和该路径实际数据/约束。

约束自审补充：min1.000 是更严格的最小延迟/hold 时序检查，不能把它
简化为原始布线延迟恰为1ns；本工具仍会叠加原0.750ns uncertainty和
器件库hold要求。新增例外只限这对寄存器，保留全部setup/复位检查。
只读子智能体未发现方向、范围或放宽定义问题，仍待新报告非空通过。

无本轮设备扫描、UART 实物通信、下载或上板许可；完整 C9、精确最小
N/尾窗证明不随本任务签署，仍不声称板级验收。

用户随后明确要求最终 Setup 严格大于0.500ns，且不改频率、不分频。
GOWIN_WAVE_03 完整实现 Setup +0.011ns，不满足该新增标准；Hold仍有
-0.002ns/1端点，原score payload更严格min1检查已达+0.147ns。
第二个自然短路径为 slot_velocity_38_s0 至 lane[3] piano 的
attack_samples_left_6_s1，仅对此精确寄存器对再加更严格min1ns；
不放宽原不确定度或时序，不修改音频RTL。02/03报告及FS继续原位保留。
根据02/03实际 Setup RAM输出至scheduler active/divider使能路径，
Task3新增 READ捕获、格式、活动音符查表、生命周期判定及提交流水级。
新增周期在取未来anchor之前，保持120帧/96768tick lead及原时钟；
新阶段均保留STOP/CLEAR、身份失效检查、复位与严格音符生命周期。
必须以新源重新做模块/系统仿真与完整商业版实现，实际结果另存新目录。
最终交付门禁新增 Setup>0.500ns；其他STA、实际例外、IP/引脚检查保持。

GOWIN_WAVE_04 完整实现退出0：Setup +1.529ns，已达到用户阈值；
Hold -0.369ns/4端点，Recovery +1.693ns、Removal +0.006ns、Pulse
+6.960ns，52约束全部active，实际引脚与R10一致。由于Hold未通过，
该轮仍拒收；报告和FS原位保留，不作为最终版。四个路径分别为：
score payload14→mailbox（更严格min1检查-0.369ns）；fatal_live_pixel→
live_end_y19（-0.069ns）；lane2 envelope20→gain DSP B4（-0.013ns）；
新read_word24→raw_mem DI8（-0.008ns）。成功的精确audio min1为+0.656ns。
不再叠加新约束；保留所有原时钟、uncertainty及两条严格min1。
在这些实际短数据锥增加保留的LUT1 INIT2恒等缓冲，沿已验证项目惯例，
不增加采样/事件周期或改变数值；需新模块/全系统仿真和实际网表保留
数量核验，再做新完整商业版实现。Task3/4独占新写集见置顶任务文件。

GOWIN_WAVE_05 完整实现：Setup+1.478ns，Hold-0.057ns/1端点，
Recovery+2.523ns、Removal+0.006ns、Pulse+6.970ns；两个严格min1
均实际非空通过，20个新增LUT全部保留，原四个短路径已修复。
仅余read_word_8_s0至raw_mem DI8，与04的tick位24属于同一32位
tick写字段；SDC和所有频率不变，将两级LUT扩展至整32位字段，
上32位事件字段直接保持，新增read缓冲64个、总82个。新R02就绪单、
模块/全系统证据独立，05报告/FS和R01就绪/快照/失败史保持原位。

GOWIN_WAVE_06：Setup+0.212ns、Hold-0.093ns/11端点，拒收并保存原
FS/报告；R02功能全组及82个显式u_identity实例保留通过。tick原短路径
不再违规，新最差Setup为state2→active bitmap D，23.709ns数据延迟中
20.648ns为route，两节点各fanout1000。原位保留全部R02证据。
SUG1220-2.1E印刷p39明确replicate_resources在PnR阶段复制高扇出资源，
SUG100-4.4.7E注明Arora V支持。后继只将root options.tcl及GUI
Replicate_Resources同步启用，RTL/IP/ROM/时钟/SDC不变。
官方run支持syn/pnr/all（印刷p16–17）；以复制到新目录的同SHA综合网表
执行open_project/run pnr，跳过无变化的综合，仍完整重新PnR/STA。
复用来源与VG SHA、实际入口、前后输入核同分别记新构建回执。
不尝试未有官方入口支持的run sta，不把更改时序报告当作物理修复。

GOWIN_WAVE_07 自动补跑综合后完成PnR，Setup+1.568ns、Hold-0.134ns/
6端点，仍拒收；原生exit0不代替STA。原helper的“网表复用不变”假设
被自动综合打破，原FAIL回执保留，未用来源纠正脚本将此STA失败版改成PASS。
新增违规含generation短传输、DVI数据入串行器及复制的prepared_key；
不继续添加更多功能缓冲，RTL/R02全部功能证据仍冻结。
后继恢复与WAVE05相同replication0，使用其真实.pr作增量物理参考，
Root/pnr_reference复制保留.p/.pr与原始SHA；旧文件不移动、不修改。
Tcl/GUI同步inc_pnr完整路径。SUG100两处正式定义.pr用途；SUG1220表中
*.p有文档差异，本轮按实际工具执行结果确认，不预称已经验证文件入口。
新执行恢复完整run all，所有时钟、SDC、功能周期不变，必须重新核完整
STA/实际引脚/例外，参考数据库本身不提供通过证据。交付包保留该必需输入。
