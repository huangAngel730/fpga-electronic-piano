# Task4 HOLD 定版静态自审

本次固定三源相对旧 Setup RUN_002 的完整 diff 及所列必要上下文中，未发现具体阻断；`findings: []`。SOURCE_READY、READY 冻结三源、模块 RUN_02 实际输入与当前三源 SHA 均已核同。

| 当前文件 | SHA256 |
|---|---|
| project/src/extension_visual/scheduler/pro_score_scheduler.sv | a03c156037e83c72942289b68c5ca874c686a2c5afe873675c7d65a069e60645 |
| project/src/extension_visual/display/pro_score_display.sv | e32c346f96b79412bf67c99b8177278e7bcdbcc9f2e011aab33d26153da549a0 |
| project/src/m1td_voice_gain_q15_candidate.sv | 21256acd78106a8825e4c452499582736fc369d062c3b8dc6ec887ce55677697 |

静态确认如下：

- 四类新增链均使用 `LUT1 INIT=2'h2`，与已读 GW5A 逻辑模型的 0→0、1→1、X→X 一致。payload[14] 八级；read_word[24]、fatal_live_pixel、每个 gain 的 envelope[4] 各两级。未增加时序级，组合传播及仿真 delta 收敛不构成新增时钟周期。
- scheduler 的 98 位 payload 和 64 位 raw 写字拼接保留原位序；READ_COMMIT 仅将 raw RAM 写数据 RHS 换为恒等组合字。命令优先级、身份校验、寿命检查、运行 offer 与 lead 未修改。
- display 仅在 `fatal_live_pixel` 到 `u_live.video_desync` 的支路加入恒等链；live 的独立 reset/flush/人事件路径、像素流水及 negedge-pixel DVI reset 保留。
- gain 的 envelope 拼接仍为 16 位，再零扩展到 signed17；signed33 乘法、算术右移 15 位、输出截取及 PCM 追加八个零均未改变。调用者仍有四路相同 gain 实例。
- 将上述新增恒等结构替换回原表达式后，三份完整文本分别等于 RUN_002 基线。这项文本核对支持无端口、时钟、复位、状态控制及周期变更；并非综合网表或物理时序证明。

`docs/TASK3_HOLD_SOURCE_READY.json` 和模块回执 SHA 已绑定于机读结论。已核模块十份原始日志身份及 PASS/Fatal/Error 行：gain 48000 个黄金比较、scheduler 56 例、display 1276726 像素比较均由 Task3 原回执报告 PASS，本窗没有重新执行。

模块边界：scheduler 的 sample_tick 为每 32 个 40 MHz core 周期一次，即 1.25 MHz 加速夹具；display 使用真实 40/25/125 MHz 与 800×525 raster，但 waveform 输入为 500 kHz 夹具，DVI 为 RGB/control 边界模型。模块证据不代签自然 2.016 秒整机 lead 或真实 core PCM/I2S 对照。原 RUN_01 的首次 live 发布等待条件失败及启动环境事件已在上游保留，本次复制其回执说明。

封存入口：`evidence/task4_hold_review/READ_001/REVIEW.json`。其中 18 项 `sources` 每项包含绝对当前路径、sha256、read_scope 与 snapshot；另保存完整 `THREE_SOURCE_DELTA.diff`、精确源/基线/READY/模块输入快照和十份模块原始日志。

按 RTL 实例估计新增 20 个 LUT1 不等于实际综合保留数量。真实 LUT 数量及全部 STA（含严格 min1、Setup 严格大于 0.500 ns）由总控拓展任务1验收。父窗负责新 directed/full/audio 与独立旧 gain 参考闭包，本结论不代签其结果。

本窗只进行静态阅读、身份核对及指定证据写入，未运行编译、仿真、EDA、设备或 Git；未修改生产源、测试、父 runner 或约束，未向 peer 通信。
