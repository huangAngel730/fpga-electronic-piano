# Task3 Hold R03 模块测试交接

RUN_01全PASS，无本轮失败，未编辑生产RTL。新测试/runner/evidence/docs独占hold_r03写集，旧R01/R02测试、runner和最终receipt对照已通过冻结输入确认未变。ModelSim SE-64 2020.4；vlib/vlog/5个vsim全退出0，正向PASS与Error/Fatal门禁齐套，原有relaxed-input-port警告完整保留。

精确四源SHA、全部实际SV/include/ROM闭包、before改名参考身份、命令/时间/exit、原始stdout/stderr与计数见 `evidence/task3_hold_r03_tests_r01/RECEIPT.json`。当前源、ROM/include与冻结输入逐字节一致；ROM根别名也逐字节核对，未使用假ROM。

## READ实际消费者

`tb_hold_r03_identity` 无时钟64位逐bit0/1/X共192次、walking-one/zero128、混合4、随机2048，总2372次，检查read_word_buffered与raw_mem_write_word完整64位等于原词；score14另3次。

`tb_hold_r03_consumer` 用实际READ握手锁存原合法包，再将buffered出口反事实改为不同合法channel15/note84/tick7包；下一真实READ_FORMAT拍必须prepared_key/is_on/5*tick采用出口，READ_COMMIT必须previous_tick/raw_mem/active也采用出口，而原read_word保持源包。再分别改kind2与孤立OFF验证格式/lifetime拒绝，计5次，证明新缓冲确实在prepared_key等消费者前，不能仅缓冲RAM写口来冒充通过。force任意词是有意消费者/故障证明，不当作合法外部score入参。

原适用scheduler回归以新top/marker复制到新目录重跑：56完成回执、18负例、8新态STOP/CLEAR、4复位、22identity变化、512 QR、5632ceil、满512准备16928core周期；READ后poison、配对/高key、高tick、120frame/96768tick与RUN背压保持通过。sample_tick每32core拍为软件加速。

## 真实envelope bank

`tb_hold_r03_bank` 实例化本次bank及精确before bank，二者都用真实router/sustain/allocator/control/pitch/four DDS+ADSR与冻结ROM，未stub bank或算法。128位capture总线在时钟停止时逐bit0/1/X384次、walking256、混合4、随机1024，总1668次，完整case-equality同时确认capture出口恒等、observer和control输入保持原始总线。

正常事务逐拍miter153670核心周期，4955次CAPTURE按公开原始generation的PRE_NBA值独立核frozen结果，4950真实结果和4952推进（SNAPSHOT/HOLD取消已计算的两次推进不回滚）；结果全部waves/envelopes非零。10次真实分配包括多source/channel同note、第五音LRU抢占与generation递增，真实NoteOff后按原4800样本Release推进4900次完整请求，出现一次真实retire，再复用该slot并核generation递增。没有修改生产timebase或强迫release_done。

WAIT_DISPATCH/SETTLE/CAPTURE/WAIT_CONTROL/ADVANCE/SNAPSHOT/HOLD七态分别实际frame_tick取消，跟踪每req_id至多一次advance/result、取消后不漏旧结果；下一拍DRAIN排入新请求并正确完成。WAIT_CONTROL中异步复位清理请求/身份；结果背压下完整304位输出保持。

另一次刻意只force capture_generations出口错误，真实CAPTURE只能改变frozen副本，原observer/control输入不变；live/math identity不匹配必须DRAIN而不产出结果。该故障注入与正常before-miter分别计数，不把故意不等的参考结果算作miter通过。

## 显示适用回归及边界

`tb_hold_r03_display` 真实40/25/125MHz、H800/V525完整光栅，before当前精确显示字节改名，1276726像素/2042722core周期一致，含active-live420000像素、真实fatal760096像素、页切换/复位和3次fault链0/1/X。没有重跑无关gain48000组，当前gain只随完整闭包封存SHA。

DVI仍是明确RGB/DE/HS/VS输入边界替身，未签TMDS或PLL物理行为。bank请求尽快握手推进，scheduler tick和display500kHz波形load也是加速fixture，不能代替真实48k/完整2.016秒系统回归。组合恒等的#1只等待delta收敛，无新增周期或可签的物理delay。

该hold特征预计read128+generation512+score8+live2+gain8=658 LUT1；实际综合保留数与物理Hold/严格min1/Setup>0.5ns由总控EDA核。没有EDA、实物、Git或跨对话消息。

复现用新输出名：`C:/Users/songdongkuan/miniconda3/python.exe -X utf8 -B tools/task3_setup_hold_r03_tests_run.py NEW_RUN_NAME`。
