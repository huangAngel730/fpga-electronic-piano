# Task4控制与音量只读自审

范围：候选midi_event_parser.sv、midi_input.sv、m3_pro_audio_core_r10.sv相对SOURCE_INPUTS所指原件的完整diff，以及新增extension_controls/pro_master_volume.sv全文。未修改被审文件。此项是Task4内部自审，不启动外部审核员制度。

本次差异范围未发现具体阻断：

- CC7生成原64位事件ABI中的CTRL_VOLUME；仅最终共享valid&&ready更新全局主音量。PCM缩放位于真实引擎play寄存器到I2S输入之间，obs_tx_left/right指向同一post-volume样点，无新增ready或音频门控。
- Q1.12增益4095提升到4096实现精确unity，其余值原值除4096；signed38乘积、绝对值加2048舍入后恢复符号，覆盖signed24最小值的绝对值8388608；gain不超过unity，无新增上溢需求。Task4使用独立longint整数模型及真实采用口验证，未调用RTL函数产生黄金。
- CC25/26/27首次raw7>=64生效、raw7<64重臂，各通道各按钮独立。CC25只在可成功进入本地FIFO时推进0/1影子，保留PC0/1的队列顺序；被丢弃的按下仍消耗，须松开才重试，属于已写明的有界溢出语义。
- 页面0/1为同core域稳定状态，CC26/27不进入公共音频FIFO、不依赖其ready。CC28/29/30未加入功能；既有Pitch、CC1、CC64、Note、PC分支不改。midi_input只增加page直连端口，UART接收器未修改。
- core保留原I2S时序、时钟、复位、四声部和score adapter。内部R06 checksum/identity继续表示pre-volume PCM，不能把其PASS冒称post-volume数据校验；本次观察器使用独立ordinal并捕获实际发送样点。

核心系统证据见evidence/task4_system/RUN_002（实际top短测）及后续RUN_004。只读审查不能替代新增组合乘法/舍入路径的商业版STA；本窗口不运行EDA，也不签物理PLL、TMDS串行器或板卡。

精确输入身份由执行RUN的inputs及最终Task4总收据绑定。原件、首失败和修改后的测试快照均保留；旧RTL/PC测试未重跑。
