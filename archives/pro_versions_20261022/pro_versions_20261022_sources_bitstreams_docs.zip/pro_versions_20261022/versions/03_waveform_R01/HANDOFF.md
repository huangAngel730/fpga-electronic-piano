# Pro 波形与键盘控制接入 R01

精确源码功能仿真、商业版综合/布局布线和当前约束下STA已通过。
全部Setup检查最小余量 **+2.697ns >0.500ns**。
保持50/40/25/125MHz和原分频，交付后按用户要求暂停修改。未下载或上板。

## 入口

- 工程 `project/pro_audio.gprj`；重建根目录 `rebuild.tcl`。
- 码流 `bitstream/pro_audio_score_slider_waveform_R01.fs`；38942210字节。
- SHA256 `ab553fbfa5bd54328a1a66f5703aa3d0b0768711d8d8127ac2b7b198211f4e64`。
- Gowin商业版V1.9.12.04，GW5AST-LV138FPG676AC1/I0、C。

首次重建：在本包根目录运行 `python -B -X utf8 tools/build_candidate.py GOWIN_REBUILD_01`，
选择尚未存在的名称。使用普通完整流程，无需准备外部增量数据库。

## 使用

K1 CC7总音量；B1 CC25轮换0/1音色，作用于新音符；B2 CC26返回双滑块合成页；
B3 CC27波形；B4 CC28预留频谱；B5/B6空。Pitch、Mod CC1、SUS CC64保持。
按钮建议瞬时127/0；>=64按下、<64重臂。真实键盘配置仍待实测确认。
波形为音频发送器实际采用的音量后左声道PCM，2048样本/512列min-max。
帧边界切页，演奏、曲谱、隐藏页面跟踪继续。原MIDI、音频、HDMI引脚、
复位与功放极性不变。详细使用和接线见README.md。

## 验证

调度器增加读取锁存、格式、生命周期查表/检查及提交流水级。
新增准备周期在选择未来anchor前，120帧/96768tick lead及整数ceil保持。
按用户允许的后备方案采用第五轮准确基线，仅RAM写字bit8新增四级恒等LUT。
原bit24两级、score14八级、显示2级和gain8级保持，这类补偿共24个显式LUT。
bank及其余生产源、CST/SDC/options/GUI与第五轮逐字节核同，未增加寄存器周期。
具体模块、真实RAM消费反事实、bank对照及系统组计数见绑定的R04原件。
新全系统回归包括定点异常/复位与自然2.016秒lead，保持原时钟与H800/V525。
具体计数、源SHA、命令、时长、退出码与PASS日志见HANDOFF.json。

`GOWIN_WAVE_14`原生Setup +2.697ns、Hold +0.000ns、
Recovery +2.498ns、Removal +0.009ns、
最小脉宽 +6.970ns；Setup/Hold违规端点均0。
实际56位波形bundle、全部时序例外、真实DVI reset及实际引脚分别核验。
验收使用第五轮原SDC及CST，逐字节核同；原0.750ns hold uncertainty及两条min1保持。
外部引脚与DVI释放FF位置保持；当前普通流程不使用后期失败的内部payload61固定位置。

## 旧结果保留

各次未验收码流及原报告保留，包括：
- `evidence/GOWIN_WAVE_02/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_03/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_04/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_05/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_06/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_07/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_11/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_12/gowin/pro_audio/impl/pnr/pro_audio.fs`
- `evidence/GOWIN_WAVE_13/gowin/pro_audio/impl/pnr/pro_audio.fs`
02/03 Setup均+0.011ns；04 Setup+1.529ns但Hold未通过，均仅作历史留档。
05 Setup+1.478ns但仍1个Hold未通过；同目录保留原报告，SHA见HANDOFF.json。
06 Setup+0.212ns、07 Setup+1.568ns亦因时序不满足拒收；08/09路径失败没有FS。
11 Setup+1.568ns/Hold-0.334ns、12 Setup+1.014ns/Hold-0.043ns均未验收，原件保留。
13 Setup+0.150ns/Hold-0.502ns未验收；用户允许第五轮后备，所有原件继续保留。
10的无空格路径已能读取，但匹配不足而回退，按失败方法受控停止；无FS。
pnr_reference与project中的旧数据库仅作失败历史留存，当前普通流程不使用它们。
所有首失败保留；原185份baseline与633份R10原件复核未改。
未执行设备操作、Git发布、完整C9或最小N/尾窗证明；自审不代替M2/实机验收。
