# 软件自审（2026-10-22）

范围：本窗口新建的PC程序、实际桥接固件、脚本和自检；未启用审核员/预审员，不代签M2或整机验收。

确认：v2版本独立、命令1..11、原始记录字节格式不变；READ ACK20/其他12；无桥合成ACK；显式READ_BEGIN/END和逐字节比对；COMMIT不START；START再次核完整读；STOP/CLEAR等待对端最终ACK；NACK立即失败；断线/CRC/中断GATT写不会推进成功；所有等待有限，持久租约不由桥超时释放。客户端序号不回卷；查询/控制与最大上传包数分离。SDK和旧候选原件不写。

已观察并修正的问题：

1. 默认沙盒初始化失败两次、Node内核同故障：无进程/源码变更。受控require_escalated调用自动批准后完成既定写集，未扩大目录。原报错见evidence/INITIAL_FAILURES.json。
2. 首次真实IDF构建成功，但旧候选同时选择USB和UART_NONE，Kconfig实际选择无控制台；首轮stdout/stderr及镜像已保留。去除旧选项、明确USB主控制台，最终由修正后的defaults在新build_release/sdkconfig.release上干净构建通过。另修正本机ESP_ROM_ELF_DIR到实际20241011目录，保留首轮诊断。
3. 自审指出先STOP/ABORT再上传时恢复序号1/2会与DATA/COMMIT复用。acceptance_r03_alias_counterexample实际退出码1、RESPONSE_COMMAND，失败源码和日志均保留。最终查询/控制从8192开始，上传最多到4097，每个客户端只进行一轮上传。acceptance_r04_final全部23项PASS，包括注入ABORT延迟合法重复ACK的反例。
4. 缺Bleak模块是现环境事实：原命令退出码1，未安装。fakeBLE测试覆盖实际适配代码，但不证明WinRT/无线已运行。PC requirements固定版本声明只属于依赖要求，未声称本机已具备。
5. 现有SDK报告v5.4.2-dirty；只读取HEAD/真实编译依赖SHA留证，未“清理”SDK以掩盖事实。目标Flash大小及芯片最小revision仍按实际构建报告保留，实物核对未执行。

最终源码身份与运行时对应：acceptance_r04_final/receipt.json含精确源码SHA和只读snapshot；idf_build_r03_clean/receipt.json含固件源SHA、环境、命令、退出码及镜像SHA。最终封存时再次核SHA一致，不重跑已通过测试。NimBLE主任务调度和物理UART溢出仅有源审/构建证据，仍需实物。


## 总控要求的4MB收尾

官方ESP32-C3-Zero/-M页面明确ESP32-C3FH4叠封4MB，型号已由用户确认，因此不再沿用IDF默认2MB。新增FLASHSIZE_4MB=y、FLASHSIZE_2MB=n，全新build_release_4mb/sdkconfig.release_4mb真实构建成功（idf_build_r04_4mb_clean）。应用与bootloader头部尺寸代码均为2（4MB），离线esptool解析校验有效；min_rev仍3。旧2MB镜像、ELF、配置及交接清单完整封存在followup_4mb_r01/previous_2mb_release和PREVIOUS_DELIVERY。

SDK只读Git调用均GIT_OPTIONAL_LOCKS=0，无SDK写入或配置修改。根及25个子模块当前HEAD/子模块指针相符；905条差异均为100755→100644可执行位，忽略mode的HEAD内容差异为0。3876个封存SDK依赖的实际原始blob与跟踪OID相同，0不一致；在封存集合中idf.py、protobuf-c.h两件仅涉及mode。当前证据支持dirty由mode差异触发、未发现涉及本次依赖的内容变化；不能由差异追溯具体历史操作人或发生时刻，不改标记掩盖。原4150项SHA保留，另封存4MB依赖清单并再次验证原清单未变。

辅助头部检查首轮把SDK中的esptool.py脚本目录加入sys.path，遮蔽已安装的esptool包，导致ModuleNotFoundError，退出1；只读定位的rg也因该错误目录推断退出1。原始检查命令、错误和退出码保留IMAGE_HEADER_CHECK_FAILED_R01.json。修为直接使用现有IDF Python环境中的esptool包，其ESP32C3ROM.FLASH_SIZES映射逐件核对应用/bootloader头部为4MB，复验退出0。未改固件或SDK，最终封存器增加该检查退出码断言。
