"""Device-free acceptance: real GCC bridge executable plus fake Bleak backend."""
import asyncio
import binascii
import json
from pathlib import Path
import struct
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'pc'))
from protocol import (Frame, decode, response, validate_response, NackError, crc,
                      BEGIN, DATA, COMMIT, ABORT, STATUS, READ, START, STOP, CLEAR,
                      READ_BEGIN, READ_END, ACK, NACK, META)
from score import encode_score, decode_records
from midi_import import convert_midi, MidiImportError
from ble_transport import BleTransport, SERVICE_UUID, RX_UUID, TX_UUID, STATUS_UUID
from client import ScoreClient


def score(count=2, score_id=17):
    events=[]
    for n in range(count//2):
        events.extend([dict(tick=n*20,type='note_on',channel=0,note=60,velocity=100),
                       dict(tick=n*20+10,type='note_off',channel=0,note=60,velocity=0)])
    return dict(schema=1,sample_hz=48000,score_id=score_id,events=events)


class Peer:
    """Independent logical peer; proves client behavior, never substitutes for RTL."""
    def __init__(self):
        self.records=b''; self.score_id=0; self.staging=None; self.cache=None
        self.playing=False; self.scope=False; self.index=0; self.verified=False
        self.commits=0; self.starts=0; self.commands=[]; self.drop={}; self.corrupt=None
        self.control_pending=False; self.delay_control=0

    async def handle(self,raw):
        q=decode(raw); self.commands.append(q.command)
        if self.cache and self.cache[0]==raw:
            reply=self.cache[1]
        else:
            error=0; event=None
            if q.command in (BEGIN,DATA,COMMIT,ABORT) and (self.playing or self.scope): error=15
            elif q.command==BEGIN:
                sid,count,length,checksum,hz=struct.unpack('<IHHHI',q.payload)
                if not q.session or q.seq or q.offset or count<1 or count>512 or length!=8*count or hz!=48000: error=11
                else:
                    self.staging=dict(sid=sid,count=count,checksum=checksum,data=bytearray(),seq=1,session=q.session)
                    self.verified=False
            elif q.command==DATA:
                st=self.staging
                if st is None or st['session']!=q.session: error=5
                elif q.seq!=st['seq']: error=6
                elif q.offset!=len(st['data']): error=7
                else: st['data'].extend(q.payload); st['seq']+=1
            elif q.command==COMMIT:
                st=self.staging
                if st is None: error=5
                elif q.seq!=st['seq']: error=6
                elif len(st['data'])!=st['count']*8: error=8
                elif binascii.crc_hqx(st['data'],0xffff)!=st['checksum']: error=9
                else:
                    self.records=bytes(st['data']); self.score_id=st['sid']; self.staging=None
                    self.commits+=1; self.verified=False
            elif q.command==ABORT: self.staging=None
            elif q.command==READ_BEGIN:
                sid,count,reserved=struct.unpack('<IHH',q.payload)
                if self.playing or self.scope: error=15
                elif reserved or (sid,count)!=(self.score_id,len(self.records)//8) or not self.records: error=13
                else: self.scope=True; self.index=0; self.verified=False
            elif q.command==READ:
                if not self.records or q.offset>=len(self.records)//8: error=13
                elif self.scope and q.offset!=self.index: error=13
                else:
                    event=self.records[q.offset*8:q.offset*8+8]
                    if self.scope: self.index+=1
            elif q.command==READ_END:
                if not self.scope or self.index!=len(self.records)//8: error=13
                else: self.scope=False; self.verified=True
            elif q.command in (START,STOP,CLEAR):
                if q.command==START:
                    sid,count,reserved=struct.unpack('<IHH',q.payload)
                    if self.scope or self.playing: error=15
                    elif reserved or not self.verified or (sid,count)!=(self.score_id,len(self.records)//8): error=13
                if not error:
                    self.control_pending=True
                    await asyncio.sleep(self.delay_control)
                    self.control_pending=False
                    if q.command==START: self.playing=True; self.starts+=1
                    else:
                        self.playing=False; self.scope=False
                        if q.command==CLEAR:
                            self.records=b''; self.score_id=0; self.verified=False; self.staging=None
            elif q.command!=STATUS: error=3
            reply=response(q,error,committed=bool(self.records),active=self.staging is not None,
                           count=len(self.records)//8,score_id=self.score_id,
                           received=len(self.staging['data']) if self.staging else 0,event=event)
            if not error: self.cache=(raw,reply)
        if self.drop.get(q.command,0):
            self.drop[q.command]-=1; return None
        if self.corrupt:
            reply=self.corrupt(q,reply)
        return reply


class Characteristic:
    def __init__(self,properties): self.properties=properties


class FakeBleak:
    def __init__(self,address,disconnected_callback,peer,version=2,missing=False,stall=False):
        self.peer=peer; self.disconnected_callback=disconnected_callback; self.is_connected=False
        self.services=self; self.buffer=bytearray(); self.callback=None; self.version=version
        self.writes=[]; self.missing=missing; self.stall=stall; self.disconnected=False
    def get_service(self,uuid): return self if uuid==SERVICE_UUID and not self.missing else None
    def get_characteristic(self,uuid):
        return Characteristic({RX_UUID:['write'],TX_UUID:['notify'],STATUS_UUID:['read']}[uuid])
    async def connect(self): self.is_connected=True
    async def disconnect(self): self.is_connected=False; self.disconnected=True; self.disconnected_callback(self)
    async def read_gatt_char(self,uuid): return bytes([self.version,0,1,0,0,0])
    async def start_notify(self,uuid,callback): self.callback=callback
    async def stop_notify(self,uuid): self.callback=None
    async def write_gatt_char(self,uuid,raw,response):
        assert uuid==RX_UUID and response is True and 1<=len(raw)<=20
        self.writes.append(bytes(raw))
        if self.stall and len(self.writes)==2:
            await asyncio.sleep(1)
        self.buffer.extend(raw)
        if len(self.buffer)>=12:
            size=int.from_bytes(self.buffer[10:12],'little')+14
            if len(self.buffer)==size:
                packet=bytes(self.buffer); self.buffer.clear()
                reply=await self.peer.handle(packet)
                if reply:
                    # Not aligned with header, payload, CRC or MIDI event boundaries.
                    for pos in range(0,len(reply),7):
                        self.callback(None,reply[pos:pos+7])


def factory(peer,**options):
    def create(address,disconnected_callback):
        obj=FakeBleak(address,disconnected_callback,peer,**options)
        create.last=obj
        return obj
    return create


class CodecTests(unittest.TestCase):
    def test_crc_golden_and_v2(self):
        self.assertEqual(crc(b'123456789'),0x29b1)
        q=Frame(11,1,2)
        self.assertEqual(decode(q.encode()),q)
        legacy=bytearray(q.encode()); legacy[2]=1
        legacy[-2:]=struct.pack('<H',crc(legacy[2:-2]))
        with self.assertRaisesRegex(ValueError,'V2'): decode(bytes(legacy))
    def test_shape_matrix(self):
        for command in range(1,12):
            q=Frame(command,1,command)
            good=response(q,0,event=b'12345678' if command==READ else None)
            validate_response(good,q)
            bad=Frame(ACK,q.session,q.seq,payload=META.pack(command,0,0,0,0,0,0)+(b'12345678' if command!=READ else b''))
            with self.assertRaisesRegex(ValueError,'SHAPE'): validate_response(bad.encode(),q)
            with self.assertRaises(NackError): validate_response(response(q,15),q)
        with self.assertRaisesRegex(ValueError,'CONTRADICTION'):
            validate_response(Frame(ACK,1,1,payload=META.pack(STATUS,15,0,0,0,0,0)).encode(),Frame(STATUS,1,1))
    def test_lifetime_and_capacity(self):
        sid,raw=encode_score(score(512)); self.assertEqual(len(raw),4096)
        self.assertEqual(encode_score(decode_records(sid,raw)),(sid,raw))
        for document in [score(514),{**score(),'events':score()['events'][:1]},
                         {**score(),'events':score()['events'][1:]},
                         {**score(),'events':[score()['events'][0]]*2}]:
            with self.assertRaises(ValueError): encode_score(document)
    def test_midi_actual_import_and_rejection(self):
        track=b'\x00\x90\x3c\x64\x60\x80\x3c\x00\x00\xff\x2f\x00'
        raw=b'MThd'+struct.pack('>IHHH',6,0,1,96)+b'MTrk'+struct.pack('>I',len(track))+track
        document,provenance=convert_midi(raw,19)
        self.assertEqual(document['events'][1]['tick'],24000)
        self.assertEqual(encode_score(document)[0],19)
        self.assertEqual(len(provenance['event_origins']),2)
        with self.assertRaises(MidiImportError): convert_midi(raw[:-1])
        malformed=raw.replace(b'\x80\x3c',b'\x80\x3d')
        with self.assertRaises(MidiImportError): convert_midi(malformed)


class ClientTests(unittest.IsolatedAsyncioTestCase):
    async def test_upload_full_read_start_stop_clear(self):
        peer=Peer(); f=factory(peer)
        sid,records=encode_score(score())
        async with BleTransport('FAKE',f) as transport:
            client=ScoreClient(transport,session=41)
            self.assertEqual(await client.upload(sid,records),records)
            self.assertFalse(peer.playing)
            self.assertTrue(peer.verified)
            await client.start(sid,records); self.assertTrue(peer.playing)
            await client.stop(); self.assertFalse(peer.playing)
            await client.clear(); self.assertEqual(peer.records,b'')
            self.assertEqual(peer.commands[:6],[BEGIN,DATA,COMMIT,STATUS,READ_BEGIN,READ])
            self.assertIn(READ_END,peer.commands)
            self.assertTrue(all(len(piece)<=20 for piece in f.last.writes))
        self.assertTrue(f.last.disconnected)
    async def test_maximum_512_unaligned_chunks(self):
        sid,records=encode_score(score(512))
        peer=Peer()
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=42)
            self.assertEqual(await client.upload(sid,records,chunk=127),records)
            self.assertEqual(peer.index,512)
            self.assertEqual(peer.commits,1)
    async def test_exact_retry_commit_and_read(self):
        sid,records=encode_score(score())
        peer=Peer(); peer.drop={COMMIT:1,READ:1}
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=43,ack_timeout=0.01,retries=1)
            await client.upload(sid,records)
            self.assertEqual((peer.commits,peer.index,client.retry_count),(1,2,2))
    async def test_lost_start_ack_cached_before_busy(self):
        sid,records=encode_score(score()); peer=Peer(); peer.drop={START:1}
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=44,ack_timeout=0.01,retries=1)
            await client.upload(sid,records)
            await client.start(sid,records)
            self.assertEqual(peer.starts,1)
            self.assertEqual(client.retry_count,1)
    async def test_busy_no_automatic_retry(self):
        peer=Peer(); peer.playing=True
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=45)
            with self.assertRaises(NackError) as error:
                await client.upload(*encode_score(score()))
            self.assertEqual(error.exception.code,15)
            self.assertEqual(peer.commands,[BEGIN])
    async def test_explicit_stop_releases_abandoned_scope(self):
        peer=Peer(); peer.scope=True
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=46)
            await client.upload(*encode_score(score()),stop_first=True)
            self.assertEqual(peer.commands[:3],[STOP,ABORT,BEGIN])
    async def test_read_mismatch_retains_scope_and_prevents_start(self):
        peer=Peer(); sid,raw=encode_score(score())
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=47)
            await client.upload(sid,raw)
            wrong=bytearray(raw); wrong[7]^=1
            with self.assertRaisesRegex(ValueError,'mismatch'):
                await client.start(sid,bytes(wrong))
            self.assertTrue(peer.scope)
            self.assertNotIn(START,peer.commands)
    async def test_wrong_shape_rejected_no_retry(self):
        peer=Peer()
        def corrupt(q,reply):
            decoded=decode(reply)
            return Frame(ACK,q.session,q.seq,q.offset,decoded.payload+b'12345678').encode()
        peer.corrupt=corrupt
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=48)
            with self.assertRaisesRegex(ValueError,'SHAPE'): await client.status()
            self.assertEqual(client.retry_count,0)
    async def test_bridge_version_and_service_rejection(self):
        for options in [dict(version=1),dict(missing=True)]:
            f=factory(Peer(),**options)
            with self.assertRaises(ValueError):
                async with BleTransport('FAKE',f): pass
            self.assertTrue(f.last.disconnected)
    async def test_disconnect_and_partial_write_fail_closed(self):
        peer=Peer(); f=factory(peer,stall=True)
        async with BleTransport('FAKE',f) as transport:
            client=ScoreClient(transport,session=49,ack_timeout=0.01,retries=2)
            with self.assertRaisesRegex(ConnectionError,'interrupted'):
                await client.upload(*encode_score(score()))
            self.assertEqual(len(f.last.writes),2)
            self.assertEqual(peer.commands,[])
        f=factory(Peer())
        async with BleTransport('FAKE',f) as transport:
            f.last.is_connected=False; f.last.disconnected_callback(f.last)
            with self.assertRaises(ConnectionError): await ScoreClient(transport).status()
    async def test_control_waits_for_done_and_total_timeout(self):
        peer=Peer(); peer.delay_control=0.02
        async with BleTransport('FAKE',factory(peer)) as transport:
            task=asyncio.create_task(ScoreClient(transport,session=50).stop())
            await asyncio.sleep(0.005)
            self.assertTrue(peer.control_pending); self.assertFalse(task.done())
            await task; self.assertFalse(peer.control_pending)
        peer=Peer(); peer.drop={STATUS:99}
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=51,ack_timeout=0.01,total_timeout=0.025,retries=99)
            with self.assertRaises(TimeoutError): await client.status()
            self.assertLessEqual(len(peer.commands),3)
    async def test_late_unrelated_and_bad_crc(self):
        peer=Peer()
        async with BleTransport('FAKE',factory(peer)) as transport:
            transport._notify(None,response(Frame(STATUS,55,600),0))
            await ScoreClient(transport,session=52).status()
            bad=bytearray(response(Frame(STATUS,52,2),0)); bad[-1]^=1
            transport._notify(None,bad)
            with self.assertRaisesRegex(ValueError,'CRC'): await transport.receive()
    async def test_recovery_response_identity_does_not_alias_commit(self):
        peer=Peer(); f=factory(peer); original=peer.handle; saved=[]
        async def handle(raw):
            q=decode(raw)
            reply=await original(raw)
            if q.command==ABORT: saved.append(reply)
            if q.command==COMMIT and saved:
                # Valid late duplicate from recovery; must not alias upload COMMIT.
                f.last.callback(None,saved[0])
            return reply
        peer.handle=handle
        async with BleTransport('FAKE',f) as transport:
            client=ScoreClient(transport,session=62)
            await client.upload(*encode_score(score()),stop_first=True)
            self.assertEqual(peer.commits,1)

    async def test_truncated_read_rejected(self):
        peer=Peer(); sid,raw=encode_score(score())
        async with BleTransport('FAKE',factory(peer)) as transport:
            client=ScoreClient(transport,session=53)
            await client.upload(sid,raw)
            def corrupt(q,reply):
                if q.command!=READ: return reply
                decoded=decode(reply)
                return Frame(ACK,q.session,q.seq,q.offset,decoded.payload[:12]).encode()
            peer.corrupt=corrupt
            with self.assertRaisesRegex(ValueError,'SHAPE'): await client.start(sid,raw)
            self.assertNotIn(START,peer.commands)


class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exe=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'evidence/desktop_bridge.exe'
    def run_host(self,commands):
        result=subprocess.run([str(self.exe)],input=('\n'.join(commands+['Q'])+'\n').encode(),capture_output=True,timeout=5)
        self.assertEqual(result.returncode,0,result.stderr.decode())
        return result.stdout.decode()
    def test_all_v2_commands_and_fragmentation(self):
        for cmd in range(1,12):
            raw=Frame(cmd,1,1,payload=b'abcdefgh' if cmd in (START,READ_BEGIN) else b'').encode()
            commands=['C']+['G 1 '+raw[p:p+3].hex() for p in range(0,len(raw),3)]+['P']
            output=self.run_host(commands)
            self.assertIn('UART '+raw.hex(),output)
        q=Frame(READ,1,1)
        raw=response(q,0,event=b'12345678')
        output=self.run_host(['C','U 1 '+raw.hex(),'P'])
        pieces=[line.split()[1] for line in output.splitlines() if line.startswith('NOTIFY ')]
        self.assertEqual(''.join(pieces),raw.hex())
    def test_crc_poison_timeout_recovery(self):
        raw=Frame(STATUS,1,1).encode(); bad=bytearray(raw); bad[-1]^=1
        output=self.run_host(['C','G 1 '+bad.hex(),'G 2 '+raw.hex(),'P','T 2100','G 2101 '+raw.hex(),'P'])
        self.assertEqual(output.count('UART '),1)
        self.assertIn('LOCAL 1',output); self.assertIn('LOCAL 4',output)
    def test_version_direction_queue_disconnect(self):
        raw=Frame(STATUS,1,1).encode()
        old=bytearray(raw); old[2]=1; old[-2:]=struct.pack('<H',crc(old[2:-2]))
        output=self.run_host(['C','G 1 '+old.hex(),'P','D','C','G 1 '+(raw*3).hex(),'P','G 2 '+raw.hex(),'D','C','P'])
        self.assertEqual(output.count('UART '),2)
        self.assertIn('LOCAL 2',output); self.assertIn('LOCAL 3',output)
        output=self.run_host(['C','U 1 '+raw.hex(),'P'])
        self.assertNotIn('NOTIFY ',output)
    def test_response_shapes_and_no_synthetic_ack(self):
        q=Frame(READ,1,1)
        bad=Frame(ACK,1,1,payload=META.pack(READ,0,1,0,2,17,0)).encode()
        output=self.run_host(['C','U 1 '+bad.hex(),'P'])
        self.assertNotIn('NOTIFY ',output); self.assertIn('LOCAL 2',output)
        output=self.run_host(['C','G 1 '+Frame(STATUS,1,1).encode().hex(),'P'])
        self.assertNotIn('NOTIFY ',output)



class CBridgedBleak(FakeBleak):
    """Same PC adapter -> compiled production bridge core -> independent FPGA peer."""
    async def connect(self):
        self.process=subprocess.Popen([str(BridgeTests.exe)],stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
        self.line('C')
        self.is_connected=True

    def line(self,text):
        self.process.stdin.write(text+'\n'); self.process.stdin.flush()
        lines=[]
        while True:
            value=self.process.stdout.readline().strip()
            if value=='END': return lines
            if not value: raise RuntimeError('C bridge process unexpectedly ended')
            lines.append(value)

    async def disconnect(self):
        self.line('Q')
        self.process.communicate(timeout=5)
        await super().disconnect()

    async def write_gatt_char(self,uuid,raw,response):
        assert uuid==RX_UUID and response is True and len(raw)<=20
        self.writes.append(bytes(raw))
        result=self.line('G 1 '+raw.hex())
        if result: raise RuntimeError('unexpected C bridge local error: '+repr(result))
        outgoing=self.line('P')
        for line in outgoing:
            if not line.startswith('UART '): raise RuntimeError(line)
            reply=await self.peer.handle(bytes.fromhex(line.split()[1]))
            if reply:
                result=self.line('U 1 '+reply.hex())
                if result: raise RuntimeError(repr(result))
                for notify in self.line('P'):
                    if not notify.startswith('NOTIFY '): raise RuntimeError(notify)
                    self.callback(None,bytes.fromhex(notify.split()[1]))


class CrossLayerTests(unittest.IsolatedAsyncioTestCase):
    async def test_compiled_bridge_full_512_upload_retry_read_and_controls(self):
        peer=Peer(); peer.drop={COMMIT:1,READ:1,START:1}
        def backend(address,disconnected_callback):
            return CBridgedBleak(address,disconnected_callback,peer)
        sid,raw=encode_score(score(512))
        async with BleTransport('FAKE-C-CORE',backend) as transport:
            client=ScoreClient(transport,session=61,ack_timeout=0.02,retries=1)
            await client.upload(sid,raw,chunk=127)
            await client.start(sid,raw)
            await client.stop()
            await client.clear()
            self.assertEqual((peer.commits,peer.starts,client.retry_count),(1,1,3))
            self.assertFalse(peer.playing)
            self.assertEqual(peer.records,b'')


if __name__=='__main__':
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c)
                                 for c in (CodecTests,ClientTests,BridgeTests,CrossLayerTests))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
