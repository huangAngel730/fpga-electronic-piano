"""Bleak adapter with injectable backend; importing this module never scans."""
import asyncio
from protocol import MAGIC, decode

SERVICE_UUID = '761e0001-6ccd-4aa4-9e21-104647415031'
RX_UUID = '761e0002-6ccd-4aa4-9e21-104647415031'
TX_UUID = '761e0003-6ccd-4aa4-9e21-104647415031'
STATUS_UUID = '761e0004-6ccd-4aa4-9e21-104647415031'


class BleTransport:
    def __init__(self, address, factory=None):
        if not isinstance(address, str) or not address.strip():
            raise ValueError('explicit BLE address required')
        self.address, self.factory = address, factory
        self.client = None
        self.queue = asyncio.Queue(maxsize=8)
        self.buffer = bytearray()
        self.failure = None
        self.closing = False
        self.tx, self.rx, self.local_status = bytearray(), bytearray(), b''

    def _fail(self, error):
        self.failure = error
        if not self.queue.full():
            self.queue.put_nowait(error)

    def _disconnect(self, client):
        if not self.closing:
            self._fail(ConnectionError('BLE disconnected; state unknown, explicit STOP recovery required'))

    def _notify(self, characteristic, data):
        if self.failure:
            return
        self.rx.extend(data)
        self.buffer.extend(data)
        if len(self.buffer) > 512:
            self._fail(ValueError('BLE stream buffer overflow'))
            return
        try:
            while len(self.buffer) >= 2:
                if self.buffer[:2] != MAGIC:
                    raise ValueError('BLE response stream sync')
                if len(self.buffer) < 12:
                    break
                length = int.from_bytes(self.buffer[10:12], 'little')
                if length > 128:
                    raise ValueError('BLE response payload overflow')
                if len(self.buffer) < 14 + length:
                    break
                raw = bytes(self.buffer[:14+length])
                del self.buffer[:14+length]
                decode(raw)
                if self.queue.full():
                    raise ValueError('BLE response queue overflow')
                self.queue.put_nowait(raw)
        except ValueError as exc:
            self._fail(exc)

    async def __aenter__(self):
        if self.factory is None:
            from bleak import BleakClient
            self.factory = BleakClient
        self.client = self.factory(self.address, disconnected_callback=self._disconnect)
        try:
            await self.client.connect()
            if not self.client.is_connected:
                raise ConnectionError('BLE not connected')
            services = self.client.services
            if services.get_service(SERVICE_UUID) is None:
                raise ValueError('required score bridge service missing')
            rx, tx, status = (services.get_characteristic(u) for u in (RX_UUID, TX_UUID, STATUS_UUID))
            if rx is None or 'write' not in rx.properties or tx is None or 'notify' not in tx.properties or status is None or 'read' not in status.properties:
                raise ValueError('required score bridge characteristic/property missing')
            self.local_status = bytes(await self.client.read_gatt_char(STATUS_UUID))
            if len(self.local_status) != 6 or self.local_status[0] != 2:
                raise ValueError('protocol-v2 bridge required')
            await self.client.start_notify(TX_UUID, self._notify)
            return self
        except BaseException:
            self.closing = True
            await self.client.disconnect()
            raise

    async def send(self, raw):
        if self.failure:
            raise self.failure
        try:
            for offset in range(0, len(raw), 20):
                piece = raw[offset:offset+20]
                await self.client.write_gatt_char(RX_UUID, piece, response=True)
                self.tx.extend(piece)
                if self.failure:
                    raise self.failure
        except BaseException as exc:
            error = ConnectionError('GATT write interrupted; partial frame uncertain, reconnect then explicit STOP recovery')
            self._fail(error)
            raise error from exc

    async def receive(self):
        if self.failure:
            raise self.failure
        result = await self.queue.get()
        if isinstance(result, BaseException):
            raise result
        return result

    async def __aexit__(self, exc_type, exc, tb):
        self.closing = True
        if self.client:
            try:
                if self.client.is_connected:
                    await self.client.stop_notify(TX_UUID)
            finally:
                await self.client.disconnect()
