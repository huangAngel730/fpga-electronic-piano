"""Windows PC MIDI/JSON -> BLE -> FPGA v2. No action occurs on import."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import sys
from ble_transport import BleTransport
from client import ScoreClient
from midi_import import convert_midi, MAX_FILE_BYTES
from score import encode_score, decode_records, unique_object


def bounded_read(path, limit):
    with path.open('rb') as stream:
        raw=stream.read(limit+1)
    if len(raw)>limit:
        raise ValueError('input exceeds byte limit')
    return raw


def load_score(args):
    if args.midi:
        return convert_midi(bounded_read(args.midi, MAX_FILE_BYTES), args.score_id)
    if args.score:
        document=json.loads(bounded_read(args.score, 2*1024*1024).decode('utf-8'), object_pairs_hook=unique_object)
        return document, {'input':str(args.score)}
    raise ValueError('--midi or --score required')


async def execute(args, receipt):
    transport=None
    client=None
    document=None
    if args.command in ('import','upload','start') or args.midi or args.score:
        document, provenance=load_score(args)
        score_id, records=encode_score(document)
        (args.output/'score.json').write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8')
        (args.output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
        (args.output/'records.bin').write_bytes(records)
    if args.command=='import':
        receipt['status']='OFFLINE_IMPORT_PASS'
        return
    if not args.address:
        raise ValueError('explicit --address required')
    transport=BleTransport(args.address)
    receipt['device_attempted']=True
    try:
        async with transport:
            client=ScoreClient(transport, session=args.session, ack_timeout=args.ack_timeout,
                               total_timeout=args.total_timeout, retries=args.retries)
            receipt['session']=client.session
            receipt['bridge_status_hex']=transport.local_status.hex()
            if args.command=='upload':
                result=await client.upload(score_id,records,stop_first=args.stop_first)
                receipt['compared_events']=len(result)//8
                (args.output/'readback.bin').write_bytes(result)
                if args.start_after_upload:
                    await client.start(score_id,records)
                    receipt['start_ack_received']=True
            elif args.command=='start':
                await client.start(score_id,records)
                receipt['start_ack_received']=True
            elif args.command=='read':
                if document is None:
                    meta=await client.status()
                    if not meta[2]:
                        raise ValueError('no published score')
                    score_id,count=meta[5],meta[4]
                    expected=None
                else:
                    count=len(records)//8
                    expected=records
                result=await client.read_all(score_id,count,expected)
                (args.output/'readback.bin').write_bytes(result)
                (args.output/'readback_score.json').write_text(json.dumps(decode_records(score_id,result),indent=2)+'\n',encoding='utf-8')
                receipt['compared_events']=count
            elif args.command=='status':
                receipt['fpga_status']=await client.status()
            else:
                meta,_=await getattr(client,args.command)()
                receipt['fpga_status']=meta
            receipt['status']='DEVICE_COMMAND_ACKNOWLEDGED'
    finally:
        (args.output/'tx.bin').write_bytes(transport.tx)
        (args.output/'rx.bin').write_bytes(transport.rx)
        if client:
            receipt['retries']=client.retry_count
            (args.output/'trace.json').write_text(json.dumps(client.trace,indent=2)+'\n',encoding='utf-8')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('import','upload','read','start','stop','clear','abort','status'))
    source=parser.add_mutually_exclusive_group()
    source.add_argument('--midi',type=Path)
    source.add_argument('--score',type=Path)
    parser.add_argument('--score-id',type=int,default=1,help='MIDI import identity; JSON preserves its score_id')
    parser.add_argument('--address',help='explicit Windows BLE address; never selects first device')
    parser.add_argument('--session',type=int,help='default fresh random nonzero u16; never automatically reconnects')
    parser.add_argument('--output',type=Path,required=True,help='new evidence directory; refuses overwrite')
    parser.add_argument('--ack-timeout',type=float,default=2.0)
    parser.add_argument('--total-timeout',type=float,default=180.0)
    parser.add_argument('--retries',type=int,default=2)
    parser.add_argument('--stop-first',action='store_true',help='UPLOAD: explicit STOP then ABORT to recover retained leases')
    parser.add_argument('--start-after-upload',action='store_true',help='explicit START after full upload/readback')
    args=parser.parse_args(argv)
    if (args.stop_first or args.start_after_upload) and args.command!='upload':
        parser.error('--stop-first/--start-after-upload are upload-only')
    args.output.mkdir(parents=True,exist_ok=False)
    receipt=dict(schema=1,command=args.command,status='FAIL',exit_code=1,device_attempted=False,
                 hardware_pass_claim=False,fpga_integration_pass_claim=False)
    try:
        asyncio.run(execute(args,receipt))
        receipt['exit_code']=0
    except Exception as exc:
        receipt['error']=type(exc).__name__+': '+str(exc)
    receipt['artifacts']={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                          for p in args.output.iterdir() if p.is_file()}
    (args.output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))
    return receipt['exit_code']

if __name__=='__main__':
    sys.exit(main())
