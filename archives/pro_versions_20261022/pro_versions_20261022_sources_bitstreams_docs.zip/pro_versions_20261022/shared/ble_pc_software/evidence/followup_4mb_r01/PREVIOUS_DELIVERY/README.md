# Pro 曲谱传输软件 v2

本交付仅属于 `basic/project/software/`。包含 ESP32-C3-Zero-M 实际固件工程和 Windows PC 命令行 BLE 发送程序，保留冻结的原始曲谱 `<IBBBB>` 字节格式。旧仓库候选只读复用，未改 baseline、FPGA 顶层、工程或约束。

## 已执行结果

- 实际 ESP-IDF 5.4.2 / RISC-V GCC 14.2.0 固件干净构建成功，退出码 0；不是仅桌面编译。
- MinGW GCC 6.3.0 使用 `-std=c99 -Wall -Wextra -Werror -O2` 编译同一生产桥接 core 成功。
- 最终 23 项自检 PASS，包括最大 512 事件、非 8 字节对齐上传、严格 ACK 长度、MIDI 导入正负例、完整回读、START/STOP/CLEAR、BUSY、断线、中断写入、丢 ACK 原包重放，以及 PC 适配→GCC bridge core→独立 FPGA 逻辑 peer 的跨层测试。
- PC CLI 的 `.mid` 导入实际退出码 0，非法 NoteOff 输入退出码 1。
- 本机 Python 3.12.4 未安装 Bleak，保留 `ModuleNotFoundError` 原件。`pc/requirements.txt` 声明 Bleak 0.22.3；本任务未安装。实际 WinRT 后端、无线/UART 实物链路、FPGA RTL 集成和上板均未验证。
- SDK 自报 `v5.4.2-dirty`，现有 SDK HEAD 为 `f5c3654a1c2d2a01f7f67def7a0dc48e691f63c0`。未修改或清理 SDK；4150 个编译依赖/构建定义文件及工具已留 SHA，不能声称使用了已证明无修改的官方树。

## 固件入口

`firmware/main/main.c` 为可编译 NimBLE 应用，`firmware/core/bridge.c` 为实际同用桥接核心；`firmware/release/` 是最终构建产物的独立副本，原始日志在 `evidence/idf_build_r03_clean/`。

固定 UART1，GPIO4 TX、GPIO5 RX，115200 8N1、空闲高、无硬件流控；USB Serial/JTAG 仅用于日志，不向应用 UART 写日志。默认配置已明确 USB 主控制台；FreeRTOS tick 1000 Hz，使 5 ms/30 ms/500 ms 的有界工作时段实际可表示。

GATT 服务 `761e0001-6ccd-4aa4-9e21-104647415031`；RX 写特征 `761e0002...`，TX Notify `761e0003...`，本地状态 Read/Notify `761e0004...`（后三者后缀均为 `-6ccd-4aa4-9e21-104647415031`）。广播名 `Pro-Score-<BT MAC末3字节>`，客户端使用显式地址并核对服务/属性/状态版本2，不按名称自动挑第一块。

请求每片最多20字节，使用 GATT Write-with-response。桥先重组并检查版本2、命令1..11、长度及CRC，再一次性向 UART 发送完整帧；对端 ACK/NACK 按20字节 Notify 原样分片，桥不生成 FPGA ACK。双向重组142字节、各2帧队列；GATT分片超时2秒，UART分片超时20毫秒；错误进入隔离直至静默或重连，断线清本地缓存/队列并增加epoch。桥接层超时绝不释放FPGA播放/读租约。

最终构建默认头部 flash size 为2MB、minimum chip revision 为3（IDF 默认值），镜像557824字节、1MB应用分区可容纳。未探测实体芯片版本/Flash；这两项须在后续设备准入时核对，不以模块商品名代签。

## Windows PC 用法

在已有授权的 Windows BLE Python 环境中提供 `pc/requirements.txt` 所列依赖；本任务没有安装或连接设备。以下实机命令只是使用说明，均未在本次执行。所有输出目录必须是全新目录，客户端保存 `tx.bin`、`rx.bin`、`trace.json` 和 `receipt.json`。

```powershell
Set-Location 'E:\FPGA\GAOYUNFPGA\extra _life\basic\project\software'
# 离线导入，不加载Bleak，也不连接设备。
python -X utf8 -B pc/pro_score.py import --midi examples/demo.mid --score-id 23 --output local_import_NEW
# 明确地址；COMMIT只发布，默认不播放。上传后自动完整逐字节回读。
python -X utf8 -B pc/pro_score.py upload --midi path/to/song.mid --score-id 23 --address AA:BB:CC:DD:EE:FF --output upload_NEW
# 已遗留读租约/播放状态时，由调用者显式要求安全STOP完成后再ABORT和上传。
python -X utf8 -B pc/pro_score.py upload --score local_import_NEW/score.json --address AA:BB:CC:DD:EE:FF --stop-first --start-after-upload --output replace_and_play_NEW
# 单独START也重新完整回读并逐条比对本地原件。
python -X utf8 -B pc/pro_score.py start --score local_import_NEW/score.json --address AA:BB:CC:DD:EE:FF --output start_NEW
python -X utf8 -B pc/pro_score.py read --address AA:BB:CC:DD:EE:FF --output read_NEW
python -X utf8 -B pc/pro_score.py stop --address AA:BB:CC:DD:EE:FF --output stop_NEW
python -X utf8 -B pc/pro_score.py clear --address AA:BB:CC:DD:EE:FF --output clear_NEW
python -X utf8 -B pc/pro_score.py status --address AA:BB:CC:DD:EE:FF --output status_NEW
```

JSON支持严格字段、整数范围、48000名义tick/s、1..512事件、原始稳定顺序、同(channel,note)不重叠和完整NoteOn/Off生命周期；不排序修复、不截曲、不编造NoteOff。MIDI复用原SMF 0/1导入算法、绝对有理数时刻舍入和跨轨生命周期检查，不依赖额外MIDI库。

协议2仍为 `A5 5A + <BBHHHH> + payload + CRC16/CCITT-FALSE`，payload≤128。命令1..6与合同原语义一致；7 START、8 STOP、9 CLEAR、10 READ_BEGIN、11 READ_END。READ成功ACK严格20字节，其他ACK和所有NACK严格12字节；元数据标志、数量、原命令、session/seq/offset和ACK/错误码一致性全部检查。NACK立即退出、不盲重试；ACK超时有限重发完全相同请求；总时限有限。

上传序号0..4097，查询/控制从8192递增，避免延迟的恢复ACK与COMMIT混淆；一个ScoreClient只允许一轮上传，默认每次CLI随机新非零session。`--session`仅供明确需要复现的调用者使用，不能复用旧会话来恢复未知操作。

READ_BEGIN获取同一发布银行的持久租约；全部索引依次成功并逐字节核对后才READ_END。回读失败时不发送READ_END，不假定租约超时消失；重连不会自动恢复上传/播放，需显式STOP恢复。START只在重新完整回读成功后发出。STOP/CLEAR的成功以FPGA最终控制ACK为准，不以GATT写成功或桥本地状态冒充。中途GATT写异常/取消立即判连接状态不确定，不把半帧盲重放进同一流。

## 离线复验与构建

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B run_acceptance.py acceptance_NEW
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B build_firmware.py idf_build_NEW
```

runner只编译/测试；不安装、不自动flash、不扫描/连接设备。现有SDK工具路径记录于构建脚本。需要重新封存依赖时应使用新的证据目录，原 `seal_evidence.py` 采用固定单次目录，重复执行会拒绝覆盖。

最小接手入口：`HANDOFF.md`、`DELIVERY_RECEIPT.json`、`MANIFEST.json`。接口/FPGA球位/工程整合均由总控负责。
