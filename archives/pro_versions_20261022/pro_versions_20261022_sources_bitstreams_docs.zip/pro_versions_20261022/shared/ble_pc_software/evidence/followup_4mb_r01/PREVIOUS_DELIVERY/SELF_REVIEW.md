# 软件自审（2026-10-22）

范围：本窗口新建的PC程序、实际桥接固件、脚本和自检；未启用审核员/预审员，不代签M2或整机验收。

确认：v2版本独立、命令1..11、原始记录字节格式不变；READ ACK20/其他12；无桥合成ACK；显式READ_BEGIN/END和逐字节比对；COMMIT不START；START再次核完整读；STOP/CLEAR等待对端最终ACK；NACK立即失败；断线/CRC/中断GATT写不会推进成功；所有等待有限，持久租约不由桥超时释放。客户端序号不回卷；查询/控制与最大上传包数分离。SDK和旧候选原件不写。

已观察并修正的问题：

1. 默认沙盒初始化失败两次、Node内核同故障：无进程/源码变更。受控require_escalated调用自动批准后完成既定写集，未扩大目录。原报错见evidence/INITIAL_FAILURES.json。
2. 首次真实IDF构建成功，但旧候选同时选择USB和UART_NONE，Kconfig实际选择无控制台；首轮stdout/stderr及镜像已保留。去除旧选项、明确USB主控制台，最终由修正后的defaults在新build_release/sdkconfig.release上干净构建通过。另修正本机ESP_ROM_ELF_DIR到实际20241011目录，保留首轮诊断。
3. 自审指出先STOP/ABORT再上传时恢复序号1/2会与DATA/COMMIT复用。acceptance_r03_alias_counterexample实际退出码1、RESPONSE_COMMAND，失败源码和日志均保留。最终查询/控制从8192开始，上传最多到4097，每个客户端只进行一轮上传。acceptance_r04_final全部23项PASS，包括注入ABORT延迟合法重复ACK的反例。
4. 缺Bleak模块是现环境事实：原命令退出码1，未安装。fakeBLE测试覆盖实际适配代码，但不证明WinRT/无线已运行。PC requirements固定版本声明只属于依赖要求，未声称本机已具备。
5. 现有SDK报告v5.4.2-dirty；只读取HEAD/真实编译依赖SHA留证，未“清理”SDK以掩盖事实。目标Flash大小及芯片最小revision仍按实际构建报告保留，实物核对未执行。

最终源码身份与运行时对应：acceptance_r04_final/receipt.json含精确源码SHA和只读snapshot；idf_build_r03_clean/receipt.json含固件源SHA、环境、命令、退出码及镜像SHA。最终封存时再次核SHA一致，不重跑已通过测试。NimBLE主任务调度和物理UART溢出仅有源审/构建证据，仍需实物。
