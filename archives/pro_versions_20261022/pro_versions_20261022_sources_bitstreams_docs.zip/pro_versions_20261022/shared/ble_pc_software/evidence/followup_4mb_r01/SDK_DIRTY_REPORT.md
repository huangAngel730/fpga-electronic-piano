# SDK dirty只读核查 — 2026-10-22

结论：当前v5.4.2-dirty可归因于可执行权限位变化；在本次检查范围未发现源码/预编译库内容变化，也没有子模块指针偏移。未修改SDK、未修改core.filemode配置、未重装；只在单次命令使用-c core.filemode=false判别mode与内容，所有Git调用禁用可选锁。

- 根SDK HEAD：f5c3654a1c2d2a01f7f67def7a0dc48e691f63c0，describe仍v5.4.2-dirty。
- 根及25个子模块共26仓库：HEAD对跟踪gitlink一致；忽略mode与各子模块的独立内容差异逐一比较，0个跟踪内容差异。
- 全部905条差异均100755→100644（执行位移除）；root diff有118项，包括下层mode变化造成的子模块dirty。文件历史为何/何时发生这种mode变化不能单靠当前差异确定，不猜测具体操作来源。
- 原4150依赖清单中落在SDK且具有跟踪blob的3876件，实际文件按Git blob原始格式计算SHA1并逐件比较跟踪OID：0个不一致。不是仅依赖Git换行过滤后的“无差异”。
- 已封存依赖集合与mode路径交集只有tools/idf.py、components/protobuf-c/protobuf-c/protobuf-c/protobuf-c.h，均原始字节一致。Python通过明确解释器运行idf.py；头文件内容未变。因此本次已查依赖内容没有dirty引入的改变，mode本身未改本次编译文本。未将SDK标记改写为clean。
- 原4150 SHA逐件保留；4MB目标另留dependency_seal_r02_4mb。生成配置由2MB→4MB发生的预期变化在项目软件目录内，不是SDK源变化。

可访问原件：SDK_READONLY_AUDIT_COMMANDS.json、SDK_READONLY_AUDIT_DETAILS.json、SDK_REPOSITORY_AUDIT.json、SDK_DEPENDENCY_VS_TRACKED_BLOBS.json、SDK_MODE_PATHS.json、SDK_DIRTY_SUMMARY.json和SDK_REPOSITORIES/下每条命令双流。所有命令及退出码均留存。
