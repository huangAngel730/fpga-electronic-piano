"""Build only with the existing pinned ESP-IDF. Never install or flash."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
IDF = Path(r'E:/FPGA/SDKs/downloads/20261008/esp-idf-v5.4.2/esp-idf-v5.4.2')
TOOLS = Path(r'E:/FPGA/SDKs/espressif/tools')
PYTHON = TOOLS / 'python_env/idf5.4_py3.11_env/Scripts/python.exe'
BINS = [TOOLS / rel for rel in (
    'tools/cmake/3.30.2/bin', 'tools/ninja/1.12.1',
    'tools/riscv32-esp-elf/esp-14.2.0_20241119/riscv32-esp-elf/bin',
    'tools/ccache/4.11.2/ccache-4.11.2-windows-x86_64',
    'tools/idf-git/2.44.0/cmd')]


def main():
    out = ROOT / 'evidence' / (sys.argv[1] if len(sys.argv) > 1 else 'idf_build_r01')
    out.mkdir(exist_ok=False)
    env = os.environ.copy()
    env.update(IDF_PATH=str(IDF), IDF_TOOLS_PATH=str(TOOLS),
               IDF_PYTHON_ENV_PATH=str(PYTHON.parent.parent), IDF_CCACHE_ENABLE='0',
               PYTHONDONTWRITEBYTECODE='1',
               ESP_ROM_ELF_DIR=str(TOOLS/'tools/esp-rom-elfs/20241011'))
    env['PATH'] = os.pathsep.join(map(str, [PYTHON.parent] + BINS)) + os.pathsep + env['PATH']
    command = [str(PYTHON), '-B', str(IDF / 'tools/idf.py'), '-C', str(ROOT/'firmware'),
               '-B', str(ROOT/'firmware/build_release'), '-DIDF_TARGET=esp32c3',
               '-DSDKCONFIG='+str(ROOT/'firmware/sdkconfig.release'), 'build']
    receipt = dict(command=command, status='RUNNING', build_only=True, device_calls=0,
                   idf_path=str(IDF), start=time.time(),
                   environment={key:env[key] for key in ('IDF_PATH','IDF_TOOLS_PATH','IDF_PYTHON_ENV_PATH','ESP_ROM_ELF_DIR')},
                   sources={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
                            for path in sorted((ROOT/'firmware').rglob('*'))
                            if path.is_file() and path.suffix in ('.c','.h','.txt','.defaults')
                            and not any(part.startswith('build') for part in path.relative_to(ROOT/'firmware').parts)})
    (out/'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    try:
        with (out/'stdout.raw').open('wb') as stdout, (out/'stderr.raw').open('wb') as stderr:
            result = subprocess.run(command, env=env, stdout=stdout, stderr=stderr, timeout=1800)
        receipt.update(exit_code=result.returncode, status='PASS' if result.returncode == 0 else 'FAIL')
    except Exception as exc:
        receipt.update(exit_code=1, status='FAIL', error=repr(exc))
    receipt['elapsed_s'] = time.time()-receipt['start']
    receipt['artifacts'] = {}
    for rel in ('pro_score_ble_bridge_v2.bin', 'pro_score_ble_bridge_v2.elf',
                'bootloader/bootloader.bin', 'partition_table/partition-table.bin'):
        path = ROOT/'firmware/build_release'/rel
        if path.exists():
            raw=path.read_bytes()
            receipt['artifacts'][rel]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    (out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt))
    return receipt['exit_code']

if __name__ == '__main__':
    sys.exit(main())
