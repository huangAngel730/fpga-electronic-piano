# 拓展任务2最终交接 — 2026-10-22

本窗口交付已实现的软件、真实C3目标构建及离线行为测试。写集严格限定 `E:/FPGA/GAOYUNFPGA/extra _life/basic/project/software/`，不修改baseline、FPGA模块、gprj/CST/SDC/rebuild、仓库共享状态；未提交/推送Git，未安装、flash、扫描、连接或操作设备。此独立备份不适用Git发布。总控通过本最终交接收件；尚未代称总控验收/集成。

精确入口：

- PC实际入口：`pc/pro_score.py`；真实Bleak适配`pc/ble_transport.py`；协议和会话`pc/protocol.py`、`pc/client.py`；严格记录/MIDI`pc/score.py`、`pc/midi_import.py`。
- ESP实际工程：`firmware/CMakeLists.txt`、`firmware/main/main.c`、`firmware/core/bridge.c`；最终默认配置`firmware/sdkconfig.defaults`，干净构建展开配置`firmware/sdkconfig.release`。
- 最终固件：`firmware/release/pro_score_ble_bridge_v2.bin`，557824字节，SHA256 `31f6aa3f32d30fab2e8153f74dbeee4871ed3ebb951374a01c1c49ff50f6286e`；配套bootloader/partition、ELF和构建描述在同目录。
- 验收：`evidence/acceptance_r04_final/receipt.json`与`tests.stderr.raw`，GCC及23项测试退出码均0；实际跨层512事件上传/完整回读/控制/丢ACK包含编译后的生产core。
- 实际目标编译：`evidence/idf_build_r03_clean/receipt.json`，退出码0。源码/工具/依赖：`SOURCE_INPUTS.json`、`evidence/dependency_seal_r01/`、`MANIFEST.json`。
- 修复史与负例：`SELF_REVIEW.md`；`evidence/acceptance_r03_alias_counterexample/`保存真实失败和修前源码。首轮配置告警/镜像保留于`evidence/idf_build_r01/`，未覆盖。

实际验证等级：软件静态自审、GCC可执行行为验证、PC CLI离线运行、fakeBLE行为和ESP-IDF目标固件编译已通过。没有RTL仿真、FPGA综合/PnR/STA、实物无线/UART、板上或整机通过声明。

总控集成说明：

1. 保持合同v2及现有GATT UUID；FPGA传输端必须只以其最终控制done形成START/STOP/CLEAR ACK。PC不会将Write-with-response当FPGA ACK。
2. C3 UART1固定GPIO4TX→FPGA BLE_RX、GPIO5RX←FPGA BLE_TX、115200 8N1，日志USB。合同已给出Pro侧C21/B20和J26；本窗口没有更改或复核约束/接线，最终CST与电气门禁归总控。
3. READ_BEGIN/所有READ/READ_END均完整匹配同一银行身份；START发出前重新完整逐字节核对。遗留读/播放租约要显式`stop`，或`upload --stop-first`，不能仅靠断开BLE或ABORT释放。
4. START/STOP/CLEAR、STATUS、READ和上传均已有实际PC入口；手机未纳本轮。Windows实际运行还需在允许的环境中具备`pc/requirements.txt`的Bleak0.22.3；本机缺件证据已保留，未擅自安装。
5. 构建采用现有SDK5.4.2，实际标记v5.4.2-dirty、HEAD f5c3654a1c2d2a01f7f67def7a0dc48e691f63c0；依赖4150件精确SHA。实际镜像默认最小芯片revision3/Flash头2MB，实体芯片和Flash未核验；后续上设备前纳入总控检查。

未验及责任：总控负责FPGA RTL接口、板级集成、真实时序及最终收件；后续获设备授权的窗口负责C3/Pro接线、无线吞吐/丢包、UART电气与稳定性、USB日志、最终控制屏障及真实音频/显示联动。本文不恢复任何旧许可。
