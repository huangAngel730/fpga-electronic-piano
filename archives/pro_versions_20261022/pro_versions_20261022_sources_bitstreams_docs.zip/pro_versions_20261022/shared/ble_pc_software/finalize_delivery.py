"""Verify final sources match executed runs, then seal this software-only delivery."""
from pathlib import Path
import hashlib
import json
import os
ROOT=Path(__file__).resolve().parent


def identity(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    acceptance=json.loads((ROOT/'evidence/acceptance_r04_final/receipt.json').read_text())
    build=json.loads((ROOT/'evidence/idf_build_r04_4mb_clean/receipt.json').read_text())
    assert acceptance['status']=='PASS' and build['status']=='PASS'
    checks={}
    for label,source in [('acceptance',acceptance),('firmware_build',build)]:
        checks[label]=all(identity(ROOT/rel)['sha256']==value for rel,value in source['sources'].items())
        assert checks[label],label+' source differs from executed run'
    for rel,info in build['artifacts'].items():
        assert identity(ROOT/'firmware/release'/rel)==info,rel
    inputs=json.loads((ROOT/'SOURCE_INPUTS.json').read_text())
    checks['frozen_precursors']=all(identity(Path(path))==info for path,info in inputs.items())
    assert checks['frozen_precursors']
    dependencies=json.loads((ROOT/'evidence/dependency_seal_r02_4mb/DEPENDENCY_IDENTITIES.json').read_text())
    checks['sealed_dependencies']=all(identity(Path(path))==info for path,info in dependencies.items())
    assert checks['sealed_dependencies']
    original=json.loads((ROOT/'evidence/dependency_seal_r01/DEPENDENCY_IDENTITIES.json').read_text())
    checks['original_4150_snapshot_unchanged']=all(identity(Path(path))==info for path,info in original.items())
    assert checks['original_4150_snapshot_unchanged']
    dirty=json.loads((ROOT/'evidence/followup_4mb_r01/SDK_DIRTY_SUMMARY.json').read_text())
    assert dirty['classification']=='EXECUTABLE_MODE_ONLY_NO_TRACKED_CONTENT_CHANGE'
    image_config=json.loads((ROOT/'evidence/followup_4mb_r01/IMAGE_AND_CONFIG_CHECK.json').read_text())
    assert image_config['flash_config']=='4MB' and image_config['minimum_revision']=='3'
    assert json.loads((ROOT/'evidence/followup_4mb_r01/IMAGE_HEADER_CHECK.json').read_text())['exit_code']==0

    contract=ROOT.parent/'extension_docs/INTEGRATION_CONTRACT_R01.md'
    checks['contract_identity_at_seal']=identity(contract)
    command_receipts=[]
    for relative in ('evidence/acceptance_r01/receipt.json','evidence/acceptance_r02/receipt.json',
                     'evidence/acceptance_r03_alias_counterexample/receipt.json','evidence/acceptance_r04_final/receipt.json',
                     'evidence/idf_build_r01/receipt.json','evidence/idf_build_r02/receipt.json',
                     'evidence/idf_build_r03_clean/receipt.json','evidence/cli_import_r01/receipt.json',
                     'evidence/dependency_seal_r01/receipt.json','evidence/idf_build_r04_4mb_clean/receipt.json',
                     'evidence/dependency_seal_r02_4mb/receipt.json',
                     'evidence/followup_4mb_r01/IMAGE_AND_CONFIG_CHECK.json',
                     'evidence/followup_4mb_r01/IMAGE_HEADER_CHECK.json',
                     'evidence/followup_4mb_r01/SDK_DIRTY_SUMMARY.json'):
        command_receipts.append(dict(path=relative,**identity(ROOT/relative)))
    excluded={'MANIFEST.json','DELIVERY_RECEIPT.json','FILE_LIST.txt'}
    files=[]
    for directory,folders,names in os.walk(ROOT):
        if Path(directory)==ROOT/'firmware':
            folders[:]=[name for name in folders if not name.startswith('build')]
        folders[:]=[name for name in folders if name!='__pycache__']
        for name in names:
            path=Path(directory)/name
            if path.parent==ROOT and name in excluded: continue
            files.append(path)
    inventory=sorted([str(path.relative_to(ROOT)).replace('\\','/') for path in files]+sorted(excluded))
    (ROOT/'FILE_LIST.txt').write_text('\n'.join(inventory)+'\n',encoding='utf-8')
    files.append(ROOT/'FILE_LIST.txt')
    manifest={str(path.relative_to(ROOT)).replace('\\','/'):identity(path) for path in sorted(files)}
    (ROOT/'MANIFEST.json').write_text(json.dumps(dict(schema=1,files=manifest,
        exclusions=['firmware/build*/ generated caches (final release separately sealed)',
                    'MANIFEST.json and DELIVERY_RECEIPT.json to avoid cyclic identities']),indent=2)+'\n',encoding='utf-8')
    receipt=dict(schema=1,role='extension_task_2',date='2026-10-22',
        status='IMPLEMENTED_TARGET_BUILD_PASS_OFFLINE_ACCEPTANCE_PASS',
        exclusive_write_root=str(ROOT),source_checks=checks,source_inputs='SOURCE_INPUTS.json',
        final_test_count=23,final_test_exit_code=0,target_build_exit_code=0,
        command_receipts=command_receipts,manifest=identity(ROOT/'MANIFEST.json'),
        file_list='FILE_LIST.txt',handoff='HANDOFF.md',self_review='SELF_REVIEW.md',
        firmware=dict(path='firmware/release/pro_score_ble_bridge_v2.bin',**identity(ROOT/'firmware/release/pro_score_ble_bridge_v2.bin')),
        flash_size_bytes=4194304, minimum_chip_revision=3,
        flash_basis='https://docs.waveshare.net/ESP32-C3-Zero/',
        previous_2mb_release='evidence/followup_4mb_r01/previous_2mb_release',
        sdk_dirty_classification=dirty['classification'],sdk_dirty_mode_changes=dirty['mode_changes'],
        sdk_tracked_dependency_files_compared=dirty['sealed_sdk_dependencies_compared'],
        sdk_dependency_raw_content_mismatches=dirty['raw_blob_mismatches'],
        pc_entry='pc/pro_score.py',protocol_version=2,commands=list(range(1,12)),
        idf_version='5.4.2',idf_reported_revision='v5.4.2-dirty',
        sdk_commit='f5c3654a1c2d2a01f7f67def7a0dc48e691f63c0',dependency_identity_count=len(dependencies),
        failures_preserved=['evidence/INITIAL_FAILURES.json','evidence/idf_build_r01/',
                            'evidence/acceptance_r03_alias_counterexample/',
                            'evidence/cli_import_r01/bleak_dependency.stderr.raw',
                            'evidence/followup_4mb_r01/IMAGE_HEADER_CHECK_FAILED_R01.json',
                            'evidence/followup_4mb_r01/AUXILIARY_INSPECTION_FAILURES.json'],
        package_requirement=dict(name='bleak',version='0.22.3',installed_in_test_interpreter=False),
        device_calls=0,flash_calls=0,install_calls=0,git_publication='NOT_APPLICABLE_STANDALONE_BACKUP',
        actual_validation=['software_self_review','GCC_executable_behavior','Python_fakeBLE',
                           'compiled_bridge_cross_layer_fake_peer','CLI_offline_import',
                           'ESP_IDF_real_target_build'],
        unverified=['real_Windows_Bleak_WinRT','physical_BLE_UART','physical_silicon_revision_min3',
                    'FPGA_RTL_integration','FPGA_synthesis_PnR_STA','hardware_and_whole_system'],
        controller_received=False,controller_accepted=False,integrated=False,hardware_pass_claim=False)
    (ROOT/'DELIVERY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=receipt['status'],files=len(manifest),source_checks=checks,
                         firmware=receipt['firmware'],manifest=receipt['manifest'])))

if __name__=='__main__': main()
