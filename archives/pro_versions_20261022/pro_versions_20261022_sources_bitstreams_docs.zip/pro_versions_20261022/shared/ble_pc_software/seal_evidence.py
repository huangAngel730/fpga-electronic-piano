"""Seal already-executed software evidence and actual compiler dependency identities."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
IDF=Path(r'E:/FPGA/SDKs/downloads/20261008/esp-idf-v5.4.2/esp-idf-v5.4.2')
NINJA=Path(r'E:/FPGA/SDKs/espressif/tools/tools/ninja/1.12.1/ninja.exe')
BUILD=ROOT/'firmware/build_release_4mb'


def identity(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    out=ROOT/'evidence/dependency_seal_r02_4mb'
    out.mkdir(exist_ok=False)
    command=[str(NINJA),'-C',str(BUILD),'-t','deps']
    result=subprocess.run(command,capture_output=True,timeout=30)
    (out/'ninja_deps.stdout.raw').write_bytes(result.stdout)
    (out/'ninja_deps.stderr.raw').write_bytes(result.stderr)
    if result.returncode: raise RuntimeError('ninja deps failed')
    inputs=set()
    for line in result.stdout.decode('utf-8',errors='replace').splitlines():
        if line.startswith('    '):
            path=Path(line.strip())
            if not path.is_absolute(): path=BUILD/path
            if path.is_file(): inputs.add(path.resolve())
    for item in json.loads((BUILD/'compile_commands.json').read_text(encoding='utf-8')):
        path=Path(item['file'])
        if path.is_file(): inputs.add(path.resolve())
    maptext=(BUILD/'pro_score_ble_bridge_v2.map').read_text(encoding='utf-8',errors='replace')
    for match in re.findall(r'[A-Za-z]:[/\\][^\s()]*?\.a',maptext):
        path=Path(match)
        if path.is_file(): inputs.add(path.resolve())
    for path in IDF.rglob('CMakeLists.txt'):
        # Build definitions are read-only source identities, including unused definitions;
        # the compiler dependency list above distinguishes the actual compilation set.
        inputs.add(path.resolve())
    for path in (IDF/'tools/idf.py',IDF/'tools/cmake/version.cmake',IDF/'.git/HEAD',
                 ROOT/'firmware/sdkconfig.release_4mb',BUILD/'config/sdkconfig.h',
                 BUILD/'project_description.json',BUILD/'build.ninja',BUILD/'compile_commands.json'):
        if path.is_file(): inputs.add(path.resolve())
    deps={str(path):identity(path) for path in sorted(inputs)}
    (out/'DEPENDENCY_IDENTITIES.json').write_text(json.dumps(deps,indent=2)+'\n',encoding='utf-8')
    tools=[Path(sys.executable),NINJA,
           Path(r'D:/program/OSsystem/MinGW/bin/gcc.exe'),
           Path(r'E:/FPGA/SDKs/espressif/tools/tools/riscv32-esp-elf/esp-14.2.0_20241119/riscv32-esp-elf/bin/riscv32-esp-elf-gcc.exe'),
           Path(r'E:/FPGA/SDKs/espressif/tools/python_env/idf5.4_py3.11_env/Scripts/python.exe'),
           Path(r'E:/FPGA/SDKs/espressif/tools/tools/cmake/3.30.2/bin/cmake.exe')]
    toolids={str(path):identity(path) for path in tools}
    (out/'TOOL_IDENTITIES.json').write_text(json.dumps(toolids,indent=2)+'\n',encoding='utf-8')
    source_inputs=json.loads((ROOT/'SOURCE_INPUTS.json').read_text(encoding='utf-8'))
    frozen_ok=all(identity(Path(path))==info for path,info in source_inputs.items())
    description=json.loads((BUILD/'project_description.json').read_text(encoding='utf-8'))
    receipt=dict(command=command,exit_code=result.returncode,dependency_files=len(deps),
                 precursor_inputs_unchanged=frozen_ok,idf_reported_revision=description['git_revision'],
                 sdk_commit=(IDF/'.git/HEAD').read_text().strip(),device_calls=0)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))
    if not frozen_ok: raise RuntimeError('precursor identity changed')

if __name__=='__main__': main()
