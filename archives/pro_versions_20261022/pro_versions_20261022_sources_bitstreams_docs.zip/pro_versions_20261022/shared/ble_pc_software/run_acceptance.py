"""Compile C core and run Python fakeBLE acceptance, with immutable run logs."""
from pathlib import Path
import json
import hashlib
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parent
GCC=Path(r'D:/program/OSsystem/MinGW/bin/gcc.exe')

def main():
    out=ROOT/'evidence'/(sys.argv[1] if len(sys.argv)>1 else 'acceptance_r01')
    out.mkdir(exist_ok=False)
    source_hashes={}
    for folder in ('pc','tests','firmware/core','firmware/main'):
        for path in sorted((ROOT/folder).rglob('*')):
            if path.is_file():
                rel=path.relative_to(ROOT)
                dest=out/'source_snapshot'/rel
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(path.read_bytes())
                source_hashes[str(rel)]=hashlib.sha256(path.read_bytes()).hexdigest()
    commands=[('gcc',[str(GCC),'-std=c99','-Wall','-Wextra','-Werror','-O2',
                     str(ROOT/'firmware/core/bridge.c'),str(ROOT/'firmware/host.c'),'-o',str(out/'desktop_bridge.exe')]),
              ('tests',[sys.executable,'-X','utf8','-B',str(ROOT/'tests/run_tests.py'),str(out/'desktop_bridge.exe')]),
              ('cli_help',[sys.executable,'-X','utf8','-B',str(ROOT/'pc/pro_score.py'),'--help'])]
    receipt=dict(schema=1,status='PASS',device_calls=0,commands=[],sources=source_hashes)
    for name,command in commands:
        start=time.monotonic()
        with (out/(name+'.stdout.raw')).open('wb') as stdout,(out/(name+'.stderr.raw')).open('wb') as stderr:
            result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=120)
        receipt['commands'].append(dict(name=name,command=command,exit_code=result.returncode,elapsed_s=time.monotonic()-start))
        if result.returncode:
            receipt['status']='FAIL'
            break
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))
    return int(receipt['status']!='PASS')
if __name__=='__main__': sys.exit(main())
