"""Verify exact tested core/API and seal Task2-owned software evidence only."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "evidence/task2"


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    run = json.loads((OUT / "RUN_02/receipt.json").read_text())
    api = json.loads((OUT / "API_CHECK/receipt.json").read_text())
    assert run["status"] == "PASS"
    assert api["exit_code"] == 0 and not api["missing_required_signatures"] and not api["android_or_androidx_imports"]
    sources_same = all(identity(ROOT / name) == item for name, item in run["sources"].items())
    assert sources_same, "current source differs from executed RUN_02"
    inputs = json.loads((OUT / "INPUTS.json").read_text())
    inputs_same = all(identity(Path(name)) == info for name, info in inputs.items())
    assert inputs_same, "frozen input identity changed"
    stdout = (OUT / "RUN_02/self_test.stdout.raw").read_text(encoding="utf-8")
    assert "RESULT tests=20 assertions=9881 failures=0" in stdout
    core = ROOT / "app/src/main/java/com/proscore/core"
    allowed = [core, ROOT / "core_tests", OUT]
    files = [p for directory in allowed for p in directory.rglob("*") if p.is_file()]
    files.append(ROOT / "HANDOFF_TASK2.md")
    files = sorted(set(files))
    manifest = {str(p.relative_to(ROOT)).replace("\\","/"): identity(p)
                for p in files if p not in (OUT / "MANIFEST.json", OUT / "RECEIPT.json")}
    (OUT / "MANIFEST.json").write_text(json.dumps(dict(schema=1, files=manifest,
        exclusions=["MANIFEST.json and RECEIPT.json avoid cyclic identities"]),indent=2)+"\n",encoding="utf-8")
    jdk = Path(r"E:/FPGA/SDKs/java/jdk17")
    receipt = dict(schema=1,date="2026-10-22",role="extension_task_2_android_core",
        status="CORE_IMPLEMENTED_JDK_TESTS_PASS_SELF_REVIEW_DONE",
        handoff="HANDOFF_TASK2.md",source_root="app/src/main/java/com/proscore/core",
        tested_sources_unchanged=sources_same,frozen_inputs_unchanged=inputs_same,
        fixed_api_verified=True,android_dependencies=False,
        tests=20,assertions=9881,failures=0,compile_release=8,
        verification=["pure_JDK_compilation","PC_v2_golden_byte_vectors",
                      "stateful_fake_transport_positive_negative_tests",
                      "fixed_public_API_javap","self_review"],
        tool_receipts={name:identity(OUT/name) for name in (
            "RUN_01/receipt.json","RUN_02/receipt.json","API_CHECK/receipt.json")},
        jdk_release_identity=identity(jdk/"release"),
        source_identities={str(p.relative_to(ROOT)).replace("\\","/"):identity(p) for p in sorted(core.glob("*.java"))},
        manifest=identity(OUT/"MANIFEST.json"),
        timeout_policy=dict(total_millis=180000,ack_millis=2000,max_receive_retries=2,
            send_errors_retried=False,clock="monotonic nanoTime",
            full512_upload_interactions=549,full512_start_interactions=515),
        receive_retry_exceptions=["java.util.concurrent.TimeoutException","java.net.SocketTimeoutException"],
        failure_history=["evidence/task2/RUN_01/","evidence/task2/FAILURE_HISTORY.json",
                         "evidence/task2/AUTHORIZATION_HISTORY.json","evidence/task2/ORCHESTRATION_FAILURES.json"],
        direct_user_authorization_revoked_old_hold=True,
        physical_device_calls=0,eda_calls=0,git_calls=0,
        legacy_artifacts_modified=False,other_owner_files_modified=False,
        unverified=["APK_Gradle_integration","Android_permission_SAF_Gatt","physical_phone_BLE",
                    "ESP_FPGA_UART_audio_display_integration"],
        controller_received=False,controller_accepted=False,integrated=False,hardware_pass_claim=False)
    (OUT/"RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(dict(status=receipt["status"],tests=20,assertions=9881,
                         source_match=sources_same,input_match=inputs_same,
                         files=len(manifest),receipt=str(OUT/"RECEIPT.json"),
                         manifest_sha256=receipt["manifest"]["sha256"])))


if __name__ == "__main__":
    main()
