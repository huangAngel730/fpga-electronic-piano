# 任务2纯Java核心自检

源码入口：app/src/main/java/com/proscore/core/Score.java、Protocol.java、ScoreClient.java；内部有界JSON解析器为包私有StrictJson.java。生产源码不引用Android/AndroidX，公开Score/ScoreClient/Transport/Progress签名与TASK_AND_API.md相同。

本地复验（输出目录必须全新，不覆盖历史）：

    & 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B core_tests/run_core_tests.py RUN_NEW

使用现有E:/FPGA/SDKs/java/jdk17，javac --release 8 -Xlint:all -Werror，纯Java main自检，无Junit/Gradle/网络/Android设备依赖。PC冻结源码只读加载生成新黄金字节向量，不执行旧验收组。RUN_01编译通过、自检一处测试判定失败；该测试只按command误把不同READ索引当重试，修正为全身份+完整原字节+精确重试数后RUN_02的20场景/9881断言全通过。首轮源码、class和原始双流继续保留。

核心行为：

- UTF-8严格解码；2MiB字节上限、深度16、节点8192、数组512、字符串4096、数值token64的资源限额；重复解码后字段拒绝，整数不接受布尔/小数/指数/字符串，未知/缺字段拒绝。
- 原始<IBBBB>格式、48kHz名义ticks、稳定同tick输入顺序、完整(channel,note)生命周期；生产note36..84、tick0..16777215；velocity0 NoteOn按冻结定义编码为NoteOff；score_id是unsigned32的long。
- Protocol.Frame、Protocol.encode/decode、Protocol.crc16、Protocol.validateResponse可供验收直接调用；READ成功payload20，其余ACK/NACK12。NackException提供getErrorCode。
- 上传只BEGIN/DATA/COMMIT/STATUS/READ_BEGIN/逐条READ/READ_END，不自动START。显式stopFirst才先STOP最终ACK、再ABORT；START始终重新完整核对本地原件后才发。
- 总事务180秒以构造client时的单调钟起算、单次ACK2秒、接收超时至多原样重发2次；query/control序号8192起，与upload0..33（128字节分包；即使1字节分包也≤4097）分开。一个client仅允许一轮upload；每次按钮操作新client随机非零session。
- 完整帧send任意失败（包括TimeoutException）立即退出，不重放可能已发送的半帧。receive仅java.util.concurrent.TimeoutException或java.net.SocketTimeoutException进入有限重发；断线/帧坏/其他异常立即失败。Transport需遵守相对超时并支持线程中断，send必须完成整帧后返回。
- cancel仅设置取消并中断当前工作线程，不自动STOP/ABORT，也不报停止成功。未完成回读不发READ_END，租约保留须用户显式STOP恢复。
- Progress在调用工作线程回调，UI自行切主线程；phase为中文可读文本，不是冻结枚举。成功phase只在最终对端ACK与全部核对通过后报告。

时间预检：512事件上传需549次交互（stopFirst551），START重新核读需515次。180秒下平均每次预算约327ms/349ms。软件检查UART115200 8N1理论下限（满上传约2620ms），若剩余连此下限都不够则发送前报错；BLE连接间隔、实际Gatt时延未知，不能保证所有链路在180秒内完成。实际慢链路触发总截止时明确报状态未知，不虚报核验成功；首要验证项仍是目标手机/ESP/FPGA的实际交互耗时。

本窗口只做纯Java、模拟Transport和静态签名检查。Android APK/权限/真实Gatt、设备、FPGA/ESP/音频显示联动由总控及对应窗口验证。
