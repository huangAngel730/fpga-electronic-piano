"""Pure-JDK software self-test runner; no Android/device/Git commands."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / "app/src/main/java/com/proscore/core"
JDK = Path(r"E:/FPGA/SDKs/java/jdk17")
PC = ROOT.parent / "software/pc"


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(name, path):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    return module


def generate_fixtures(target):
    protocol = load("task2_original_pc_protocol", PC / "protocol.py")
    score = load("task2_original_pc_score", PC / "score.py")
    target.mkdir()
    def event(tick, kind, channel, note, velocity):
        return dict(tick=tick, type=kind, channel=channel, note=note, velocity=velocity)
    document = dict(schema=1, sample_hz=48000, score_id=0xffffffff, events=[
        event(0, "note_on", 0, 60, 100), event(0, "note_on", 1, 64, 127),
        event(0, "note_off", 0, 60, 80), event(1, "note_off", 1, 64, 0),
        event(16777215, "note_on", 15, 84, 1),
        event(16777215, "note_on", 15, 84, 0)])
    _, records = score.encode_score(document)
    (target / "valid.score.json").write_text(json.dumps(document, separators=(",", ":")), encoding="utf-8")
    (target / "valid.records.bin").write_bytes(records)
    vectors = []
    for command in range(1, 12):
        request = protocol.Frame(command, 0x1234, 0x4567, 0x89ab, b"\x00\x01\x7f\x80\xff")
        ack = protocol.response(request, 0, committed=True, count=512, score_id=0xffffffff,
                                event=records[:8] if command == protocol.READ else None)
        nack = protocol.response(request, 15)
        vectors.append(f"{command}|{request.encode().hex()}|{ack.hex()}|{nack.hex()}")
    (target / "golden_frames.txt").write_text("\n".join(vectors) + "\n", encoding="utf-8")
    pair = [event(0, "note_on", 0, 60, 100), event(10, "note_off", 0, 60, 0)]
    base = dict(schema=1, sample_hz=48000, score_id=1, events=pair)
    good = json.dumps(base, separators=(",", ":"))
    bad = [
        good.replace('"schema":1', '"schema":1,"schema":1'),
        good.replace('"schema":1', '"schema":1,"\\u0073chema":1'),
        good.replace('"tick":0', '"tick":0,"tick":0', 1),
        good.replace('"schema":1', '"schema":true'),
        good.replace('"schema":1', '"schema":1.0'),
        good.replace('"schema":1', '"schema":1e0'),
        good.replace('"schema":1', '"schema":"1"'),
        good.replace('"schema":1', '"schema":null'),
        good.replace('"schema":1', '"schema":01'),
        good.replace('"score_id":1', '"score_id":4294967296'),
        good.replace('"score_id":1', '"score_id":-1'),
        good.replace('"score_id":1', '"score_id":9223372036854775808'),
        good.replace('"sample_hz":48000', '"sample_hz":48001'),
        good.replace('"tick":0', '"tick":16777216', 1),
        good.replace('"note":60', '"note":35'),
        good.replace('"note":60', '"note":85'),
        good.replace('"channel":0', '"channel":16'),
        good.replace('"velocity":100', '"velocity":128'),
        good.replace('"type":"note_on"', '"type":"cc"'),
        good.replace('"schema":1', '"extra":1,"schema":1'),
        good.replace('"tick":0', '"extra":0,"tick":0', 1),
        good + " trailing",
        good[:-1] + ",}",
        "\ufeff" + good,
        good.replace('"schema"', '"\\ud800"', 1),
        good.replace('"schema"', '"\\x73chema"', 1),
        "[]" , "{}", "null", "[" * 20 + "0" + "]" * 20,
        json.dumps({**base, "events": []}),
        json.dumps({**base, "events": [pair[0]]}),
        json.dumps({**base, "events": [pair[1]]}),
        json.dumps({**base, "events": [pair[0], pair[0], pair[1]]}),
        json.dumps({**base, "events": [event(10, "note_on", 0, 60, 100), event(0, "note_off", 0, 60, 0)]}),
    ]
    (target / "invalid_json.txt").write_text("\n".join(bad) + "\n", encoding="utf-8")


def main():
    out = ROOT / "evidence/task2" / (sys.argv[1] if len(sys.argv) > 1 else "RUN_01")
    out.mkdir(parents=True, exist_ok=False)
    fixtures = out / "fixtures"
    generate_fixtures(fixtures)
    sources = sorted(CORE.glob("*.java")) + [ROOT / "core_tests/CoreSelfTest.java"]
    source_ids = {}
    for path in sources + [Path(__file__).resolve()]:
        rel = path.relative_to(ROOT)
        dest = out / "source_snapshot" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(path.read_bytes())
        source_ids[str(rel)] = identity(path)
    classes = out / "classes"
    classes.mkdir()
    commands = [
        ("javac_version", [str(JDK / "bin/javac.exe"), "-J-XX:-UsePerfData", "-version"]),
        ("javac", [str(JDK / "bin/javac.exe"), "-J-XX:-UsePerfData", "-encoding", "UTF-8",
                   "--release", "8", "-Xlint:all", "-Werror", "-d", str(classes)] + list(map(str, sources))),
        ("self_test", [str(JDK / "bin/java.exe"), "-XX:-UsePerfData", "-Dfile.encoding=UTF-8",
                       "-ea", "-cp", str(classes), "com.proscore.core.CoreSelfTest", str(fixtures)]),
    ]
    receipt = dict(schema=1, status="PASS", commands=[], sources=source_ids, device_calls=0,
                   source_inputs={str(PC/name): identity(PC/name)
                                  for name in ("protocol.py", "score.py", "client.py")},
                   tool_identities={str(JDK/"bin"/name): identity(JDK/"bin"/name)
                                    for name in ("javac.exe", "java.exe")})
    env = os.environ.copy()
    env["JAVA_TOOL_OPTIONS"] = "-XX:-UsePerfData"
    for name, command in commands:
        with (out/(name+".stdout.raw")).open("wb") as stdout, (out/(name+".stderr.raw")).open("wb") as stderr:
            result = subprocess.run(command, env=env, stdout=stdout, stderr=stderr, timeout=60)
        receipt["commands"].append(dict(name=name, command=command, exit_code=result.returncode))
        if result.returncode:
            receipt["status"] = "FAIL"
            break
    (out/"receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(dict(status=receipt["status"],run=str(out),
                         commands=[dict(name=x["name"],exit_code=x["exit_code"]) for x in receipt["commands"]])))
    return int(receipt["status"] != "PASS")


if __name__ == "__main__":
    sys.exit(main())
