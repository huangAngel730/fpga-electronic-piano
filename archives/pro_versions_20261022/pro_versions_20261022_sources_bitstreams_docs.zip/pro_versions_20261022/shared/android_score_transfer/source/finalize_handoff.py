"""Bind member evidence, actual APK and unchanged original inputs for handoff."""
import datetime as dt
import json
from pathlib import Path

from build_android import HERE, capture_build_inputs, identity


def read(relative):
    return json.loads((HERE / relative).read_text(encoding='utf-8-sig'))


def check(path, expected):
    if identity(path) != {key: expected[key] for key in ('bytes', 'sha256')}:
        raise ValueError('Identity mismatch: ' + str(path))


def main():
    target = HERE / 'HANDOFF.json'
    if target.exists():
        raise FileExistsError('Preserve handoff; choose new revision')
    core = read('evidence/task2/RECEIPT.json')
    ui = read('evidence/task3/RECEIPT.json')
    independent = read('evidence/task4/receipt.json')
    final = read('evidence/METADATA_REVIEW_R01/receipt.json')
    if core['failures'] != 0 or not core['tested_sources_unchanged']:
        raise ValueError('Core evidence not passing')
    if ui['transport_tests']['exit'] != 0 or ui['compile']['exit'] != 0:
        raise ValueError('UI/transport evidence not passing')
    if independent['status'] != 'SOFTWARE_MOCK_PASS_AND_READONLY_UI_REVIEW_NO_BLOCKERS' or not independent['full_app_source_resource_binding']:
        raise ValueError('Independent final source binding missing')
    if final['status'] != 'PASS_APK_BUILD_LINT_AND_SIGNATURE_ONLY':
        raise ValueError('APK final review not passing')
    for relative, expected in core['source_identities'].items():
        check(HERE / relative, expected)
    for relative, expected in ui['sources'].items():
        check(HERE / relative, expected)
    for expected in independent['checked_current_sources']:
        check(Path(expected['path']), expected)
    if capture_build_inputs() != final['build_input_identities']:
        raise ValueError('Built source inventory changed')
    origin = read('evidence/BUILD_R04/receipt.json')
    check(HERE / 'evidence/BUILD_R04/receipt.json', final['original_receipt_identity'])
    for name, expected in origin['log_identities'].items():
        check(HERE / 'evidence/BUILD_R04' / name, expected)
    check(HERE / 'evidence/BUILD_R04/executed_build_android.py', origin['script_identity'])
    check(Path(final['apk']['path']), final['apk'])
    refs = [
        'evidence/task2/RECEIPT.json', 'evidence/task2/FAILURE_HISTORY.json',
        'evidence/task3/RECEIPT.json', 'evidence/task3/FAILURE_HISTORY.json',
        'evidence/task4/receipt.json', 'evidence/BUILD_R01/receipt.json',
        'evidence/BUILD_R02/receipt.json', 'evidence/BUILD_R03/receipt.json',
        'evidence/BUILD_R04/receipt.json', 'evidence/METADATA_REVIEW_R01/receipt.json',
        'HANDOFF.md', 'HANDOFF_TASK2.md', 'HANDOFF_TASK3.md', 'HANDOFF_TASK4.md',
    ]
    result = {
        'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'status': 'ANDROID_SOFTWARE_IMPLEMENTATION_BUILD_AND_DELIVERY_READY',
        'root': str(HERE), 'apk': final['apk'],
        'scope': ['preconverted JSON selection', 'explicit BLE selection/connection',
                  'upload and complete READ compare', 'explicit START with repeated compare', 'STOP'],
        'excluded': ['phone MIDI import', 'hardware operations', 'FPGA/ESP modifications', 'Git publication'],
        'build_input_identities': final['build_input_identities'],
        'reference_pc_inputs': origin['reference_input_identities'],
        'tests': {'core_scenarios': core['tests'], 'core_assertions': core['assertions'],
                  'independent_public_api_cases': independent['Java_public_API_cases'],
                  'fixed_codec_cases': independent['Java_fixed_codec_cases'],
                  'transport_checks': ui['transport_tests']['checks'],
                  'lint_errors': final['lint']['errors'], 'lint_warning_count': len(final['lint']['warnings'])},
        'evidence_identities': {relative: identity(HERE / relative) for relative in refs},
        'original_identity_readbacks': {
            'baseline_files': 185, 'baseline_failures': [], 'native_exit': 0,
            'extension_files': 633, 'bringup_supplement_files': 51,
            'extension_manifest_sha256': '53bfe6d66fe1d5a08e18bdad221b5df7c9413e481e493dd27e5140df4e1334b7',
            'bringup_manifest_sha256': '4e53d768ff3465b8bea0122a524d370197d2e0af1db656a7e4a0bd9c6a09ef46',
            'grade': 'read-only identity verification; not functional rerun'},
        'self_review': {'coordinator': 'complete within scope',
                        'own_readonly_subagent': 'build/package identity fixes and APK metadata delta reviewed; no remaining blocker',
                        'external_reviewer_windows': 'NOT_ENABLED'},
        'phone_install_test': 'NOT_RUN', 'real_ble_uart_board_validation': 'NOT_RUN',
        'device_operations': False, 'hardware_pass': False, 'board_release_allowed': False,
        'git': 'NOT_COMMITTED_NOT_PUSHED; standalone backup',
        'M2_acceptance': 'NOT_PROVEN',
        'delivery_manifest': 'delivery/R01/MANIFEST.json (generated after this handoff)',
    }
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'status': result['status'], 'handoff': str(target),
                      'identity': identity(target), 'tests': result['tests']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
