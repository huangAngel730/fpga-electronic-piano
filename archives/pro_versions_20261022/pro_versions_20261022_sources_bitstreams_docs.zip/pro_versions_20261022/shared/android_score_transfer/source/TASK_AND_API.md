# 安卓传谱 R01：总控写集与接口

用户2026-10-22直接授权：安卓手机选择已转换曲谱、BLE上传／全量回读核同、显式开始、停止。总控可调度拓展任务2/3/4，允许各自子智能体自审，少通信。不做手机MIDI解析，不修改既有FPGA/ESP/PC封存源或码流，不连接实物、不烧录、不Git发布。

根：E:/FPGA/GAOYUNFPGA/extra _life/basic/project/android_score_transfer_r01

- 拓展任务2独占 app/src/main/java/com/proscore/core/、core_tests/、evidence/task2/、HANDOFF_TASK2.md。
- 拓展任务3独占 app/src/main/java/com/proscore/android/、app/src/main/res/、app/src/main/AndroidManifest.xml、evidence/task3/、HANDOFF_TASK3.md。
- 拓展任务4独占 acceptance/、evidence/task4/、HANDOFF_TASK4.md。独立Python与原PC客户端生成黄金向量，对Java核心协议做黑盒正负验收；只读审UI/BLE边界。不得修改他人源码。
- 总控负责Gradle/SDK/JDK构建配置、assets样例、最终集成、修复协调、签名APK、交付文档与原封存身份核验。

统一接口（Java，无Kotlin／AndroidX依赖；Android minSdk26，compile/target35，applicationId com.proscore.android）：

```java
package com.proscore.core;
public final class Score {
  public static Score parseUtf8(byte[] bytes) throws Exception;
  public long getScoreId();
  public int getCount();
  public byte[] getRecords(); // defensive clone
}
public final class ScoreClient {
  public interface Transport {
    void send(byte[] frame, long timeoutMillis) throws Exception;
    byte[] receive(long timeoutMillis) throws Exception;
  }
  public interface Progress {
    void onProgress(String phase, int done, int total);
  }
  public ScoreClient(Transport transport, Progress progress);
  public void upload(Score score, boolean stopFirst) throws Exception;
  public void start(Score score) throws Exception;
  public void stop() throws Exception;
  public void cancel();
}
```

上述核心运行于单工作线程，每次按钮操作新建client/session；Transport只在一条已就绪连接上使用，send和receive参数为相对超时毫秒，以单调钟计算内部总截止。取消只取消手机等待，不冒称已STOP；失败保留明确未知状态，由用户显式STOP恢复。不自动重连、自动选首设备或自动START。

核心完全移植当前 software/pc/protocol.py、score.py、client.py 的v2字节语义，READ成功payload20B，其余ACK/NACK12B；NACK立即失败，最多原有限timeout重试2次，同请求同序列；不把部分GATT写超时当作可重试的完整帧发送。总事务180s，ACK2s，若完整文件接近上限需先评估是否足够并如实报错。严格JSON唯一字段与整数、稳定同tick顺序、完整note生命周期；安卓还拒生产超范围note36..84、tick>16777215；1..512原始事件，48kHz。

BLE UUID沿用原pc/ble_transport.py：service761e0001、RX0002 write-with-response、TX0003 notify、status0004 read，尾部均-6ccd-4aa4-9e21-104647415031。20B分片，GATT操作串行；状态6B且version2；CCCD成功及状态读取通过后才ready。接收严格拆完整帧、队列和缓冲有界，断线/损坏立即失败。手机权限按官方Android版本要求，文件使用系统选择器，不要请求全盘存储。UI中文、明确设备选择、连接状态／曲谱摘要／进度／错误、上传不自动播放、START再次核同、STOP应无文件也可用；后台生命周期取消断开，不显示假成功。无实物测试入口自动触发。

可用工具候选：E:/FPGA/SDKs/java/jdk17，E:/FPGA/SDKs/gradle/gradle-8.9，E:/FPGA/SDKs/android/sdk；总控核验具体版本与下载缺件。新环境目录已授权，依赖只用官方源。

成员完成把结果写入自己HANDOFF并结束回复即可，总控用wait_threads和文件收取，不需相互聊天。普通实现／有据修复自行决定；不引入外部审核员制度。不把APK构建／模拟传输等同于手机或板上实测通过。
