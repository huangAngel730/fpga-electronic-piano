"""Exercise remaining fixed codec vectors on the already-tested core snapshot."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
JDK = Path('E:/FPGA/SDKs/java/jdk17/bin')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    core_run = Path(sys.argv[1]).resolve()
    core_receipt = json.loads((core_run/'receipt.json').read_text(encoding='utf-8'))
    assert core_receipt['status'] == 'PASS'
    assert all(sha(Path(item['path'])) == item['sha256'] for item in core_receipt['sources'])
    out = core_run/'codec_vectors'
    out.mkdir()  # Preserve any earlier run; do not overwrite it.
    sources = [ROOT/'acceptance/CodecHarness.java', Path(__file__).resolve(),
               ROOT/'acceptance/vectors/wire/golden_frames.json']
    identities = []
    for source in sources:
        target = out/source.name
        shutil.copyfile(source, target)
        identities.append(dict(path=str(source), snapshot=str(target), sha256=sha(source)))
    vectors = json.loads((out/'golden_frames.json').read_text(encoding='utf-8'))
    expected, inputs = [], []
    for case in vectors['requests_and_ack']:
        inputs.append(f"{case['id']} {case['request_hex']} {case['ack_hex']}")
        expected.append(f"{case['id']} ACK "+','.join(map(str,case['metadata']))+' '+case['read_event_hex'])
    for case in vectors['nacks']:
        inputs.append(f"{case['id']} {case['request_hex']} {case['response_hex']}")
        expected.append(f"{case['id']} NACK {case['error_code']}")
    for case in vectors['invalid_responses']:
        inputs.append(f"{case['id']} {case['request_hex']} {case['response_hex']}")
        expected.append(f"{case['id']} INVALID")
    assert len(expected) == 42
    payload = '\n'.join(inputs)+'\n'
    (out/'stdin.txt').write_text(payload,encoding='utf-8')
    classes = out/'classes'
    classes.mkdir()
    compile_command = [str(JDK/'javac.exe'), '-encoding', 'UTF-8', '-cp', str(core_run/'classes'),
                       '-d',str(classes), str(out/'CodecHarness.java')]
    compile_result = subprocess.run(compile_command,capture_output=True,text=True,encoding='utf-8')
    (out/'javac.stdout.log').write_text(compile_result.stdout,encoding='utf-8')
    (out/'javac.stderr.log').write_text(compile_result.stderr,encoding='utf-8')
    assert compile_result.returncode == 0
    command = [str(JDK/'java.exe'), '-cp', str(classes)+';'+str(core_run/'classes'),
               'com.proscore.acceptance.CodecHarness']
    result = subprocess.run(command,input=payload,capture_output=True,text=True,encoding='utf-8',timeout=15)
    (out/'stdout.log').write_text(result.stdout,encoding='utf-8')
    (out/'stderr.log').write_text(result.stderr,encoding='utf-8')
    actual = result.stdout.splitlines()
    passed = result.returncode == 0 and actual == expected
    unchanged = all(sha(Path(item['path'])) == item['sha256']
                    for item in core_receipt['sources']+identities)
    receipt = dict(status='PASS' if passed and unchanged else 'FAIL', tests=42,
        compile_command=compile_command, compile_exit=compile_result.returncode,
        command=command,exit_code=result.returncode,expected=expected,actual=actual,
        inputs=identities,core_receipt_sha256=sha(core_run/'receipt.json'),
        core_sources=core_receipt['sources'],inputs_unchanged=unchanged,device_operations=False)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt['status'], '42 fixed codec vectors', str(out))
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
