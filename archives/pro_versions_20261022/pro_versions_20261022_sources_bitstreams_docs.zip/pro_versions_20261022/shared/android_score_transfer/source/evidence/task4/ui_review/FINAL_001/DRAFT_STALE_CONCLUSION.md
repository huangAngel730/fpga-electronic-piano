# Task4 最终 BLE/UI 只读结论

在本目录 `review.json` 所绑定的七份源码/资源精确 SHA 范围内，未发现具体阻断。原字节保存于 `source_snapshot/`。这只是一轮静态边界检查，不代签 Android 运行、APK 构建或实物 BLE 通过。

已读完整 MainActivity、GattTransport、ResponseStream、Manifest 和两份资源文件；ScoreClient 作为发送失败、取消和 START/STOP 调用边界的必要上下文读取。确认 status6B/version2 与实际CCCD成功回调先于ready；20B响应写逐片串行等待；send失败粘滞关闭且不进入核心receive超时重试；流缓冲/队列有界且坏流终止。权限按版本请求，文件走系统选择器；前台生命周期取消断开并以token屏蔽迟到成功；设备需显式选择，按钮每次创建新client，START再次全量核同，STOP不依赖文件。

关键身份：

- MainActivity：`bd7f0e78536e8533661e1847b8816e2ace393e2f84237fc9ef0f0985093c83dd`
- GattTransport：`a05f80377fa2d0ff328abee407f159d555a711a7e877ba5e2014b971fb809542`
- ResponseStream：`dbccde07b9caa790c0768635b337a3411d1b06db8598b28fa0cface102e29e70`

精确行号映射、其他SHA、官方API来源和未验边界均见 `review.json`。准备/未到货记录和两次局部快照继续保留在父目录。本轮未修改生产文件，未编译、构建、扫描、连接或操作实物；总控报告的95例/42例通过仅作上下文，未在此重跑。
