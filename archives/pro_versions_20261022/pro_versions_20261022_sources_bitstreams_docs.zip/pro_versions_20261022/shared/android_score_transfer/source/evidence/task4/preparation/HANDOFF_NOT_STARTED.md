# 安卓传谱R01：拓展任务4交接

**PARTIAL：独立验收准备完成；Java黑盒验收和UI/BLE源码审查NOT_STARTED。**

2026-10-22按TASK_AND_API.md执行，独占写集仅acceptance/**、evidence/task4/**及本文件。总控最新通知任务2、3源码创建被其窗口自动审批拒绝，应保留准备成果并结束，不等待缺件、不代写或换入口绕过。当前可见app/src/main只有assets/sample.score.json；未将缺件当作功能通过。

## 已交付与实际验证

- acceptance/vectors/：原PC黄金生成68例曲谱（13合法、51原PC拒绝、4仅安卓生产范围拒绝），13组协议请求/ACK、15例NACK、14例畸形响应。字节与原PC函数直接生成，未替换原算法。
- acceptance/Harness.java：仅依赖约定Score/ScoreClient公共API的stdin/stdout假Transport。支持独立parse/upload/start/stop、完整flow和取消；可注入ACK超时、连接损坏、部分GATT写错误。**源码准备，未编译。**
- acceptance/run_acceptance.py：独立PC编解码与客户端oracle、严格Peer、Java核心快照编译与逐例证据。准备了95例计划：68解析、26工作流/反例、1例512事件完整流程。**Java入口未运行，不报告95例通过。**
- acceptance/prepare_check.py：本轮实际运行PASS，68例分类重新核实；对13个合法输入分别运行upload、stopFirst upload、start、stop、flow，共65组原PC→独立Peer流程；保存所有请求帧。重复请求同身份字节约束自检通过。Python语法检查通过；全部准备输入和PC源码前后SHA一致。
- evidence/task4/golden/：黄金生成与子智能体自审原件；evidence/task4/preparation/RUN_01/：父窗口准备自检原件。新生成向量/新工作流检查，不重跑旧PC/RTL测试组。

实际命令：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/android_score_transfer_r01/acceptance/prepare_check.py'
```

工具退出码0；受控子进程实际命令、cwd、退出码0见preparation/RUN_01/RESULT.json，原始stdout.log、stderr.log与SELF_CHECK.json同目录。黄金生成命令及退出码0见golden/RUN_01/RESULT.json。机器汇总及关键输入/产物SHA见evidence/task4/receipt.json。

## 自审及边界

已纠正准备阶段manifest读取错误：实际是JSON数组，原草稿曾按manifest['cases']读取；在任何Java执行前完成修正，且准备自检确实消费68例。无产品执行失败史；上述自有驱动修正不能写成产品修复。准备自检RUN_01无失败，未删除失败原件。

UI辅助子智能体只核任务约定、旧BLE语义及官方Android API资料；生产源码未到，没有完成源码审查，也没有审查通过结论。不能以资料准备代签握手、权限、串行GATT、20B分片、部分写禁止重发、有界接收、状态6B/version2、生命周期取消等实现要求。

Java黑盒、Java编译、Android编译/lint、APK签名、手机安装、BLE运行、板卡/音频实测均NOT_STARTED/NOT_RUN。本窗口未连接设备、未烧录、未Git、未改旧PC/ESP/FPGA封存或他人写集。180秒总截止、实际吞吐与Android权限/生命周期仍需后续验证。审核制度未启动；不向审核员/预审员发送材料。

## 接手事项

总控处理任务2/3窗口所需的直接授权确认；收到二者精确源码交付后恢复本任务，从现有材料继续：运行acceptance/run_acceptance.py，审查UI/GATT，若产品不符给出具体输入、源码SHA、失败帧和命令原件，由对应实现窗口修复。自有测试缺陷可在本写集修正并保留历史。最终由总控集成构建APK与签名核验，明确区分软件mock通过、APK构建和实物通过。

本次送达状态：本地文件已封存，交总控按文件读取；不冒称产品验收通过、真人已通知或M2已签收。具体准备入口与未来命令见acceptance/README.md。
