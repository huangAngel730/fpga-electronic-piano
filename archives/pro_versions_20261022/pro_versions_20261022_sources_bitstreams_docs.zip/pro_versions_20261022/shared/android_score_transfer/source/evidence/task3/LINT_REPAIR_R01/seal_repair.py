from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[3]
e=r/'evidence/task3';out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owned=[*sorted((r/'app/src/main/java/com/proscore/android').glob('*.java')),*sorted((r/'app/src/main/res').rglob('*.xml')),r/'app/src/main/AndroidManifest.xml']
c=json.loads((e/'COMPILE_03_LINT_REPAIR/RESULT.json').read_text())
t=json.loads((e/'TRANSPORT_05_LINT_REPAIR/RESULT.json').read_text())
assert c['exit']==0 and t['status']=='PASS'
for p in owned:
    if p.suffix=='.java':assert c['sources'][str(p)]==sha(p)
for name in ['GattTransport.java','ResponseStream.java']:
    p=r/'app/src/main/java/com/proscore/android'/name
    assert t['source_sha256'][str(p)]==sha(p)
assert json.loads((out/'DELTA_CHECK.json').read_text(encoding='utf-8'))['status']=='PASS'
p=r/'HANDOFF_TASK3.md'
s=p.read_text(encoding='utf-8').replace('COMPILE_02_FINAL：JDK17','COMPILE_03_LINT_REPAIR：JDK17').replace('TRANSPORT_04_FINAL：236项PASS','TRANSPORT_05_LINT_REPAIR：236项PASS')
s=s.replace('`app/src/main/res/values/{strings,styles}.xml`：中文资源和系统Material原生主题，无AndroidX依赖。',
 '`app/src/main/res/values/{strings,styles}.xml`及`values-v27/styles.xml`：中文资源和原生主题，API27导航栏属性仅放版本目录，无AndroidX依赖。')
s += '''

## BUILD_R03 lint返工收口

总控提供的真实R03报告4 errors、2 warnings已留原件于`evidence/task3/LINT_REPAIR_R01/BUILD_R03_lint-results-release.original.txt`；旧源码、旧HANDOFF与旧收据在同目录保留。按该报告最小修复：

1. 默认资源用AppThemeBase保存原有兼容属性，AppTheme继承该基类；仅values-v27/AppTheme加入windowLightNavigationBar，API26不再读API27属性。
2. API33的writeCharacteristic/writeDescriptor返回比较均改为BluetoothStatusCodes.SUCCESS，保留原API33守卫和API26..32兼容分支。
3. Manifest补ACCESS_COARSE_LOCATION(maxSdk30)，旧版运行时权限列表同时包含FINE/COARSE；Android31+仍只请求SCAN/CONNECT，未新增位置用途。

增量验证：COMPILE_03_LINT_REPAIR退出0；TRANSPORT_05_LINT_REPAIR真实传输源码236项host检查PASS；DELTA_CHECK.json确认API26/27/35样式解析和两支权限名单/清单有效范围。没有抬minSdk或关闭lint；未重跑旧FPGA/软件封存组。

两条warning保留：neverForLocation在旧系统被忽略，旧系统明确使用定位权限和定位开关；allowBackup=false的DataExtractionRules迁移建议未在这次最小修复扩写，本应用不持久复制导入文件或连接状态，设备迁移行为尚未实测。没有使用tools:ignore掩盖报告。

**最新源码已稳定，可由总控重跑必要APK/lint。任务3没有自行重跑lint，不宣称4 errors已获工具复验清零；实际lint结论以后续总控报告为准。**
'''
p.write_text(s,encoding='utf-8',newline='\n')
receipt=json.loads((e/'RECEIPT.json').read_text(encoding='utf-8'))
receipt['status']='LINT_REPAIR_SOURCE_AND_SOFTWARE_CHECKS_COMPLETE'
receipt['sources']={str(p.relative_to(r)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in owned}
receipt['compile']['run']='COMPILE_03_LINT_REPAIR'
receipt['transport_tests']['run']='TRANSPORT_05_LINT_REPAIR'
receipt['lint_repair']={'trigger':'BUILD_R03 report: 4 errors,2 warnings','source_fixes':4,'delta_check':'LINT_REPAIR_R01/DELTA_CHECK.json','lint_rerun':'PENDING_COORDINATOR','warnings_retained':['UnusedAttribute','DataExtractionRules'],'handoff_sha256':sha(r/'HANDOFF_TASK3.md')}
(e/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
failures=json.loads((e/'FAILURE_HISTORY.json').read_text(encoding='utf-8'))
failures.append(dict(stage='Coordinator BUILD_R03 lint',result='4 errors,2 warnings; prior javac/host checks do not substitute resource/API lint',evidence='LINT_REPAIR_R01/BUILD_R03_lint-results-release.original.txt',resolution='API27 style qualified, SDK33 SUCCESS symbols, max30 COARSE/FINE declaration and runtime pair; final javac +236host checks PASS; coordinator lint pending'))
(e/'FAILURE_HISTORY.json').write_text(json.dumps(failures,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest={str(p.relative_to(r)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in owned+[r/'HANDOFF_TASK3.md']+list(e.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and 'classes' not in p.parts}
(e/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('Repaired-source handoff sealed; coordinator APK/lint rerun explicitly pending')