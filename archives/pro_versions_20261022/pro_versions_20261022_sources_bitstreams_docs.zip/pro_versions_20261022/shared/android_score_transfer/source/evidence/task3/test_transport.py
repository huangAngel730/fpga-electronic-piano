"""Host-only software doubles; never loads Android Bluetooth/device APIs."""
from pathlib import Path
import subprocess,json,hashlib,sys
r=Path(__file__).resolve().parents[2]
e=Path(__file__).resolve().parent
run=e/(sys.argv[1] if len(sys.argv)>1 else 'TRANSPORT_01');run.mkdir();src=run/'sources';src.mkdir()
files={
'android/Manifest.java':'package android; public final class Manifest { public static class permission { public static final String BLUETOOTH_CONNECT="connect"; }}',
'android/annotation/SuppressLint.java':'package android.annotation; public @interface SuppressLint { String[] value(); }',
'android/content/pm/PackageManager.java':'package android.content.pm; public class PackageManager { public static final int PERMISSION_GRANTED=0; }',
'android/content/Context.java':'package android.content; public class Context { public int permission=0; public Context getApplicationContext(){return this;} public int checkSelfPermission(String p){return permission;} }',
'android/os/Build.java':'package android.os; public class Build { public static class VERSION { public static int SDK_INT=35; }}',
'android/os/SystemClock.java':'package android.os; public class SystemClock { public static long elapsedRealtime(){return System.nanoTime()/1000000;} }',
'android/bluetooth/BluetoothStatusCodes.java':'package android.bluetooth; public final class BluetoothStatusCodes { public static final int SUCCESS=0; }',
'android/bluetooth/BluetoothProfile.java':'package android.bluetooth; public interface BluetoothProfile { int STATE_CONNECTED=2,STATE_DISCONNECTED=0; }',
'android/bluetooth/BluetoothGattCharacteristic.java':'''package android.bluetooth; import java.util.*;
public class BluetoothGattCharacteristic {
 public static final int PROPERTY_WRITE=8,PROPERTY_NOTIFY=16,PROPERTY_READ=2,WRITE_TYPE_DEFAULT=2;
 public final UUID id; public int properties; public byte[] value; public BluetoothGattDescriptor descriptor;
 public BluetoothGattCharacteristic(UUID u,int p){id=u;properties=p;}
 public UUID getUuid(){return id;} public int getProperties(){return properties;}
 public BluetoothGattDescriptor getDescriptor(UUID u){return descriptor!=null&&descriptor.id.equals(u)?descriptor:null;}
 public boolean setValue(byte[]v){value=v.clone();return true;} public byte[] getValue(){return value==null?null:value.clone();}
 public void setWriteType(int type){if(type!=2)throw new AssertionError("not response write");}
}''',
'android/bluetooth/BluetoothGattDescriptor.java':'''package android.bluetooth; import java.util.*;
public class BluetoothGattDescriptor {
 public static final byte[] ENABLE_NOTIFICATION_VALUE={1,0};public final UUID id;public byte[]value;
 public BluetoothGattDescriptor(UUID u){id=u;} public UUID getUuid(){return id;}
 public boolean setValue(byte[]v){value=v.clone();return true;}
}''',
'android/bluetooth/BluetoothGattService.java':'''package android.bluetooth; import java.util.*;
public class BluetoothGattService {public Map<UUID,BluetoothGattCharacteristic>items=new HashMap<>();
 public BluetoothGattCharacteristic getCharacteristic(UUID id){return items.get(id);}}''',
'android/bluetooth/BluetoothGattCallback.java':'''package android.bluetooth; public abstract class BluetoothGattCallback {
 public void onConnectionStateChange(BluetoothGatt g,int s,int n){} public void onServicesDiscovered(BluetoothGatt g,int s){}
 public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int s){}
 public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int s){}
 public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,byte[]v,int s){}
 public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int s){}
 public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[]v){}
 public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){}
}''',
'android/bluetooth/BluetoothDevice.java':'''package android.bluetooth; import android.content.Context;
public class BluetoothDevice {public static final int TRANSPORT_LE=2;public final BluetoothGatt link;
 public BluetoothDevice(BluetoothGatt l){link=l;} public BluetoothGatt connectGatt(Context c,boolean auto,BluetoothGattCallback cb,int mode){
 if(auto)throw new AssertionError("auto reconnect");link.cb=cb;link.later(()->cb.onConnectionStateChange(link,0,2));return link;}}''',
'android/bluetooth/BluetoothGatt.java':'''package android.bluetooth;
import java.util.*;import java.util.concurrent.*;import android.os.Build;
public class BluetoothGatt {
 public static final int GATT_SUCCESS=0;
 public BluetoothGattCallback cb;public final BluetoothGattService service=new BluetoothGattService();
 public byte[]status={2,0,0,0,0,0};public int writes,cccdWrites,failWrite,dropWrite,callbackError;
 public boolean lateWrite,missingService,closed;public volatile boolean holdCccd;public volatile Runnable held;
 public final List<byte[]>pieces=new ArrayList<>();
 private final ScheduledExecutorService scheduler=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r);t.setDaemon(true);return t;});
 public static UUID uuid(int n){return UUID.fromString(String.format("761e%04x-6ccd-4aa4-9e21-104647415031",n));}
 public BluetoothGatt(){service.items.put(uuid(2),new BluetoothGattCharacteristic(uuid(2),8));
 service.items.put(uuid(3),new BluetoothGattCharacteristic(uuid(3),16));service.items.put(uuid(4),new BluetoothGattCharacteristic(uuid(4),2));
 service.items.get(uuid(3)).descriptor=new BluetoothGattDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));}
 public void later(Runnable r){scheduler.schedule(r,2,TimeUnit.MILLISECONDS);}
 public boolean discoverServices(){later(()->cb.onServicesDiscovered(this,0));return true;}
 public BluetoothGattService getService(UUID u){return !missingService&&u.equals(uuid(1))?service:null;}
 public boolean readCharacteristic(BluetoothGattCharacteristic c){c.value=status.clone();later(()->{if(Build.VERSION.SDK_INT>=33)cb.onCharacteristicRead(this,c,status.clone(),0);else cb.onCharacteristicRead(this,c,0);});return true;}
 public boolean setCharacteristicNotification(BluetoothGattCharacteristic c,boolean enabled){return enabled;}
 private int descriptor(BluetoothGattDescriptor d){cccdWrites++;Runnable action=()->cb.onDescriptorWrite(this,d,0);if(holdCccd)held=action;else later(action);return 0;}
 public int writeDescriptor(BluetoothGattDescriptor d,byte[]v){return descriptor(d);}
 public boolean writeDescriptor(BluetoothGattDescriptor d){return descriptor(d)==0;}
 private int write(BluetoothGattCharacteristic c,byte[]v){writes++;pieces.add(v.clone());int index=writes;
 if(index==1&&lateWrite){try{Thread.sleep(100);}catch(InterruptedException e){throw new RuntimeException(e);}cb.onCharacteristicWrite(this,c,0);return 0;}
 if(index==failWrite)return 7;if(index!=dropWrite)later(()->cb.onCharacteristicWrite(this,c,index==callbackError?5:0));return 0;}
 public int writeCharacteristic(BluetoothGattCharacteristic c,byte[]v,int type){if(type!=2)throw new AssertionError();return write(c,v);}
 public boolean writeCharacteristic(BluetoothGattCharacteristic c){return write(c,c.value)==0;}
 public void notifyData(byte[]v){BluetoothGattCharacteristic c=service.items.get(uuid(3));c.value=v.clone();if(Build.VERSION.SDK_INT>=33)cb.onCharacteristicChanged(this,c,v.clone());else cb.onCharacteristicChanged(this,c);}
 public void disconnect(){closed=true;}public void close(){closed=true;}
 public void remoteDisconnect(){cb.onConnectionStateChange(this,0,0);}
}''',
'com/proscore/android/TransportChecks.java':'''package com.proscore.android;
import android.bluetooth.*;import android.content.Context;import android.os.Build;
import java.io.*;import java.util.*;import java.util.concurrent.*;
public class TransportChecks {
 static int checks; interface Throwing {void run()throws Exception;}
 static void yes(boolean x,String s){checks++;if(!x)throw new AssertionError(s);}
 static void bad(Throwing action,boolean timeout)throws Exception{try{action.run();throw new AssertionError("negative accepted");}catch(Exception e){yes((e instanceof TimeoutException)==timeout,"wrong timeout classification "+e);}}
 static byte[] frame(int cmd,int error,int payload){byte[]b=new byte[14+payload];b[0]=(byte)165;b[1]=90;b[2]=2;b[3]=(byte)(error==0?128:129);b[10]=(byte)payload;b[12]=(byte)cmd;b[13]=(byte)error;b[14]=1;b[16]=2;
 crc(b);return b;}
 static void crc(byte[]b){int c=65535;for(int i=2;i<b.length-2;i++){c^=(b[i]&255)<<8;for(int n=0;n<8;n++)c=(c&32768)!=0?((c<<1)^4129)&65535:(c<<1)&65535;}b[b.length-2]=(byte)c;b[b.length-1]=(byte)(c>>>8);}
 static GattTransport open(BluetoothGatt fake)throws Exception{GattTransport t=new GattTransport(new Context(),s->{});t.connect(new BluetoothDevice(fake),1000);return t;}
 public static void main(String[]args)throws Exception{
  byte[]ack=frame(5,0,12),read=frame(6,0,20),nack=frame(6,15,12);
  for(byte[]v:new byte[][]{ack,read,nack})for(int split=0;split<=v.length;split++){
   ResponseStream p=new ResponseStream();if(split>0)p.feed(Arrays.copyOfRange(v,0,split));if(split<v.length)p.feed(Arrays.copyOfRange(v,split,v.length));yes(Arrays.equals(v,p.poll()),"all splits");yes(p.poll()==null,"no fabricated reply");}
  ResponseStream p=new ResponseStream();for(byte v:read)p.feed(new byte[]{v});yes(Arrays.equals(read,p.poll()),"one byte");
  p=new ResponseStream();byte[]both=new byte[ack.length+read.length];System.arraycopy(ack,0,both,0,ack.length);System.arraycopy(read,0,both,ack.length,read.length);p.feed(both);yes(Arrays.equals(ack,p.poll())&&Arrays.equals(read,p.poll()),"coalesced");
  for(int mutation=0;mutation<8;mutation++){
   byte[]b=ack.clone();switch(mutation){case 0:b[0]=0;break;case 1:b[2]=1;break;case 2:b[b.length-1]^=1;break;case 3:b[3]=127;crc(b);break;case 4:b[12]=6;crc(b);break;case 5:b[14]=2;crc(b);break;case 6:b[13]=1;crc(b);break;case 7:b[16]=1;b[17]=3;crc(b);break;}
   ResponseStream broken=new ResponseStream();bad(()->broken.feed(b),false);bad(()->broken.poll(),false);
  }
  ResponseStream overflow=new ResponseStream();for(int i=0;i<8;i++)overflow.feed(ack);bad(()->overflow.feed(ack),false);
  ResponseStream huge=new ResponseStream();bad(()->huge.feed(new byte[513]),false);
  ResponseStream payload=new ResponseStream();byte[]header=Arrays.copyOf(ack,12);header[10]=(byte)129;bad(()->payload.feed(header),false);
  for(int sdk:new int[]{26,35}){
   Build.VERSION.SDK_INT=sdk;BluetoothGatt fake=new BluetoothGatt();GattTransport t=open(fake);yes(t.isReady(),"connect version"+sdk);
   t.send(new byte[45],500);yes(fake.writes==3,"three chunks");yes(fake.pieces.get(0).length==20&&fake.pieces.get(2).length==5,"20B max");
   fake.notifyData(Arrays.copyOf(read,13));fake.notifyData(Arrays.copyOfRange(read,13,read.length));yes(Arrays.equals(t.receive(500),read),"notification immutable callback");
   bad(()->t.receive(20),true);yes(t.isReady(),"receive timeout keeps link for bounded core retry");t.close();bad(()->t.send(ack,100),false);
  }
  Build.VERSION.SDK_INT=35;
  BluetoothGatt hold=new BluetoothGatt();hold.holdCccd=true;GattTransport waiting=new GattTransport(new Context(),s->{});
  ExecutorService workers=Executors.newCachedThreadPool(r->{Thread thread=new Thread(r);thread.setDaemon(true);return thread;});Future<?> connect=workers.submit(()->{try{waiting.connect(new BluetoothDevice(hold),1000);}catch(Exception e){throw new RuntimeException(e);}});
  long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(1);while(hold.held==null&&System.nanoTime()<until)Thread.sleep(1);
  yes(hold.held!=null&&!waiting.isReady(),"ready waits actual CCCD callback");hold.held.run();connect.get(1,TimeUnit.SECONDS);yes(waiting.isReady(),"CCCD completed");waiting.close();
  for(int mode=0;mode<5;mode++){
   BluetoothGatt fake=new BluetoothGatt();if(mode==0)fake.status=new byte[]{1,0,0,0,0,0};if(mode==1)fake.status=new byte[]{2};if(mode==2)fake.missingService=true;if(mode==3)fake.service.items.get(BluetoothGatt.uuid(2)).properties=4;if(mode==4)fake.service.items.get(BluetoothGatt.uuid(3)).descriptor=null;
   bad(()->open(fake),false);yes(fake.closed,"failed setup closes");
  }
  for(int mode=0;mode<3;mode++){
   BluetoothGatt fake=new BluetoothGatt();GattTransport t=open(fake);if(mode==0)fake.failWrite=2;if(mode==1)fake.dropWrite=2;if(mode==2)fake.callbackError=2;
   bad(()->t.send(new byte[45],60),false);yes(fake.writes==2&&!t.isReady()&&fake.closed,"partial write is fatal not replayable");
  }
  BluetoothGatt remote=new BluetoothGatt();GattTransport t=open(remote);Future<?> receiving=workers.submit(()->{try{t.receive(1000);throw new AssertionError();}catch(IOException expected){}catch(Exception e){throw new RuntimeException(e);}});Thread.sleep(10);remote.remoteDisconnect();receiving.get(1,TimeUnit.SECONDS);yes(!t.isReady(),"disconnect wakes receive");
  BluetoothGatt corrupt=new BluetoothGatt();GattTransport q=open(corrupt);corrupt.notifyData(new byte[]{0});yes(!q.isReady()&&corrupt.closed,"stream corruption disconnects immediately");bad(()->q.receive(100),false);
  BluetoothGatt late=new BluetoothGatt();late.lateWrite=true;GattTransport lateTransport=open(late);bad(()->lateTransport.send(new byte[14],20),false);yes(!lateTransport.isReady(),"late completed callback cannot bypass deadline");
  workers.shutdownNow();System.out.println("PASS transport/parser checks="+checks+"; host doubles only, no Android or BLE hardware execution");
 }
}'''
}
for name,value in files.items():
 p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value,encoding='utf-8',newline='\n')
production=list((r/'app/src/main/java/com/proscore/core').glob('*.java'))+[r/'app/src/main/java/com/proscore/android'/n for n in ['GattTransport.java','ResponseStream.java']]
for p in production:
 dst=src/('com/proscore/core/' if p.parent.name=='core' else 'com/proscore/android/')/p.name
 dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes())
commands=[]
for name,cmd in [('compile',['E:/FPGA/SDKs/java/jdk17/bin/javac.exe','-encoding','UTF-8','-d',str(run/'classes'),*map(str,src.rglob('*.java'))]),('test',['E:/FPGA/SDKs/java/jdk17/bin/java.exe','-ea','-cp',str(run/'classes'),'com.proscore.android.TransportChecks'])]:
 a=subprocess.run(cmd,capture_output=True,timeout=30);(run/(name+'.stdout.raw')).write_bytes(a.stdout);(run/(name+'.stderr.raw')).write_bytes(a.stderr)
 commands.append({'command':cmd,'exit':a.returncode});(run/'COMMANDS.json').write_text(json.dumps(commands,indent=2),encoding='utf-8')
 print(a.stdout.decode(errors='replace'));print(a.stderr.decode(errors='replace'))
 if a.returncode:sys.exit(a.returncode)
(run/'RESULT.json').write_text(json.dumps({'status':'PASS','level':'host GATT doubles and real parser/core, no device','source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in production}},indent=2),encoding='utf-8')