"""Strict score validation; frozen raw <IBBBB> format and stable input order."""
import struct
CAPACITY = 512

def integer(value, upper, label):
    if type(value) is not int or not 0 <= value <= upper:
        raise ValueError(f"invalid {label}")
    return value


def encode_score(document):
    if type(document) is not dict or set(document) != {"schema", "sample_hz", "score_id", "events"}:
        raise ValueError("score fields")
    if type(document["schema"]) is not int or document["schema"] != 1:
        raise ValueError("schema")
    if type(document["sample_hz"]) is not int or document["sample_hz"] != 48000:
        raise ValueError("sample_hz")
    sid = integer(document["score_id"], 0xffffffff, "score_id")
    events = document["events"]
    if type(events) is not list or not 1 <= len(events) <= CAPACITY:
        raise ValueError("capacity 1..512")
    result, previous, active = bytearray(), 0, set()
    for event in events:
        if type(event) is not dict or set(event) != {"tick", "type", "channel", "note", "velocity"}:
            raise ValueError("event fields")
        tick = integer(event["tick"], 0xffffffff, "tick")
        channel = integer(event["channel"], 15, "channel")
        note = integer(event["note"], 127, "note")
        velocity = integer(event["velocity"], 127, "velocity")
        if event["type"] not in ("note_on", "note_off") or tick < previous:
            raise ValueError("type/tick order")
        kind = int(event["type"] == "note_off" or velocity == 0)
        key = channel, note
        if kind == 0:
            if key in active:
                raise ValueError("overlapping note identity")
            active.add(key)
        else:
            if key not in active:
                raise ValueError("unmatched note off")
            active.remove(key)
        result.extend(struct.pack("<IBBBB", tick, kind, channel, note, velocity))
        previous = tick
    if active:
        raise ValueError("unfinished note lifetime")
    return sid, bytes(result)



def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON field: ' + str(key))
        result[key] = value
    return result


def decode_records(score_id, records):
    if not records or len(records) % 8 or len(records) > 4096:
        raise ValueError('record length')
    events = []
    for tick, kind, channel, note, velocity in struct.iter_unpack('<IBBBB', records):
        if kind not in (0, 1) or (kind == 0 and velocity == 0):
            raise ValueError('noncanonical record kind/velocity')
        events.append(dict(tick=tick, type='note_off' if kind else 'note_on',
                           channel=channel, note=note, velocity=velocity))
    document = dict(schema=1, sample_hz=48000, score_id=score_id, events=events)
    if encode_score(document)[1] != records:
        raise ValueError('record roundtrip')
    return document
