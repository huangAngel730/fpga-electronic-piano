package android.bluetooth;
import java.util.*;import java.util.concurrent.*;import android.os.Build;
public class BluetoothGatt {
 public static final int GATT_SUCCESS=0;
 public BluetoothGattCallback cb;public final BluetoothGattService service=new BluetoothGattService();
 public byte[]status={2,0,0,0,0,0};public int writes,cccdWrites,failWrite,dropWrite,callbackError;
 public boolean missingService,closed;public volatile boolean holdCccd;public volatile Runnable held;
 public final List<byte[]>pieces=new ArrayList<>();
 private final ScheduledExecutorService scheduler=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r);t.setDaemon(true);return t;});
 public static UUID uuid(int n){return UUID.fromString(String.format("761e%04x-6ccd-4aa4-9e21-104647415031",n));}
 public BluetoothGatt(){service.items.put(uuid(2),new BluetoothGattCharacteristic(uuid(2),8));
 service.items.put(uuid(3),new BluetoothGattCharacteristic(uuid(3),16));service.items.put(uuid(4),new BluetoothGattCharacteristic(uuid(4),2));
 service.items.get(uuid(3)).descriptor=new BluetoothGattDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));}
 public void later(Runnable r){scheduler.schedule(r,2,TimeUnit.MILLISECONDS);}
 public boolean discoverServices(){later(()->cb.onServicesDiscovered(this,0));return true;}
 public BluetoothGattService getService(UUID u){return !missingService&&u.equals(uuid(1))?service:null;}
 public boolean readCharacteristic(BluetoothGattCharacteristic c){c.value=status.clone();later(()->{if(Build.VERSION.SDK_INT>=33)cb.onCharacteristicRead(this,c,status.clone(),0);else cb.onCharacteristicRead(this,c,0);});return true;}
 public boolean setCharacteristicNotification(BluetoothGattCharacteristic c,boolean enabled){return enabled;}
 private int descriptor(BluetoothGattDescriptor d){cccdWrites++;Runnable action=()->cb.onDescriptorWrite(this,d,0);if(holdCccd)held=action;else later(action);return 0;}
 public int writeDescriptor(BluetoothGattDescriptor d,byte[]v){return descriptor(d);}
 public boolean writeDescriptor(BluetoothGattDescriptor d){return descriptor(d)==0;}
 private int write(BluetoothGattCharacteristic c,byte[]v){writes++;pieces.add(v.clone());int index=writes;
 if(index==failWrite)return 7;if(index!=dropWrite)later(()->cb.onCharacteristicWrite(this,c,index==callbackError?5:0));return 0;}
 public int writeCharacteristic(BluetoothGattCharacteristic c,byte[]v,int type){if(type!=2)throw new AssertionError();return write(c,v);}
 public boolean writeCharacteristic(BluetoothGattCharacteristic c){return write(c,c.value)==0;}
 public void notifyData(byte[]v){BluetoothGattCharacteristic c=service.items.get(uuid(3));c.value=v.clone();if(Build.VERSION.SDK_INT>=33)cb.onCharacteristicChanged(this,c,v.clone());else cb.onCharacteristicChanged(this,c);}
 public void disconnect(){closed=true;}public void close(){closed=true;}
 public void remoteDisconnect(){cb.onConnectionStateChange(this,0,0);}
}