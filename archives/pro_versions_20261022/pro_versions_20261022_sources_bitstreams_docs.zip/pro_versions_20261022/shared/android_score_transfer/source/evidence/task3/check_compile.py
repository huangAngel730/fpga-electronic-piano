from pathlib import Path
import xml.etree.ElementTree as ET
import subprocess,json,hashlib,sys
r=Path(__file__).resolve().parents[2]
e=Path(__file__).resolve().parent
run=e/(sys.argv[1] if len(sys.argv)>1 else 'COMPILE_01');run.mkdir()
sources=list((r/'app/src/main/java').rglob('*.java'))
ids=[x.attrib['name'] for x in ET.parse(r/'app/src/main/res/values/strings.xml').getroot()]
rfile=run/'R.java'
rfile.write_text('package com.proscore.android; public final class R { public static final class string {'+''.join('public static final int '+s+'='+str(i+1)+';' for i,s in enumerate(ids))+'}}',encoding='utf-8')
cmd=['E:/FPGA/SDKs/java/jdk17/bin/javac.exe','-encoding','UTF-8','-Xlint:deprecation','-cp','E:/FPGA/SDKs/android/sdk/platforms/android-35/android.jar','-d',str(run/'classes'),str(rfile),*map(str,sources)]
a=subprocess.run(cmd,capture_output=True)
(run/'stdout.raw').write_bytes(a.stdout);(run/'stderr.raw').write_bytes(a.stderr)
(run/'RESULT.json').write_text(json.dumps({'command':cmd,'exit':a.returncode,'R_note':'R IDs synthesized from actual XML solely for javac; resource packaging/APK/lint are coordinator-owned','sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}},indent=2),encoding='utf-8')
print(a.stderr.decode(errors='replace'));print('javac Android35 / actual task2 core exit',a.returncode)
sys.exit(a.returncode)