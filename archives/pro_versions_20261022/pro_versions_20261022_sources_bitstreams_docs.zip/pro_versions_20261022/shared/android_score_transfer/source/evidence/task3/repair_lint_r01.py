from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parents[2]
e=Path(__file__).resolve().parent
out=e/'LINT_REPAIR_R01';out.mkdir()
old=json.loads((e/'RECEIPT.json').read_text(encoding='utf-8'))
for name in old['sources']:
    p=r/name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==old['sources'][name]['sha256'],f'concurrent source change: {p}'
    dest=out/'before'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for name in ['RECEIPT.json','MANIFEST.json','FAILURE_HISTORY.json']:
    shutil.copy2(e/name,out/('PREVIOUS_'+name))
shutil.copy2(r/'HANDOFF_TASK3.md',out/'PREVIOUS_HANDOFF_TASK3.md')
report=r/'app/build/intermediates/lint_intermediate_text_report/release/lintReportRelease/lint-results-release.txt'
shutil.copy2(report,out/'BUILD_R03_lint-results-release.original.txt')
p=r/'app/src/main/res/values/styles.xml'
s=p.read_text(encoding='utf-8').replace('name="AppTheme" parent=', 'name="AppThemeBase" parent=')
s=s.replace('        <item name="android:windowLightNavigationBar">true</item>\n','')
s=s.replace('</resources>', '    <style name="AppTheme" parent="@style/AppThemeBase" />\n</resources>')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'app/src/main/res/values-v27/styles.xml';p.parent.mkdir(exist_ok=True)
p.write_text('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="@style/AppThemeBase">
        <item name="android:windowLightNavigationBar">true</item>
    </style>
</resources>
''',encoding='utf-8',newline='\n')
p=r/'app/src/main/java/com/proscore/android/GattTransport.java'
s=p.read_text(encoding='utf-8').replace('import android.bluetooth.BluetoothProfile;', 'import android.bluetooth.BluetoothProfile;\nimport android.bluetooth.BluetoothStatusCodes;')
s=s.replace('BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == 0;', 'BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS;')
s=s.replace('link.writeDescriptor(d, value) == 0;', 'link.writeDescriptor(d, value) == BluetoothStatusCodes.SUCCESS;')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'app/src/main/AndroidManifest.xml'
s=p.read_text(encoding='utf-8').replace('    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"',
 '    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="30" />\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'app/src/main/java/com/proscore/android/MainActivity.java'
s=p.read_text(encoding='utf-8').replace(': new String[]{Manifest.permission.ACCESS_FINE_LOCATION};',
 ': new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};')
p.write_text(s,encoding='utf-8',newline='\n')
print('Minimal lint repair applied; R03 report, original source and previous receipts preserved')