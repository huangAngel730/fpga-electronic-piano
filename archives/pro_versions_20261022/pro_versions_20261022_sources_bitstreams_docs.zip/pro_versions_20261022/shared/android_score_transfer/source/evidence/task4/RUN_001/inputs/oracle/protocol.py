"""Strict protocol v2 codec. Derived from the byte-shape checked precursor."""
import binascii
from dataclasses import dataclass
import math
import struct
import time

MAGIC = b'\xa5\x5a'
HEADER = struct.Struct('<BBHHHH')
META = struct.Struct('<BBBBHIH')
BEGIN, DATA, COMMIT, ABORT, STATUS, READ, START, STOP, CLEAR, READ_BEGIN, READ_END = range(1, 12)
ACK, NACK, BUSY = 0x80, 0x81, 15
VERSION = 2


def uint(value, bits, label):
    if type(value) is not int or not 0 <= value < (1 << bits):
        raise ValueError('RANGE:' + label)
    return value


def crc(raw):
    return binascii.crc_hqx(raw, 0xffff)


@dataclass(frozen=True)
class Frame:
    command: int
    session: int
    seq: int
    offset: int = 0
    payload: bytes = b''

    def encode(self):
        for label, bits in (('command', 8), ('session', 16), ('seq', 16), ('offset', 16)):
            uint(getattr(self, label), bits, label)
        if type(self.payload) is not bytes or len(self.payload) > 128:
            raise ValueError('PAYLOAD_LENGTH')
        body = HEADER.pack(VERSION, self.command, self.session, self.seq,
                           self.offset, len(self.payload)) + self.payload
        return MAGIC + body + struct.pack('<H', crc(body))


def decode(raw):
    if type(raw) is not bytes or len(raw) < 14 or raw[:2] != MAGIC:
        raise ValueError('FRAME_SYNC_OR_TRUNCATION')
    version, command, session, seq, offset, length = HEADER.unpack(raw[2:12])
    if version != VERSION:
        raise ValueError('VERSION_V2_REQUIRED')
    if length > 128 or len(raw) != 14 + length:
        raise ValueError('EXACT_FRAME_LENGTH')
    if crc(raw[2:-2]) != int.from_bytes(raw[-2:], 'little'):
        raise ValueError('FRAME_CRC')
    return Frame(command, session, seq, offset, raw[12:-2])


class NackError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__('NACK:' + str(code))


def response(request, error, committed=False, active=False, count=0, score_id=0,
             received=0, event=None):
    payload = META.pack(request.command, error, int(committed), int(active),
                        count, score_id, received)
    if event is not None:
        if request.command != READ or error or len(event) != 8:
            raise ValueError('RESPONSE_EVENT_SHAPE')
        payload += event
    return Frame(ACK if error == 0 else NACK, request.session, request.seq,
                 request.offset, payload).encode()


def validate_response(raw, request):
    reply = decode(raw)
    if (reply.session, reply.seq, reply.offset) != (request.session, request.seq, request.offset):
        raise ValueError('RESPONSE_IDENTITY')
    if reply.command not in (ACK, NACK) or len(reply.payload) not in (12, 20):
        raise ValueError('RESPONSE_SHAPE')
    metadata = META.unpack(reply.payload[:12])
    if metadata[0] != request.command:
        raise ValueError('RESPONSE_COMMAND')
    expected = 20 if request.command == READ and reply.command == ACK else 12
    if len(reply.payload) != expected:
        raise ValueError('RESPONSE_SHAPE')
    if reply.command == ACK and metadata[1] != 0 or reply.command == NACK and metadata[1] == 0:
        raise ValueError('ACK_ERROR_CONTRADICTION')
    if metadata[2] not in (0, 1) or metadata[3] not in (0, 1) or metadata[4] > 512:
        raise ValueError('METADATA_RANGE')
    if reply.command == NACK:
        if not 1 <= metadata[1] <= BUSY:
            raise ValueError('UNKNOWN_ERROR_CODE')
        raise NackError(metadata[1])
    return metadata, reply.payload[12:]

