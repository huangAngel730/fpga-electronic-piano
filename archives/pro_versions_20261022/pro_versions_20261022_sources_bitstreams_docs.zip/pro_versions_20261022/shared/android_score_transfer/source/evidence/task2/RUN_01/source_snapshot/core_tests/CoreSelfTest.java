package com.proscore.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Device-free tests against a stateful peer and independently decoded headers. */
public final class CoreSelfTest {
    interface Checked { void run() throws Exception; }
    static int tests,assertions,failed;
    static Path fixtures;
    static void check(boolean value,String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
    }
    static void test(String name,Checked body) {
        tests++;
        try { body.run();System.out.println("PASS "+name); }
        catch (Exception | AssertionError error) { failed++;System.err.println("FAIL "+name);error.printStackTrace(); }
    }
    static Exception fails(Checked body,String code) throws Exception {
        try { body.run(); } catch (Exception error) {
            check(code==null || error.toString().contains(code),"expected "+code+", got "+error);
            return error;
        }
        throw new AssertionError("expected failure "+code);
    }
    static byte[] utf(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    static byte[] unhex(String text) {
        byte[] out=new byte[text.length()/2];
        for(int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(text.substring(i*2,i*2+2),16);
        return out;
    }
    static String event(int tick,String kind,int channel,int note,int velocity) {
        return "{\"tick\":"+tick+",\"type\":\""+kind+"\",\"channel\":"+channel+",\"note\":"+note+",\"velocity\":"+velocity+"}";
    }
    static String document(String events) { return "{\"schema\":1,\"sample_hz\":48000,\"score_id\":4294967295,\"events\":["+events+"]}"; }
    static String pair() { return event(0,"note_on",0,60,100)+","+event(10,"note_off",0,60,0); }
    static Score score(int count) throws Exception {
        StringBuilder events=new StringBuilder();
        for(int i=0;i<count/2;i++) {
            if(i>0) events.append(',');
            events.append(event(i*20,"note_on",0,60,100)).append(',').append(event(i*20+10,"note_off",0,60,0));
        }
        return Score.parseUtf8(utf(document(events.toString())));
    }
    static int u16(byte[] b,int p) { return (b[p]&255)|((b[p+1]&255)<<8); }
    static long u32(byte[] b,int p) { return ((long)u16(b,p))|((long)u16(b,p+2)<<16); }
    static void le16(byte[] b,int p,int n) { b[p]=(byte)n;b[p+1]=(byte)(n>>>8); }
    static void le32(byte[] b,int p,long n) { for(int i=0;i<4;i++) b[p+i]=(byte)(n>>>(8*i)); }
    static final int[] CRC_TABLE=new int[256];
    static {
        for(int n=0;n<256;n++) {
            int c=n<<8;
            for(int j=0;j<8;j++) c=((c<<1)^((c&32768)!=0?0x1021:0))&65535;
            CRC_TABLE[n]=c;
        }
    }
    static int crc(byte[] raw,int start,int count) {
        int c=65535;
        for(int i=start;i<start+count;i++) c=((c<<8)^CRC_TABLE[((c>>>8)^(raw[i]&255))&255])&65535;
        return c;
    }
    static void fixCrc(byte[] raw) { le16(raw,raw.length-2,crc(raw,2,raw.length-4)); }
    static byte[] reply(byte[] request,int error,boolean committed,boolean active,int count,long id,int received,byte[] event) {
        byte[] raw=new byte[26+(event==null?0:8)];
        raw[0]=(byte)165;raw[1]=90;raw[2]=2;raw[3]=(byte)(error==0?128:129);
        System.arraycopy(request,4,raw,4,6);le16(raw,10,raw.length-14);
        raw[12]=request[3];raw[13]=(byte)error;raw[14]=(byte)(committed?1:0);raw[15]=(byte)(active?1:0);
        le16(raw,16,count);le32(raw,18,id);le16(raw,22,received);
        if(event!=null) System.arraycopy(event,0,raw,24,8);
        fixCrc(raw);return raw;
    }
    static final class FakeClock implements ScoreClient.Clock {
        long now;
        public long nanoTime() { return now; }
        void advance(long millis) { now+=millis*1_000_000L; }
    }
    static final class Peer implements ScoreClient.Transport {
        final FakeClock clock;
        final Queue<byte[]> incoming=new ArrayDeque<>();
        final List<byte[]> sent=new ArrayList<>();
        final List<Integer> commands=new ArrayList<>();
        final Map<Integer,Integer> drops=new HashMap<>();
        byte[] records=new byte[0],cachedRequest,cachedReply,delayedAbort;
        ByteArrayOutputStream staging;
        long id,stagedId;
        int expectedSeq,expectedBytes,expectedCrc,uploadSession,index,commits,starts;
        boolean playing,scope,verified,sendFails,sendTimeout,disconnect,badCrc,wrongRead,wrongIdentity,shortRead,aliasAbort;
        long receiveDelay,sendDelay;
        CountDownLatch waiting,release;
        Peer(FakeClock clock) { this.clock=clock; }
        public void send(byte[] raw,long timeout) throws Exception {
            check(timeout>0 && timeout<=2000,"finite relative send timeout");
            sent.add(raw.clone());
            if(sendFails) throw new IOException("GATT partial write");
            if(sendTimeout) throw new TimeoutException("GATT partial write timeout");
            if(disconnect) throw new IOException("disconnected");
            clock.advance(sendDelay);
            check(raw.length>=14 && (raw[0]&255)==165 && raw[1]==90 && raw[2]==2,"request framing");
            check(raw.length==14+u16(raw,10),"request exact size");
            check(u16(raw,raw.length-2)==crc(raw,2,raw.length-4),"request CRC");
            int cmd=raw[3]&255,session=u16(raw,4),seq=u16(raw,6),offset=u16(raw,8);
            byte[] data=Arrays.copyOfRange(raw,12,raw.length-2);
            commands.add(cmd);
            byte[] response;
            if(Arrays.equals(raw,cachedRequest)) response=cachedReply.clone();
            else {
                int error=0;
                byte[] event=null;
                if(cmd>=1 && cmd<=4 && (scope||playing)) error=15;
                else if(cmd==1) {
                    check(data.length==14 && seq==0 && offset==0,"BEGIN shape");
                    stagedId=u32(data,0);expectedBytes=u16(data,6);expectedCrc=u16(data,8);
                    check(u16(data,4)*8==expectedBytes && u32(data,10)==48000,"BEGIN score fields");
                    expectedSeq=1;uploadSession=session;staging=new ByteArrayOutputStream();verified=false;
                } else if(cmd==2) {
                    if(staging==null || session!=uploadSession) error=5;
                    else if(seq!=expectedSeq) error=6;
                    else if(offset!=staging.size()) error=7;
                    else { staging.write(data);expectedSeq++; }
                } else if(cmd==3) {
                    if(staging==null) error=5;
                    else if(seq!=expectedSeq) error=6;
                    else if(staging.size()!=expectedBytes) error=8;
                    else if(crc(staging.toByteArray(),0,staging.size())!=expectedCrc) error=9;
                    else { records=staging.toByteArray();id=stagedId;staging=null;commits++;verified=false; }
                } else if(cmd==4) staging=null;
                else if(cmd==10) {
                    check(offset==0 && data.length==8 && u16(data,6)==0,"READ_BEGIN shape");
                    if(playing||scope) error=15;
                    else if(records.length==0 || u32(data,0)!=id || u16(data,4)!=records.length/8) error=13;
                    else { scope=true;index=0;verified=false; }
                } else if(cmd==6) {
                    check(data.length==0,"READ no payload");
                    if(!scope || offset!=index || index>=records.length/8) error=13;
                    else { event=Arrays.copyOfRange(records,index*8,index*8+8);index++; }
                } else if(cmd==11) {
                    check(offset==0 && data.length==0,"READ_END shape");
                    if(!scope || index!=records.length/8) error=13;
                    else { scope=false;verified=true; }
                } else if(cmd==7) {
                    check(offset==0 && data.length==8 && u16(data,6)==0,"START shape");
                    if(scope||playing) error=15;
                    else if(!verified || u32(data,0)!=id || u16(data,4)!=records.length/8) error=13;
                    else { playing=true;starts++; }
                } else if(cmd==8) {
                    check(offset==0 && data.length==0,"STOP no score required");
                    playing=false;scope=false;
                } else if(cmd!=5) error=3;
                response=reply(raw,error,records.length!=0,staging!=null,records.length/8,id,staging==null?0:staging.size(),event);
                if(error==0) { cachedRequest=raw.clone();cachedReply=response.clone(); }
            }
            if(cmd==4) delayedAbort=response.clone();
            if(cmd==3 && aliasAbort && delayedAbort!=null) incoming.add(delayedAbort.clone());
            Integer remaining=drops.get(cmd);
            if(remaining!=null && remaining>0) { drops.put(cmd,remaining-1);return; }
            if(cmd==6 && wrongRead) { response[24]^=1;fixCrc(response); }
            if(cmd==6 && wrongIdentity) { response[18]^=1;fixCrc(response); }
            if(cmd==6 && shortRead) { response=Arrays.copyOf(response,26);le16(response,10,12);fixCrc(response); }
            if(badCrc) response[response.length-1]^=1;
            incoming.add(response);
        }
        public byte[] receive(long timeout) throws Exception {
            check(timeout>0 && timeout<=2000,"finite relative receive timeout");
            if(waiting!=null) {
                waiting.countDown();
                if(!release.await(10,TimeUnit.SECONDS)) throw new IOException("test latch timeout");
            }
            if(!incoming.isEmpty()) { clock.advance(receiveDelay);return incoming.remove(); }
            clock.advance(timeout);throw new TimeoutException("simulated receive timeout");
        }
    }
    static ScoreClient client(Peer peer) { return new ScoreClient(peer,null,0x1234,peer.clock); }

    public static void main(String[] args) throws Exception {
        fixtures=java.nio.file.Paths.get(args[0]);
        test("CRC and Python v2 golden vectors",()->{
            check(Protocol.crc16(utf("123456789"))==0x29b1,"gold CRC");
            for(String row:Files.readAllLines(fixtures.resolve("golden_frames.txt"),StandardCharsets.UTF_8)) {
                String[] values=row.split("\\|");
                byte[] raw=unhex(values[1]);
                Protocol.Frame q=Protocol.decode(raw);
                check(q.command==Integer.parseInt(values[0]),"gold command");
                check(Arrays.equals(q.encode(),raw),"exact Python frame");
                Protocol.validateResponse(unhex(values[2]),q);
                Exception error=fails(()->Protocol.validateResponse(unhex(values[3]),q),"NACK:15");
                check(error instanceof Protocol.NackException,"NACK type");
            }
        });
        test("Score Python bytes, uint32 identity, defensive clones",()->{
            Score score=Score.parseUtf8(Files.readAllBytes(fixtures.resolve("valid.score.json")));
            byte[] expected=Files.readAllBytes(fixtures.resolve("valid.records.bin"));
            check(Arrays.equals(score.getRecords(),expected),"frozen record equality");
            check(score.getScoreId()==4294967295L,"u32 unsigned id");
            byte[] clone=score.getRecords();clone[0]^=1;
            check(Arrays.equals(score.getRecords(),expected),"defensive clone");
        });
        test("Strict malformed JSON matrix",()->{
            for(String bad:Files.readAllLines(fixtures.resolve("invalid_json.txt"),StandardCharsets.UTF_8)) fails(()->Score.parseUtf8(utf(bad)),null);
            fails(()->Score.parseUtf8(new byte[]{(byte)0xc0,(byte)0xaf}),null);
            fails(()->Score.parseUtf8(new byte[2*1024*1024+1]),"JSON_SIZE");
        });
        test("Production ranges and same-tick stable order",()->{
            String events=event(16777215,"note_on",15,36,127)+","+event(16777215,"note_off",15,36,127);
            check(Score.parseUtf8(utf(document(events))).getCount()==2,"inclusive tick/note min");
            check(Score.parseUtf8(utf(document(event(0,"note_on",0,84,1)+","+event(0,"note_on",0,84,0)))).getRecords()[12]==1,"zero velocity NoteOn becomes off");
            fails(()->Score.parseUtf8(utf(document(event(0,"note_off",0,60,0)+","+event(0,"note_on",0,60,1)))),"UNMATCHED");
            check(score(512).getRecords().length==4096,"maximum event capacity");
            fails(()->score(514),"JSON_ARRAY_LIMIT");
        });
        test("Response exact shapes, flags and error matrix",()->{
            for(int cmd=1;cmd<=11;cmd++) {
                final int command=cmd;
                Protocol.Frame q=new Protocol.Frame(cmd,1,2,3,new byte[0]);
                byte[] good=reply(q.encode(),0,false,false,0,0,0,cmd==6?new byte[8]:null);
                Protocol.validateResponse(good,q);
                byte[] bad=reply(q.encode(),0,false,false,0,0,0,cmd!=6?new byte[8]:null);
                fails(()->Protocol.validateResponse(bad,q),"SHAPE");
                for(int code=1;code<=15;code++) {
                    byte[] nack=reply(q.encode(),code,false,false,0,0,0,null);
                    fails(()->Protocol.validateResponse(nack,q),"NACK:"+code);
                }
                byte[] invalid=reply(q.encode(),16,false,false,0,0,0,null);
                fails(()->Protocol.validateResponse(invalid,q),"UNKNOWN_ERROR");
                check(command==cmd,"loop stable");
            }
            Protocol.Frame q=new Protocol.Frame(5,1,1,0,new byte[0]);
            byte[] flag=reply(q.encode(),0,false,false,0,0,0,null);flag[14]=2;fixCrc(flag);
            fails(()->Protocol.validateResponse(flag,q),"METADATA_RANGE");
            byte[] contradiction=reply(q.encode(),15,false,false,0,0,0,null);contradiction[3]=(byte)128;fixCrc(contradiction);
            fails(()->Protocol.validateResponse(contradiction,q),"CONTRADICTION");
            byte[] old=q.encode();old[2]=1;fixCrc(old);
            fails(()->Protocol.decode(old),"VERSION_V2");
        });
        test("Upload publishes only, full sequential read verifies",()->{
            Peer p=new Peer(new FakeClock());Score score=score(2);
            ScoreClient c=client(p);c.upload(score,false);
            check(p.commits==1 && !p.playing && p.verified,"publish != start");
            check(p.commands.equals(Arrays.asList(1,2,3,5,10,6,6,11)),"upload/read order");
            fails(()->c.upload(score,false),"ONE_UPLOAD_PER_SESSION");
        });
        test("Maximum512 upload, START re-read, STOP without file",()->{
            Peer p=new Peer(new FakeClock());Score score=score(512);
            client(p).upload(score,false);
            check(p.index==512,"all READ indices");
            int before=p.commands.size();
            client(p).start(score);
            check(p.commands.get(before)==10 && p.index==512 && p.playing,"START re-read first");
            check(p.commands.get(p.commands.size()-1)==7,"START last");
            client(p).stop();check(!p.playing && !p.scope,"STOP independently usable");
        });
        test("Lost COMMIT and READ ACK exact replay once, not double commit/advance",()->{
            Peer p=new Peer(new FakeClock());p.drops.put(3,1);p.drops.put(6,1);
            client(p).upload(score(2),false);
            check(p.commits==1 && p.index==2,"replay side effects once");
            for(int i=1;i<p.sent.size();i++) if((p.sent.get(i)[3]&255)==(p.sent.get(i-1)[3]&255)) check(Arrays.equals(p.sent.get(i),p.sent.get(i-1)),"same request retry bytes");
        });
        test("Lost START ACK cache wins over playing BUSY",()->{
            Peer p=new Peer(new FakeClock());Score score=score(2);client(p).upload(score,false);
            p.drops.put(7,1);client(p).start(score);
            check(p.starts==1 && p.playing,"START replay once");
        });
        test("BUSY15 immediate failure without retransmission",()->{
            Peer p=new Peer(new FakeClock());p.playing=true;
            Exception e=fails(()->client(p).upload(score(2),false),"NACK:15");
            check(e instanceof Protocol.NackException && p.sent.size()==1,"NACK not retried");
        });
        test("Explicit recovery STOP/ABORT; late ABORT cannot alias COMMIT",()->{
            Peer p=new Peer(new FakeClock());p.scope=true;p.aliasAbort=true;
            client(p).upload(score(2),true);
            check(p.commands.subList(0,3).equals(Arrays.asList(8,4,1)),"explicit safe recovery");
            check(u16(p.sent.get(0),6)==8192 && u16(p.sent.get(1),6)==8193,"query identity range");
            check(p.commits==1 && p.verified,"late recovery ACK ignored");
        });
        test("Read mismatch, wrong published identity and short ACK fail before START/END",()->{
            for(int variant=0;variant<3;variant++) {
                Peer p=new Peer(new FakeClock());Score score=score(2);client(p).upload(score,false);
                p.commands.clear();p.wrongRead=variant==0;p.wrongIdentity=variant==1;p.shortRead=variant==2;
                fails(()->client(p).start(score),variant==0?"READBACK_MISMATCH":variant==1?"PUBLISHED_IDENTITY":"RESPONSE_SHAPE");
                check(!p.commands.contains(7) && !p.commands.contains(11) && p.scope,"no START/END or auto lease release");
            }
        });
        test("Corrupt response stream fails immediately",()->{
            Peer p=new Peer(new FakeClock());p.badCrc=true;
            fails(()->client(p).stop(),"FRAME_CRC");check(p.sent.size()==1,"bad CRC no retry");
        });
        test("Send failure and send timeout never replay partial frame",()->{
            for(int variant=0;variant<2;variant++) {
                Peer p=new Peer(new FakeClock());p.sendFails=variant==0;p.sendTimeout=variant==1;
                fails(()->client(p).stop(),"SEND_FAILED_STATE_UNKNOWN");
                check(p.sent.size()==1 && p.commands.isEmpty(),"partial send never retried");
            }
        });
        test("Receive timeout has at most two exact retransmissions",()->{
            Peer p=new Peer(new FakeClock());p.drops.put(8,99);
            fails(()->client(p).stop(),"ACK_TIMEOUT");
            check(p.sent.size()==3,"initial plus two retries");
            check(Arrays.equals(p.sent.get(0),p.sent.get(1)) && Arrays.equals(p.sent.get(1),p.sent.get(2)),"identical raw retries");
        });
        test("Late full send fails closed rather than retry",()->{
            Peer p=new Peer(new FakeClock());p.sendDelay=2000;
            fails(()->client(p).stop(),"SEND_DEADLINE_STATE_UNKNOWN");check(p.sent.size()==1,"no resend after send deadline");
        });
        test("Monotonic total deadline and preflight impossibility",()->{
            FakeClock clock=new FakeClock();Peer p=new Peer(clock);ScoreClient c=client(p);clock.advance(178000);
            fails(()->c.upload(score(512),false),"TIME_BUDGET");check(p.sent.isEmpty(),"reject impossible UART lower bound before BEGIN");
            Peer slow=new Peer(new FakeClock());slow.receiveDelay=400;
            fails(()->client(slow).upload(score(512),false),"TOTAL_TIMEOUT_180S");
            check(!slow.commands.contains(11) && !slow.commands.contains(7),"no fake final success");
        });
        test("Cancel before send and during read do not autoSTOP",()->{
            Peer p=new Peer(new FakeClock());ScoreClient c=client(p);c.cancel();
            fails(c::stop,"CANCELLED");check(p.sent.isEmpty(),"cancel before sends");
            Peer reading=new Peer(new FakeClock());Score score=score(2);client(reading).upload(score,false);reading.commands.clear();
            ScoreClient[] holder=new ScoreClient[1];
            holder[0]=new ScoreClient(reading,(phase,done,total)->{ if(phase.equals("完整回读核对") && done==1) holder[0].cancel(); },0x2345,reading.clock);
            fails(()->holder[0].start(score),"CANCELLED");
            check(!reading.commands.contains(7) && !reading.commands.contains(8) && !reading.commands.contains(11),"cancel is not STOP");
        });
        test("Cancel interrupts a blocked receive, no success indication",()->{
            Peer p=new Peer(new FakeClock());p.waiting=new CountDownLatch(1);p.release=new CountDownLatch(1);
            ScoreClient c=client(p);Exception[] error=new Exception[1];
            Thread thread=new Thread(()->{ try { c.stop(); } catch(Exception ex) { error[0]=ex; } });
            thread.start();check(p.waiting.await(2,TimeUnit.SECONDS),"worker entered receive");
            c.cancel();thread.join(2000);
            check(!thread.isAlive() && error[0] instanceof InterruptedException,"cancellation interrupts wait");
            check(p.commands.equals(Arrays.asList(8)),"no extra control generated");
        });
        test("No success progress after failure; full-size preflight visible",()->{
            Peer p=new Peer(new FakeClock());p.playing=true;List<String> phases=new ArrayList<>();
            ScoreClient c=new ScoreClient(p,(phase,done,total)->phases.add(phase),1,p.clock);
            fails(()->c.upload(score(512),false),"NACK:15");
            check(phases.get(0).contains("549次交互") && phases.get(0).contains("平均预算"),"full transfer timing assessed");
            check(phases.stream().noneMatch(x->x.equals("上传并核验完成")),"no fake success progress");
        });
        System.out.println("RESULT tests="+tests+" assertions="+assertions+" failures="+failed);
        if(failed!=0) System.exit(1);
    }
}
