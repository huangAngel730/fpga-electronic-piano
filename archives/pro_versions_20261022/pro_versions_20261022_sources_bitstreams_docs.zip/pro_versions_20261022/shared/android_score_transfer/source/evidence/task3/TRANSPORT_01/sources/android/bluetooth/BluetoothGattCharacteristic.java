package android.bluetooth; import java.util.*;
public class BluetoothGattCharacteristic {
 public static final int PROPERTY_WRITE=8,PROPERTY_NOTIFY=16,PROPERTY_READ=2,WRITE_TYPE_DEFAULT=2;
 public final UUID id; public int properties; public byte[] value; public BluetoothGattDescriptor descriptor;
 public BluetoothGattCharacteristic(UUID u,int p){id=u;properties=p;}
 public UUID getUuid(){return id;} public int getProperties(){return properties;}
 public BluetoothGattDescriptor getDescriptor(UUID u){return descriptor!=null&&descriptor.id.equals(u)?descriptor:null;}
 public boolean setValue(byte[]v){value=v.clone();return true;} public byte[] getValue(){return value==null?null:value.clone();}
 public void setWriteType(int type){if(type!=2)throw new AssertionError("not response write");}
}