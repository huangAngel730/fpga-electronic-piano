package com.proscore.android;
import android.bluetooth.*;import android.content.Context;import android.os.Build;
import java.io.*;import java.util.*;import java.util.concurrent.*;
public class TransportChecks {
 static int checks; interface Throwing {void run()throws Exception;}
 static void yes(boolean x,String s){checks++;if(!x)throw new AssertionError(s);}
 static void bad(Throwing action,boolean timeout)throws Exception{try{action.run();throw new AssertionError("negative accepted");}catch(Exception e){yes((e instanceof TimeoutException)==timeout,"wrong timeout classification "+e);}}
 static byte[] frame(int cmd,int error,int payload){byte[]b=new byte[14+payload];b[0]=(byte)165;b[1]=90;b[2]=2;b[3]=(byte)(error==0?128:129);b[10]=(byte)payload;b[12]=(byte)cmd;b[13]=(byte)error;b[14]=1;b[16]=2;
 crc(b);return b;}
 static void crc(byte[]b){int c=65535;for(int i=2;i<b.length-2;i++){c^=(b[i]&255)<<8;for(int n=0;n<8;n++)c=(c&32768)!=0?((c<<1)^4129)&65535:(c<<1)&65535;}b[b.length-2]=(byte)c;b[b.length-1]=(byte)(c>>>8);}
 static GattTransport open(BluetoothGatt fake)throws Exception{GattTransport t=new GattTransport(new Context(),s->{});t.connect(new BluetoothDevice(fake),1000);return t;}
 public static void main(String[]args)throws Exception{
  byte[]ack=frame(5,0,12),read=frame(6,0,20),nack=frame(6,15,12);
  for(byte[]v:new byte[][]{ack,read,nack})for(int split=0;split<=v.length;split++){
   ResponseStream p=new ResponseStream();if(split>0)p.feed(Arrays.copyOfRange(v,0,split));if(split<v.length)p.feed(Arrays.copyOfRange(v,split,v.length));yes(Arrays.equals(v,p.poll()),"all splits");yes(p.poll()==null,"no fabricated reply");}
  ResponseStream p=new ResponseStream();for(byte v:read)p.feed(new byte[]{v});yes(Arrays.equals(read,p.poll()),"one byte");
  p=new ResponseStream();byte[]both=new byte[ack.length+read.length];System.arraycopy(ack,0,both,0,ack.length);System.arraycopy(read,0,both,ack.length,read.length);p.feed(both);yes(Arrays.equals(ack,p.poll())&&Arrays.equals(read,p.poll()),"coalesced");
  for(int mutation=0;mutation<8;mutation++){
   byte[]b=ack.clone();switch(mutation){case 0:b[0]=0;break;case 1:b[2]=1;break;case 2:b[b.length-1]^=1;break;case 3:b[3]=127;crc(b);break;case 4:b[12]=6;crc(b);break;case 5:b[14]=2;crc(b);break;case 6:b[13]=1;crc(b);break;case 7:b[16]=1;b[17]=3;crc(b);break;}
   ResponseStream broken=new ResponseStream();bad(()->broken.feed(b),false);bad(()->broken.poll(),false);
  }
  ResponseStream overflow=new ResponseStream();for(int i=0;i<8;i++)overflow.feed(ack);bad(()->overflow.feed(ack),false);
  ResponseStream huge=new ResponseStream();bad(()->huge.feed(new byte[513]),false);
  ResponseStream payload=new ResponseStream();byte[]header=Arrays.copyOf(ack,12);header[10]=(byte)129;bad(()->payload.feed(header),false);
  for(int sdk:new int[]{26,35}){
   Build.VERSION.SDK_INT=sdk;BluetoothGatt fake=new BluetoothGatt();GattTransport t=open(fake);yes(t.isReady(),"connect version"+sdk);
   t.send(new byte[45],500);yes(fake.writes==3,"three chunks");yes(fake.pieces.get(0).length==20&&fake.pieces.get(2).length==5,"20B max");
   fake.notifyData(Arrays.copyOf(read,13));fake.notifyData(Arrays.copyOfRange(read,13,read.length));yes(Arrays.equals(t.receive(500),read),"notification immutable callback");
   bad(()->t.receive(20),true);yes(t.isReady(),"receive timeout keeps link for bounded core retry");t.close();bad(()->t.send(ack,100),false);
  }
  Build.VERSION.SDK_INT=35;
  BluetoothGatt hold=new BluetoothGatt();hold.holdCccd=true;GattTransport waiting=new GattTransport(new Context(),s->{});
  ExecutorService workers=Executors.newCachedThreadPool();Future<?> connect=workers.submit(()->{try{waiting.connect(new BluetoothDevice(hold),1000);}catch(Exception e){throw new RuntimeException(e);}});
  long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(1);while(hold.held==null&&System.nanoTime()<until)Thread.sleep(1);
  yes(hold.held!=null&&!waiting.isReady(),"ready waits actual CCCD callback");hold.held.run();connect.get(1,TimeUnit.SECONDS);yes(waiting.isReady(),"CCCD completed");waiting.close();
  for(int mode=0;mode<5;mode++){
   BluetoothGatt fake=new BluetoothGatt();if(mode==0)fake.status=new byte[]{1,0,0,0,0,0};if(mode==1)fake.status=new byte[]{2};if(mode==2)fake.missingService=true;if(mode==3)fake.service.items.get(BluetoothGatt.uuid(2)).properties=4;if(mode==4)fake.service.items.get(BluetoothGatt.uuid(3)).descriptor=null;
   bad(()->open(fake),false);yes(fake.closed,"failed setup closes");
  }
  for(int mode=0;mode<3;mode++){
   BluetoothGatt fake=new BluetoothGatt();GattTransport t=open(fake);if(mode==0)fake.failWrite=2;if(mode==1)fake.dropWrite=2;if(mode==2)fake.callbackError=2;
   bad(()->t.send(new byte[45],60),false);yes(fake.writes==2&&!t.isReady()&&fake.closed,"partial write is fatal not replayable");
  }
  BluetoothGatt remote=new BluetoothGatt();GattTransport t=open(remote);Future<?> receiving=workers.submit(()->{try{t.receive(1000);throw new AssertionError();}catch(IOException expected){}catch(Exception e){throw new RuntimeException(e);}});Thread.sleep(10);remote.remoteDisconnect();receiving.get(1,TimeUnit.SECONDS);yes(!t.isReady(),"disconnect wakes receive");
  BluetoothGatt corrupt=new BluetoothGatt();GattTransport q=open(corrupt);corrupt.notifyData(new byte[]{0});yes(!q.isReady()&&corrupt.closed,"stream corruption disconnects immediately");bad(()->q.receive(100),false);
  BluetoothGatt late=new BluetoothGatt();late.lateWrite=true;GattTransport lateTransport=open(late);bad(()->lateTransport.send(new byte[14],20),false);yes(!lateTransport.isReady(),"late completed callback cannot bypass deadline");
  workers.shutdownNow();System.out.println("PASS transport/parser checks="+checks+"; host doubles only, no Android or BLE hardware execution");
 }
}