"""Finite stop-and-wait v2 client. A timeout never proves FPGA control completion."""
import asyncio
import math
import secrets
import struct
import time
from protocol import (Frame, decode, validate_response, crc, uint, BEGIN, DATA,
                      COMMIT, ABORT, STATUS, READ, START, STOP, CLEAR, READ_BEGIN, READ_END)
from score import decode_records


class ScoreClient:
    def __init__(self, transport, session=None, ack_timeout=2.0, total_timeout=180.0, retries=2):
        for value in (ack_timeout, total_timeout):
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError('finite positive timeout required')
        uint(retries, 16, 'retries')
        self.session = secrets.randbelow(65535)+1 if session is None else uint(session, 16, 'session')
        if not self.session:
            raise ValueError('nonzero session required')
        self.transport, self.ack_timeout, self.retries = transport, ack_timeout, retries
        self.deadline = time.monotonic() + total_timeout
        # Upload is at most 4096 single-byte DATA packets plus COMMIT 4097.
        # Keep query/control identities disjoint, including late recovery ACKs.
        self.seq = 8192
        self.upload_attempted = False
        self.retry_count = 0
        self.trace = []
        self.lock = asyncio.Lock()

    def request(self, command, offset=0, payload=b''):
        if self.seq > 65535:
            raise ValueError('session sequence exhausted; reconnect explicitly')
        request = Frame(command, self.session, self.seq, offset, payload)
        self.seq += 1
        return request

    async def exchange(self, request):
        if request.command not in range(1, 12):
            raise ValueError('request command')
        raw = request.encode()
        async with self.lock:
            for attempt in range(self.retries+1):
                remaining = self.deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('total transaction deadline')
                until = min(self.deadline, time.monotonic()+self.ack_timeout)
                try:
                    await asyncio.wait_for(self.transport.send(raw), timeout=until-time.monotonic())
                    self.trace.append(dict(tx=raw.hex(), attempt=attempt))
                    while True:
                        remaining = until-time.monotonic()
                        if remaining <= 0:
                            raise TimeoutError('ACK deadline')
                        reply_raw = await asyncio.wait_for(self.transport.receive(), timeout=remaining)
                        reply = decode(reply_raw)
                        if (reply.session, reply.seq, reply.offset) != (request.session, request.seq, request.offset):
                            self.trace.append(dict(unrelated_rx=reply_raw.hex()))
                            continue
                        self.trace.append(dict(rx=reply_raw.hex()))
                        return validate_response(reply_raw, request)
                except TimeoutError:
                    self.trace.append(dict(timeout=True, attempt=attempt, tx=raw.hex()))
                    # A partly written request cannot be replayed into the same bridge stream:
                    # transport.send must flag this situation as a fatal ConnectionError.
                    if attempt == self.retries or time.monotonic() >= self.deadline:
                        raise TimeoutError('ACK missing; control/read lease state unknown; use explicit STOP recovery')
                    self.retry_count += 1

    async def status(self):
        meta, _ = await self.exchange(self.request(STATUS))
        return meta

    async def stop(self):
        return await self.exchange(self.request(STOP))

    async def clear(self):
        return await self.exchange(self.request(CLEAR))

    async def abort(self):
        return await self.exchange(self.request(ABORT))

    @staticmethod
    def identity(meta, score_id, count):
        if (meta[2], meta[4], meta[5]) != (1, count, score_id):
            raise ValueError('published score identity changed')

    @staticmethod
    def identity_payload(score_id, count):
        uint(score_id, 32, 'score_id')
        if type(count) is not int or not 1 <= count <= 512:
            raise ValueError('count 1..512')
        return struct.pack('<IHH', score_id, count, 0)

    async def read_all(self, score_id, count, expected=None):
        payload = self.identity_payload(score_id, count)
        if expected is not None and (type(expected) is not bytes or len(expected) != count*8):
            raise ValueError('expected readback bytes')
        meta, _ = await self.exchange(self.request(READ_BEGIN, payload=payload))
        self.identity(meta, score_id, count)
        collected = bytearray()
        for index in range(count):
            meta, event = await self.exchange(self.request(READ, offset=index))
            self.identity(meta, score_id, count)
            if expected is not None and event != expected[8*index:8*index+8]:
                raise ValueError('readback mismatch at index '+str(index)+'; read lease retained until STOP')
            collected.extend(event)
        records = bytes(collected)
        decode_records(score_id, records)
        meta, _ = await self.exchange(self.request(READ_END))
        self.identity(meta, score_id, count)
        return records

    async def start(self, score_id, records):
        # Always re-acquire and verify this generation, including a separate CLI START.
        await self.read_all(score_id, len(records)//8, records)
        return await self.exchange(self.request(START, payload=self.identity_payload(score_id, len(records)//8)))

    async def upload(self, score_id, records, chunk=128, stop_first=False):
        decode_records(score_id, records)
        if type(chunk) is not int or not 1 <= chunk <= 128:
            raise ValueError('chunk 1..128')
        if self.upload_attempted:
            raise ValueError('one upload per session; create a fresh ScoreClient')
        self.upload_attempted = True
        if stop_first:
            await self.stop()
            await self.abort()
        count = len(records)//8
        # BEGIN/DATA/COMMIT retain original upload sequence semantics.
        await self.exchange(Frame(BEGIN, self.session, 0, payload=struct.pack('<IHHHI',
                            score_id, count, len(records), crc(records), 48000)))
        seq=1
        for offset in range(0, len(records), chunk):
            await self.exchange(Frame(DATA, self.session, seq, offset, records[offset:offset+chunk]))
            seq += 1
        meta, _ = await self.exchange(Frame(COMMIT, self.session, seq))
        self.identity(meta, score_id, count)
        if meta[3] != 0:
            raise ValueError('COMMIT upload session still active')
        self.seq = max(self.seq, seq+1)
        self.identity(await self.status(), score_id, count)
        return await self.read_all(score_id, count, records)
