from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
ns='{http://schemas.android.com/apk/res/android}'
base=ET.parse(r/'app/src/main/res/values/styles.xml').getroot()
new=ET.parse(r/'app/src/main/res/values-v27/styles.xml').getroot()
def table(root):return {s.attrib['name']:{'parent':s.get('parent'),'items':{i.get('name'):i.text for i in s}} for s in root}
b,n=table(base),table(new)
assert 'android:windowLightNavigationBar' not in {k for s in b.values() for k in s['items']}
assert b['AppTheme']['parent']=='@style/AppThemeBase'
assert n['AppTheme']['parent']=='@style/AppThemeBase'
def resolve(sdk):
    styles=dict(b)
    if sdk>=27:styles.update(n)
    theme=styles['AppTheme'];parent=styles[theme['parent'][7:]]
    return dict(parent['items'],**theme['items'])
assert 'android:windowLightNavigationBar' not in resolve(26)
assert resolve(27)['android:windowLightNavigationBar']=='true'
assert resolve(35)['android:windowLightNavigationBar']=='true'
for sdk in [26,27,35]:
    assert resolve(sdk)['android:fontFamily']=='sans'
    assert resolve(sdk)['android:windowBackground']=='#EFF4F7'
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
permissions={p.get(ns+'name'):p for p in manifest.findall('uses-permission')}
for name in ['ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION','BLUETOOTH','BLUETOOTH_ADMIN']:
    assert permissions['android.permission.'+name].get(ns+'maxSdkVersion')=='30'
assert permissions['android.permission.BLUETOOTH_SCAN'].get(ns+'usesPermissionFlags')=='neverForLocation'
assert not any('STORAGE' in name for name in permissions)
activity=(r/'app/src/main/java/com/proscore/android/MainActivity.java').read_text(encoding='utf-8')
m=re.search(r'String\[\] needed = Build.VERSION.SDK_INT >= 31\s*\? new String\[\]\{([^}]+)\}\s*: new String\[\]\{([^}]+)\};',activity)
assert m
modern=re.findall(r'Manifest.permission.([A-Z_]+)',m[1])
legacy=re.findall(r'Manifest.permission.([A-Z_]+)',m[2])
assert modern==['BLUETOOTH_SCAN','BLUETOOTH_CONNECT']
assert legacy==['ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION']
gatt=(r/'app/src/main/java/com/proscore/android/GattTransport.java').read_text(encoding='utf-8')
assert gatt.count('== BluetoothStatusCodes.SUCCESS')==2
assert 'writeDescriptor(d, value) == 0' not in gatt
assert 'BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == 0' not in gatt
assert 'if (Build.VERSION.SDK_INT >= 33)' in gatt
result=dict(status='PASS',level='XML style resolution and source permission/API guard inspection',
    themes={str(sdk):resolve(sdk) for sdk in [26,27,35]},
    permission_requests={'26..30':legacy,'31+':modern},
    retained_warnings={
      'UnusedAttribute':'neverForLocation is intentionally ignored below31; legacy API<=30 uses location permissions and location-service check',
      'DataExtractionRules':'allowBackup=false retained; application does not persist imported score files/connection state; device-transfer behavior is untested; backup migration is outside this minimal lint repair'},
    actual_lint_rerun='NOT_RUN_BY_TASK3; coordinator owns necessary APK/lint rerun')
(out/'DELTA_CHECK.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('PASS: API26/27/35 styles, legacy fine+coarse max30, Nearby-only31+, API33 SUCCESS constants; no lint disabling/minSdk change')