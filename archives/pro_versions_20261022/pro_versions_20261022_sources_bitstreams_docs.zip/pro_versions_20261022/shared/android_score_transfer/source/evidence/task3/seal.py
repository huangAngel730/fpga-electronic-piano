from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[2]
e=Path(__file__).resolve().parent
owned=[*sorted((r/'app/src/main/java/com/proscore/android').glob('*.java')),
       *sorted((r/'app/src/main/res').rglob('*.xml')),r/'app/src/main/AndroidManifest.xml']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
compile_result=json.loads((e/'COMPILE_02_FINAL/RESULT.json').read_text())
assert compile_result['exit']==0
for p in owned:
    if p.suffix=='.java':assert compile_result['sources'][str(p)]==sha(p)
test=json.loads((e/'TRANSPORT_04_FINAL/RESULT.json').read_text())
assert test['status']=='PASS'
for name in ['GattTransport.java','ResponseStream.java']:
    p=r/'app/src/main/java/com/proscore/android'/name
    assert test['source_sha256'][str(p)]==sha(p)
write(e/'RECEIPT.json',dict(schema='ANDROID_SCORE_TRANSFER_TASK3_R01',status='SOURCE_AND_SOFTWARE_CHECKS_COMPLETE',
   scope='Native Activity + true BluetoothGatt transport + strict bounded response stream',
   sources={str(p.relative_to(r)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in owned},
   compile=dict(run='COMPILE_02_FINAL',exit=0,level='javac against Android35 SDK + actual task2 core; synthesized R IDs only'),
   transport_tests=dict(run='TRANSPORT_04_FINAL',checks=236,exit=0,level='host software Android/GATT doubles + real transport/parser/core; no BLE hardware'),
   pending=['Coordinator full APK/resource build and lint','Android device/permission/SAF/rotation/system-bar runtime','Real BLE bridge and FPGA integration'],
   no_device_operations=True,no_git=True,authority='Direct human revocation of earlier no-change limit in this chat; TASK_AND_API.md'))
write(e/'FAILURE_HISTORY.json',[
 dict(stage='initial Android write authorization',result='Two automatic approval rejections referenced older 先不改 instruction',
      resolution='Human explicitly revoked that restriction and authorized this chat; no file writes occurred before that confirmation'),
 dict(stage='command inspection',exit=1,result='rg invoked with unsupported -LiteralPath',resolution='Used correct quoted positional path; no data changed'),
 dict(stage='self review',result='Connection callback originally shared per-operation epoch; progress mapping only recognized English',
      resolution='Independent connectionEpoch; actual Chinese progress recognized; SAF result loading posted after foreground return'),
 dict(stage='deadline counterexample TRANSPORT_02',exit=1,result='Test failed but non-daemon host test executor prevented JVM exit; subprocess timed out after30s',
      evidence='TRANSPORT_02_DEADLINE_NEGATIVE/sources, compile outputs; timeout observed in tool transcript; test stderr was not persisted by first runner',
      resolution='Host test executor made daemon; no production change for this harness issue'),
 dict(stage='TRANSPORT_03_DEADLINE_NEGATIVE',exit=1,result='Deterministic late successful write callback bypassed transport deadline before fix',
      evidence='TRANSPORT_03_DEADLINE_NEGATIVE/test.stderr.raw',
      resolution='Monotonic deadline rechecked after wake, on operation completion and before receive poll; send still wraps timeouts as fatal IOException'),
 dict(stage='TRANSPORT_04_FINAL',exit=0,result='236 software checks PASS including the formerly failing deadline counterexample')])
text='''# 安卓传谱任务3交接（2026-10-22）

状态：任务3授权源码实现、软件测试和自审完成。总控可进行统一 APK 构建／资源打包／lint；本窗口未执行 APK 构建、实物扫描、手机连接、安装、BLE连接、设备/EDA/Git操作。先前自动审批的“先不改”阻断已由本对话人类直接撤销并明确重新授权。

## 文件与入口

- `app/src/main/java/com/proscore/android/MainActivity.java`：原生中文界面、SAF选择JSON、内置样例、权限、10秒显式BLE扫描、最多32个明确选择项、连接／断开、上传／START／STOP、进度与错误、生命周期取消。
- 同目录 `GattTransport.java`：真实 Android BluetoothGatt，实现任务2固定 `ScoreClient.Transport`。
- 同目录 `ResponseStream.java`：有界严格通知流拆帧。
- `app/src/main/AndroidManifest.xml`：包名由总控Gradle指定，启动 `.MainActivity`，仅蓝牙及Android≤30所需定位权限；未声明全盘存储、Internet或后台服务权限。
- `app/src/main/res/values/{strings,styles}.xml`：中文资源和系统Material原生主题，无AndroidX依赖。

启动不扫描、不自动选设备、不连接、不上传、不START。请先选JSON或载入内置assets/sample.score.json，再扫描、选中设备、连接；SAF文件选择器会使Activity离开前台，因此按本轮安全策略断开现有连接。返回前台后通过主线程队列稳定加载文件。STOP只要求连接ready，不要求有文件。上传调用 `client.upload(score,true)`，先STOP/ABORT恢复再上传／全量回读，完成不自动播放；START调用 `client.start(score)` 再核同；每次控制新建client/session、单工作线程，进度识别核心真实中文阶段。超时/NACK/取消/断线均不显示设备已成功停止。

## GATT行为

服务761e0001、RX0002、TX0003、status0004，固定尾部与TASK_AND_API一致。显式设备 `connectGatt(autoConnect=false, TRANSPORT_LE)`；发现服务后校验RX响应写、TX notify、status read和TX CCCD存在。串行读取status，严格6字节/version2；status中的桥错误码仅展示，绝不生成FPGA ACK。启用本地notify并写CCCD，实际成功回调到达后才ready。

每帧≤142字节、每片≤20字节，WRITE_TYPE_DEFAULT逐片等待成功回调，全帧共用单调钟截止。任何发送启动失败、错误回调、部分发送或超时均封装为致命IOException并断开，不能成为核心可重试的完整帧ACK超时。receive超时才抛TimeoutException供核心有限重试；断线/流损坏会唤醒等待并失败。关闭后旧GATT对象回调被忽略。连接代次独立于每次文件/控制操作的代次，操作完成后发生的真实断线仍能更新界面。

通知缓冲512字节、完整帧队列8项；magic/version/CRC/payload长度/命令/元数据严格校验；仅READ成功payload20，其余ACK/NACK12。坏前缀不扫描重同步，溢出或损坏立即关闭。等待唤醒后、操作完成返回前和接收取队列前再次检查单调时钟截止，迟到成功不能绕过超时。

## Android兼容与生命周期

min26/target35按总控配置。Android31+请求SCAN/CONNECT运行时权限并声明neverForLocation；≤30请求定位权限并检查系统定位，拒绝或服务异常给出错误，不静默扫描。API33+使用不可变value参数的新GATT写入/回调；API26..32兼容分支使用已弃用setValue/旧回调，并在串行访问中复制数据，未隐瞒弃用。官方依据：[蓝牙权限](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)、[BluetoothGatt](https://developer.android.com/reference/android/bluetooth/BluetoothGatt)。

SAF使用系统ACTION_OPEN_DOCUMENT，不需全盘存储权限；最多256KiB，实际JSON/事件范围/生命周期由任务2严格Score解析器验证。依据：[系统文件选择器](https://developer.android.com/training/data-storage/shared/documents-files)。

根ScrollView实际应用systemBars/displayCutout inset，API30+使用WindowInsets.Type，API26..29保留兼容分支；内容含横竖屏左右安全区，按钮随页面滚动。依据：[Android15 edge-to-edge](https://developer.android.com/develop/ui/views/layout/edge-to-edge)。未在手机或模拟器验证最终视觉布局。

onStop取消client/工作Future、关闭文件InputStream、停止扫描并关闭GATT；仅表示手机等待取消，明确未知状态与显式重连STOP恢复。没有自动重连或后台控制。旋转/切后台会按上述策略断开。

## 实际软件验证与失败

- COMPILE_02_FINAL：JDK17 javac对真实Android35 android.jar、真实任务2core及任务3Java源码编译退出0。仅为编译检查，R字段从实际strings.xml生成测试ID，未替代总控资源打包或lint。
- TRANSPORT_04_FINAL：236项PASS，真实生产GattTransport/ResponseStream加真实任务2core，运行在明确Android/GATT软件替身上，没有加载真实蓝牙栈或设备。覆盖任意拆分点/单字节通知/合并帧、CRC/version/形状/字段、队列和缓冲溢出、API26与35回调、3个20B以内分片串行响应、CCCD完成前不可ready、服务/属性/status/CCCD拒绝、发送第二片失败/丢回调/错误status致命断开、receive超时仍允许核心有限重试、断线唤醒、通知损坏立即关闭、迟到写成功回调不可越过截止。
- 修复前TRANSPORT_03_DEADLINE_NEGATIVE：退出1，真实反例失败为`negative accepted`，原件保留。TRANSPORT_02的首测试失败还暴露host测试非daemon线程阻止退出，30秒超时；该轮source/compile原件保留，首runner没有落盘test.stderr，不能冒充完整捕获。
- 其余检查与历史见 evidence/task3/{RECEIPT,FAILURE_HISTORY}.json。各执行目录有COMMANDS.json、stdout/stderr与精确源快照。最终源SHA写入收据，保留所有失败文件，旧FPGA/ESP/PC封存未改。

总控下一步：统一构建APK和lint，按任务4黑盒/只读检查收口。未验手机权限对话框、真实SAF/定位/系统栏布局、BLE吞吐及FPGA完整链路，不将host替身通过写成手机或实物通过。
'''
(r/'HANDOFF_TASK3.md').write_text(text,encoding='utf-8',newline='\n')
write(e/'MANIFEST.json',{str(p.relative_to(r)):dict(sha256=sha(p),bytes=p.stat().st_size)
 for p in owned+[r/'HANDOFF_TASK3.md']+list(e.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and 'classes' not in p.parts})
print('Task3 handoff and receipts sealed; final compile and 236 transport/parser software checks verified')