package android.bluetooth; import java.util.*;
public class BluetoothGattService {public Map<UUID,BluetoothGattCharacteristic>items=new HashMap<>();
 public BluetoothGattCharacteristic getCharacteristic(UUID id){return items.get(id);}}