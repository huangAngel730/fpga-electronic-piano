# Task4 BLE/UI 只读审查准备及到货边界

依据 `android_score_transfer_r01/TASK_AND_API.md`，本次仅静态读取生产源码，不修改实现、不构建 Java/APK、不扫描、不连接、不操作实物。写入仅限本 `evidence/task4/ui_review/` 子集。PC 参考是原 `software/pc/ble_transport.py`、`protocol.py`、`client.py`；身份记录在每次只读快照的 `review.json`。

初次准备时 Android 源码尚未到货；已读取任务契约、PC BLE/协议/客户端，并核对以下 Android 官方资料：

- [BluetoothGatt API](https://developer.android.com/reference/android/bluetooth/BluetoothGatt)：写入启动返回值不能替代完成回调；descriptor 也有独立完成回调。API33起提供接收显式 byte[] 的写入重载。
- [BLE 数据传输](https://developer.android.com/develop/connectivity/bluetooth/ble/transfer-ble-data)：本地通知开关与远端 CCCD 写入需分别处理。
- [蓝牙权限](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)：按 Android 版本核对 runtime SCAN/CONNECT 和旧版定位权限，不因 Manifest 声明即认为已获授权。
- [Activity 生命周期](https://developer.android.com/guide/components/activities/activity-lifecycle)：核对退后台/销毁时取消等待、断开连接及迟到回调失效；不能把手机取消描述为 FPGA 已 STOP。
- [系统文件选择器](https://developer.android.com/training/data-storage/shared/documents-files)：通过 SAF 获取用户指定文件，不要求全盘存储权限。

## READ_001

`ResponseStream.java` 已完整读取；同时到达 `GattTransport.java`，为确认拆帧器串行访问已读取其上下文。两份原字节和 SHA/行号保存在 `READ_001/source_snapshot/`、`READ_001/review.json`。

在该精确版本的 ResponseStream 范围内未发现具体阻断：固定512B缓冲、最多8帧、严格帧头/version/长度/CRC和ACK-NACK形状检查；坏流粘滞失败并清空之前排队的帧。GattTransport 的 feed/poll 在同一 guard 下。

当前到货不足：MainActivity、Manifest、UI资源、完整 ScoreClient 尚未齐全。不能据上述局部结论签握手到事务、权限/生命周期或 UI 整链通过。等待总控到货通知后，增量复查明确版本；不忙轮询目录。

后续仅反馈具体可复现阻断：精确源码SHA/行号、触发序列、影响及最小修法。重点检查 CCCD+status6B/version2 就绪屏障；20B响应写串行完成；部分写失败不能变成 ACK 超时重试；队列及坏流终止；权限与取消/断线；显式设备选择；START重核；无文件STOP。

## READ_002

总控通知 GattTransport 已到、MainActivity 未到及核心独立95例通过后，继续完整静态读取 GattTransport，并读取 ScoreClient 的 send/receive 异常与取消边界。原字节及 SHA 保存在 `READ_002/`。

该精确 GATT/stream 范围未发现具体阻断：status6B/version2与CCCD完成回调均先于ready；20B WRITE_TYPE_DEFAULT分片逐一等待回调；send所有异常转换为粘滞fatal IOException并断开；核心send位于receive超时重试处理之外。旧连接回调被代际/closed过滤，坏流会关闭连接。未重跑核心95例。

MainActivity/Manifest/资源的权限、生命周期和按钮门禁尚待到货审查。本局部记录不代表完整Android链路通过。

## FINAL_001

总控通知 MainActivity 到货后，完整读取并核对 UI/Manifest/资源及其 GATT/core 调用边界。第一次封存时 MainActivity SHA 已变化，断言拒绝封存，见 `FINAL_001/FREEZE_001_failure.log`；旧稿标记为 `DRAFT_STALE_CONCLUSION.md`。继续读取新版本后才形成正式结论，以最终 `review.json` 是否存在及其所绑定 SHA 为准。此前未到货记录作为历史保留。未构建或操作实物。

最终已完整读取更新后的 MainActivity（`fd69f839...`）并封存七份原字节；`FINAL_001/review.json` 与 `CONCLUSION.md` 为正式入口。在该精确静态范围内未发现具体阻断，不代签运行或实物通过。
