package android.bluetooth; import android.content.Context;
public class BluetoothDevice {public static final int TRANSPORT_LE=2;public final BluetoothGatt link;
 public BluetoothDevice(BluetoothGatt l){link=l;} public BluetoothGatt connectGatt(Context c,boolean auto,BluetoothGattCallback cb,int mode){
 if(auto)throw new AssertionError("auto reconnect");link.cb=cb;link.later(()->cb.onConnectionStateChange(link,0,2));return link;}}