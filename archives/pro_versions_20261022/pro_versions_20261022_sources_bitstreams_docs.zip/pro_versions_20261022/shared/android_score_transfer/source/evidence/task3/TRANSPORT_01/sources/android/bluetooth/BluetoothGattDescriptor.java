package android.bluetooth; import java.util.*;
public class BluetoothGattDescriptor {
 public static final byte[] ENABLE_NOTIFICATION_VALUE={1,0};public final UUID id;public byte[]value;
 public BluetoothGattDescriptor(UUID u){id=u;} public UUID getUuid(){return id;}
 public boolean setValue(byte[]v){value=v.clone();return true;}
}