package com.proscore.android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.OpenableColumns;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import com.proscore.core.Score;
import com.proscore.core.ScoreClient;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Native Android UI. No scan, connection, upload or START happens at launch. */
public final class MainActivity extends Activity {
    private static final int PICK_FILE = 20, ENABLE_BLUETOOTH = 21, PERMISSIONS = 22;
    private static final int FILE_LIMIT = 256 * 1024;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Map<String, BluetoothDevice> devices = new LinkedHashMap<>();
    private final Map<Integer, BluetoothDevice> deviceRows = new LinkedHashMap<>();
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private ScanCallback scanCallback;
    private BluetoothDevice selectedDevice;
    private GattTransport transport;
    private volatile ScoreClient currentClient;
    private volatile InputStream currentInput;
    private Future<?> future;
    private Score selectedScore;
    private long epoch, connectionEpoch;
    private boolean foreground, busy, receiverRegistered;
    private TextView fileSummary, bleState, scanState, operationState, playbackState;
    private ProgressBar progress;
    private RadioGroup choices;
    private Button fileButton, sampleButton, scanButton, connectButton, disconnectButton;
    private Button uploadButton, startButton, stopButton, cancelButton;

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi();
        registerBluetoothReceiver();
        render();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(239, 244, 247));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        heading(content, R.string.subtitle, 13);
        heading(content, R.string.title, 28);
        LinearLayout file = card(content, R.string.file_section);
        fileSummary = text(file, R.string.file_none, 16);
        fileButton = button(file, R.string.pick_file, this::pickFile);
        sampleButton = button(file, R.string.sample_file, () -> loadScore(null));
        LinearLayout ble = card(content, R.string.ble_section);
        bleState = text(ble, R.string.ble_unknown, 15);
        scanButton = button(ble, R.string.scan, () -> {
            if (scanCallback == null) scan(); else stopScan(true);
        });
        scanState = text(ble, R.string.scan_hint, 14);
        choices = new RadioGroup(this);
        choices.setOrientation(RadioGroup.VERTICAL);
        ble.addView(choices);
        choices.setOnCheckedChangeListener((group, id) -> {
            selectedDevice = deviceRows.get(id); render();
        });
        connectButton = button(ble, R.string.connect, this::connectSelected);
        disconnectButton = button(ble, R.string.disconnect, () -> cancelSession(R.string.canceled));
        LinearLayout control = card(content, R.string.control_section);
        playbackState = text(control, R.string.playback_unknown, 15);
        uploadButton = button(control, R.string.upload, () -> runControl(0));
        startButton = button(control, R.string.start, () -> runControl(1));
        stopButton = button(control, R.string.stop, () -> runControl(2));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        LinearLayout.LayoutParams bar = new LinearLayout.LayoutParams(-1, dp(16));
        bar.topMargin = dp(16); control.addView(progress, bar);
        operationState = text(control, R.string.idle, 15);
        operationState.setTextIsSelectable(true);
        cancelButton = button(control, R.string.cancel, () -> cancelSession(R.string.canceled));
        text(content, R.string.cancel_note, 13);
        setContentView(scroll);
        applyInsets(scroll);
    }

    private void heading(LinearLayout parent, int resource, int size) {
        TextView view = text(parent, resource, size);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextColor(Color.rgb(24, 48, 66));
    }

    private TextView text(LinearLayout parent, int resource, int size) {
        TextView view = new TextView(this);
        view.setText(resource); view.setTextSize(size);
        view.setTextColor(Color.rgb(54, 75, 88));
        view.setPadding(0, dp(8), 0, dp(8));
        parent.addView(view, new LinearLayout.LayoutParams(-1, -2));
        return view;
    }

    private LinearLayout card(LinearLayout parent, int title) {
        LinearLayout view = new LinearLayout(this); view.setOrientation(LinearLayout.VERTICAL);
        view.setPadding(dp(16), dp(12), dp(16), dp(16));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE); background.setCornerRadius(dp(16));
        view.setBackground(background);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16); parent.addView(view, lp);
        heading(view, title, 18); return view;
    }

    private Button button(LinearLayout parent, int title, Runnable action) {
        Button button = new Button(this); button.setText(title); button.setAllCaps(false);
        button.setMinHeight(dp(48));
        button.setOnClickListener(v -> action.run());
        parent.addView(button, new LinearLayout.LayoutParams(-1, -2)); return button;
    }

    @SuppressWarnings("deprecation")
    private void applyInsets(View root) {
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = safe.left; top = safe.top; right = safe.right; bottom = safe.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom();
                if (Build.VERSION.SDK_INT >= 28) {
                    DisplayCutout cutout = insets.getDisplayCutout();
                    if (cutout != null) {
                        left = Math.max(left, cutout.getSafeInsetLeft());
                        top = Math.max(top, cutout.getSafeInsetTop());
                        right = Math.max(right, cutout.getSafeInsetRight());
                        bottom = Math.max(bottom, cutout.getSafeInsetBottom());
                    }
                }
            }
            view.setPadding(left, top, right, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }

    private boolean granted(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean permissions() {
        String[] needed = Build.VERSION.SDK_INT >= 31
                ? new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}
                : new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        List<String> missing = new ArrayList<>();
        for (String permission : needed) if (!granted(permission)) missing.add(permission);
        if (missing.isEmpty()) return true;
        operationState.setText(R.string.permission);
        requestPermissions(missing.toArray(new String[0]), PERMISSIONS);
        return false;
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    private boolean bluetoothReady() {
        if (adapter == null || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            bleState.setText(R.string.ble_unavailable); return false;
        }
        if (!permissions()) return false;
        try {
            if (!adapter.isEnabled()) {
                operationState.setText(R.string.bluetooth_enable);
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), ENABLE_BLUETOOTH);
                return false;
            }
            return true;
        } catch (RuntimeException error) {
            bleState.setText(getString(R.string.connection_error, message(error))); return false;
        }
    }

    @SuppressLint("MissingPermission")
    private void scan() {
        if (busy || transport != null || !bluetoothReady()) return;
        if (Build.VERSION.SDK_INT <= 30) {
            LocationManager location = getSystemService(LocationManager.class);
            if (location == null || !(location.isProviderEnabled(LocationManager.GPS_PROVIDER)
                    || location.isProviderEnabled(LocationManager.NETWORK_PROVIDER))) {
                scanState.setText(R.string.location_off); return;
            }
        }
        stopScan(false); devices.clear(); deviceRows.clear(); selectedDevice = null; choices.removeAllViews();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { bleState.setText(R.string.bluetooth_off); return; }
        final ScanCallback callback = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult result) {
                main.post(() -> {
                    if (!foreground || scanCallback != this) return;
                    try { addDevice(result); }
                    catch (RuntimeException error) { stopScan(false); scanState.setText(message(error)); }
                });
            }
            @Override public void onBatchScanResults(List<ScanResult> results) {
                for (ScanResult result : results) onScanResult(0, result);
            }
            @Override public void onScanFailed(int code) {
                main.post(() -> {
                    if (scanCallback != this) return;
                    stopScan(false); scanState.setText(getString(R.string.scan_error, code));
                });
            }
        };
        scanCallback = callback;
        try {
            scanner.startScan(Arrays.asList(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(GattTransport.SERVICE)).build()),
                    new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), callback);
            scanState.setText(getString(R.string.scan_count, 0)); render();
            main.postDelayed(() -> { if (scanCallback == callback) stopScan(true); }, 10000);
        } catch (RuntimeException error) {
            stopScan(false); scanState.setText(message(error));
        }
    }

    @SuppressLint("MissingPermission")
    private void addDevice(ScanResult result) {
        BluetoothDevice device = result.getDevice(); String address = device.getAddress();
        if (devices.containsKey(address)) return;
        if (devices.size() >= 32) { scanState.setText(R.string.scan_limit); return; }
        devices.put(address, device);
        String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
        if (name == null || name.trim().isEmpty()) name = getString(R.string.device_unknown);
        RadioButton row = new RadioButton(this); row.setId(View.generateViewId()); row.setMinHeight(dp(56));
        row.setText(getString(R.string.device_row, name, address, result.getRssi()));
        deviceRows.put(row.getId(), device); choices.addView(row);
        scanState.setText(getString(R.string.scan_count, devices.size())); render();
    }

    @SuppressLint("MissingPermission")
    private void stopScan(boolean summarize) {
        ScanCallback old = scanCallback; scanCallback = null;
        if (old != null && scanner != null) {
            try { scanner.stopScan(old); } catch (RuntimeException ignored) { /* revoked/off */ }
        }
        scanner = null;
        if (summarize) scanState.setText(devices.isEmpty() ? getString(R.string.scan_no_device)
                : getString(R.string.scan_count, devices.size()));
        if (scanButton != null) render();
    }

    @SuppressLint("MissingPermission")
    private void connectSelected() {
        if (selectedDevice == null || busy || transport != null || !bluetoothReady()) return;
        stopScan(false);
        final BluetoothDevice device = selectedDevice;
        final String address = device.getAddress();
        final long token = ++epoch;
        final long connectionToken = ++connectionEpoch;
        busy = true; bleState.setText(R.string.connecting); progress.setIndeterminate(true); render();
        final GattTransport link = new GattTransport(this, reason -> main.post(() -> {
            if (!foreground || connectionToken != connectionEpoch) return;
            cancelSession(R.string.canceled);
            bleState.setText(getString(R.string.connection_error, reason));
        }));
        transport = link;
        future = worker.submit(() -> {
            try {
                link.connect(device, 20000);
                byte[] status = link.getBridgeStatus();
                post(token, () -> {
                    busy = false; progress.setIndeterminate(false); progress.setProgress(0);
                    bleState.setText(getString(R.string.connected, address, status[1] & 255,
                            (status[2] & 255) | (status[3] & 255) << 8));
                    playbackState.setText(R.string.playback_unknown); render();
                });
            } catch (Exception error) {
                link.close();
                post(token, () -> {
                    transport = null; busy = false; progress.setIndeterminate(false);
                    bleState.setText(getString(R.string.connection_error, message(error))); render();
                });
            }
        });
        render();
    }

    @SuppressWarnings("deprecation")
    private void pickFile() {
        if (busy) return;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
        try { startActivityForResult(intent, PICK_FILE); }
        catch (RuntimeException error) { operationState.setText(getString(R.string.file_error, message(error))); }
    }

    private void loadScore(Uri uri) {
        if (busy) return;
        stopScan(false); selectedScore = null; fileSummary.setText(R.string.loading);
        final long token = ++epoch;
        busy = true; operationState.setText(R.string.loading); render();
        future = worker.submit(() -> {
            try {
                Score score;
                String name = uri == null ? getString(R.string.sample_name) : documentName(uri);
                try (InputStream input = uri == null ? getAssets().open("sample.score.json")
                        : getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new IOException(getString(R.string.file_missing));
                    currentInput = input;
                    score = Score.parseUtf8(readBounded(input));
                } finally { currentInput = null; }
                byte[] records = score.getRecords();
                int end = records.length - 8;
                long tick = (records[end] & 255L) | (records[end + 1] & 255L) << 8
                        | (records[end + 2] & 255L) << 16 | (records[end + 3] & 255L) << 24;
                post(token, () -> {
                    selectedScore = score; busy = false;
                    fileSummary.setText(getString(R.string.score_summary, name, Long.toString(score.getScoreId()),
                            score.getCount(), Long.toString(tick)));
                    operationState.setText(R.string.idle); render();
                });
            } catch (Exception error) {
                post(token, () -> {
                    selectedScore = null; busy = false;
                    fileSummary.setText(getString(R.string.file_error, message(error))); render();
                });
            }
        });
    }

    private byte[] readBounded(InputStream input) throws IOException, InterruptedException {
        ByteArrayOutputStream output = new ByteArrayOutputStream(); byte[] block = new byte[8192];
        int count;
        while ((count = input.read(block)) != -1) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedException("读取已取消");
            if (count > FILE_LIMIT - output.size()) throw new IOException(getString(R.string.file_large));
            output.write(block, 0, count);
        }
        return output.toByteArray();
    }

    private String documentName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String value = cursor.getString(0);
                if (value != null) return value.substring(0, Math.min(100, value.length()));
            }
        } catch (RuntimeException ignored) { /* provider has no name */ }
        return getString(R.string.file_default);
    }

    private void runControl(int action) {
        final GattTransport link = transport;
        final Score score = selectedScore;
        if (busy || link == null || !link.isReady() || (action != 2 && score == null)) return;
        final long token = ++epoch;
        busy = true; progress.setProgress(0); progress.setIndeterminate(true);
        operationState.setText(action == 0 ? R.string.uploading : action == 1 ? R.string.starting : R.string.stopping);
        render();
        future = worker.submit(() -> {
            try {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException("操作已取消");
                ScoreClient client = new ScoreClient(link, (phase, done, total) -> post(token, () -> {
                    progress.setIndeterminate(total <= 0);
                    if (total > 0) progress.setProgress((int) Math.max(0, Math.min(1000, 1000L * done / total)));
                    operationState.setText(getString(R.string.progress_counts, phaseText(phase), done, total));
                }));
                currentClient = client;
                if (Thread.currentThread().isInterrupted()) { client.cancel(); throw new InterruptedException("操作已取消"); }
                if (action == 0) client.upload(score, true);
                else if (action == 1) client.start(score);
                else client.stop();
                post(token, () -> {
                    busy = false; progress.setIndeterminate(false); progress.setProgress(1000);
                    int result = action == 0 ? R.string.uploaded : action == 1 ? R.string.started : R.string.stopped;
                    operationState.setText(result); playbackState.setText(result); render();
                });
            } catch (Exception error) {
                post(token, () -> {
                    busy = false; progress.setIndeterminate(false); progress.setProgress(0);
                    operationState.setText(getString(R.string.operation_error, message(error)));
                    playbackState.setText(R.string.playback_unknown); render();
                });
            } finally { currentClient = null; }
        });
    }

    private String phaseText(String phase) {
        String value = phase == null ? "" : phase.toLowerCase(Locale.ROOT);
        int id = value.contains("read") || value.contains("verify") || value.contains("回读") || value.contains("核对") ? R.string.phase_read
                : value.contains("stop") || value.contains("停止") ? R.string.phase_stop : value.contains("start") || value.contains("开始") ? R.string.phase_start
                : value.contains("commit") || value.contains("发布") ? R.string.phase_commit : value.contains("data") || value.contains("upload") || value.contains("上传")
                ? R.string.phase_upload : R.string.phase_other;
        return getString(id);
    }

    private void post(long token, Runnable action) {
        main.post(() -> { if (foreground && !isFinishing() && token == epoch) action.run(); });
    }

    private void cancelSession(int status) {
        ++epoch; ++connectionEpoch;
        stopScan(false);
        ScoreClient client = currentClient; if (client != null) client.cancel();
        Future<?> task = future; future = null; if (task != null) task.cancel(true);
        InputStream input = currentInput; currentInput = null;
        if (input != null) { try { input.close(); } catch (IOException ignored) { /* canceled */ } }
        GattTransport old = transport; transport = null; if (old != null) old.close();
        busy = false; progress.setIndeterminate(false); progress.setProgress(0);
        bleState.setText(R.string.ble_unknown); playbackState.setText(R.string.playback_unknown);
        operationState.setText(status); render();
    }

    private void render() {
        if (scanButton == null) return;
        boolean ready = transport != null && transport.isReady();
        fileButton.setEnabled(!busy && scanCallback == null); sampleButton.setEnabled(!busy && scanCallback == null);
        scanButton.setEnabled(!busy && transport == null);
        scanButton.setText(scanCallback == null ? R.string.scan : R.string.scan_stop);
        connectButton.setEnabled(!busy && selectedDevice != null && transport == null);
        disconnectButton.setEnabled(transport != null);
        uploadButton.setEnabled(!busy && ready && selectedScore != null);
        startButton.setEnabled(!busy && ready && selectedScore != null);
        stopButton.setEnabled(!busy && ready); // STOP requires no file.
        cancelButton.setEnabled(busy || ready || scanCallback != null);
        for (int i = 0; i < choices.getChildCount(); i++) choices.getChildAt(i).setEnabled(!busy && transport == null);
    }

    private String message(Exception error) {
        String value = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
        return value.substring(0, Math.min(700, value.length()));
    }

    @Override protected void onStart() { super.onStart(); foreground = true; }
    @Override protected void onStop() {
        foreground = false; cancelSession(R.string.background); super.onStop();
    }
    @Override protected void onDestroy() {
        worker.shutdownNow(); main.removeCallbacksAndMessages(null);
        if (receiverRegistered) unregisterReceiver(bluetoothReceiver);
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            main.post(() -> { if (foreground && !isFinishing()) loadScore(uri); });
        }
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request == PERMISSIONS) {
            boolean all = grants.length > 0;
            for (int grant : grants) all &= grant == PackageManager.PERMISSION_GRANTED;
            operationState.setText(all ? R.string.permission_granted : R.string.permission_denied);
        }
    }

    private void registerBluetoothReceiver() {
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(bluetoothReceiver, filter, Context.RECEIVER_EXPORTED);
        else registerReceiver(bluetoothReceiver, filter);
        receiverRegistered = true;
    }
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(intent.getAction())
                    && intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR) != BluetoothAdapter.STATE_ON) {
                cancelSession(R.string.bluetooth_off);
            }
        }
    };
}