# Task4 最终 BLE/UI 只读结论

在 `review.json` 所绑定的七份精确源码/资源 SHA 范围内，未发现具体阻断。原字节保存于 `source_snapshot/`。本结论限静态边界检查，不代签 APK 构建、Android 运行或实物 BLE 通过。

已完整读取 MainActivity、GattTransport、ResponseStream、Manifest 和两份资源；ScoreClient 作为发送异常、取消及 START/STOP 调用的必要上下文读取。status6B/version2 与实际CCCD成功回调先于ready；20B响应写逐片串行等待；send失败粘滞关闭且不进入receive超时重试；流缓冲/队列有界且坏流终止。权限按版本请求，文件走系统选择器；生命周期取消断开、token抑制迟到成功；设备需显式选择，每次操作创建新client，START重新全量核同，STOP不依赖文件。

关键身份：

- MainActivity：`fd69f83921f27b285cd931fcbdbdb9b32ab559fd688065a3ef522923124a6930`
- GattTransport：`a05f80377fa2d0ff328abee407f159d555a711a7e877ba5e2014b971fb809542`
- ResponseStream：`dbccde07b9caa790c0768635b337a3411d1b06db8598b28fa0cface102e29e70`

首轮封存发现 MainActivity 从 `bd7f...` 变为上述 `fd69...`，断言按预期拒绝封存；记录在 `FREEZE_001_failure.log`，旧稿在 `DRAFT_STALE_CONCLUSION.md`，均保留。随后完整读取更新版本（中文阶段标签识别增量），再完成正式快照。封存拒绝属于版本变化记录，不是产品测试失败。

精确行号映射、全部SHA、官方API来源和未验边界见 `review.json`。准备及未到货记录保留在父目录。本轮未修改生产文件，未编译、构建、扫描、连接或操作实物；总控报告的95例/42例通过仅作上下文，未在此重跑。
