# 安卓传谱R01 — 拓展任务2交接

状态：本窗口纯Java核心实现、软件自检与自审完成；不是整份安卓应用或硬件验收。继续接受拓展任务1总控调度。

独占写入仅：

- app/src/main/java/com/proscore/core/
- core_tests/
- evidence/task2/
- 本文件HANDOFF_TASK2.md

入口：

- Score.java：parseUtf8(byte[])、getScoreId/getCount/getRecords（defensive clone），严格JSON/UTF-8、冻结原始记录格式与生产note36..84/tick≤16777215。
- Protocol.java：v2命令1..11 codec、CRC、精确ACK形状/元数据校验。公开辅助Frame构造器/encode、Protocol.encode/decode/crc16/validateResponse；NackException.getErrorCode。
- ScoreClient.java：固定二参公开构造器与upload(Score,boolean)、start(Score)、stop()、cancel()；Transport/Progress完全沿用TASK_AND_API。完整上传回读、START再核同、显式STOP、严格重试/取消/状态未知。
- core_tests/run_core_tests.py、CoreSelfTest.java：可独立运行；详细行为和复验命令见core_tests/README.md。

实际验证：现有JDK17 javac --release 8 -Xlint:all -Werror退出0；RUN_02纯Java自检20场景、9881断言、0失败，退出0；API_CHECK的javap公开签名与固定接口完全相符，无Android/AndroidX导入。覆盖最大512事件、PC v2全部11命令黄金字节/正负回执、严格JSON/生命周期/范围、COMMIT不播放、回读边界、START再核、无文件STOP、ACK丢失精确缓存重放、BUSY15立即失败、半帧send错误不重试、流CRC失败、180秒截止、取消中断和无假成功。

首失败与修正：RUN_01编译0、自检1，测试仅按相同command把连续不同索引READ误认作重放。保留原源码/日志；RUN_02修正测试按完整身份比较、要求两个预期重放，生产核心源码未改。见evidence/task2/FAILURE_HISTORY.json和RUN_01/source_snapshot。权限拒绝未绕过，用户在本窗口直接撤销旧限制后才开始写入。

总控/任务3集成要点：

1. 每次按钮操作创建新ScoreClient，Progress在工作线程回调，由UI切主线程。总截止从client构造起算180秒；ACK2秒，至多2次相同接收超时重发。新session随机非零，query/control序号从8192开始。
2. Transport只在已ready连接使用；send必须整帧完成才返回，内部20B GATT分片/串行由任务3负责。send任何异常（含超时）不重发。receive完整一帧，标准java.util.concurrent.TimeoutException或java.net.SocketTimeoutException才进入有限重发；其余异常立即失败。需遵守相对超时和线程中断。
3. cancel仅取消等待，绝不自行STOP。回读失败不READ_END，旧播放/读租约不得靠断线恢复；用户显式STOP。upload(score,true)先等待STOP最终ACK再ABORT/BEGIN，upload(false)不暗中停止/播放。
4. START会重新完整回读逐字节比对；上传/回读/START成功只依据对应FPGA最终ACK。Progress成功阶段不代表手机/板卡已实测。
5. 512事件上传549次交互（含stopFirst551），START515次；180秒平均预算约327/349ms。发送前可读时间预检及UART理论下限检查已做，实际BLE时延未知，不保证所有手机链路能在期限内完成；慢链路到期会明确失败，不提高合同期限掩盖。
6. 协议字节和PC冻结客户端保持一致，新增安卓生产范围按任务单执行；不做MIDI解析。旧封存不改。

证据和身份：evidence/task2/RECEIPT.json、MANIFEST.json、INPUTS.json、RUN_02/receipt.json、API_CHECK/receipt.json、SELF_REVIEW.md。含实际命令/退出码、精确输入/源码/工具SHA与首失败原件。

未验：APK/Gradle集成、Android权限/SAF/Gatt实际行为、手机安装与真实BLE、ESP/FPGA/UART和音频/显示联动。本窗口未执行设备/EDA/Git，未修改总控或任务3/4写集。总控负责后续整合与最终交付，未代称已收件/验收。
