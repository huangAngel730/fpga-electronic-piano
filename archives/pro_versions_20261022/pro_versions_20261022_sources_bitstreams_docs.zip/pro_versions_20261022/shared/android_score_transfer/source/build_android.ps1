param(
    [string]$OutputDirectory = '',
    [switch]$Offline
)
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$pythonExe = 'C:\Users\songdongkuan\miniconda3\python.exe'
$taskArgs = @('-B', '-X', 'utf8', (Join-Path $taskRoot 'build_android.py'))
if ($OutputDirectory) { $taskArgs += @('--output', $OutputDirectory) }
if ($Offline) { $taskArgs += '--offline' }
& $pythonExe @taskArgs
exit $LASTEXITCODE
