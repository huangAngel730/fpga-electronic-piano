"""Recorded local Android build, no device enumeration or installation."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
JDK = Path('E:/FPGA/SDKs/java/jdk17')
SDK = Path('E:/FPGA/SDKs/android/sdk')
GRADLE = Path('E:/FPGA/SDKs/gradle/gradle-8.9/bin/gradle.bat')


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def identity(path):
    return {'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def capture_build_inputs():
    paths = list((HERE / 'app/src').rglob('*'))
    paths += [HERE / name for name in (
        'build.gradle', 'settings.gradle', 'gradle.properties',
        'local.properties', 'app/build.gradle')]
    return {path.relative_to(HERE).as_posix(): identity(path)
            for path in sorted(set(paths)) if path.is_file()}


def validate_manifest_dump(raw):
    expected = {
        'package': 'package="com.proscore.android"' in raw,
        'version': '"1.0.0-r01"' in raw,
        'min_sdk_26': bool(re.search(r'android:minSdkVersion[^\n]*\(type 0x10\)0x1a\b', raw)),
        'target_sdk_35': bool(re.search(r'android:targetSdkVersion[^\n]*\(type 0x10\)0x23\b', raw)),
        'launcher': all(value in raw for value in (
            '"com.proscore.android.MainActivity"', '"android.intent.action.MAIN"',
            '"android.intent.category.LAUNCHER"')),
    }
    permission_blocks = re.findall(r'E: uses-permission[^\n]*\n(.*?)(?=\n\s*E:|\Z)', raw, re.S)
    permissions = {}
    for block in permission_blocks:
        match = re.search(r'"(android\.permission\.[A-Z_]+)"', block)
        if match:
            permissions[match.group(1)] = block
    legacy = {'android.permission.' + name for name in (
        'BLUETOOTH', 'BLUETOOTH_ADMIN', 'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION')}
    expected['exact_permissions'] = set(permissions) == legacy | {
        'android.permission.BLUETOOTH_SCAN', 'android.permission.BLUETOOTH_CONNECT'}
    expected['legacy_max_sdk_30'] = all('android:maxSdkVersion' in permissions.get(name, '')
        and '(type 0x10)0x1e' in permissions[name] for name in legacy)
    expected['scan_never_for_location'] = '0x10000' in permissions.get('android.permission.BLUETOOTH_SCAN', '')
    if not all(expected.values()):
        raise ValueError('APK manifest checks failed: ' + str(expected))
    return expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--offline', action='store_true')
    args = parser.parse_args()
    out = args.output or HERE / 'evidence' / ('BUILD_' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S'))
    out = out.resolve()
    if not out.is_relative_to((HERE / 'evidence').resolve()):
        raise ValueError('Output must be a new directory under this task evidence')
    out.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env['JAVA_HOME'] = str(JDK)
    env['ANDROID_HOME'] = str(SDK)
    env['ANDROID_SDK_ROOT'] = str(SDK)
    env['GRADLE_USER_HOME'] = 'E:/FPGA/SDKs/cache/gradle'
    env['PATH'] = str(JDK / 'bin') + os.pathsep + env.get('PATH', '')
    # JDK17 Windows PipeImpl uses automatically bound Unix-domain sockets.
    # The original run failed in the inherited 8.3 TEMP location. Keep a short,
    # explicit socket directory for this child JVM tree; no global setting changes.
    socket_directory = Path('E:/FPGA/SDKs/cache/android_build_tmp')
    socket_directory.mkdir(parents=True, exist_ok=True)
    env['JAVA_TOOL_OPTIONS'] = (env.get('JAVA_TOOL_OPTIONS', '') +
        ' -Djdk.net.unixdomain.tmpdir=' + socket_directory.as_posix()).strip()
    receipt = {'started_utc': stamp(), 'status': 'STARTED',
               'device_operations': False, 'hardware_pass': False,
               'sdk': str(SDK), 'jdk': str(JDK), 'gradle': str(GRADLE),
               'process_only_unix_socket_directory': str(socket_directory),
               'script_identity': identity(Path(__file__)), 'steps': []}
    sources = {}
    for path in sorted(HERE.rglob('*')):
        relative = path.relative_to(HERE)
        if path.is_file() and not any(part in {'.gradle', 'build', 'evidence', 'delivery', 'signing', '__pycache__'} for part in relative.parts):
            sources[relative.as_posix()] = identity(path)
    receipt['input_identities'] = sources
    build_inputs = capture_build_inputs()
    receipt['build_input_identities'] = build_inputs
    receipt['reference_input_identities'] = {
        'pc/' + name: identity(HERE.parent / 'software/pc' / name)
        for name in ('protocol.py', 'score.py', 'client.py', 'ble_transport.py')}
    receipt['tool_input_identities'] = {
        str(path): identity(path) for path in (
            JDK / 'bin/java.exe', JDK / 'bin/javac.exe', JDK / 'release',
            GRADLE, SDK / 'platforms/android-35/android.jar',
            SDK / 'platforms/android-35/source.properties',
            SDK / 'build-tools/34.0.0/source.properties',
            SDK / 'build-tools/34.0.0/aapt.exe')}
    def run(label, argv):
        step = {'label': label, 'argv': [str(a) for a in argv], 'started_utc': stamp()}
        receipt['steps'].append(step)
        start = time.monotonic()
        with (out / (label + '.stdout.log')).open('wb') as stdout, (out / (label + '.stderr.log')).open('wb') as stderr:
            result = subprocess.run(step['argv'], cwd=HERE, env=env, stdout=stdout, stderr=stderr,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
        step.update(exit_code=result.returncode, ended_utc=stamp(), elapsed_seconds=time.monotonic()-start)
        print(label + ' exit=' + str(result.returncode), flush=True)
        if result.returncode:
            raise RuntimeError(label + ' failed; see retained streams')
    try:
        run('java_version', [JDK / 'bin/java.exe', '-version'])
        key = HERE / 'signing/pro-score-development.jks'
        if not key.exists():
            key.parent.mkdir(exist_ok=True)
            run('development_key', [JDK / 'bin/keytool.exe', '-genkeypair', '-keystore', key,
                '-storetype', 'JKS', '-storepass', 'android', '-keypass', 'android',
                '-alias', 'proscoredev', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
                '-dname', 'CN=Pro Score Development,OU=Local Development,O=FPGA Project,C=CN', '-noprompt'])
        receipt['development_keystore_identity'] = identity(key)
        command = [str(GRADLE), '--no-daemon', '--console=plain']
        if args.offline:
            command.append('--offline')
        run('gradle_build_lint', command + ['assembleRelease', 'lintRelease'])
        built_apk = HERE / 'app/build/outputs/apk/release/app-release.apk'
        artifact_dir = out / 'artifacts'
        artifact_dir.mkdir()
        apk = artifact_dir / 'ProScoreAndroid.apk'
        shutil.copyfile(built_apk, apk)
        if identity(apk) != identity(built_apk):
            raise RuntimeError('APK snapshot identity mismatch')
        receipt['apk'] = {'path': str(apk), **identity(apk), 'signing': 'local development certificate, not store release'}
        receipt['lint_reports'] = {}
        for extension in ('html', 'xml'):
            source_report = HERE / ('app/build/reports/lint-results-release.' + extension)
            report = artifact_dir / source_report.name
            shutil.copyfile(source_report, report)
            receipt['lint_reports'][report.name] = identity(report)
        tools = SDK / 'build-tools/34.0.0'
        run('verify_apk_signature', [tools / 'apksigner.bat', 'verify', '--verbose', '--print-certs', str(apk)])
        run('apk_manifest', [tools / 'aapt.exe', 'dump', 'xmltree', str(apk), 'AndroidManifest.xml'])
        receipt['apk_manifest_checks'] = validate_manifest_dump((out / 'apk_manifest.stdout.log').read_text(encoding='utf-8'))
        after_inputs = capture_build_inputs()
        changed = [name for name in sorted(set(build_inputs) | set(after_inputs))
                   if build_inputs.get(name) != after_inputs.get(name)]
        receipt['build_input_changes_during_run'] = changed
        if changed:
            raise RuntimeError('Build inputs changed during build: ' + ', '.join(changed))
        receipt['status'] = 'PASS_APK_BUILD_LINT_AND_SIGNATURE_ONLY'
    except Exception as error:
        receipt['status'] = 'FAIL'
        receipt['error'] = str(error)
    receipt['ended_utc'] = stamp()
    receipt['log_identities'] = {p.name: identity(p) for p in sorted(out.glob('*.log'))}
    (out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'status': receipt['status'], 'receipt': str(out / 'receipt.json')}, ensure_ascii=False))
    return 0 if receipt['status'].startswith('PASS_') else 1


if __name__ == '__main__':
    sys.exit(main())
