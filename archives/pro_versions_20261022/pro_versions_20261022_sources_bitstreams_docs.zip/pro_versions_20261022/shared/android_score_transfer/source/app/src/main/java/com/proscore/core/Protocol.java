package com.proscore.core;

import java.util.Arrays;

/** Exact protocol-v2 wire codec. No Android classes or I/O. */
public final class Protocol {
    private Protocol() { }
    public static final int VERSION=2,MAX_PAYLOAD=128;
    public static final int BEGIN=1,DATA=2,COMMIT=3,ABORT=4,STATUS=5,READ=6;
    public static final int START=7,STOP=8,CLEAR=9,READ_BEGIN=10,READ_END=11;
    public static final int ACK=128,NACK=129,BUSY=15;
    public static final class Frame {
        public final int command,session,seq,offset;
        private final byte[] payload;
        public Frame(int command,int session,int seq,int offset,byte[] payload) {
            range(command,255,"command");range(session,65535,"session");
            range(seq,65535,"seq");range(offset,65535,"offset");
            if (payload==null || payload.length>MAX_PAYLOAD) throw invalid("PAYLOAD_LENGTH");
            this.command=command;this.session=session;this.seq=seq;this.offset=offset;
            this.payload=payload.clone();
        }
        public byte[] getPayload() { return payload.clone(); }
        public byte[] encode() { return Protocol.encode(command,session,seq,offset,payload); }
    }
    public static final class Response {
        public final int originalCommand,error,committed,uploadActive,count,received;
        public final long scoreId;
        private final byte[] event;
        private Response(byte[] payload) {
            originalCommand=u8(payload[0]);error=u8(payload[1]);committed=u8(payload[2]);uploadActive=u8(payload[3]);
            count=u16(payload,4);scoreId=u32(payload,6);received=u16(payload,10);
            event=Arrays.copyOfRange(payload,12,payload.length);
        }
        public byte[] getEvent() { return event.clone(); }
    }
    public static final class NackException extends Exception {
        private static final long serialVersionUID=1L;
        private final int code;
        public NackException(int code,int command) { super("NACK:"+code+"，命令"+command+"被FPGA拒绝；未确认播放/停止状态");this.code=code; }
        public int getErrorCode() { return code; }
    }
    public static int crc16(byte[] bytes) {
        if (bytes==null) throw invalid("NULL_CRC_INPUT");
        return crc16(bytes,0,bytes.length);
    }
    private static int crc16(byte[] bytes,int start,int length) {
        int c=0xffff;
        for(int i=start;i<start+length;i++) {
            c^=u8(bytes[i])<<8;
            for(int bit=0;bit<8;bit++) c=((c<<1)^((c&0x8000)!=0?0x1021:0))&0xffff;
        }
        return c;
    }
    public static byte[] encode(int command,int session,int seq,int offset,byte[] payload) {
        Frame q=new Frame(command,session,seq,offset,payload);
        byte[] raw=new byte[14+q.payload.length];
        raw[0]=(byte)0xa5;raw[1]=0x5a;raw[2]=VERSION;raw[3]=(byte)command;
        putU16(raw,4,session);putU16(raw,6,seq);putU16(raw,8,offset);putU16(raw,10,q.payload.length);
        System.arraycopy(q.payload,0,raw,12,q.payload.length);
        putU16(raw,raw.length-2,crc16(raw,2,raw.length-4));
        return raw;
    }
    public static Frame decode(byte[] raw) {
        if (raw==null || raw.length<14 || u8(raw[0])!=0xa5 || u8(raw[1])!=0x5a) throw invalid("FRAME_SYNC_OR_TRUNCATION");
        if (u8(raw[2])!=VERSION) throw invalid("VERSION_V2_REQUIRED");
        int length=u16(raw,10);
        if (length>MAX_PAYLOAD || raw.length!=14+length) throw invalid("EXACT_FRAME_LENGTH");
        if (crc16(raw,2,raw.length-4)!=u16(raw,raw.length-2)) throw invalid("FRAME_CRC");
        return new Frame(u8(raw[3]),u16(raw,4),u16(raw,6),u16(raw,8),Arrays.copyOfRange(raw,12,raw.length-2));
    }
    public static Response validateResponse(byte[] raw,Frame request) throws NackException {
        if (request==null) throw invalid("NULL_REQUEST");
        Frame reply=decode(raw);
        if (reply.session!=request.session || reply.seq!=request.seq || reply.offset!=request.offset) throw invalid("RESPONSE_IDENTITY");
        if (reply.command!=ACK && reply.command!=NACK || reply.payload.length!=12 && reply.payload.length!=20) throw invalid("RESPONSE_SHAPE");
        Response meta=new Response(reply.payload);
        if (meta.originalCommand!=request.command) throw invalid("RESPONSE_COMMAND");
        int expected=request.command==READ && reply.command==ACK?20:12;
        if (reply.payload.length!=expected) throw invalid("RESPONSE_SHAPE");
        if (reply.command==ACK && meta.error!=0 || reply.command==NACK && meta.error==0) throw invalid("ACK_ERROR_CONTRADICTION");
        if (meta.committed>1 || meta.uploadActive>1 || meta.count>512) throw invalid("METADATA_RANGE");
        if (reply.command==NACK) {
            if (meta.error<1 || meta.error>BUSY) throw invalid("UNKNOWN_ERROR_CODE");
            throw new NackException(meta.error,request.command);
        }
        return meta;
    }
    static int u8(byte x) { return x&255; }
    static int u16(byte[] x,int p) { return u8(x[p])|u8(x[p+1])<<8; }
    static long u32(byte[] x,int p) { return (long)u16(x,p)|(long)u16(x,p+2)<<16; }
    static void putU16(byte[] x,int p,int n) { x[p]=(byte)n;x[p+1]=(byte)(n>>>8); }
    static void putU32(byte[] x,int p,long n) { for(int i=0;i<4;i++) x[p+i]=(byte)(n>>>(8*i)); }
    private static void range(int n,int max,String name) { if(n<0||n>max) throw invalid("RANGE_"+name); }
    private static IllegalArgumentException invalid(String code) { return new IllegalArgumentException(code+": 协议v2帧校验失败"); }
}
