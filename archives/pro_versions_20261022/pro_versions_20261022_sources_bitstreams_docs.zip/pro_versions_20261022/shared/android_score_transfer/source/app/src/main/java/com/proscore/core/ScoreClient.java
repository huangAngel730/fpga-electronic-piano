package com.proscore.core;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Single-worker v2 client. A UI button creates a fresh client/session.
 * send must complete an entire frame or throw; any send error is fatal.
 * Only receive TimeoutException/SocketTimeoutException permits exact replay.
 */
public final class ScoreClient {
    public interface Transport {
        void send(byte[] frame,long timeoutMillis) throws Exception;
        byte[] receive(long timeoutMillis) throws Exception;
    }
    public interface Progress { void onProgress(String phase,int done,int total); }
    interface Clock { long nanoTime(); }

    private static final byte[] EMPTY=new byte[0];
    private static final long ACK_NANOS=2_000_000_000L,TOTAL_NANOS=180_000_000_000L;
    private static final int MAX_RETRIES=2;
    private static final SecureRandom RANDOM=new SecureRandom();
    private final Transport transport;
    private final Progress progress;
    private final Clock clock;
    private final int session;
    private final long startedNanos;
    private final AtomicBoolean running=new AtomicBoolean();
    private volatile Thread worker;
    private volatile boolean cancelled;
    private boolean uploadAttempted;
    // Upload DATA/COMMIT fit 1..4097 even with one-byte chunks; no identity alias.
    private int querySequence=8192;
    private String phase="准备";

    public ScoreClient(Transport transport,Progress progress) {
        this(transport,progress,RANDOM.nextInt(65535)+1,System::nanoTime);
    }
    ScoreClient(Transport transport,Progress progress,int session,Clock clock) {
        if (transport==null || clock==null || session<1 || session>65535) throw new IllegalArgumentException("CLIENT_ARGUMENT");
        this.transport=transport;this.progress=progress;this.session=session;this.clock=clock;
        this.startedNanos=clock.nanoTime();
    }
    /** Cancels local waits only; no STOP/ABORT is emitted or claimed. */
    public void cancel() {
        cancelled=true;
        Thread current=worker;
        if (current!=null) current.interrupt();
    }
    public void upload(Score score,boolean stopFirst) throws Exception {
        if (score==null) throw new IllegalArgumentException("SCORE_REQUIRED: 请选择曲谱");
        enter();
        try {
            if (uploadAttempted) throw new IllegalStateException("ONE_UPLOAD_PER_SESSION: 请为新上传创建新client");
            byte[] records=score.getRecords();
            int count=score.getCount(),chunks=(records.length+127)/128;
            preflight(count+chunks+5+(stopFirst?2:0),222L+40L*chunks+56L*count+(stopFirst?80:0));
            uploadAttempted=true;
            if (stopFirst) {
                report("等待STOP最终确认",0,1);
                exchange(request(Protocol.STOP,0,EMPTY));
                exchange(request(Protocol.ABORT,0,EMPTY));
            }
            byte[] begin=new byte[14];
            Protocol.putU32(begin,0,score.getScoreId());Protocol.putU16(begin,4,count);
            Protocol.putU16(begin,6,records.length);Protocol.putU16(begin,8,Protocol.crc16(records));
            Protocol.putU32(begin,10,48000);
            report("上传",0,records.length);
            exchange(new Protocol.Frame(Protocol.BEGIN,session,0,0,begin));
            int seq=1;
            for (int offset=0;offset<records.length;offset+=128) {
                int end=Math.min(offset+128,records.length);
                exchange(new Protocol.Frame(Protocol.DATA,session,seq++,offset,Arrays.copyOfRange(records,offset,end)));
                report("上传",end,records.length);
            }
            Protocol.Response committed=exchange(new Protocol.Frame(Protocol.COMMIT,session,seq,0,EMPTY));
            identity(committed,score);
            if (committed.uploadActive!=0) throw new IOException("COMMIT_METADATA: 发布后上传会话仍有效");
            identity(exchange(request(Protocol.STATUS,0,EMPTY)),score);
            readAll(score,records);
            report("上传并核验完成",count,count);
        } finally { leave(); }
    }
    public void start(Score score) throws Exception {
        if (score==null) throw new IllegalArgumentException("SCORE_REQUIRED: 请选择曲谱");
        enter();
        try {
            preflight(score.getCount()+3,136L+48L*score.getCount());
            readAll(score,score.getRecords());
            report("等待START最终确认",0,1);
            exchange(request(Protocol.START,0,identityPayload(score)));
            report("START已确认",1,1);
        } finally { leave(); }
    }
    public void stop() throws Exception {
        enter();
        try {
            report("等待STOP最终确认",0,1);
            exchange(request(Protocol.STOP,0,EMPTY));
            report("STOP已确认",1,1);
        } finally { leave(); }
    }
    private void readAll(Score score,byte[] expected) throws Exception {
        int count=score.getCount();
        report("完整回读核对",0,count);
        identity(exchange(request(Protocol.READ_BEGIN,0,identityPayload(score))),score);
        for (int i=0;i<count;i++) {
            Protocol.Response response=exchange(request(Protocol.READ,i,EMPTY));
            identity(response,score);
            byte[] event=response.getEvent();
            for (int j=0;j<8;j++) {
                if (event[j]!=expected[i*8+j]) throw new IOException("READBACK_MISMATCH: 事件"+i+"字节"+j+"不一致；读租约可能保留，需显式STOP恢复");
            }
            report("完整回读核对",i+1,count);
        }
        // No READ_END on mismatch/cancellation; never pretend a lease auto-expires.
        identity(exchange(request(Protocol.READ_END,0,EMPTY)),score);
    }
    private static byte[] identityPayload(Score score) {
        byte[] payload=new byte[8];
        Protocol.putU32(payload,0,score.getScoreId());Protocol.putU16(payload,4,score.getCount());
        return payload;
    }
    private static void identity(Protocol.Response meta,Score score) throws IOException {
        if (meta.committed!=1 || meta.count!=score.getCount() || meta.scoreId!=score.getScoreId()) throw new IOException("PUBLISHED_IDENTITY: 发布曲谱身份变化；未确认播放状态");
    }
    private Protocol.Frame request(int command,int offset,byte[] payload) {
        if (querySequence>65535) throw new IllegalStateException("SEQUENCE_EXHAUSTED: 请创建新client/session");
        return new Protocol.Frame(command,session,querySequence++,offset,payload);
    }
    private Protocol.Response exchange(Protocol.Frame request) throws Exception {
        byte[] raw=request.encode();
        for (int attempt=0;attempt<=MAX_RETRIES;attempt++) {
            check();
            long attemptStart=clock.nanoTime(),limit=Math.min(ACK_NANOS,totalRemaining());
            // Intentionally OUTSIDE the receive-timeout retry handler. A partial
            // GATT send, including its TimeoutException, must never be replayed.
            try { transport.send(raw.clone(),millis(limit)); }
            catch (InterruptedException ex) {
                Thread.currentThread().interrupt(); check(); throw ex;
            } catch (Exception ex) {
                check();
                throw new IOException("SEND_FAILED_STATE_UNKNOWN: 完整帧发送未确认；不得重放半帧，需重连后显式STOP恢复",ex);
            }
            check();
            if (clock.nanoTime()-attemptStart>=limit) throw new IOException("SEND_DEADLINE_STATE_UNKNOWN: 发送已超时，不能确认对端状态");
            try {
                while (true) {
                    check();
                    long remaining=Math.min(totalRemaining(),limit-(clock.nanoTime()-attemptStart));
                    if (remaining<=0) throw new TimeoutException("ACK_DEADLINE");
                    byte[] replyRaw=transport.receive(millis(remaining));
                    check();
                    if (clock.nanoTime()-attemptStart>=limit) throw new TimeoutException("ACK_DEADLINE");
                    Protocol.Frame reply=Protocol.decode(replyRaw);
                    if (reply.session!=request.session || reply.seq!=request.seq || reply.offset!=request.offset) continue;
                    return Protocol.validateResponse(replyRaw,request);
                }
            } catch (TimeoutException | SocketTimeoutException ex) {
                check();
                if (attempt==MAX_RETRIES) throw new TimeoutException("ACK_TIMEOUT: "+phase+"未收到FPGA确认；状态未知，请显式STOP恢复");
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt(); check(); throw ex;
            }
        }
        throw new AssertionError("unreachable");
    }
    private void enter() throws Exception {
        if (!running.compareAndSet(false,true)) throw new IllegalStateException("CLIENT_BUSY: 一个client只能由单工作线程操作");
        worker=Thread.currentThread();
        try { check(); } catch (Exception ex) { leave(); throw ex; }
    }
    private void leave() {
        worker=null;
        if (cancelled) Thread.interrupted(); // Clear only this client's own cancellation signal.
        running.set(false);
    }
    private long totalRemaining() { return TOTAL_NANOS-(clock.nanoTime()-startedNanos); }
    private void check() throws Exception {
        if (cancelled || Thread.currentThread().isInterrupted()) throw new InterruptedException("CANCELLED: 仅取消手机等待，FPGA状态未知，未确认STOP");
        if (totalRemaining()<=0) throw new TimeoutException("TOTAL_TIMEOUT_180S: "+phase+"达到总截止；FPGA状态未知，请显式STOP恢复");
    }
    private static long millis(long nanos) throws TimeoutException {
        if (nanos<=0) throw new TimeoutException("TIME_BUDGET_EXHAUSTED");
        return (nanos+999_999L)/1_000_000L;
    }
    private void report(String message,int done,int total) throws Exception {
        check();phase=message;
        if (progress!=null) progress.onProgress(message,done,total);
        check();
    }
    private void preflight(int interactions,long uartBytes) throws Exception {
        check();
        long available=millis(totalRemaining());
        long uartMinimum=(uartBytes*10_000L+115199)/115200;
        if (available<uartMinimum) throw new TimeoutException("TIME_BUDGET: 剩余时间不足UART理论下限"+uartMinimum+"ms；实际BLE还需额外时间");
        report("时间预检："+interactions+"次交互，平均预算"+(available/interactions)+"ms；无线耗时需实测",0,interactions);
    }
}
