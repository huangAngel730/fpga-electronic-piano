package com.proscore.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Bounded JSON parser preserving numeric spelling and rejecting duplicate decoded keys. */
final class StrictJson {
    static final class NumberToken {
        final String text;
        NumberToken(String text) { this.text = text; }
    }
    private final String input;
    private int position, nodes;
    private StrictJson(String input) { this.input = input; }
    static Object parse(String input) {
        StrictJson p = new StrictJson(input);
        Object result = p.value(0);
        p.space();
        if (p.position != input.length()) throw p.error("JSON_TRAILING");
        return result;
    }
    private IllegalArgumentException error(String code) {
        return new IllegalArgumentException(code + ": JSON格式错误，字符位置" + position);
    }
    private void space() {
        while (position < input.length()) {
            char c = input.charAt(position);
            if (c != ' ' && c != '\t' && c != '\r' && c != '\n') break;
            position++;
        }
    }
    private boolean take(char c) {
        if (position < input.length() && input.charAt(position) == c) { position++; return true; }
        return false;
    }
    private void require(char c) { space(); if (!take(c)) throw error("JSON_EXPECTED_" + c); }
    private Object value(int depth) {
        if (depth > 16 || ++nodes > 8192) throw error("JSON_RESOURCE_LIMIT");
        space();
        if (position == input.length()) throw error("JSON_TRUNCATED");
        char c = input.charAt(position);
        if (c == '"') return string();
        if (c == '{') {
            position++;
            Map<String,Object> result = new LinkedHashMap<>();
            space(); if (take('}')) return result;
            while (true) {
                space();
                if (position == input.length() || input.charAt(position) != '"') throw error("JSON_KEY");
                String key = string();
                if (result.containsKey(key)) throw error("JSON_DUPLICATE_FIELD_" + key);
                require(':'); result.put(key, value(depth + 1));
                space(); if (take('}')) return result;
                require(',');
            }
        }
        if (c == '[') {
            position++;
            List<Object> result = new ArrayList<>();
            space(); if (take(']')) return result;
            while (true) {
                if (result.size() >= 512) throw error("JSON_ARRAY_LIMIT");
                result.add(value(depth + 1));
                space(); if (take(']')) return result;
                require(',');
            }
        }
        if (c == '-' || c >= '0' && c <= '9') return number();
        for (String literal : new String[]{"true","false","null"}) {
            if (input.startsWith(literal,position)) {
                position += literal.length();
                return literal.equals("null") ? null : Boolean.valueOf(literal);
            }
        }
        throw error("JSON_VALUE");
    }
    private boolean digit() { return position < input.length() && input.charAt(position) >= '0' && input.charAt(position) <= '9'; }
    private NumberToken number() {
        int start = position; take('-');
        if (!take('0')) {
            if (!digit() || input.charAt(position) == '0') throw error("JSON_NUMBER");
            while (digit()) position++;
        }
        if (take('.')) {
            if (!digit()) throw error("JSON_NUMBER");
            while (digit()) position++;
        }
        if (take('e') || take('E')) {
            if (!take('+')) take('-');
            if (!digit()) throw error("JSON_NUMBER");
            while (digit()) position++;
        }
        if (position - start > 64) throw error("JSON_NUMBER_LIMIT");
        return new NumberToken(input.substring(start,position));
    }
    private String string() {
        if (!take('"')) throw error("JSON_STRING");
        StringBuilder result = new StringBuilder();
        while (position < input.length()) {
            char c = input.charAt(position++);
            if (c == '"') {
                for (int i=0; i<result.length(); i++) {
                    char unit=result.charAt(i);
                    if (Character.isHighSurrogate(unit)) {
                        if (++i >= result.length() || !Character.isLowSurrogate(result.charAt(i))) throw error("JSON_SURROGATE");
                    } else if (Character.isLowSurrogate(unit)) throw error("JSON_SURROGATE");
                }
                return result.toString();
            }
            if (c < 32) throw error("JSON_CONTROL_CHAR");
            if (c == '\\') {
                if (position == input.length()) throw error("JSON_ESCAPE");
                char escape=input.charAt(position++);
                switch (escape) {
                    case '"': c='"'; break;
                    case '\\': c='\\'; break;
                    case '/': c='/'; break;
                    case 'b': c='\b'; break;
                    case 'f': c='\f'; break;
                    case 'n': c='\n'; break;
                    case 'r': c='\r'; break;
                    case 't': c='\t'; break;
                    case 'u':
                        if (position+4 > input.length()) throw error("JSON_UNICODE");
                        int code=0;
                        for (int i=0;i<4;i++) {
                            char hex=input.charAt(position++);
                            int v=hex>='0' && hex<='9' ? hex-'0' : hex>='a' && hex<='f' ? hex-'a'+10 : hex>='A' && hex<='F' ? hex-'A'+10 : -1;
                            if (v<0) throw error("JSON_UNICODE");
                            code=code*16+v;
                        }
                        c=(char)code; break;
                    default: throw error("JSON_ESCAPE");
                }
            }
            result.append(c);
            if (result.length()>4096) throw error("JSON_STRING_LIMIT");
        }
        throw error("JSON_UNTERMINATED_STRING");
    }
}
