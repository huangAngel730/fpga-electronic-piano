package com.proscore.android;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Arrays;

/** Bounded, fail-closed v2 stream. Caller must serialize access. */
final class ResponseStream {
    private static final int MAX_BUFFER = 512;
    private static final int MAX_QUEUED = 8;
    private final byte[] buffer = new byte[MAX_BUFFER];
    private final ArrayDeque<byte[]> frames = new ArrayDeque<>();
    private int size;
    private IOException failure;

    void feed(byte[] bytes) throws IOException {
        checkFailure();
        if (bytes == null || bytes.length == 0) reject("BLE 通知为空");
        if (bytes.length > MAX_BUFFER - size) reject("BLE 接收缓冲溢出");
        System.arraycopy(bytes, 0, buffer, size, bytes.length);
        size += bytes.length;
        while (size > 0) {
            if (u(buffer[0]) != 0xa5 || (size >= 2 && u(buffer[1]) != 0x5a)) {
                reject("BLE 响应流失去帧同步");
            }
            if (size < 3) return;
            if (u(buffer[2]) != 2) reject("仅接受协议 v2 响应");
            if (size < 12) return;
            int payload = u16(buffer, 10);
            if (payload > 128) reject("BLE 响应 payload 超出 128 字节");
            int length = 14 + payload;
            if (size < length) return;
            byte[] frame = Arrays.copyOf(buffer, length);
            validate(frame);
            if (frames.size() == MAX_QUEUED) reject("BLE 响应队列溢出");
            frames.addLast(frame);
            size -= length;
            System.arraycopy(buffer, length, buffer, 0, size);
        }
    }

    byte[] poll() throws IOException {
        checkFailure();
        return frames.pollFirst();
    }

    private void validate(byte[] frame) throws IOException {
        if (crc16(frame, 2, frame.length - 2) != u16(frame, frame.length - 2)) {
            reject("BLE 响应 CRC16 错误");
        }
        int response = u(frame[3]);
        int length = u16(frame, 10);
        if ((response != 0x80 && response != 0x81) || (length != 12 && length != 20)) {
            reject("BLE ACK/NACK 响应形状错误");
        }
        int command = u(frame[12]);
        int error = u(frame[13]);
        if (command < 1 || command > 11 || (response == 0x80) != (error == 0)
                || (response == 0x81 && error > 15)) {
            reject("BLE 响应命令或错误码无效");
        }
        int expected = command == 6 && response == 0x80 ? 20 : 12;
        if (length != expected || u(frame[14]) > 1 || u(frame[15]) > 1
                || u16(frame, 16) > 512) {
            reject("READ 成功须为20字节，其余ACK/NACK须为12字节且元数据合法");
        }
    }

    static int crc16(byte[] bytes, int from, int until) {
        int crc = 0xffff;
        for (int i = from; i < until; i++) {
            crc ^= u(bytes[i]) << 8;
            for (int bit = 0; bit < 8; bit++) {
                crc = (crc & 0x8000) != 0 ? (crc << 1) ^ 0x1021 : crc << 1;
                crc &= 0xffff;
            }
        }
        return crc;
    }

    private void checkFailure() throws IOException {
        if (failure != null) throw failure;
    }

    private void reject(String message) throws IOException {
        failure = new IOException(message);
        frames.clear();
        size = 0;
        throw failure;
    }

    static int u(byte b) { return b & 0xff; }
    static int u16(byte[] b, int i) { return u(b[i]) | u(b[i + 1]) << 8; }
}