package com.proscore.android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.SystemClock;

import com.proscore.core.ScoreClient;

import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.TimeoutException;

/** One explicit GATT connection. All public blocking operations run off the UI thread. */
public final class GattTransport implements ScoreClient.Transport, AutoCloseable {
    public static final UUID SERVICE = uuid("0001");
    private static final UUID RX = uuid("0002");
    private static final UUID TX = uuid("0003");
    private static final UUID STATUS = uuid("0004");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final int NONE = 0, READ_STATUS = 1, WRITE_CCCD = 2, WRITE_RX = 3;

    public interface Listener { void onFailure(String reason); }

    private final Context context;
    private final Listener listener;
    private final Object guard = new Object();
    private final Object serial = new Object();
    private final ResponseStream stream = new ResponseStream();
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic rx;
    private boolean connected, discovered, ready, closed;
    private IOException failure;
    private int pending;
    private UUID expectedUuid;
    private boolean completed;
    private byte[] readValue;
    private byte[] bridgeStatus;

    public GattTransport(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    private static UUID uuid(String suffix) {
        return UUID.fromString("761e" + suffix + "-6ccd-4aa4-9e21-104647415031");
    }

    public boolean isReady() {
        synchronized (guard) { return ready && !closed && failure == null; }
    }

    public byte[] getBridgeStatus() {
        synchronized (guard) { return bridgeStatus == null ? new byte[0] : bridgeStatus.clone(); }
    }

    // Permissions are checked immediately before calls; loss/revocation is fatal.
    @SuppressLint("MissingPermission")
    public void connect(BluetoothDevice device, long timeoutMillis) throws Exception {
        synchronized (serial) {
            long until = deadline(timeoutMillis);
            try {
                ensurePermission();
                synchronized (guard) {
                    checkOpen();
                    if (gatt != null) throw new IOException("该连接已经使用，请显式新建连接");
                    // The monitor also fences callbacks racing connectGatt's return.
                    gatt = device.connectGatt(context, false, callbacks, BluetoothDevice.TRANSPORT_LE);
                    if (gatt == null) throw new IOException("系统未创建 BLE GATT 连接");
                    while (!connected) await(until);
                    checkDeadline(until);
                    if (!gatt.discoverServices()) throw new IOException("无法启动 GATT 服务发现");
                    while (!discovered) await(until);
                    BluetoothGattService service = gatt.getService(SERVICE);
                    if (service == null) throw new IOException("缺少指定的 v2 传谱 BLE 服务");
                    rx = service.getCharacteristic(RX);
                    BluetoothGattCharacteristic tx = service.getCharacteristic(TX);
                    BluetoothGattCharacteristic status = service.getCharacteristic(STATUS);
                    if (!has(rx, BluetoothGattCharacteristic.PROPERTY_WRITE)
                            || !has(tx, BluetoothGattCharacteristic.PROPERTY_NOTIFY)
                            || !has(status, BluetoothGattCharacteristic.PROPERTY_READ)) {
                        throw new IOException("BLE RX响应写 / TX通知 / status读取属性不匹配");
                    }
                    BluetoothGattDescriptor descriptor = tx.getDescriptor(CCCD);
                    if (descriptor == null) throw new IOException("TX 通知缺少 CCCD 描述符");
                    begin(READ_STATUS, STATUS);
                    ensurePermission();
                    if (!gatt.readCharacteristic(status)) throw new IOException("status 读取未启动");
                    awaitOperation(until);
                    if (readValue == null || readValue.length != 6 || readValue[0] != 2) {
                        throw new IOException("桥 status 必须为6字节且 version=2");
                    }
                    bridgeStatus = readValue.clone();
                    ensurePermission();
                    if (!gatt.setCharacteristicNotification(tx, true)) {
                        throw new IOException("系统拒绝启用 TX 本地通知");
                    }
                    begin(WRITE_CCCD, CCCD);
                    if (!writeDescriptor(gatt, descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)) {
                        throw new IOException("CCCD 订阅写入未启动");
                    }
                    awaitOperation(until);
                    checkOpen();
                    ready = true; // Not before the actual CCCD success callback.
                }
            } catch (Exception error) {
                fail(new IOException("BLE 连接未就绪：" + description(error), error));
                throw error;
            }
        }
    }

    @Override
    @SuppressLint("MissingPermission")
    public void send(byte[] frame, long timeoutMillis) throws Exception {
        synchronized (serial) {
            try {
                if (frame == null || frame.length < 14 || frame.length > 142) {
                    throw new IOException("发送帧长度无效");
                }
                long until = deadline(timeoutMillis); // ONE deadline for the whole frame.
                synchronized (guard) {
                    requireReady();
                    for (int offset = 0; offset < frame.length; offset += 20) {
                        ensurePermission();
                        if (SystemClock.elapsedRealtime() >= until) throw new TimeoutException("分片写入总截止");
                        byte[] piece = Arrays.copyOfRange(frame, offset, Math.min(frame.length, offset + 20));
                        begin(WRITE_RX, RX);
                        if (!writeCharacteristic(gatt, rx, piece)) throw new IOException("GATT 响应写未启动");
                        awaitOperation(until); // Every fragment requires its own write response.
                    }
                }
            } catch (Exception error) {
                // NEVER leak TimeoutException from send: the core must not replay
                // a possibly partial byte stream as if it were a whole-frame ACK timeout.
                IOException fatal = new IOException("GATT 写入中断，帧可能仅发送一部分；状态未知，请重连后显式STOP："
                        + description(error), error);
                fail(fatal);
                throw fatal;
            }
        }
    }

    @Override
    public byte[] receive(long timeoutMillis) throws Exception {
        synchronized (serial) {
            long until = deadline(timeoutMillis);
            synchronized (guard) {
                requireReady();
                while (true) {
                    checkOpen();
                    checkDeadline(until);
                    byte[] value = stream.poll();
                    if (value != null) return value;
                    // A receive timeout is retryable by the finite stop-and-wait core.
                    // A partial notification remains buffered and never counts as a reply.
                    await(until);
                }
            }
        }
    }

    private static boolean has(BluetoothGattCharacteristic c, int property) {
        return c != null && (c.getProperties() & property) != 0;
    }

    private void begin(int operation, UUID uuid) throws IOException {
        checkOpen();
        if (pending != NONE) throw new IOException("检测到并行 GATT 操作");
        pending = operation;
        expectedUuid = uuid;
        completed = false;
        readValue = null;
    }

    private void awaitOperation(long until) throws Exception {
        while (!completed) await(until);
        checkOpen();
        checkDeadline(until);
        pending = NONE;
    }

    private void await(long until) throws Exception {
        checkOpen();
        long remaining = until - SystemClock.elapsedRealtime();
        if (remaining <= 0) throw new TimeoutException("BLE 等待超时；设备状态尚未确认");
        guard.wait(remaining);
        checkOpen();
        checkDeadline(until);
    }

    private static void checkDeadline(long until) throws TimeoutException {
        if (SystemClock.elapsedRealtime() >= until) throw new TimeoutException("BLE 超过单调时钟截止");
    }

    private static long deadline(long milliseconds) {
        if (milliseconds <= 0 || milliseconds > 180000) throw new IllegalArgumentException("BLE 超时范围无效");
        return SystemClock.elapsedRealtime() + milliseconds;
    }

    private void checkOpen() throws IOException {
        if (failure != null) throw failure;
        if (closed) throw new IOException("BLE 已断开；设备状态未知，需重连并显式STOP");
    }

    private void requireReady() throws IOException {
        checkOpen();
        if (!ready) throw new IOException("BLE 尚未通过服务、status 与 CCCD 校验");
    }

    private void ensurePermission() throws IOException {
        if (Build.VERSION.SDK_INT >= 31
                && context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            throw new IOException("缺少附近设备连接权限");
        }
    }

    @SuppressWarnings("deprecation")
    @SuppressLint("MissingPermission")
    private boolean writeCharacteristic(BluetoothGatt link, BluetoothGattCharacteristic c, byte[] value) {
        if (Build.VERSION.SDK_INT >= 33) {
            return link.writeCharacteristic(c, value, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS;
        }
        // API26..32 compatibility only; serialized and no shared mutable buffer.
        c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        return c.setValue(value) && link.writeCharacteristic(c);
    }

    @SuppressWarnings("deprecation")
    @SuppressLint("MissingPermission")
    private boolean writeDescriptor(BluetoothGatt link, BluetoothGattDescriptor d, byte[] value) {
        if (Build.VERSION.SDK_INT >= 33) return link.writeDescriptor(d, value) == BluetoothStatusCodes.SUCCESS;
        return d.setValue(value.clone()) && link.writeDescriptor(d);
    }

    private void complete(BluetoothGatt link, int operation, UUID uuid, int status, byte[] value) {
        IOException problem = null;
        synchronized (guard) {
            if (link != gatt || closed) return; // Late callbacks from closed generations never apply.
            if (pending != operation || !uuid.equals(expectedUuid) || completed) {
                problem = new IOException("GATT 回调与当前串行操作不匹配");
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                problem = new IOException("GATT 操作失败，status=" + status);
            } else {
                readValue = value == null ? null : value.clone();
                completed = true;
                guard.notifyAll();
            }
        }
        if (problem != null) fail(problem);
    }

    private void notifyBytes(BluetoothGatt link, BluetoothGattCharacteristic c, byte[] value) {
        IOException problem = null;
        synchronized (guard) {
            if (link != gatt || closed || !TX.equals(c.getUuid())) return;
            try {
                stream.feed(value == null ? null : value.clone());
                guard.notifyAll();
            } catch (IOException error) { problem = error; }
        }
        if (problem != null) fail(problem);
    }

    private final BluetoothGattCallback callbacks = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt link, int status, int state) {
            synchronized (guard) {
                if (link != gatt || closed) return;
                if (status == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
                    connected = true;
                    guard.notifyAll();
                    return;
                }
            }
            if (status != BluetoothGatt.GATT_SUCCESS || state == BluetoothProfile.STATE_DISCONNECTED) {
                fail(new IOException("BLE 连接已断开，设备状态未知，需显式STOP恢复；status=" + status));
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt link, int status) {
            synchronized (guard) {
                if (link != gatt || closed) return;
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    discovered = true; guard.notifyAll(); return;
                }
            }
            fail(new IOException("BLE 服务发现失败，status=" + status));
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            complete(g, WRITE_RX, c.getUuid(), status, null);
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            complete(g, WRITE_CCCD, d.getUuid(), status, null);
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int status) {
            complete(g, READ_STATUS, c.getUuid(), status, value);
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            notifyBytes(g, c, value);
        }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            if (Build.VERSION.SDK_INT < 33) complete(g, READ_STATUS, c.getUuid(), status, c.getValue());
        }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            if (Build.VERSION.SDK_INT < 33) notifyBytes(g, c, c.getValue());
        }
    };

    private static String description(Exception error) {
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }

    private void fail(IOException error) {
        boolean announce;
        synchronized (guard) {
            announce = !closed && failure == null;
            if (failure == null) failure = error;
        }
        close();
        if (announce && listener != null) listener.onFailure(error.getMessage());
    }

    @Override
    @SuppressLint("MissingPermission")
    public void close() {
        BluetoothGatt old;
        synchronized (guard) {
            closed = true; ready = false;
            old = gatt; gatt = null;
            guard.notifyAll();
        }
        if (old != null) {
            // Permission can be revoked during callbacks; close still attempted.
            try { old.disconnect(); } catch (RuntimeException ignored) { /* no fake success */ }
            try { old.close(); } catch (RuntimeException ignored) { /* already invalidated */ }
        }
    }
}