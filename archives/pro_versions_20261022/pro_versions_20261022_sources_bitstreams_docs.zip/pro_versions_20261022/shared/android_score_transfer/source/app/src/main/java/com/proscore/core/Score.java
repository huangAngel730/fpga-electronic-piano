package com.proscore.core;

import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Immutable score; records preserve input order and use frozen <IBBBB> encoding. */
public final class Score {
    private final long scoreId;
    private final byte[] records;
    private Score(long scoreId,byte[] records) { this.scoreId=scoreId; this.records=records.clone(); }
    public long getScoreId() { return scoreId; }
    public int getCount() { return records.length/8; }
    public byte[] getRecords() { return records.clone(); }

    public static Score parseUtf8(byte[] bytes) throws Exception {
        if (bytes==null || bytes.length==0 || bytes.length>2*1024*1024) throw error("JSON_SIZE","曲谱JSON必须为1字节至2MiB");
        String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        Map<?,?> document=object(StrictJson.parse(text));
        fields(document,"schema","sample_hz","score_id","events");
        if (integer(document.get("schema"),1,"schema")!=1) throw error("SCHEMA","schema必须为整数1");
        if (integer(document.get("sample_hz"),48000,"sample_hz")!=48000) throw error("SAMPLE_RATE","sample_hz必须为整数48000");
        long id=integer(document.get("score_id"),0xffffffffL,"score_id");
        if (!(document.get("events") instanceof List<?>)) throw error("EVENTS_TYPE","events必须为数组");
        List<?> events=(List<?>)document.get("events");
        if (events.isEmpty() || events.size()>512) throw error("CAPACITY","必须有1至512个原始事件");
        byte[] records=new byte[events.size()*8];
        Set<Integer> active=new HashSet<>();
        long previous=0;
        for (int i=0;i<events.size();i++) {
            Map<?,?> event=object(events.get(i));
            fields(event,"tick","type","channel","note","velocity");
            long tick=integer(event.get("tick"),16777215,"tick");
            int channel=(int)integer(event.get("channel"),15,"channel");
            int note=(int)integer(event.get("note"),84,"note");
            int velocity=(int)integer(event.get("velocity"),127,"velocity");
            if (note<36) throw error("NOTE_RANGE","生产音符范围为36至84，事件"+i);
            Object type=event.get("type");
            if (!"note_on".equals(type) && !"note_off".equals(type)) throw error("EVENT_TYPE","类型必须为note_on/note_off");
            if (tick<previous) throw error("TICK_ORDER","必须保持非递减tick及同tick输入顺序，事件"+i);
            int kind="note_off".equals(type) || velocity==0 ? 1 : 0;
            int key=channel*128+note;
            if (kind==0) {
                if (!active.add(key)) throw error("OVERLAPPING_NOTE","同channel/note生命周期重叠，事件"+i);
            } else if (!active.remove(key)) throw error("UNMATCHED_NOTE_OFF","NoteOff没有匹配NoteOn，事件"+i);
            int offset=i*8;
            Protocol.putU32(records,offset,tick);
            records[offset+4]=(byte)kind; records[offset+5]=(byte)channel;
            records[offset+6]=(byte)note; records[offset+7]=(byte)velocity;
            previous=tick;
        }
        if (!active.isEmpty()) throw error("UNFINISHED_NOTE","曲谱结尾仍有未结束NoteOn");
        return new Score(id,records);
    }
    private static Map<?,?> object(Object value) {
        if (!(value instanceof Map<?,?>)) throw error("OBJECT_TYPE","曲谱/事件必须为JSON对象");
        return (Map<?,?>)value;
    }
    private static void fields(Map<?,?> value,String... names) {
        if (!value.keySet().equals(new HashSet<String>(Arrays.asList(names)))) throw error("FIELDS","字段缺失或含未知字段");
    }
    private static long integer(Object value,long max,String name) {
        if (!(value instanceof StrictJson.NumberToken)) throw error("INTEGER_"+name,name+"必须为整数，不能是布尔、字符串或null");
        String token=((StrictJson.NumberToken)value).text;
        if (token.indexOf('.')>=0 || token.indexOf('e')>=0 || token.indexOf('E')>=0) throw error("INTEGER_"+name,name+"不接受小数/指数");
        try {
            long result=Long.parseLong(token);
            if (result<0 || result>max) throw error("RANGE_"+name,name+"超范围");
            return result;
        } catch (NumberFormatException ex) { throw error("RANGE_"+name,name+"整数溢出"); }
    }
    private static IllegalArgumentException error(String code,String message) { return new IllegalArgumentException(code+": "+message); }
}
