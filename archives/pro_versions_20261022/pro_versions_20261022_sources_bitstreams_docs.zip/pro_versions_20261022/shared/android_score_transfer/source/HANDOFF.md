# 安卓预转换曲谱传输 R01：总控交接

本轮限定软件实现与交付完成：手机选择预转换JSON、显式扫描并选择BLE设备、上传并完整回读核同、显式START和STOP。APK真实构建、lint、签名及编译清单核验通过；没有在手机安装或连接实物。`board_release_allowed=false`。历史`HANDOFF_PARTIAL.md`是此前审批暂停时的快照，以本文件及HANDOFF.json说明当前状态。

## 实际产物

总根：`E:/FPGA/GAOYUNFPGA/extra _life/basic/project/android_score_transfer_r01`。

交付入口：`delivery/R01/ProScoreAndroid-r01.apk`；完整包`delivery/R01.zip`，包含APK、样例JSON、源码、测试和原始证据。精确大小及SHA由交付MANIFEST与封存命令输出给出。

实际APK源：`evidence/BUILD_R04/artifacts/ProScoreAndroid.apk`，46778字节，SHA256 `5f5da9c903dbb12f6896e818963f83f129ebda3d10f52dc75bd098c139f4e4d8`。包名`com.proscore.android`，版本`1.0.0-r01`／versionCode1，最低API26、目标API35。RSA2048本地开发签名，APK v2签名验证通过；证书SHA256 `9dbc1ae8cefdc312084040d72b58e56b57553cb00b2b7df5de777af397fbf339`。私钥保留本机signing目录，不包含在交付ZIP中；这不是应用商店发布包。

## 实现与使用

拓展任务2完成纯Java严格JSON／UTF-8／整数／完整音符生命周期／稳定同tick顺序校验，冻结v2编码和客户端；任务3完成原生中文UI、系统文件选择器、运行时权限、真实串行BluetoothGatt、严格有界通知拆帧与前后台取消；任务4以原PC实现为黄金源做独立跨语言正负验收和只读增量审查。总控负责工程配置、构建、集成修复协调、签名、身份核对和交付，自身子智能体只读自审。未启用外部审核员制度。

先选文件或内置样例，再扫描并确认自己的`Pro-Score-XXXXXX`、连接。“上传并全量核对（先STOP）”等待STOP/ABORT后上传；COMMIT不自动播放，必须全READ逐字节核同才显示上传成功。START再次核同；STOP无需选文件。手机取消或离开前台会关闭连接，只表示取消等待，不能表示FPGA已停；返回后显式连接并STOP恢复。SAF选择器也会使应用离开前台，建议先选曲再连接。

手机接受最多256KiB的预转换JSON，1..512个原始事件，音符36..84，tick≤16777215，48k名义时基；不解析MIDI。原四声部音频和八显示槽不变；实际BLE吞吐与最大曲谱能否在180秒内完成仍需实测。每次操作新session，ACK2秒、最多2次相同接收超时重发；发送失败／部分GATT写失败不重发，NACK立即失败。20B响应写逐片等待，服务／6B版本状态／CCCD实际完成后才ready。

## 实际验证

| 验证 | 实际结果与原件 |
| --- | --- |
| 核心JDK编译及软件自检 | 20场景、9881断言通过；evidence/task2/RUN_02、API_CHECK及RECEIPT.json |
| 独立PC黄金对Java黑盒 | 95例通过，含512事件完整流程和错误注入；evidence/task4/RUN_001 |
| 固定协议字节与负形状 | 42例通过；RUN_001/codec_vectors_01 |
| GATT与拆帧host替身 | 修复后236项通过，API26/35分支与真实Java产品代码；evidence/task3/TRANSPORT_05_LINT_REPAIR |
| 完整APK构建及lint | BUILD_R04的assembleRelease＋lintRelease实际退出0，0 errors、2 warnings |
| APK签名 | BUILD_R04/verify_apk_signature原生退出0，v2签名有效 |
| APK清单与系统图标 | METADATA_REVIEW_R01原生xmltree及SDK常量核对退出0，绑定同一APK与构建输入 |
| 最终UI/BLE增量只读审查 | task4/ui_review/FINAL_004，12份app源码/资源/样例加app配置，未发现具体阻断，SHA已绑定 |

Model/host替身不是实际Android蓝牙栈，不替代手机权限、SAF、旋转和系统栏布局运行验证。没有声称像素／CDC／FPGA新上板／完整C9通过。原185份baseline、633份拓展封存及51份上机准备材料的最终只读身份核验均通过。

## 工具、执行与失败原件

固定现有JDK17.0.20.1、Gradle8.9、AGP8.7.3、Android SDK35 revision2、Build Tools34.0.0。真实构建命令为本机Python加`-B -X utf8 build_android.py --offline --output <全新evidence目录>`；内层Gradle完整argv、cwd、每阶段UTC时间、退出码、SDK/JDK/源码/产物SHA在对应receipt中。各成员完整命令与入口参数在其HANDOFF和原始收据中，均随源码包保留。

- 旧审批暂停：用户在任务2/3直接撤销此前“先不改”限制后恢复，没有换入口绕过；历史原件保留。
- 核心首测：测试将不同READ索引误当重放；仅修测试，RUN_01保留，RUN_02通过，核心未变。
- GATT产品缺陷：迟到回调越过截止，确定性负例复现后修复，重新验证236项通过；同时保留host测试线程未退出及早轮stderr未捕获的限制，不补造原日志。
- 独立验收驱动字段名错误、封存时源码变化拒收：全部原件保留，按新依据修复/增量复核，不把工具失败写成产品失败。
- BUILD_R01：Java Unix-domain临时Socket EINVAL；原生daemon堆栈保存在environment_diagnosis。按[官方JDK临时目录属性](https://docs.oracle.com/en/java/javase/17/core/java-networking.html)仅为子进程设置短socket目录后，R02进入Gradle配置成功；未改全局系统设置。
- BUILD_R02：离线缓存缺3项固定AGP依赖；R03从既定官方仓库补齐，不更换版本。
- BUILD_R03：APK打包成功，lint4 errors。最小修复为API27版本化样式、两个API33 SUCCESS常量和legacy COARSE/FINE权限，保留完整失败报告；R04 lint退出0。
- BUILD_R04：Gradle、lint、签名均退出0；旧aapt badging在解析`@android:drawable/ic_media_play`时退出1，原FAIL不改写。METADATA_REVIEW_R01直接解析同一APK编译清单，再将0x01080024核对为实际SDK常量，补齐包名、版本、权限、启动入口及图标身份；它没有重新构建或重新签名。

两条lint warning有据保留：neverForLocation在旧API被忽略，由legacy定位分支覆盖；DataExtractionRules为备份迁移建议，应用allowBackup=false且不持久复制导入曲谱或连接状态，真实OEM迁移行为未测。没有禁用lint错误、抬高最低版本或引入baseline隐藏问题。

## 未验项与后续

真实安卓安装、权限对话框、SAF、布局／旋转、真实扫描／GATT／吞吐、ESP UART、FPGA收谱／声音／双滑块联动仍NOT_RUN。ESP需配套桥接固件，FPGA需此前拓展码流；本APK不改两边镜像，也不替它们烧录。硬件接线与供电沿用`../hardware_bringup_r01/README.md`。

源与证据全部本地保存，basic为独立备份，本轮无Git提交／推送、无外部发布／SMTP、无M2收件或准入代签。软件交付完成不恢复旧设备许可。用户接线并核当轮设备准入后，再分阶段验证真实链路。
