"""Package a successful Android build and evidence, never install it."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
from build_android import capture_build_inputs


HERE = Path(__file__).resolve().parent


def identity(path):
    return {'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-receipt', required=True, type=Path)
    parser.add_argument('--name', default='R01')
    args = parser.parse_args()
    if not args.name.isalnum():
        raise ValueError('Alphanumeric delivery name required')
    receipt = json.loads(args.build_receipt.read_text(encoding='utf-8'))
    if receipt['status'] != 'PASS_APK_BUILD_LINT_AND_SIGNATURE_ONLY':
        raise ValueError('Requires actual successful build/lint/signature receipt')
    if capture_build_inputs() != receipt['build_input_identities']:
        raise ValueError('Built input set or identity changed')
    apk = Path(receipt['apk']['path'])
    if identity(apk) != {key: receipt['apk'][key] for key in ('bytes', 'sha256')}:
        raise ValueError('Built APK identity mismatch')
    out = HERE / 'delivery' / args.name
    archive_path = out.with_suffix('.zip')
    if out.exists() or archive_path.exists():
        raise FileExistsError('Preserve previous delivery')
    sources = []
    excluded = {'.gradle', 'build', 'delivery', 'signing', '__pycache__'}
    for path in sorted(HERE.rglob('*')):
        relative = path.relative_to(HERE)
        if path.is_file() and not any(part in excluded for part in relative.parts):
            if path.name != 'local.properties':
                sources.append((relative, path))
    out.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(apk, out / 'ProScoreAndroid-r01.apk')
    expected_apk = {key: receipt['apk'][key] for key in ('bytes', 'sha256')}
    if identity(out / 'ProScoreAndroid-r01.apk') != expected_apk:
        raise ValueError('Copied APK differs from successful build receipt')
    shutil.copyfile(HERE / 'README.md', out / 'README.md')
    shutil.copyfile(HERE / 'app/src/main/assets/sample.score.json', out / 'sample.score.json')
    for relative, source in sources:
        destination = out / 'source' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        if identity(destination) != identity(source):
            raise ValueError('Copied identity mismatch: ' + str(relative))
    for relative, expected in receipt['build_input_identities'].items():
        if relative == 'local.properties':
            continue
        if identity(out / 'source' / relative) != expected:
            raise ValueError('Delivered source differs from built input: ' + relative)
    if capture_build_inputs() != receipt['build_input_identities']:
        raise ValueError('Build input set or identity changed while packaging')
    files = {path.relative_to(out).as_posix(): identity(path)
             for path in sorted(out.rglob('*')) if path.is_file()}
    manifest = {
        'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'status': 'ANDROID_SOFTWARE_DELIVERY_ONLY',
        'build_receipt': str(args.build_receipt.resolve()),
        'build_receipt_identity': identity(args.build_receipt),
        'apk_signing': 'Local development certificate; private key excluded',
        'device_operations': False, 'phone_install_test': 'NOT_RUN',
        'real_ble_uart_board_validation': 'NOT_RUN',
        'board_release_allowed': False,
        'excluded_from_source': sorted(excluded | {'local.properties'}),
        'files': files,
    }
    manifest_path = out / 'MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    for relative, expected in files.items():
        if identity(out / relative) != expected:
            raise ValueError('Readback mismatch: ' + relative)
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(out.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(out).as_posix())
    with zipfile.ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC mismatch')
        for name in archive.namelist():
            if hashlib.sha256(archive.read(name)).hexdigest() != identity(out / name)['sha256']:
                raise ValueError('Archive SHA mismatch: ' + name)
    print(json.dumps({'status': 'PASS_PACKAGE_READBACK', 'files': len(files),
                      'directory': str(out), 'apk': identity(out / 'ProScoreAndroid-r01.apk'),
                      'archive': str(archive_path), 'archive_identity': identity(archive_path),
                      'manifest_identity': identity(manifest_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
