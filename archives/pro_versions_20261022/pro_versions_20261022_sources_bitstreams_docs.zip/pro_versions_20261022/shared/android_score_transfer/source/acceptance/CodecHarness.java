package com.proscore.acceptance;

import com.proscore.core.Protocol;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Runs fixed PC byte vectors against only the public Java codec. */
public final class CodecHarness {
    private static byte[] unhex(String text) {
        byte[] data = new byte[text.length()/2];
        for (int i=0;i<data.length;i++) data[i]=(byte)Integer.parseInt(text.substring(i*2,i*2+2),16);
        return data;
    }
    private static String hex(byte[] data) {
        StringBuilder text=new StringBuilder();
        for (byte value:data) text.append(String.format("%02x",value&255));
        return text.toString();
    }
    public static void main(String[] args) throws Exception {
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8));
        String line;
        while ((line=input.readLine())!=null) {
            String[] fields=line.split(" ");
            byte[] raw=unhex(fields[1]);
            Protocol.Frame request=Protocol.decode(raw);
            if (!Arrays.equals(raw,request.encode())) throw new AssertionError("request byte roundtrip");
            try {
                byte[] reply=unhex(fields[2]);
                Protocol.Response r=Protocol.validateResponse(reply,request);
                if (!Arrays.equals(reply,Protocol.decode(reply).encode())) throw new AssertionError("response byte roundtrip");
                System.out.println(fields[0]+" ACK "+r.originalCommand+","+r.error+","+r.committed+","+
                    r.uploadActive+","+r.count+","+r.scoreId+","+r.received+" "+hex(r.getEvent()));
            } catch (Protocol.NackException error) {
                System.out.println(fields[0]+" NACK "+error.getErrorCode());
            } catch (IllegalArgumentException error) {
                System.out.println(fields[0]+" INVALID");
            }
        }
    }
}
