"""Seal actual task4 evidence, checking that tested/reviewed sources still match."""
from datetime import datetime, timezone
from pathlib import Path
import ast
import hashlib
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    ui_path = Path(sys.argv[1]).resolve()
    core_path = ROOT/'evidence/task4/RUN_001/receipt.json'
    codec_path = ROOT/'evidence/task4/RUN_001/codec_vectors_01/receipt.json'
    core = json.loads(core_path.read_text(encoding='utf-8'))
    codec = json.loads(codec_path.read_text(encoding='utf-8'))
    ui = json.loads(ui_path.read_text(encoding='utf-8'))
    assert core['status'] == 'PASS' and len(core['tests']) == 95
    assert codec['status'] == 'PASS' and codec['tests'] == 42
    # An unchanged tested core does not require repeating its passing group.
    checked = []
    for item in core['sources']+core['dependencies']+codec['inputs']+ui['sources']:
        source = Path(item['path'])
        if not source.is_absolute():
            source = ROOT/source
        assert sha(source) == item['sha256'], 'source changed: '+str(source)
        if item.get('snapshot'):
            snapshot = Path(item['snapshot'])
            if not snapshot.is_absolute():
                snapshot = ROOT/snapshot
            assert sha(snapshot) == item['sha256'], 'snapshot changed: '+str(snapshot)
        checked.append(identity(source))
    expected_app = {item['path'] for item in ui['sources'] if item['path'].startswith('app/src/main/')}
    current_app = {path.relative_to(ROOT).as_posix() for path in (ROOT/'app/src/main').rglob('*') if path.is_file()}
    assert expected_app == current_app, 'app source/resource inventory changed'
    assert not ui['findings'], 'UI/BLE has unresolved findings'
    assert not ui.get('not_yet_reviewed', []), 'UI/BLE review incomplete'
    assert 'PENDING' not in ui['status'], 'UI/BLE review pending'
    syntax = []
    for path in (ROOT/'acceptance').rglob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
        syntax.append(identity(path))
    artifacts = sorted(path for folder in [ROOT/'acceptance', ROOT/'evidence/task4']
                       for path in folder.rglob('*')
                       if path.is_file() and path != ROOT/'evidence/task4/receipt.json')
    artifacts.append(ROOT/'HANDOFF_TASK4.md')
    receipt = dict(status='SOFTWARE_MOCK_PASS_AND_READONLY_UI_REVIEW_NO_BLOCKERS',
        created_utc=datetime.now(timezone.utc).isoformat(),
        Java_public_API_cases=95, Java_fixed_codec_cases=42,
        core_receipt=identity(core_path), codec_receipt=identity(codec_path),
        ui_review_receipt=identity(ui_path), ui_status=ui['status'],
        full_app_source_resource_inventory=sorted(current_app),
        full_app_source_resource_binding=True, core_tests_reexecuted_at_final_seal=False,
        checked_current_sources=checked, Python_syntax_checked=syntax,
        actual_commands=[dict(command=['C:/Users/songdongkuan/miniconda3/python.exe','-X','utf8','-B',
            str(ROOT/'acceptance/run_acceptance.py')], observed_exit_code=0),
            dict(command=['C:/Users/songdongkuan/miniconda3/python.exe','-X','utf8','-B',
            str(ROOT/'acceptance/run_codec_vectors.py'),str(core_path.parent)],observed_exit_code=0)],
        artifacts=[identity(path) for path in artifacts],
        preparation_original='evidence/task4/preparation/HANDOFF_NOT_STARTED.md',
        preserved_driver_failure='evidence/task4/RUN_001/codec_vectors/FAILURE.json',
        preserved_source_drift=['evidence/task4/SEAL_001_FAILURE.json',
                                'evidence/task4/UI_REFRESH_001_FAILURE.json',
                                'evidence/task4/SEAL_002_FAILURE.json',
                                'evidence/task4/ui_review/FINAL_001/FREEZE_001_failure.log'],
        preserved_wait_record='evidence/task4/WAITING_STABLE_001.json',
        APK_build_or_lint_by_task4=False, phone_install_test='NOT_RUN',
        real_BLE_or_hardware='NOT_RUN', device_operations=False,
        old_test_groups_executed=False, Git_operations=False,
        limitations=['Mock transport cannot validate Android scheduling or BLE throughput',
                     'UI/BLE review is static and bound to recorded source SHA',
                     '180-second total deadline not tested by elapsed wall time',
                     'APK integration, signing and actual hardware verification belong to coordinator'])
    output = ROOT/'evidence/task4/receipt.json'
    output.write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(receipt['status'], str(output))


if __name__ == '__main__':
    main()
