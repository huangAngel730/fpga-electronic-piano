# 任务4独立验收入口

当前状态：任务4限定范围完成。核心RUN_001的95例黑盒及codec_vectors_01的42例固定字节验收PASS；稳定版UI/GATT最终增量只读审查未发现具体阻断，FINAL_004绑定全部12份app/src/main文件及app/build.gradle，共13份原字节与SHA。核心未变，最终收口未重跑137例。最终汇总evidence/task4/receipt.json。NOT_STARTED、PARTIAL等待、源码变化拒绝及不完整FINAL_002原件均保留；不代签手机/BLE或板卡实测。

只检查本验收准备材料：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/android_score_transfer_r01/acceptance/prepare_check.py'
```

该入口对本次新向量重新分类，调用原PC客户端对独立Peer运行65组工作流，保存全帧、实际子进程命令、退出码、stdout/stderr与输入前后SHA；不编译Java，不运行旧测试组，不接触设备。

待任务2/3有效授权恢复并交付精确源码后，由总控安排执行：

```powershell
& 'C:/Users/songdongkuan/miniconda3/python.exe' -X utf8 -B 'E:/FPGA/GAOYUNFPGA/extra _life/basic/project/android_score_transfer_r01/acceptance/run_acceptance.py'
```

后一个入口已运行一次退出0。缺Score.java或ScoreClient.java时打印NOT_STARTED并退出2，不创建虚假的Java验收结果。其使用JDK17编译核心快照和Harness.java，仅通过Score/ScoreClient公共API驱动假Transport。每例保存stdout/stderr、发收帧、超时、退出码和语义判定，Harness业务错误不能靠进程exit0冒充成功。核心文件或依赖输入在运行中改变会导致最终FAIL。

已执行95例：68例曲谱解析、26例基本工作流及错误注入、1例512事件完整上传/回读/START重核/STOP。涵盖上传不自动START、STOP无文件、取消、完整帧ACK有限重试、异identity响应、NACK、畸形ACK、CRC、断线、部分写、回读错误、发布身份改变、START重新核同。随机session不按固定值比较；每帧经原PC编解码核验，命令/offset/payload顺序与原PC客户端比对，重复请求必须字节完全相同。

固定字节向量另含13组请求/ACK、15例NACK和14例畸形响应，已用CodecHarness.java对同一个已验核心快照的Protocol公共API执行42例并全部通过。命令：上述Python可执行程序加-X utf8 -B，再传acceptance/run_codec_vectors.py绝对路径及evidence/task4/RUN_001绝对路径。首次驱动字段名错误发生在Java启动前，原件保存在RUN_001/codec_vectors/FAILURE.json；修正版运行于codec_vectors_01，不覆盖历史。180秒总事务截止尚无实耗反例；实际BLE调度/吞吐/Android生命周期需源码审查及后续手机实测。

仅写acceptance、evidence/task4和HANDOFF_TASK4.md；不代实现缺失核心/UI。当前没有APK、手机安装、BLE扫描连接、FPGA下载或实测结论。
