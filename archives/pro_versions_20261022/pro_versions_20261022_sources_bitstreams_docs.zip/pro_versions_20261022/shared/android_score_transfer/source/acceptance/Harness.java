package com.proscore.acceptance;

import com.proscore.core.Score;
import com.proscore.core.ScoreClient;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.concurrent.TimeoutException;

/** A black-box, standard-input fake Transport. It uses only the public API. */
public final class Harness {
    private static final BufferedReader INPUT = new BufferedReader(
            new InputStreamReader(System.in, StandardCharsets.UTF_8));

    private static void emit(String value) {
        System.out.println(value);
        System.out.flush();
    }

    private static String hex(byte[] data) {
        StringBuilder result = new StringBuilder(data.length * 2);
        for (byte value : data) result.append(String.format("%02x", value & 255));
        return result.toString();
    }

    private static byte[] unhex(String value) throws IOException {
        if ((value.length() & 1) != 0) throw new IOException("odd harness hex");
        byte[] result = new byte[value.length() / 2];
        for (int i = 0; i < result.length; i++) {
            int high = Character.digit(value.charAt(2 * i), 16);
            int low = Character.digit(value.charAt(2 * i + 1), 16);
            if (high < 0 || low < 0) throw new IOException("bad harness hex");
            result[i] = (byte) ((high << 4) | low);
        }
        return result;
    }

    private static String instruction() throws IOException {
        String line = INPUT.readLine();
        if (line == null) throw new IOException("independent peer closed");
        return line;
    }

    private static final class FakeTransport implements ScoreClient.Transport {
        ScoreClient client;

        public void send(byte[] frame, long timeoutMillis) throws Exception {
            emit("SEND " + hex(frame) + " " + timeoutMillis);
            String action = instruction();
            if (action.equals("SENT")) return;
            if (action.equals("CANCEL_SENT")) {
                client.cancel();
                return;
            }
            if (action.equals("PARTIAL_WRITE")) {
                throw new IOException("GATT partial write after first 20 bytes; stream state unknown");
            }
            if (action.equals("SEND_ERROR")) throw new IOException("GATT send failure");
            throw new IOException("invalid harness send action " + action);
        }

        public byte[] receive(long timeoutMillis) throws Exception {
            emit("RECEIVE " + timeoutMillis);
            String action = instruction();
            if (action.startsWith("FRAME ")) return unhex(action.substring(6));
            if (action.startsWith("CANCEL_FRAME ")) {
                client.cancel();
                return unhex(action.substring(13));
            }
            if (action.equals("ACK_TIMEOUT")) {
                // Honor the requested relative timeout instead of a tight mock loop.
                Thread.sleep(Math.max(1L, timeoutMillis));
                throw new TimeoutException("independent peer ACK timeout");
            }
            if (action.equals("STREAM_ERROR")) throw new IOException("corrupt BLE response stream");
            if (action.equals("DISCONNECTED")) throw new IOException("BLE disconnected; state unknown");
            throw new IOException("invalid harness receive action " + action);
        }
    }

    private static ScoreClient client(FakeTransport transport, String phase) {
        ScoreClient result = new ScoreClient(transport, (name, done, total) ->
                emit("PROGRESS " + phase + " " + done + " " + total + " " +
                        Base64.getEncoder().encodeToString(name.getBytes(StandardCharsets.UTF_8))));
        transport.client = result;
        return result;
    }

    public static void main(String[] args) {
        try {
            String mode = args[0];
            if (mode.equals("parse")) {
                Score score = Score.parseUtf8(Files.readAllBytes(Paths.get(args[1])));
                byte[] first = score.getRecords();
                byte[] second = score.getRecords();
                boolean clone = first != second;
                if (first.length > 0) first[0] ^= 0x7f;
                clone &= java.util.Arrays.equals(second, score.getRecords());
                emit("SCORE " + score.getScoreId() + " " + score.getCount() + " " +
                        hex(second) + " " + clone);
                emit("END OK");
                return;
            }
            FakeTransport transport = new FakeTransport();
            Score score = mode.equals("stop") ? null :
                    Score.parseUtf8(Files.readAllBytes(Paths.get(args[1])));
            boolean stopFirst = args.length > 2 && Boolean.parseBoolean(args[2]);
            if (mode.equals("flow")) {
                emit("OP upload");
                client(transport, "upload").upload(score, stopFirst);
                emit("OP start");
                client(transport, "start").start(score);
                emit("OP stop");
                client(transport, "stop").stop();
            } else {
                emit("OP " + mode);
                ScoreClient instance = client(transport, mode);
                if (mode.equals("cancel_before")) {
                    instance.cancel();
                    instance.upload(score, stopFirst);
                } else if (mode.equals("upload")) instance.upload(score, stopFirst);
                else if (mode.equals("start")) instance.start(score);
                else if (mode.equals("stop")) instance.stop();
                else throw new IllegalArgumentException("unknown harness mode");
            }
            emit("END OK");
        } catch (Exception error) {
            String message = String.valueOf(error.getMessage());
            emit("END ERROR " + error.getClass().getName() + " " +
                    Base64.getEncoder().encodeToString(message.getBytes(StandardCharsets.UTF_8)));
        }
    }
}
