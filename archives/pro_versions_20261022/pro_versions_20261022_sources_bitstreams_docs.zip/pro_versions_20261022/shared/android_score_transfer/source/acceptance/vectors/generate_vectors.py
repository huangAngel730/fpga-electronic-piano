"""Generate new Android acceptance vectors from the frozen PC functions.

Normal invocation captures a fresh child command's exact stdout/stderr/exit.
The worker calls only original PC codec/score functions, never old test groups.
All writes stay in acceptance/vectors and evidence/task4/golden.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'acceptance/vectors'
EVIDENCE = ROOT / 'evidence/task4/golden'
PC = ROOT.parent / 'software/pc'


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load_original(name):
    spec = importlib.util.spec_from_file_location(name, PC / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def score_document(events=None, sid=0x12345678):
    if events is None:
        events = [event(0, 'note_on', 0, 60, 100), event(100, 'note_off', 0, 60, 0)]
    return {'schema': 1, 'sample_hz': 48000, 'score_id': sid, 'events': events}


def event(tick, kind='note_on', channel=0, note=60, velocity=100):
    return {'tick': tick, 'type': kind, 'channel': channel, 'note': note, 'velocity': velocity}


def encoded_json(document):
    return (json.dumps(document, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf8')


def write_json(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')


def worker(run):
    before = [identity(PC / (name + '.py')) for name in ['protocol', 'score', 'client']]
    protocol = load_original('protocol')
    score = load_original('score')
    client = load_original('client')
    manifest, details, produced = [], [], []

    def add(case_id, document, valid=False, android_only=False, reason=None):
        blob = document if isinstance(document, bytes) else encoded_json(document)
        score_path = OUT / 'scores' / (case_id + '.json')
        score_path.parent.mkdir(parents=True, exist_ok=True)
        score_path.write_bytes(blob)
        produced.append(score_path)
        decoded = None
        pc_error = None
        sid = None
        records = None
        try:
            decoded = json.loads(blob.decode('utf8'), object_pairs_hook=score.unique_object)
            sid, records = score.encode_score(decoded)
        except (ValueError, TypeError, KeyError, UnicodeError) as exc:
            pc_error = type(exc).__name__ + ': ' + str(exc)
        if valid or android_only:
            assert pc_error is None, (case_id, pc_error)
            # This is the original PC decode/encode round-trip, including v0
            # NoteOn normalization; do not reimplement packing in this script.
            assert score.encode_score(score.decode_records(sid, records)) == (sid, records)
        else:
            assert pc_error is not None, (case_id, 'PC unexpectedly accepted')
        android_error = None
        if pc_error is None:
            if any(not 36 <= row['note'] <= 84 for row in decoded['events']):
                android_error = 'ANDROID_PRODUCTION_NOTE_36_84_PC_ACCEPTS'
            elif any(row['tick'] > 16777215 for row in decoded['events']):
                android_error = 'ANDROID_PRODUCTION_TICK_MAX_16777215_PC_ACCEPTS'
        assert valid == (pc_error is None and android_error is None), case_id
        assert android_only == (pc_error is None and android_error is not None), case_id
        row = {'id': case_id, 'score_file': score_path.relative_to(ROOT).as_posix(),
               'valid': valid, 'score_id': sid,
               'count': len(records) // 8 if records is not None else None,
               'reason': reason or android_error or pc_error or 'PC_GOLDEN_AND_ANDROID_PRODUCTION_VALID'}
        if valid:
            records_path = OUT / 'records' / (case_id + '.bin')
            records_path.parent.mkdir(parents=True, exist_ok=True)
            records_path.write_bytes(records)
            produced.append(records_path)
            row['records_file'] = records_path.relative_to(ROOT).as_posix()
        manifest.append(row)
        details.append({'id': case_id, 'pc_accepts': pc_error is None,
                        'pc_error': pc_error, 'android_only_error': android_error,
                        'score_sha256': hashlib.sha256(blob).hexdigest(),
                        'records_sha256': hashlib.sha256(records).hexdigest() if records is not None else None})
        return records

    add('valid_basic', score_document(), True)
    add('valid_sid_zero', score_document(sid=0), True)
    add('valid_sid_u32_high_bit', score_document(sid=0x80000000), True)
    unsigned_records = add('valid_sid_u32_max', score_document(sid=0xffffffff), True)
    add('valid_same_tick_stable_off_then_on', score_document([
        event(0), event(10, 'note_off', velocity=0), event(10, velocity=111),
        event(11, 'note_off', velocity=0)]), True)
    zero_records = add('valid_v0_note_on_canonical_off', score_document([
        event(0, velocity=127), event(1, velocity=0)]), True,
        reason='PC_NORMALIZES_ACTIVE_NOTE_ON_V0_TO_RAW_KIND1_OFF')
    assert zero_records[12] == 1, 'raw second record kind must be off'
    add('valid_release_velocity127', score_document([
        event(0), event(1, 'note_off', velocity=127)]), True)
    add('valid_note36_84_channel0_15', score_document([
        event(0, channel=15, note=84, velocity=1), event(0, channel=0, note=36, velocity=127),
        event(1, 'note_off', 15, 84, 0), event(1, 'note_off', 0, 36, 0)]), True)
    add('valid_max_tick16777215', score_document([
        event(16777215, note=84), event(16777215, 'note_off', note=84, velocity=0)]), True)
    maximum = []
    for i in range(256):
        maximum += [event(i * 2, channel=i % 16, note=36 + i % 49, velocity=1 + i % 127),
                    event(i * 2 + 1, 'note_off', i % 16, 36 + i % 49, 0)]
    add('valid_capacity512', score_document(maximum, sid=0xdeadbeef), True)
    escaped = encoded_json(score_document()).replace(b'"score_id"', b'"score\\u005fid"').replace(
        b'"note_on"', b'"\\u006eote_on"')
    add('valid_json_escaped_names', escaped, True)
    add('valid_json_whitespace', b' \t\r\n' + encoded_json(score_document()) + b'\t\r\n ', True)
    add('valid_json_negative_zero_integer', encoded_json(score_document(sid=0)).replace(
        b'"score_id":0', b'"score_id":-0'), True)

    base = encoded_json(score_document())
    add('invalid_duplicate_root', base.replace(b'"score_id":305419896', b'"score_id":1,"score_id":305419896'))
    add('invalid_duplicate_root_escaped', base.replace(b'"score_id":305419896',
        b'"score_id":1,"score\\u005fid":305419896'))
    add('invalid_duplicate_event', base.replace(b'"tick":0', b'"tick":0,"tick":0', 1))
    add('invalid_duplicate_event_escaped', base.replace(b'"tick":0', b'"tick":0,"ti\\u0063k":0', 1))
    for name, key, event_field in [('root_extra', 'extra', False), ('event_extra', 'extra', True),
                                    ('root_missing', 'sample_hz', False), ('event_missing', 'velocity', True)]:
        document = score_document()
        target = document['events'][0] if event_field else document
        if name.endswith('extra'):
            target[key] = 1
        else:
            del target[key]
        add('invalid_' + name, document)
    for scalar_name, scalar in [('float', 1.0), ('bool', True)]:
        for key in ['schema', 'sample_hz', 'score_id', 'tick', 'channel', 'note', 'velocity']:
            document = score_document()
            target = document if key in ['schema', 'sample_hz', 'score_id'] else document['events'][0]
            target[key] = scalar
            add('invalid_' + scalar_name + '_' + key, document)
    add('invalid_exponent_integer_value', base.replace(b'"schema":1', b'"schema":1e0'))
    add('invalid_json_nan', base.replace(b'"score_id":305419896', b'"score_id":NaN'))
    add('invalid_json_infinity', base.replace(b'"score_id":305419896', b'"score_id":Infinity'))
    add('invalid_json_utf8_bom', b'\xef\xbb\xbf' + base)
    add('invalid_utf8_ff', base.replace(b'"note_on"', b'"\xff"'))
    add('invalid_utf8_overlong', base.replace(b'"note_on"', b'"\xc0\xaf"'))
    add('invalid_utf8_surrogate', base.replace(b'"note_on"', b'"\xed\xa0\x80"'))
    add('invalid_json_trailing', base + b'{}')
    add('invalid_json_leading_zero', base.replace(b'"schema":1', b'"schema":01'))
    add('invalid_json_root_array', b'[]')
    add('invalid_json_root_null', b'null')
    for case_id, events in [
        ('overlap_on', [event(0), event(1), event(2, 'note_off', velocity=0)]),
        ('unmatched_off', [event(0, 'note_off', velocity=0)]),
        ('unfinished', [event(0)]),
        ('v0_without_active', [event(0, velocity=0)]),
        ('unordered_tick', [event(2), event(1, 'note_off', velocity=0)]),
        ('unknown_type', [event(0, 'note_maybe'), event(1, 'note_off', velocity=0)]),
        ('capacity0', []), ('capacity513', maximum + [event(512)])]:
        add('invalid_' + case_id, score_document(events))
    for key, values in [('score_id', [-1, 4294967296]), ('channel', [-1, 16]),
                        ('velocity', [-1, 128]), ('note', [-1, 128]), ('tick', [-1, 4294967296])]:
        for value in values:
            document = score_document()
            target = document if key == 'score_id' else document['events'][0]
            target[key] = value
            add('invalid_' + key + '_' + str(value).replace('-', 'minus'), document)
    for note in [35, 85]:
        add('android_only_note' + str(note), score_document([
            event(0, note=note), event(1, 'note_off', note=note, velocity=0)]), android_only=True)
    add('android_only_tick16777216', score_document([
        event(16777216), event(16777216, 'note_off', velocity=0)]), android_only=True)
    # The old PC allows larger u32 ticks and notes0..127. These cases must not
    # be mislabeled as old-PC rejections merely because Android narrows scope.
    add('android_only_tick_u32max', score_document([
        event(4294967295), event(4294967295, 'note_off', velocity=0)]), android_only=True)

    manifest_path = OUT / 'manifest.json'
    write_json(manifest_path, manifest)
    produced.append(manifest_path)
    wire_path = OUT / 'wire/golden_frames.json'
    wire = make_wire_vectors(protocol, client, unsigned_records)
    write_json(wire_path, wire)
    produced.append(wire_path)
    after = [identity(PC / (name + '.py')) for name in ['protocol', 'score', 'client']]
    assert before == after, 'PC source identity changed'
    summary = {'status': 'PASS', 'score_cases': len(manifest),
               'valid': sum(x['valid'] for x in manifest),
               'pc_negative': sum(x['pc_error'] is not None for x in details),
               'android_only_negative': sum(x['android_only_error'] is not None for x in details),
               'wire_positive': len(wire['requests_and_ack']),
               'wire_nack': len(wire['nack']), 'wire_negative': len(wire['invalid_responses']),
               'pc_sources_before': before, 'pc_sources_after': after,
               'generator': identity(Path(__file__)), 'outputs': [identity(p) for p in produced],
               'score_expectations': details,
               'scope': 'New vector generation only; original PC tests, Java, APK, BLE and hardware not executed'}
    write_json(run / 'GENERATION.json', summary)
    print(json.dumps({key: summary[key] for key in ['status', 'score_cases', 'valid', 'pc_negative',
        'android_only_negative', 'wire_positive', 'wire_nack', 'wire_negative']}))


def make_wire_vectors(p, client, records):
    sid, count, session = 0xffffffff, len(records) // 8, 0x2345
    c = client.ScoreClient(None, session=session)
    identity_payload = client.ScoreClient.identity_payload(sid, count)
    requests = [p.Frame(p.BEGIN, session, 0, payload=struct.pack('<IHHHI', sid, count,
                    len(records), p.crc(records), 48000)),
                p.Frame(p.DATA, session, 1, 0, records), p.Frame(p.COMMIT, session, 2)]
    for command in [p.ABORT, p.STATUS, p.READ, p.START, p.STOP, p.CLEAR, p.READ_BEGIN, p.READ_END]:
        requests.append(c.request(command, payload=identity_payload if command in [p.START, p.READ_BEGIN] else b''))
    requests.append(p.Frame(p.READ, session, 65535, 1))
    requests.append(p.Frame(p.STATUS, 65535, 65535))
    positives = []
    for request in requests:
        response = p.response(request, 0, committed=True,
                              active=request.command in [p.BEGIN, p.DATA], count=count,
                              score_id=sid, received=len(records),
                              event=records[request.offset * 8:request.offset * 8 + 8]
                              if request.command == p.READ else None)
        metadata, event_bytes = p.validate_response(response, request)
        assert p.decode(request.encode()) == request
        positives.append({'id': 'wire_cmd%02d_seq%05d_offset%05d' % (request.command, request.seq, request.offset),
                          'request_hex': request.encode().hex(), 'ack_hex': response.hex(),
                          'command': request.command, 'session': request.session,
                          'seq': request.seq, 'offset': request.offset,
                          'metadata': list(metadata), 'read_event_hex': event_bytes.hex()})
    status_request = c.request(p.STATUS)
    nack = []
    for error in range(1, 16):
        response = p.response(status_request, error, committed=True, count=count, score_id=sid)
        try:
            p.validate_response(response, status_request)
            raise AssertionError('NACK unexpectedly accepted')
        except p.NackError as exc:
            assert exc.code == error
        nack.append({'id': 'nack_%02d' % error, 'request_hex': status_request.encode().hex(),
                     'response_hex': response.hex(), 'error_code': error})
    read_request = c.request(p.READ)
    ack = p.response(status_request, 0, committed=True, count=count, score_id=sid)
    meta = p.decode(ack).payload
    negative = []

    def bad(name, request, response):
        try:
            p.validate_response(response, request)
        except (ValueError, TypeError) as exc:
            negative.append({'id': name, 'request_hex': request.encode().hex(),
                             'response_hex': response.hex(), 'reason': type(exc).__name__ + ': ' + str(exc)})
        else:
            raise AssertionError('invalid response accepted: ' + name)

    bad('bad_crc', status_request, ack[:-1] + bytes([ack[-1] ^ 1]))
    bad('bad_magic', status_request, b'\0\0' + ack[2:])
    bad('truncated', status_request, ack[:-1])
    bad('trailing', status_request, ack + b'\0')
    old_body = bytes([1]) + ack[3:-2]
    bad('old_version1_crc_valid', status_request, p.MAGIC + old_body + struct.pack('<H', p.crc(old_body)))
    bad('read_ack12', read_request, p.response(read_request, 0))
    bad('nonread_ack20', status_request, p.Frame(p.ACK, status_request.session, status_request.seq,
        status_request.offset, meta + records[:8]).encode())
    for name, response in [
        ('ack_nonzero_error', p.Frame(p.ACK, status_request.session, status_request.seq, 0,
            p.META.pack(p.STATUS, 3, 1, 0, count, sid, 0)).encode()),
        ('nack_zero_error', p.Frame(p.NACK, status_request.session, status_request.seq, 0,
            p.META.pack(p.STATUS, 0, 1, 0, count, sid, 0)).encode()),
        ('unknown_error16', p.response(status_request, 16)),
        ('metadata_count513', p.response(status_request, 0, count=513)),
        ('metadata_flag2', p.response(status_request, 0, committed=2)),
        ('wrong_seq', p.Frame(p.ACK, status_request.session, status_request.seq + 1, 0, meta).encode()),
        ('wrong_response_command', p.Frame(p.ACK, status_request.session, status_request.seq, 0,
            p.META.pack(p.STOP, 0, 1, 0, count, sid, 0)).encode())]:
        bad(name, status_request, response)
    return {'basis': 'Original PC Frame/response/validate_response and ScoreClient request/identity_payload; codec-level byte goldens, not a stateful FPGA acceptance claim',
            'requests_and_ack': positives, 'nack': nack, 'invalid_responses': negative}


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        run = Path(sys.argv[2]).resolve()
        if not run.is_relative_to(EVIDENCE.resolve()):
            raise ValueError('worker evidence path outside owned golden directory')
        worker(run)
        return 0
    if len(sys.argv) != 1:
        raise ValueError('no user arguments supported')
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    number = 1
    while (EVIDENCE / ('RUN_%02d' % number)).exists():
        number += 1
    run = EVIDENCE / ('RUN_%02d' % number)
    run.mkdir()
    command = [sys.executable, '-X', 'utf8', '-B', str(Path(__file__).resolve()), '--worker', str(run)]
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (run / 'stdout.txt').write_bytes(result.stdout)
    (run / 'stderr.txt').write_bytes(result.stderr)
    write_json(run / 'RESULT.json', {'command': command, 'cwd': str(ROOT), 'exit_code': result.returncode,
        'status': 'PASS' if result.returncode == 0 else 'FAIL', 'generator': identity(Path(__file__))})
    print(result.stdout.decode('utf8', errors='replace'), end='')
    print(result.stderr.decode('utf8', errors='replace'), end='', file=sys.stderr)
    print('Evidence: ' + str(run))
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
