"""Seal explicitly read final location/deadline deltas; keep prior records intact."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'evidence/task4/ui_review/FINAL_001'
OUT = ROOT/'evidence/task4/ui_review/FINAL_003'
EXPECTED_MAIN = '8eebb07a134634075b5d24bb4737500995dafe84c555e01b428da1948164003f'
EXPECTED_GATT = 'a9128015550ad7c8d15729ff07742493d463593804fde4b97bcb09f31e1259c6'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    review = json.loads((BASE/'review.json').read_text(encoding='utf-8'))
    OUT.mkdir()
    for item in review['sources']:
        path = ROOT/item['path']
        expected = {'MainActivity.java': EXPECTED_MAIN, 'GattTransport.java': EXPECTED_GATT}.get(path.name,item['sha256'])
        assert sha(path) == expected, 'unexpected new source delta: '+str(path)
        target = OUT/'source_snapshot'/item['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(path) == sha(target) == expected
        item.update(sha256=expected, size=target.stat().st_size,
                    lines=len(target.read_text(encoding='utf-8').splitlines()),
                    snapshot=str(target.relative_to(ROOT)))
    old = (BASE/'source_snapshot/app/src/main/java/com/proscore/android/MainActivity.java').read_text(encoding='utf-8')
    new = (OUT/'source_snapshot/app/src/main/java/com/proscore/android/MainActivity.java').read_text(encoding='utf-8')
    expected = old.replace('if (Build.VERSION.SDK_INT <= 30) {\n            LocationManager',
                           'if (Build.VERSION.SDK_INT <= 30) {\n            try {\n            LocationManager', 1)
    expected = expected.replace('        }\n        stopScan(false); devices.clear();',
        '            } catch (RuntimeException error) { scanState.setText(R.string.location_off); return; }\n'
        '        }\n        stopScan(false); devices.clear();', 1)
    assert new == expected, 'MainActivity has an unreviewed delta'
    old_gatt = (BASE/'source_snapshot/app/src/main/java/com/proscore/android/GattTransport.java').read_text(encoding='utf-8')
    new_gatt = (OUT/'source_snapshot/app/src/main/java/com/proscore/android/GattTransport.java').read_text(encoding='utf-8')
    expected_gatt = old_gatt.replace('while (!connected) await(until);\n',
        'while (!connected) await(until);\n                    checkDeadline(until);\n', 1)
    expected_gatt = expected_gatt.replace('                    checkOpen();\n                    byte[] value = stream.poll();',
        '                    checkOpen();\n                    checkDeadline(until);\n                    byte[] value = stream.poll();', 1)
    expected_gatt = expected_gatt.replace('        checkOpen();\n        pending = NONE;',
        '        checkOpen();\n        checkDeadline(until);\n        pending = NONE;', 1)
    expected_gatt = expected_gatt.replace('        guard.wait(remaining);\n        checkOpen();\n    }',
        '        guard.wait(remaining);\n        checkOpen();\n        checkDeadline(until);\n    }\n\n'
        '    private static void checkDeadline(long until) throws TimeoutException {\n'
        '        if (SystemClock.elapsedRealtime() >= until) throw new TimeoutException("BLE 超过单调时钟截止");\n    }', 1)
    assert new_gatt == expected_gatt, 'GattTransport has an unreviewed delta'
    review['created_utc'] = datetime.now(timezone.utc).isoformat()
    review['prior_version_coverage'] = review.pop('coverage')
    review['coverage'] = [dict(boundary='All FINAL_001 boundaries retained; only location exception and deadline guards changed',
        evidence=['FINAL_001/review.json and original source snapshot; its line numbers refer to that version',
                  'FINAL_003 MainActivity scan(): API<=30 LocationManager check now catches RuntimeException',
                  'FINAL_003 GattTransport connect/receive/awaitOperation/await/checkDeadline: recheck monotonic deadline before accepting success'])]
    review['delta_review'] = dict(reviewer='/root', base='FINAL_001/review.json',
        new_main_sha256=EXPECTED_MAIN,
        new_gatt_sha256=EXPECTED_GATT,
        description='Pre-31 location provider exceptions report location_off before scanning; GattTransport checks monotonic deadline after wake/completion and before queued receive success, preventing late callbacks bypassing timeout.',
        conclusion='No concrete blocker in these read deltas; no automatic scan/connect/control or retry change added.',
        preserved_refusals=['evidence/task4/SEAL_001_FAILURE.json','evidence/task4/UI_REFRESH_001_FAILURE.json'],
        task3_completed_handoff='HANDOFF_TASK3.md')
    review['freeze_history']['second_snapshot_refused'] = 'evidence/task4/SEAL_001_FAILURE.json'
    for item in review['sources']:
        assert sha(ROOT/item['path']) == item['sha256']
    (OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
    (OUT/'CONCLUSION.md').write_text(
        '# Task4 UI/BLE 增量审查结论\n\n'
        '原FINAL_001七份完整只读审查保留。收到任务3完整交接后，读取两份源码的全部增量：MainActivity对API<=30的定位provider状态读取增加try/catch RuntimeException，失败显示location_off并在扫描前返回；GattTransport在连接唤醒、操作完成、等待返回和接收取队列前重核单调时钟截止，迟到回调不能形成超时成功。其余五份源码/资源SHA不变。差异已逐字节断言，无新增自动控制或重试，未发现具体阻断。\n\n'
        'MainActivity SHA：'+EXPECTED_MAIN+'；GattTransport SHA：'+EXPECTED_GATT+'。七份最新原字节见source_snapshot，身份见review.json。旧版行号映射仍仅指FINAL_001；本版按函数及增量描述定位。SEAL_001_FAILURE.json、UI_REFRESH_001_FAILURE.json与不完整FINAL_002均保留。仍仅静态审查，不代签APK/Android/BLE运行。\n',encoding='utf-8')
    print('UI_DELTA_REVIEW_PASS', str(OUT/'review.json'))


if __name__ == '__main__':
    main()
