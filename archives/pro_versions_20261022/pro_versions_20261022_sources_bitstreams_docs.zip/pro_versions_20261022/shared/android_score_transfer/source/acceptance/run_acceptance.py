"""Independent Python-PC oracle against Java public API over a fake Transport.

No BLE, Android emulator, network, board or old test group is invoked.
"""
from __future__ import annotations

import asyncio
import base64
from collections import deque
import hashlib
import json
from pathlib import Path
import queue
import shutil
import struct
import subprocess
import sys
sys.dont_write_bytecode = True
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
PC = PROJECT / 'software/pc'
sys.path.insert(0, str(PC))
import protocol as p  # noqa: E402 -- immutable independent golden implementation
import score as pc_score  # noqa: E402
from client import ScoreClient as PcClient  # noqa: E402

JDK = Path('E:/FPGA/SDKs/java/jdk17/bin')
SID = 0xfedcba98
DOC = dict(schema=1, sample_hz=48000, score_id=SID, events=[
    dict(tick=0, type='note_on', channel=0, note=60, velocity=100),
    dict(tick=48000, type='note_off', channel=0, note=60, velocity=0)])
RECORDS = pc_score.encode_score(DOC)[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Peer:
    """Small independent endpoint: PC codec owns all wire parsing/ACK bytes."""
    def __init__(self, sid=SID, records=RECORDS, preloaded=False):
        self.sid, self.records = sid, records
        self.count = len(records) // 8
        self.committed = preloaded
        self.active = False
        self.staged = bytearray()
        self.read_index = 0
        self.read_scope = False
        self.verified = False
        self.cache = {}
        self.identities = {}
        self.trace = []
        self.phase = 'upload'

    def apply(self, raw):
        request = p.decode(raw)
        assert request.encode() == raw, 'PC encoder disagreement'
        assert request.session != 0, 'zero session'
        identity = (request.session, request.seq)
        if identity in self.identities:
            assert self.identities[identity] == raw, 'same request identity changed bytes'
        self.identities[identity] = raw
        self.trace.append((self.phase, request, raw))
        if raw in self.cache:
            return request, self.cache[raw]
        c, data = request.command, request.payload
        if c == p.STOP:
            assert not data and request.offset == 0
            self.read_scope = False
        elif c == p.ABORT:
            assert not data and request.offset == 0
            self.active = False
        elif c == p.BEGIN:
            assert request.seq == 0 and request.offset == 0
            assert data == struct.pack('<IHHHI', self.sid, self.count,
                                       len(self.records), p.crc(self.records), 48000)
            self.active, self.verified = True, False
            self.staged.clear()
        elif c == p.DATA:
            assert self.active and 1 <= len(data) <= 128
            assert request.offset == len(self.staged)
            assert data == self.records[request.offset:request.offset+len(data)]
            self.staged.extend(data)
        elif c == p.COMMIT:
            assert not data and request.offset == 0
            assert self.active and bytes(self.staged) == self.records
            self.committed, self.active = True, False
        elif c == p.STATUS:
            assert not data and request.offset == 0
        elif c == p.READ_BEGIN:
            assert self.committed and not self.read_scope
            assert request.offset == 0 and data == struct.pack('<IHH', self.sid, self.count, 0)
            self.read_scope, self.read_index = True, 0
        elif c == p.READ:
            assert self.committed and self.read_scope and not data
            assert request.offset == self.read_index < self.count
            self.read_index += 1
        elif c == p.READ_END:
            assert not data and request.offset == 0
            assert self.read_scope and self.read_index == self.count
            self.read_scope, self.verified = False, True
        elif c == p.START:
            assert request.offset == 0 and data == struct.pack('<IHH', self.sid, self.count, 0)
            assert self.verified and not self.read_scope
        else:
            raise AssertionError('unexpected command ' + str(c))
        event = (self.records[request.offset*8:request.offset*8+8]
                 if c == p.READ else None)
        reply = p.response(request, 0, committed=self.committed, active=self.active,
                           count=self.count if self.committed else 0,
                           score_id=self.sid if self.committed else 0,
                           received=len(self.staged), event=event)
        self.cache[raw] = reply
        return request, reply


async def golden_trace(mode, stop_first, sid, records):
    peer = Peer(sid, records, preloaded=mode in ('start', 'stop'))

    class Transport:
        async def send(self, raw):
            self.reply = peer.apply(raw)[1]

        async def receive(self):
            return self.reply

    transport = Transport()
    for n, phase in enumerate(['upload', 'start', 'stop'] if mode == 'flow' else [mode]):
        peer.phase = phase
        client = PcClient(transport, session=0x4321+n)
        if phase == 'upload':
            await client.upload(sid, records, stop_first=stop_first)
        elif phase == 'start':
            await client.start(sid, records)
        else:
            await client.stop()
    return peer.trace


def replace_reply(raw, *, kind=None, metadata=None, event=None, payload=None):
    frame = p.decode(raw)
    meta = list(p.META.unpack(frame.payload[:12]))
    if metadata:
        for index, value in metadata.items():
            meta[index] = value
    body = p.META.pack(*meta) + (frame.payload[12:] if event is None else event)
    return p.Frame(frame.command if kind is None else kind, frame.session, frame.seq,
                   frame.offset, body if payload is None else payload).encode()


def comparable(trace):
    # Sessions are intentionally random per Java operation. Validate every
    # frame's full PC-codec byte roundtrip; compare deterministic request data.
    return [(phase, req.command, req.offset, req.payload.hex()) for phase, req, raw in trace]


def read_process(process, lines, raw_lines):
    for line in process.stdout:
        raw_lines.append(line)
        lines.put(line.rstrip('\n'))
    lines.put(None)


def java_case(classes, out, name, mode, score_file, *, fault=None, stop_first=False,
              sid=SID, records=RECORDS, valid_score=True):
    folder = out / name
    folder.mkdir()
    command = [str(JDK/'java.exe'), '-Xmx128m', '-cp', str(classes),
               'com.proscore.acceptance.Harness', mode, str(score_file), str(stop_first).lower()]
    lines, raw_lines, errors = queue.Queue(), [], []
    peer = Peer(sid, records, preloaded=mode in ('start', 'stop'))
    pending = deque()
    fault_used = False
    end = None
    score_result = None
    phase = mode
    events = []
    deadline = time.monotonic() + (50 if len(records) > 1024 else 16)
    started = time.monotonic()
    with (folder/'stderr.log').open('w', encoding='utf-8') as stderr:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=stderr, text=True, encoding='utf-8', bufsize=1)
        thread = threading.Thread(target=read_process, args=(process, lines, raw_lines), daemon=True)
        thread.start()
        try:
            while True:
                line = lines.get(timeout=max(0.01, deadline-time.monotonic()))
                if line is None:
                    break
                if line.startswith('OP '):
                    phase = peer.phase = line[3:]
                elif line.startswith('SCORE '):
                    score_result = line.split()
                elif line.startswith('SEND '):
                    _, value, timeout = line.split()
                    assert 0 < int(timeout) <= 180000, 'invalid relative send deadline'
                    raw = bytes.fromhex(value)
                    req = p.decode(raw)
                    events.append(dict(kind='send', phase=phase, frame=value, timeout_ms=int(timeout)))
                    target = ((fault == 'bad_start_read' and phase == 'start' and req.command == p.READ) or
                              (fault in ('bad_read_shape','bad_read_data') and req.command == p.READ) or
                              (fault == 'wrong_published_id' and req.command == p.STATUS) or
                              (fault == 'partial_data' and req.command == p.DATA) or
                              (fault not in ('bad_start_read','bad_read_shape','bad_read_data',
                                             'wrong_published_id','partial_data') and not fault_used))
                    if target and fault in ('partial_begin','partial_data'):
                        # A real adapter wraps partial GATT writes as IOException.
                        peer.trace.append((phase, req, raw))
                        action = 'PARTIAL_WRITE'
                    else:
                        req, reply = peer.apply(raw)
                        action = 'SENT'
                        if target and fault == 'cancel_sent':
                            action = 'CANCEL_SENT'
                        elif target and fault == 'timeout_all':
                            pending.append('ACK_TIMEOUT')
                        elif target and fault == 'timeout_once':
                            pending.append('ACK_TIMEOUT')
                        elif fault == 'timeout_all' and req.command == p.BEGIN:
                            pending.append('ACK_TIMEOUT')
                        elif target and fault == 'stream_error':
                            pending.append('STREAM_ERROR')
                        elif target and fault == 'disconnect':
                            pending.append('DISCONNECTED')
                        else:
                            if target:
                                if fault == 'nack15': reply = replace_reply(reply, kind=p.NACK, metadata={1:15})
                                elif fault == 'nack_zero': reply = replace_reply(reply, kind=p.NACK)
                                elif fault == 'nack_unknown': reply = replace_reply(reply, kind=p.NACK, metadata={1:16})
                                elif fault == 'ack_error': reply = replace_reply(reply, metadata={1:15})
                                elif fault == 'ack_extra': reply = replace_reply(reply, event=b'\x00'*8)
                                elif fault == 'metadata_bool': reply = replace_reply(reply, metadata={2:2})
                                elif fault == 'metadata_count': reply = replace_reply(reply, metadata={4:513})
                                elif fault == 'wrong_command': reply = replace_reply(reply, metadata={0:p.CLEAR})
                                elif fault == 'bad_crc': reply = reply[:-1] + bytes([reply[-1]^1])
                                elif fault == 'bad_read_shape': reply = replace_reply(reply, event=b'')
                                elif fault in ('bad_read_data','bad_start_read'):
                                    event = bytearray(p.decode(reply).payload[12:]); event[6] ^= 1
                                    reply = replace_reply(reply, event=bytes(event))
                                elif fault == 'wrong_published_id': reply = replace_reply(reply, metadata={5:sid^1})
                                elif fault == 'foreign_then_valid':
                                    decoded = p.decode(reply)
                                    foreign = p.Frame(decoded.command, decoded.session^1, decoded.seq,
                                                      decoded.offset, decoded.payload).encode()
                                    pending.append('FRAME '+foreign.hex())
                            pending.append(('CANCEL_FRAME ' if target and fault == 'cancel_receive' else 'FRAME ')+reply.hex())
                    if target:
                        fault_used = True
                    process.stdin.write(action+'\n'); process.stdin.flush()
                elif line.startswith('RECEIVE '):
                    timeout = int(line.split()[1])
                    assert 0 < timeout <= 2001, 'invalid ACK relative timeout'
                    assert pending, 'unexpected receive without an independent response'
                    action = pending.popleft()
                    events.append(dict(kind='receive', action=action, timeout_ms=timeout))
                    process.stdin.write(action+'\n'); process.stdin.flush()
                elif line.startswith('END '):
                    end = line
                    break
                if time.monotonic() > deadline:
                    raise TimeoutError('independent process watchdog')
        except Exception as error:
            errors.append(type(error).__name__+': '+str(error))
        finally:
            if process.poll() is None and end is None:
                process.kill()
            try:
                code = process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill(); code = process.wait(timeout=3)
            thread.join(timeout=2)
    (folder/'stdout.log').write_text(''.join(raw_lines), encoding='utf-8')
    result = dict(name=name, command=command, exit_code=code, end=end,
                  seconds=round(time.monotonic()-started,3), events=events, errors=errors,
                  score_result=score_result)
    try:
        assert not errors and code == 0 and end is not None, 'harness/peer execution failure'
        if mode == 'parse':
            assert (end == 'END OK') == valid_score, 'score acceptance disagrees'
            if valid_score:
                assert score_result is not None
                assert (int(score_result[1]),int(score_result[2]),bytes.fromhex(score_result[3])) == (sid,len(records)//8,records)
                assert score_result[4] == 'true', 'getRecords is not defensive'
        else:
            expected_success = fault in (None,'foreign_then_valid','timeout_once') and mode != 'cancel_before'
            assert (end == 'END OK') == expected_success, 'operation result disagrees'
            if end.startswith('END ERROR '):
                result['exception_class'] = end.split()[2]
                result['exception_message'] = base64.b64decode(end.split()[3]).decode('utf-8')
            if mode == 'cancel_before':
                assert not peer.trace, 'cancelled client transmitted'
            else:
                golden = asyncio.run(golden_trace(mode,stop_first,sid,records))
                actual, dedup = [], set()
                for entry in peer.trace:
                    key = (entry[0],entry[2])
                    if key not in dedup:
                        actual.append(entry); dedup.add(key)
                assert comparable(actual) == comparable(golden[:len(actual)]), 'request order/data differs from PC oracle'
                if expected_success:
                    assert len(actual) == len(golden), 'workflow incomplete'
                if fault == 'timeout_all':
                    assert len(peer.trace) == 3 and len({r for _,_,r in peer.trace}) == 1, 'timeout retry bound or identity'
                elif fault == 'timeout_once':
                    assert len(peer.trace) == len(golden)+1 and peer.trace[0][2] == peer.trace[1][2], 'retry changed request'
                elif not expected_success:
                    assert len(peer.trace) == len(actual), 'non-timeout failure retransmitted'
                if fault in ('nack15','nack_zero','nack_unknown','ack_error','ack_extra',
                             'metadata_bool','metadata_count','wrong_command','bad_crc',
                             'stream_error','disconnect','partial_begin','cancel_sent','cancel_receive'):
                    assert len(peer.trace) == 1, 'failure sent extra commands/recovery'
                if fault in ('bad_read_data','bad_start_read','bad_read_shape'):
                    assert peer.trace[-1][1].command == p.READ, 'read failure released lease or started'
                if fault == 'bad_start_read':
                    assert not any(phase=='start' and req.command==p.START for phase,req,_ in peer.trace)
                if mode == 'upload':
                    assert not any(req.command==p.START for _,req,_ in peer.trace), 'upload auto-started'
        result['status'] = 'PASS'
    except Exception as error:
        result['status'] = 'FAIL'
        result['failure'] = str(error)
    (folder/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result


def main():
    evidence = ROOT/'evidence/task4'
    evidence.mkdir(parents=True,exist_ok=True)
    sources = sorted((ROOT/'app/src/main/java/com/proscore/core').rglob('*.java'))
    required = {'Score.java', 'ScoreClient.java'}
    if not required.issubset({source.name for source in sources}):
        print(json.dumps(dict(status='NOT_STARTED', reason='CORE_NOT_READY',
                              expected=sorted(required)), indent=2), flush=True)
        return 2
    manifest = json.loads((ROOT/'acceptance/vectors/manifest.json').read_text(encoding='utf-8'))
    assert isinstance(manifest, list) and len(manifest) == 68, 'golden manifest incomplete'
    assert len({case['id'] for case in manifest}) == len(manifest), 'duplicate golden ID'
    n = 1
    while (evidence/f'RUN_{n:03d}').exists(): n += 1
    out = evidence/f'RUN_{n:03d}'; out.mkdir()
    snapshots = []
    for source in sources+[Path(__file__).with_name('Harness.java')]:
        target = out/'inputs'/source.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,target)
        snapshots.append(dict(path=str(source),snapshot=str(target),sha256=sha(source)))
    dependencies = [Path(__file__), ROOT/'acceptance/vectors/manifest.json']
    for case in manifest:
        dependencies.append(ROOT/case['score_file'])
        if case['valid']:
            dependencies.append(ROOT/case['records_file'])
    dependencies += [PC/name for name in ['protocol.py','score.py','client.py']]
    dependency_snapshots = []
    input_map = {}
    for source in dict.fromkeys(dependencies):
        relative = source.relative_to(ROOT) if source.is_relative_to(ROOT) else Path('oracle')/source.name
        target = out/'inputs'/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        dependency_snapshots.append(dict(path=str(source), snapshot=str(target), sha256=sha(source)))
        input_map[str(source)] = target
    classes = out/'classes'; classes.mkdir()
    command = [str(JDK/'javac.exe'),'-encoding','UTF-8','-d',str(classes)]+[x['snapshot'] for x in snapshots]
    (out/'receipt.json').write_text(json.dumps(dict(status='STARTED_NOT_COMPLETED',
        sources=snapshots, dependencies=dependency_snapshots, javac_command=command),indent=2)+'\n',encoding='utf-8')
    compile_result = subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (out/'javac.stdout.log').write_text(compile_result.stdout,encoding='utf-8')
    (out/'javac.stderr.log').write_text(compile_result.stderr,encoding='utf-8')
    assert compile_result.returncode == 0, 'independent Java compilation failed'
    basic = out/'basic.score.json'; basic.write_text(json.dumps(DOC),encoding='utf-8')
    results = []
    for name,mode,fault,stop_first in [
        ('flow','flow',None,False),('flow_stop_first','flow',None,True),
        ('stop_without_file','stop',None,False),('cancel_before','cancel_before',None,False),
        ('ack_timeout_once','upload','timeout_once',False),('ack_timeout_all','upload','timeout_all',False),
        ('foreign_identity_then_valid','upload','foreign_then_valid',False),
        *[(name,'upload',name,False) for name in ['nack15','nack_zero','nack_unknown','ack_error',
          'ack_extra','metadata_bool','metadata_count','wrong_command','bad_crc','stream_error',
          'disconnect','partial_begin','partial_data','cancel_sent','cancel_receive',
          'bad_read_shape','bad_read_data','wrong_published_id']],
        ('start_rechecks_bytes','flow','bad_start_read',False)]:
        score_file = out/'intentionally_absent.score.json' if mode == 'stop' else basic
        result=java_case(classes,out,name,mode,score_file,fault=fault,stop_first=stop_first)
        results.append(result); print(name,result['status'],result.get('failure',''),flush=True)
    for case in manifest:
        records=(ROOT/case['records_file']).read_bytes() if case['valid'] else RECORDS
        result=java_case(classes,out,'parse_'+case['id'],'parse',input_map[str(ROOT/case['score_file'])],
                         sid=case['score_id'] if case['valid'] else SID,
                         records=records,valid_score=case['valid'])
        results.append(result); print(result['name'],result['status'],result.get('failure',''),flush=True)
        if case['id'] == 'valid_capacity512':
            result=java_case(classes,out,'capacity512_flow','flow',input_map[str(ROOT/case['score_file'])],
                             sid=case['score_id'],records=records)
            results.append(result); print(result['name'],result['status'],result.get('failure',''),flush=True)
    unchanged=all(sha(Path(item['path']))==item['sha256'] for item in snapshots+dependency_snapshots)
    receipt=dict(status='PASS' if unchanged and all(x['status']=='PASS' for x in results) else 'FAIL',
        commands=dict(javac=command,javac_exit=compile_result.returncode),sources=snapshots,
        dependencies=dependency_snapshots,
        tests=[dict(name=x['name'],status=x['status'],failure=x.get('failure'),seconds=x['seconds']) for x in results],
        PC_oracle_sources=[dict(path=str(PC/name),sha256=sha(PC/name)) for name in ['protocol.py','score.py','client.py']],
        sources_unchanged=unchanged,device_operations=False,old_test_groups_rerun=False)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=receipt['status'],tests=len(results),evidence=str(out)),indent=2),flush=True)
    return 0 if receipt['status']=='PASS' else 1


if __name__=='__main__':
    raise SystemExit(main())
