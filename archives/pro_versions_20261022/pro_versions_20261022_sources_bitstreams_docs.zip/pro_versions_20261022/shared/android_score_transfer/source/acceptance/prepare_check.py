"""Self-check only the task4 preparation; never load or compile Java sources."""
from pathlib import Path
import ast
import asyncio
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def worker(out):
    import run_acceptance as driver

    paths = sorted((ROOT/'acceptance').rglob('*'))
    paths = [path for path in paths if path.is_file()]
    paths += [driver.PC/name for name in ['protocol.py', 'score.py', 'client.py']]
    before = [identity(path) for path in paths]
    for path in (ROOT/'acceptance').rglob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    manifest = json.loads((ROOT/'acceptance/vectors/manifest.json').read_text(encoding='utf-8'))
    assert isinstance(manifest, list) and len(manifest) == 68
    assert len({case['id'] for case in manifest}) == 68
    original_receipt = json.loads((ROOT/'evidence/task4/golden/RECEIPT_GOLDEN.json').read_text(encoding='utf-8'))
    for item in original_receipt['source_PC_identities']:
        assert identity(Path(item['path']))['sha256'] == item['sha256'], 'PC source changed'
    cases, traces = [], []
    for case in manifest:
        path = (ROOT/case['score_file']).resolve()
        assert path.is_relative_to(ROOT/'acceptance/vectors/scores')
        parsed, error = None, None
        try:
            parsed = json.loads(path.read_bytes().decode('utf-8'),
                                object_pairs_hook=driver.pc_score.unique_object)
            sid, records = driver.pc_score.encode_score(parsed)
        except (ValueError, TypeError, KeyError, UnicodeError) as exc:
            error = type(exc).__name__+': '+str(exc)
        pc_valid = error is None
        production_valid = pc_valid and all(
            36 <= event['note'] <= 84 and event['tick'] <= 16777215
            for event in parsed['events'])
        assert production_valid == case['valid'], case['id']
        cases.append(dict(id=case['id'], pc_valid=pc_valid,
                          production_valid=production_valid, pc_error=error))
        if not case['valid']:
            continue
        assert sid == case['score_id'] and len(records) == case['count']*8
        assert records == (ROOT/case['records_file']).read_bytes()
        for mode, stop_first in [('upload', False), ('upload', True),
                                 ('start', False), ('stop', False), ('flow', False)]:
            trace = asyncio.run(driver.golden_trace(mode, stop_first, sid, records))
            for phase, request, raw in trace:
                assert driver.p.decode(raw).encode() == raw
            if mode == 'flow':
                assert sum(req.command == driver.p.READ for _, req, _ in trace) == 2*case['count']
            if mode == 'upload':
                assert not any(req.command == driver.p.START for _, req, _ in trace)
            traces.append(dict(case=case['id'], mode=mode, stop_first=stop_first,
                               requests=len(trace), frames=[raw.hex() for _, _, raw in trace]))
    assert sum(case['production_valid'] for case in cases) == 13
    assert sum(not case['pc_valid'] for case in cases) == 51
    assert len(traces) == 65
    # Exercise the peer's retry-identity check without a Java implementation.
    peer = driver.Peer()
    begin = driver.p.Frame(driver.p.BEGIN, 1, 0, 0,
        driver.struct.pack('<IHHHI', driver.SID, 2, 16, driver.p.crc(driver.RECORDS), 48000)).encode()
    assert peer.apply(begin)[1] == peer.apply(begin)[1]
    altered = driver.p.Frame(driver.p.STATUS, 1, 0).encode()
    rejected = False
    try:
        peer.apply(altered)
    except AssertionError:
        rejected = True
    assert rejected, 'peer failed to reject changed bytes for same identity'
    after = [identity(path) for path in paths]
    assert before == after, 'preparation/PC inputs changed during self-check'
    (out/'SELF_CHECK.json').write_text(json.dumps(dict(
        status='PASS', scope='PREPARATION_ONLY', inputs_before=before, inputs_after=after,
        score_cases=cases, original_PC_workflows=traces,
        Java_execution='NOT_STARTED', UI_review='NOT_STARTED', device_operations=False,
        old_test_groups_executed=False), indent=2)+'\n', encoding='utf-8')
    print('PREPARATION_ONLY PASS: 68 score classifications; 65 PC-to-peer workflows; unchanged inputs.')


def main():
    base = ROOT/'evidence/task4/preparation'
    base.mkdir(parents=True, exist_ok=True)
    n = 1
    while (base/f'RUN_{n:02d}').exists():
        n += 1
    out = base/f'RUN_{n:02d}'
    out.mkdir()
    command = [sys.executable, '-X', 'utf8', '-B', str(Path(__file__).resolve()), '--worker', str(out)]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    (out/'stdout.log').write_text(result.stdout, encoding='utf-8')
    (out/'stderr.log').write_text(result.stderr, encoding='utf-8')
    (out/'RESULT.json').write_text(json.dumps(dict(command=command, cwd=str(ROOT),
        exit_code=result.returncode, status='PASS' if result.returncode == 0 else 'FAIL',
        scope='PREPARATION_ONLY'), indent=2)+'\n', encoding='utf-8')
    print(result.stdout, end='')
    print(result.stderr, end='', file=sys.stderr)
    print(str(out))
    return result.returncode


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        worker(Path(sys.argv[2]))
    else:
        raise SystemExit(main())
