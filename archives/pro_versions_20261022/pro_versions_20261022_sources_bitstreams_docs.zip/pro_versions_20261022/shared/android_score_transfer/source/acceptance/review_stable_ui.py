"""Freeze the final, explicitly read lint delta and every app source/resource."""
from datetime import datetime, timezone
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'evidence/task4/ui_review/FINAL_004'
EXPECTED = {
    'app/src/main/java/com/proscore/android/MainActivity.java': 'a583f3d21624c50af3a13ae4326e47a35f57a05a07368d91154393b72fd93d3a',
    'app/src/main/java/com/proscore/android/GattTransport.java': 'e574341c3a72aa54060c1822941fa4fc73c98361bb03ae6b3d089ee680806010',
    'app/src/main/java/com/proscore/android/ResponseStream.java': 'dbccde07b9caa790c0768635b337a3411d1b06db8598b28fa0cface102e29e70',
    'app/src/main/AndroidManifest.xml': '33efd06527d0994f935fd26e4e2de88c7d444eea0a779157880f70d909de7dff',
    'app/src/main/res/values/strings.xml': 'e0ae09db22602183eb0a1f44b91fb5e0e500bbe246112e3b2703adeb248a6b2a',
    'app/src/main/res/values/styles.xml': '8c4e6871b110015a634812f84353548eee4d24e84cf71300b559cc87d8db187b',
    'app/src/main/res/values-v27/styles.xml': '05350db3eb26469abbc90f4a96f844aaf1a82fd89166d55ed716b498e59156e3',
    'app/src/main/assets/sample.score.json': '19b347587a38f0609fd70e923b788736fb3a82ae8c29d2cc8e7cec2e76ba40c6',
    'app/build.gradle': '49dd9a63da19000b0b898a58887411a058ee971524fdc1a55766b30bfb0c5b1f',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def worker():
    core = json.loads((ROOT/'evidence/task4/RUN_001/receipt.json').read_text(encoding='utf-8'))
    assert core['status'] == 'PASS' and len(core['tests']) == 95
    for item in core['sources']:
        path = Path(item['path'])
        if path.is_relative_to(ROOT/'app'):
            EXPECTED[path.relative_to(ROOT).as_posix()] = item['sha256']
    actual = {path.relative_to(ROOT).as_posix() for path in (ROOT/'app/src/main').rglob('*') if path.is_file()}
    actual.add('app/build.gradle')
    assert actual == set(EXPECTED), 'App source/resource inventory differs from the read scope'
    prior = json.loads((ROOT/'evidence/task4/ui_review/FINAL_003/review.json').read_text(encoding='utf-8'))
    sources, changes = [], []
    for name in sorted(EXPECTED):
        path = ROOT/name
        assert sha(path) == EXPECTED[name], 'Unreviewed source change: '+name
        target = OUT/'source_snapshot'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == EXPECTED[name]
        sources.append(dict(path=name, sha256=EXPECTED[name], size=target.stat().st_size,
                            lines=len(target.read_text(encoding='utf-8').splitlines()),
                            snapshot=target.relative_to(ROOT).as_posix()))
        old_item = next((item for item in prior['sources'] if item['path'] == name), None)
        if old_item and old_item['sha256'] != EXPECTED[name]:
            old_text = (ROOT/old_item['snapshot']).read_text(encoding='utf-8')
            changes.extend(difflib.unified_diff(old_text.splitlines(True),target.read_text(encoding='utf-8').splitlines(True),
                fromfile='FINAL_003/'+name,tofile='FINAL_004/'+name))
    (OUT/'FINAL_DELTA.diff').write_text(''.join(changes),encoding='utf-8')
    for source in sources:
        assert sha(ROOT/source['path']) == source['sha256']
    report = dict(task='Task4 final stable source delta review and full app binding',
        created_utc=datetime.now(timezone.utc).isoformat(),
        status='NO_CONCRETE_BLOCKER_FOUND_IN_PINNED_STATIC_SCOPE', findings=[],
        sources=sources, not_yet_reviewed=[],
        contract=dict(path='TASK_AND_API.md',sha256=sha(ROOT/'TASK_AND_API.md')),
        prior_reviews=['evidence/task4/ui_review/FINAL_001/review.json',
                       'evidence/task4/ui_review/FINAL_003/review.json'],
        delta_scope=[
            'MainActivity: API<=30 permission request adds COARSE beside FINE; API31+ SCAN/CONNECT unchanged.',
            'Manifest: COARSE maxSdk30 added consistently; no broad storage/background permissions.',
            'GattTransport: API33 guarded writes compare BluetoothStatusCodes.SUCCESS; write response awaiting and fatal partial-send behavior unchanged.',
            'Default AppThemeBase excludes API27 navigation attribute; AppTheme inherits it. values-v27 AppTheme explicitly inherits same base and adds the API27-only item.',
            'Previously read GATT monotonic deadline guards retained byte-for-byte except SUCCESS naming/import.',
            'MainActivity Chinese phase mapping and independent connectionEpoch retained; only final permission line differs from FINAL_003.',
            'All four tested core sources byte-identical to RUN_001; no137-case rerun.',
            'Sample score and app/build.gradle read and included; source/resource inventory exact, including new values-v27.'],
        observations=dict(core_tests_reexecuted=False, production_files_modified=False,
                          device_operations=False, APK_or_lint_run_by_task4=False),
        coordinator_report=dict(source='Stable-source notice from task1 coordinator,2026-10-22',
            reported_result='BUILD_R04 offline assembleRelease+lintRelease BUILD SUCCESSFUL; signing/identity checks owned by coordinator',
            independently_executed_by_task4=False),
        official_sources=prior['official_sources'],
        review_limits=['Static final delta review plus prior full-source reviews; not Android runtime or real BLE validation',
                       'All13 bound files include12 app/src/main files plus app/build.gradle',
                       'APK build/lint/signing outcome remains coordinator responsibility',
                       'No phone/FPGA or180-second physical transport deadline signoff'],
        histories_preserved=['WAITING_STABLE_001.json','SEAL_001_FAILURE.json','UI_REFRESH_001_FAILURE.json',
                             'SEAL_002_FAILURE.json','ui_review/FINAL_002'])
    assert len(sources) == 13
    (OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    (OUT/'CONCLUSION.md').write_text(
        '# 任务4稳定版最终增量结论\n\n'
        '按总控稳定通知，只审相对FINAL_003的完整最终diff及新增API27资源。未发现具体阻断。粗/精定位的Manifest与旧版请求一致；API33具名SUCCESS处于原版本守卫内；默认主题保留API26兼容属性，API27导航属性仅在values-v27显式继承基类的主题中。GATT截止、中文阶段和独立连接代次沿用已审逻辑。\n\n'
        '当前全部12份app/src/main源码、资源及样例，加app/build.gradle，共13份原字节及SHA已绑定；四份核心与95+42例已验版本相同，未重跑137例。完整新diff见FINAL_DELTA.diff，原始字节见source_snapshot，身份与边界见review.json。\n\n'
        '这是静态源码与身份结论；没有本窗口新增APK/lint运行、手机/BLE或板卡实测。总控报告的BUILD_R04成功明确记为外部执行上下文。全部旧失败、未开始、等待和过时快照继续保留。\n',encoding='utf-8')
    print('STABLE_UI_DELTA_REVIEW_PASS;13 app inputs bound;137 cases not rerun.')


def main():
    OUT.mkdir()
    command = [sys.executable,'-X','utf8','-B',str(Path(__file__).resolve()),'--worker']
    result = subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    (OUT/'stdout.log').write_text(result.stdout,encoding='utf-8')
    (OUT/'stderr.log').write_text(result.stderr,encoding='utf-8')
    (OUT/'RESULT.json').write_text(json.dumps(dict(command=command,cwd=str(ROOT),exit_code=result.returncode,
        status='PASS' if result.returncode==0 else 'FAIL',scope='FINAL_STATIC_DELTA_AND_IDENTITY_ONLY'),indent=2)+'\n',encoding='utf-8')
    print(result.stdout,end='')
    print(result.stderr,end='',file=sys.stderr)
    return result.returncode


if __name__=='__main__':
    if sys.argv[1:] == ['--worker']:
        worker()
    else:
        raise SystemExit(main())
