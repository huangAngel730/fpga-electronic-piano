# 安卓传谱R01：拓展任务4最终交接（2026-10-22）

**任务4限定范围完成：Java公共API95例及固定协议42例全部PASS；稳定版UI/BLE最终增量静态审查未发现具体阻断，当前全部app源码、资源、样例及app构建配置已绑定精确SHA。未进行手机或板卡实测。**

独占写集仅acceptance/**、evidence/task4/**、本文件。未修改任务2/3或总控源码；未连接实物、烧录、Git或启用外部审核员制度。总控最终稳定通知后继续本轮收尾，未再追逐中间版本，未重跑已通过137例。

## 实际验证及证据

- 黄金生成68例曲谱：13合法、51原PC拒绝、4仅安卓生产范围拒绝；另13组请求/ACK、15种NACK、14种畸形响应。直接使用只读原PC protocol.py、score.py、client.py，源SHA未变。证据golden/RECEIPT_GOLDEN.json及RUN_01。
- 准备自检PASS：68例重新分类，13个合法输入各5种原PC→独立Peer流程共65组；输入前后SHA一致。见preparation/RUN_01/SELF_CHECK.json和RESULT.json。
- Java公共API95例PASS：68解析、26工作流/反例、1例512事件完整上传/回读/START重核/STOP。验证严格JSON/UTF8、同tick顺序、velocity0规范化、unsigned32 ID、防御拷贝、生产边界；上传不自动START、无文件STOP；有限同帧重试、NACK立即失败、部分写/坏流/断线/取消不可自动重发或恢复、回读错误不可READ_END/START、START重新核同。见RUN_001/receipt.json及每例RESULT.json、stdout/stderr；inputs保存精确核心和输入快照。JDK17编译退出0，运行退出0；业务错误按END语义判定，不以exit0冒充成功。
- 固定Java Protocol42例PASS：13组请求/ACK、15种NACK码、14种畸形响应，直接核同一已编译核心快照的字节、元数据和READ事件。见RUN_001/codec_vectors_01/receipt.json、stdin.txt及日志，编译/运行均退出0。
- 最终稳定版静态增量及身份核对PASS：见ui_review/FINAL_004/{review.json,CONCLUSION.md,FINAL_DELTA.diff,RESULT.json,source_snapshot/}。实际review_stable_ui.py子进程退出0，完整命令、cwd与原始stdout/stderr均已保存。完整先前审查为FINAL_001，GATT截止/旧版定位异常处理增量为FINAL_003；各历史快照的行号只对各自版本有效。

以上均为本任务新验收；没有重跑旧PC、RTL或EDA组。

## 最终增量与身份

按总控指定范围读取最终全部差异：

1. GATT单调截止检查沿用已审FINAL_003；API33两处写返回比较改用BluetoothStatusCodes.SUCCESS，均保留API33守卫、逐片回调等待及部分写致命失败逻辑。
2. 默认AppThemeBase仅含API26兼容属性，AppTheme显式继承；仅values-v27/AppTheme加入windowLightNavigationBar并显式继承同一基类。
3. Manifest新增COARSE_LOCATION(maxSdk30)，旧版运行时同时请求FINE/COARSE；API31+仍为SCAN/CONNECT。未引入全盘存储、自动扫描/连接/控制。
4. 中文阶段识别及独立connectionEpoch已在前次完整审查覆盖，最终MainActivity相对FINAL_003只改变旧版权限名单，该逻辑保留。

全部12份app/src/main Java、Manifest、资源及样例，加app/build.gradle共13份完整原字节与SHA见FINAL_004/review.json。当前核心四份与RUN_001相同，未重跑137例。主要UI身份：MainActivity a583f3d21624c50af3a13ae4326e47a35f57a05a07368d91154393b72fd93d3a；GattTransport e574341c3a72aa54060c1822941fa4fc73c98361bb03ae6b3d089ee680806010。

最终机器汇总evidence/task4/receipt.json：核对全部当前来源、既存输入/快照、完整源码/资源目录清单，保存证据及产物SHA、实际命令/退出码与验证边界。封存不执行产品测试。封存入口是acceptance/seal_task4.py加FINAL_004/review.json绝对路径。

## 历史与未验边界

准备期NOT_STARTED原件preparation/HANDOFF_NOT_STARTED.md保留。验收驱动曾在Java执行前误用manifest/schema字段名，固定codec首跑KeyError退出1，失败脚本/输入与FAILURE.json保留在RUN_001/codec_vectors；修正版使用codec_vectors_01，没有覆盖。它是驱动缺陷，不是产品失败。

源码并发更新触发的FREEZE_001_failure.log、SEAL_001_FAILURE.json、UI_REFRESH_001_FAILURE.json、SEAL_002_FAILURE.json、不完整FINAL_002及WAITING_STABLE_001.json均保留。它们记录当时未完成/拒绝封存事实，不改写成通过。稳定通知后才形成FINAL_004，不用旧SHA代签新源。

总控报告BUILD_R04离线assembleRelease+lintRelease BUILD SUCCESSFUL，APK签名/身份核验仍由总控负责。本窗口没有自行执行APK构建、lint或签名，也不代签其最终产物。任务3的236项host检查仅作其交付上下文，未在任务4重跑或合并成137例。

手机权限/SAF/系统栏实际布局、真实Android蓝牙栈、BLE吞吐与180秒总截止实耗、ESP/FPGA/UART/音频/显示联动均未实测。mock和静态结论不等同手机或整机通过。总控接手APK最终交付与必要实物验证；若后续源变，按具体增量重新绑定，不能沿用本收据签新源码。
