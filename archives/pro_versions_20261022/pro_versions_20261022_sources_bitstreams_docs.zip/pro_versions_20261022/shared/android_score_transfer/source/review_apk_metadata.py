"""Finish metadata verification of the exact APK; preserve original build receipt."""
import datetime as dt
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

from build_android import HERE, JDK, SDK, capture_build_inputs, identity, validate_manifest_dump


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def main():
    origin = HERE / 'evidence/BUILD_R04/receipt.json'
    original = json.loads(origin.read_text(encoding='utf-8'))
    out = HERE / 'evidence/METADATA_REVIEW_R01'
    out.mkdir(exist_ok=False)
    result = {
        'started_utc': stamp(), 'status': 'STARTED',
        'original_receipt': str(origin), 'original_receipt_identity': identity(origin),
        'original_status_preserved': original['status'],
        'script_identity': identity(Path(__file__)),
        'steps': [], 'device_operations': False, 'hardware_pass': False,
        'board_release_allowed': False,
        'fresh_gradle_or_signature_execution': False,
        'reason': 'Legacy aapt badging cannot resolve @android:drawable/ic_media_play; verify compiled manifest directly and bind framework resource to actual SDK',
    }
    try:
        stages = {step['label']: step for step in original['steps']}
        for name in ('gradle_build_lint', 'verify_apk_signature'):
            if stages[name]['exit_code'] != 0:
                raise ValueError('Required original stage did not pass: ' + name)
        result['reused_passed_stages'] = {name: stages[name] for name in ('gradle_build_lint', 'verify_apk_signature')}
        if capture_build_inputs() != original['build_input_identities']:
            raise ValueError('Build input set changed')
        apk = Path(original['apk']['path'])
        if identity(apk) != {key: original['apk'][key] for key in ('bytes', 'sha256')}:
            raise ValueError('Original signed APK changed')
        for name, expected in original['lint_reports'].items():
            if identity(apk.parent / name) != expected:
                raise ValueError('Original lint report changed')
        lint = ET.parse(apk.parent / 'lint-results-release.xml')
        errors = [issue.attrib for issue in lint.findall('issue')
                  if issue.get('severity', '').lower() in ('error', 'fatal')]
        warnings = [issue.attrib for issue in lint.findall('issue') if issue.get('severity', '').lower() == 'warning']
        if errors:
            raise ValueError('Lint has errors')
        result['lint'] = {'errors': 0, 'warnings': warnings}
        def run(label, command):
            step = {'label': label, 'argv': [str(item) for item in command], 'started_utc': stamp()}
            result['steps'].append(step)
            with (out / (label + '.stdout.log')).open('wb') as stdout, (out / (label + '.stderr.log')).open('wb') as stderr:
                completed = subprocess.run(step['argv'], stdout=stdout, stderr=stderr,
                                           creationflags=subprocess.CREATE_NO_WINDOW)
            step.update(exit_code=completed.returncode, ended_utc=stamp())
            if completed.returncode:
                raise ValueError(label + ' failed')
            return (out / (label + '.stdout.log')).read_text(encoding='utf-8')
        tree = run('apk_manifest', [SDK / 'build-tools/34.0.0/aapt.exe',
                                   'dump', 'xmltree', apk, 'AndroidManifest.xml'])
        result['apk_manifest_checks'] = validate_manifest_dump(tree)
        constants = run('sdk_framework_drawable', [JDK / 'bin/javap.exe', '-constants',
            '-classpath', SDK / 'platforms/android-35/android.jar', 'android.R$drawable'])
        if 'public static final int ic_media_play = 17301540;' not in constants or 'android:icon(0x01010002)=@0x01080024' not in tree:
            raise ValueError('Framework icon reference does not match SDK constant')
        result['framework_icon'] = {'name': 'android.R.drawable.ic_media_play',
            'resource_id_hex': '0x01080024', 'sdk_constant_matched': True,
            'sdk_identity': identity(SDK / 'platforms/android-35/android.jar')}
        with zipfile.ZipFile(apk) as archive:
            if archive.testzip() is not None or not {'classes.dex', 'resources.arsc', 'AndroidManifest.xml'} <= set(archive.namelist()):
                raise ValueError('APK contents or CRC invalid')
        result['build_input_identities'] = original['build_input_identities']
        result['apk'] = original['apk']
        result['lint_reports'] = original['lint_reports']
        if capture_build_inputs() != original['build_input_identities']:
            raise ValueError('Inputs changed during review')
        result['status'] = 'PASS_APK_BUILD_LINT_AND_SIGNATURE_ONLY'
    except Exception as error:
        result['status'] = 'FAIL'
        result['error'] = str(error)
    result['ended_utc'] = stamp()
    result['log_identities'] = {path.name: identity(path) for path in sorted(out.glob('*.log'))}
    (out / 'receipt.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'status': result['status'], 'receipt': str(out / 'receipt.json'),
                      'error': result.get('error'), 'apk': result.get('apk')}, ensure_ascii=False))
    return 0 if result['status'].startswith('PASS_') else 1


if __name__ == '__main__':
    sys.exit(main())
