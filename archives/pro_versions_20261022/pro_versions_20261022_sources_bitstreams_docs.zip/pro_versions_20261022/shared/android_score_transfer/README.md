# Pro 传谱：安卓端 R01

本轮范围：安卓手机选择已经转换好的 `.score.json` 曲谱，通过 BLE 发送到 ESP32-C3，再由 FPGA 完整回读核同；提供显式开始和停止。手机不解析 MIDI，不生成声音或代替 FPGA 运行双滑块。

当前软件交付已完成：`delivery/R01/ProScoreAndroid-r01.apk`是可安装的本地开发签名APK，`delivery/R01.zip`包含安装包、样例、源码和证据。详细实际验证／失败／SHA见`HANDOFF.md`及`HANDOFF.json`；`HANDOFF_PARTIAL.md`仅为此前审批暂停的历史快照。真实手机安装和BLE／板卡链路尚未验证。

## 使用前准备

- 安卓8.0或更新、支持BLE的手机。本项目最低API26，目标API35。
- FPGA使用已交付的 `02_pro_audio_score_slider_R10.fs` 拓展码流，基础版不含传谱接口。
- ESP32-C3已写入配套桥接固件，广告名 `Pro-Score-XXXXXX`；手机应用不能替ESP32安装固件。
- ESP GPIO4 TX→Pro Dock J26第11脚；GPIO5 RX←J26第9脚；GND→J26第3或4脚。断电接线，按板上1脚标记识别，3.3V逻辑。ESP32用USB电源，FPGA沿用此前验证的适配器；不并接两板电源输出。
- 显示接J11 DVI_TX_A，音频沿用基础版本连接，初次降低音量。

## 手机上怎样操作

1. 把交付APK传到手机，使用系统文件管理器打开，按系统提示允许该来源安装。此APK使用本地开发签名，不是应用商店发布版。
2. 开启手机蓝牙。打开应用并按提示授予扫描／连接权限。旧版Android扫描还可能要求定位权限和定位开关；应用不收集位置，未申请互联网或全盘存储权限。
3. 先使用内置六事件样例，或通过系统文件选择器打开 `.score.json`。第一次先测内置样例，便于区分曲谱和链路问题。打开系统文件选择器会离开应用前台，已有BLE连接会关闭，因此建议先选文件再连接。
4. 扫描后核对并选择自己的 `Pro-Score-XXXXXX`，连接。应用核对服务、v2状态并成功订阅回执后才进入可操作状态，不自动选第一台或自动重连。
5. 点“上传并全量核对（先 STOP）”。应用会先等待STOP确认并解除旧上传，再上传并完整READ逐字节核同；上传不自动开始播放。
6. 开始。应用再次核对曲谱，再发送START。FPGA按公共未来锚点安排下降滑块和自动音频，预留约2.016秒；人类演奏仍即时发声并形成上升滑块。
7. 停止。收到FPGA STOP ACK后才确认停止；没有选曲文件也能STOP。自然播完后也先STOP，再换曲上传。

手机取消等待、切后台或连接断开不代表FPGA已经停止。遇错误按界面提示重新显式连接并STOP恢复，不反复自动上传。应用不提供锁屏／后台持续传输服务；传输期间保持前台。

## 文件格式与范围

当前只接受严格的预转换JSON，不接受`.mid`、音频文件或任意二进制。手机界面文件上限256KiB，足以容纳正常格式的512事件曲谱；核心解析另有2MiB保护上限。转换继续使用原电脑端 `project/software/pc/pro_score.py import`。示例在 `app/src/main/assets/sample.score.json`，同时随交付包提供。

顶层字段必须且仅有 `schema`（1）、`sample_hz`（48000）、`score_id`（无符号32位整数）、`events`（1..512个原始事件）。每事件必须且仅有 `tick`、`type`、`channel`、`note`、`velocity`；时间单调不减，同tick保留输入顺序，完整note_on/note_off配对，不允许重叠相同channel/note身份。手机预先拒绝生产范围外note36..84、tick>16777215，最多约349.525秒。512是原始事件数，不是512个完整音符；每个普通音符至少需要On/Off两个事件。原音频四声部、显示八槽的限制保持。

## 构建与验证

固定已有本机工具：JDK17、Gradle8.9、AGP8.7.3、Android SDK35、Build Tools34.0.0，无AndroidX或第三方运行时库。`build_android.ps1 -Offline`执行本地release构建、lint、APK签名校验及编译manifest直接解析；输出放全新evidence子目录。缺依赖时不跳过验证，需要按官方源补件。本地开发证书放signing，不在交付包中分发私钥；非正式商店签名。本机JDK Socket启动使用仅限子进程的短临时目录，未更改全局系统设置。已交付APK沿用真实R04构建／lint／签名通过原件；旧badging的系统图标解析失败由METADATA_REVIEW_R01在同一APK上直接核清单和实际SDK常量后完成复核，没有重跑构建或改写旧FAIL。

普通软件自审由总控和实现窗口／子智能体完成，没有启动外部审核员制度。已执行的实际命令、退出码、正负用例、首失败和修复依据以最终HANDOFF与原始evidence为准。APK编译、lint和假Transport测试均不表示已在手机上安装或完成真实BLE／UART／板卡验证；FPGA上板准入不因安卓APK改变。

## 实现依据

- 严格协议与曲谱格式：同一basic内封存的 `project/software/pc/protocol.py`、`score.py`、`client.py`、`ble_transport.py`。
- [Android官方蓝牙权限](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)：按系统版本分别处理扫描与连接运行时权限。
- [Android官方BLE数据传输](https://developer.android.com/develop/connectivity/bluetooth/ble/transfer-ble-data)：发现服务、订阅通知并等待异步操作回调。
- [Android官方窗口边界处理](https://developer.android.com/develop/ui/views/layout/edge-to-edge)：target35处理系统栏／刘海遮挡。
- [AGP8.7官方兼容矩阵](https://developer.android.com/build/releases/agp-8-7-0-release-notes)：API35／Gradle8.9／JDK17／Build Tools34.0.0。
